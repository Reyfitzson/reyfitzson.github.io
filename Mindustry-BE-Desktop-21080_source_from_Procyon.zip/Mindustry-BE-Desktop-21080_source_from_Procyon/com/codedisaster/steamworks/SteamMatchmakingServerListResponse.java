// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public abstract class SteamMatchmakingServerListResponse extends SteamInterface
{
    protected SteamMatchmakingServerListResponse() {
        super(-1L);
        this.callback = createProxy(this);
    }
    
    public abstract void serverResponded(final SteamServerListRequest p0, final int p1);
    
    void serverResponded(final long request, final int server) {
        this.serverResponded(new SteamServerListRequest(request), server);
    }
    
    public abstract void serverFailedToRespond(final SteamServerListRequest p0, final int p1);
    
    void serverFailedToRespond(final long request, final int server) {
        this.serverFailedToRespond(new SteamServerListRequest(request), server);
    }
    
    public abstract void refreshComplete(final SteamServerListRequest p0, final Response p1);
    
    void refreshComplete(final long request, final int response) {
        this.refreshComplete(new SteamServerListRequest(request), Response.byOrdinal(response));
    }
    
    private static native long createProxy(final SteamMatchmakingServerListResponse p0);
    
    public enum Response
    {
        ServerResponded, 
        ServerFailedToRespond, 
        NoServersListedOnMasterServer;
        
        private static final Response[] values;
        
        static Response byOrdinal(final int ordinal) {
            return Response.values[ordinal];
        }
        
        static {
            values = values();
        }
    }
}
