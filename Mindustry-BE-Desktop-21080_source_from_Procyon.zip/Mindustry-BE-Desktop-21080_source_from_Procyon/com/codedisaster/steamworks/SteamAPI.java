// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

import java.io.PrintStream;

public class SteamAPI
{
    private static boolean isRunning;
    private static boolean isNativeAPILoaded;
    
    public static void loadLibraries() throws SteamException {
        if (SteamAPI.isNativeAPILoaded) {
            return;
        }
        SteamSharedLibraryLoader.loadLibrary("steam_api");
        SteamSharedLibraryLoader.loadLibrary("steamworks4j");
        SteamAPI.isNativeAPILoaded = true;
    }
    
    public static void skipLoadLibraries() {
        SteamAPI.isNativeAPILoaded = true;
    }
    
    public static boolean restartAppIfNecessary(final int appId) throws SteamException {
        if (!SteamAPI.isNativeAPILoaded) {
            throw new SteamException("Native libraries not loaded.\nEnsure to call SteamAPI.loadLibraries() first!");
        }
        return nativeRestartAppIfNecessary(appId);
    }
    
    public static boolean init() throws SteamException {
        if (!SteamAPI.isNativeAPILoaded) {
            throw new SteamException("Native libraries not loaded.\nEnsure to call SteamAPI.loadLibraries() first!");
        }
        return SteamAPI.isRunning = nativeInit();
    }
    
    public static void shutdown() {
        SteamAPI.isRunning = false;
        nativeShutdown();
    }
    
    public static boolean isSteamRunning() {
        return isSteamRunning(false);
    }
    
    public static boolean isSteamRunning(final boolean checkNative) {
        return SteamAPI.isRunning && (!checkNative || isSteamRunningNative());
    }
    
    public static void printDebugInfo(final PrintStream stream) {
        stream.println("  Steam API initialized: " + SteamAPI.isRunning);
        stream.println("  Steam client active: " + isSteamRunning());
    }
    
    static boolean isIsNativeAPILoaded() {
        return SteamAPI.isNativeAPILoaded;
    }
    
    private static native boolean nativeRestartAppIfNecessary(final int p0);
    
    public static native void releaseCurrentThreadMemory();
    
    private static native boolean nativeInit();
    
    private static native void nativeShutdown();
    
    public static native void runCallbacks();
    
    private static native boolean isSteamRunningNative();
    
    static native long getSteamAppsPointer();
    
    static native long getSteamControllerPointer();
    
    static native long getSteamFriendsPointer();
    
    static native long getSteamHTTPPointer();
    
    static native long getSteamMatchmakingPointer();
    
    static native long getSteamMatchmakingServersPointer();
    
    static native long getSteamNetworkingPointer();
    
    static native long getSteamRemoteStoragePointer();
    
    static native long getSteamScreenshotsPointer();
    
    static native long getSteamUGCPointer();
    
    static native long getSteamUserPointer();
    
    static native long getSteamUserStatsPointer();
    
    static native long getSteamUtilsPointer();
    
    static {
        SteamAPI.isRunning = false;
        SteamAPI.isNativeAPILoaded = false;
    }
}
