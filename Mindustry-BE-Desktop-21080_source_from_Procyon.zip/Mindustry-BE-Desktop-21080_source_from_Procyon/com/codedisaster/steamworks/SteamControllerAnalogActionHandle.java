// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public class SteamControllerAnalogActionHandle extends SteamNativeHandle
{
    SteamControllerAnalogActionHandle(final long handle) {
        super(handle);
    }
}
