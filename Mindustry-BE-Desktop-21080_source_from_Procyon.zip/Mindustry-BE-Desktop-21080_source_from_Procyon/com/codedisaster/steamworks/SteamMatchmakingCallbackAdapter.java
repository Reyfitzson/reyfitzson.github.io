// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

class SteamMatchmakingCallbackAdapter extends SteamCallbackAdapter<SteamMatchmakingCallback>
{
    private static final SteamMatchmaking.ChatMemberStateChange[] stateChangeValues;
    
    SteamMatchmakingCallbackAdapter(final SteamMatchmakingCallback callback) {
        super(callback);
    }
    
    void onFavoritesListChanged(final int ip, final int queryPort, final int connPort, final int appID, final int flags, final boolean add, final int accountID) {
        ((SteamMatchmakingCallback)this.callback).onFavoritesListChanged(ip, queryPort, connPort, appID, flags, add, accountID);
    }
    
    void onLobbyInvite(final long steamIDUser, final long steamIDLobby, final long gameID) {
        ((SteamMatchmakingCallback)this.callback).onLobbyInvite(new SteamID(steamIDUser), new SteamID(steamIDLobby), gameID);
    }
    
    void onLobbyEnter(final long steamIDLobby, final int chatPermissions, final boolean blocked, final int response) {
        ((SteamMatchmakingCallback)this.callback).onLobbyEnter(new SteamID(steamIDLobby), chatPermissions, blocked, SteamMatchmaking.ChatRoomEnterResponse.byValue(response));
    }
    
    void onLobbyDataUpdate(final long steamIDLobby, final long steamIDMember, final boolean success) {
        ((SteamMatchmakingCallback)this.callback).onLobbyDataUpdate(new SteamID(steamIDLobby), new SteamID(steamIDMember), success);
    }
    
    void onLobbyChatUpdate(final long steamIDLobby, final long steamIDUserChanged, final long steamIDMakingChange, final int stateChange) {
        final SteamID lobby = new SteamID(steamIDLobby);
        final SteamID userChanged = new SteamID(steamIDUserChanged);
        final SteamID makingChange = new SteamID(steamIDMakingChange);
        for (final SteamMatchmaking.ChatMemberStateChange value : SteamMatchmakingCallbackAdapter.stateChangeValues) {
            if (SteamMatchmaking.ChatMemberStateChange.isSet(value, stateChange)) {
                ((SteamMatchmakingCallback)this.callback).onLobbyChatUpdate(lobby, userChanged, makingChange, value);
            }
        }
    }
    
    void onLobbyChatMessage(final long steamIDLobby, final long steamIDUser, final int entryType, final int chatID) {
        ((SteamMatchmakingCallback)this.callback).onLobbyChatMessage(new SteamID(steamIDLobby), new SteamID(steamIDUser), SteamMatchmaking.ChatEntryType.byValue(entryType), chatID);
    }
    
    void onLobbyGameCreated(final long steamIDLobby, final long steamIDGameServer, final int ip, final short port) {
        ((SteamMatchmakingCallback)this.callback).onLobbyGameCreated(new SteamID(steamIDLobby), new SteamID(steamIDGameServer), ip, port);
    }
    
    void onLobbyMatchList(final int lobbiesMatching) {
        ((SteamMatchmakingCallback)this.callback).onLobbyMatchList(lobbiesMatching);
    }
    
    void onLobbyKicked(final long steamIDLobby, final long steamIDAdmin, final boolean kickedDueToDisconnect) {
        ((SteamMatchmakingCallback)this.callback).onLobbyKicked(new SteamID(steamIDLobby), new SteamID(steamIDAdmin), kickedDueToDisconnect);
    }
    
    void onLobbyCreated(final int result, final long steamIDLobby) {
        ((SteamMatchmakingCallback)this.callback).onLobbyCreated(SteamResult.byValue(result), new SteamID(steamIDLobby));
    }
    
    void onFavoritesListAccountsUpdated(final int result) {
        ((SteamMatchmakingCallback)this.callback).onFavoritesListAccountsUpdated(SteamResult.byValue(result));
    }
    
    static {
        stateChangeValues = SteamMatchmaking.ChatMemberStateChange.values();
    }
}
