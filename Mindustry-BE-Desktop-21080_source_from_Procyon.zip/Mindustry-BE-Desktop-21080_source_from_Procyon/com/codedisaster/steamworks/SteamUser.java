// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

import java.nio.ByteBuffer;

public class SteamUser extends SteamInterface
{
    public SteamUser(final SteamUserCallback callback) {
        super(SteamAPI.getSteamUserPointer(), createCallback(new SteamUserCallbackAdapter(callback)));
    }
    
    public SteamID getSteamID() {
        return new SteamID(getSteamID(this.pointer));
    }
    
    public int initiateGameConnection(final ByteBuffer authBlob, final SteamID steamIDGameServer, final int serverIP, final short serverPort, final boolean secure) throws SteamException {
        if (!authBlob.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        final int bytesWritten = initiateGameConnection(this.pointer, authBlob, authBlob.position(), authBlob.remaining(), steamIDGameServer.handle, serverIP, serverPort, secure);
        if (bytesWritten > 0) {
            authBlob.limit(bytesWritten);
        }
        return bytesWritten;
    }
    
    public void terminateGameConnection(final int serverIP, final short serverPort) {
        terminateGameConnection(this.pointer, serverIP, serverPort);
    }
    
    public void startVoiceRecording() {
        startVoiceRecording(this.pointer);
    }
    
    public void stopVoiceRecording() {
        stopVoiceRecording(this.pointer);
    }
    
    public VoiceResult getAvailableVoice(final int[] bytesAvailable) {
        final int result = getAvailableVoice(this.pointer, bytesAvailable);
        return VoiceResult.byOrdinal(result);
    }
    
    public VoiceResult getVoice(final ByteBuffer voiceData, final int[] bytesWritten) throws SteamException {
        if (!voiceData.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        final int result = getVoice(this.pointer, voiceData, voiceData.position(), voiceData.remaining(), bytesWritten);
        return VoiceResult.byOrdinal(result);
    }
    
    public VoiceResult decompressVoice(final ByteBuffer voiceData, final ByteBuffer audioData, final int[] bytesWritten, final int desiredSampleRate) throws SteamException {
        if (!voiceData.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        if (!audioData.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        final int result = decompressVoice(this.pointer, voiceData, voiceData.position(), voiceData.remaining(), audioData, audioData.position(), audioData.remaining(), bytesWritten, desiredSampleRate);
        return VoiceResult.byOrdinal(result);
    }
    
    public int getVoiceOptimalSampleRate() {
        return getVoiceOptimalSampleRate(this.pointer);
    }
    
    public SteamAuthTicket getAuthSessionTicket(final ByteBuffer authTicket, final int[] sizeInBytes) throws SteamException {
        if (!authTicket.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        final int ticket = getAuthSessionTicket(this.pointer, authTicket, authTicket.position(), authTicket.remaining(), sizeInBytes);
        if (ticket != 0L) {
            authTicket.limit(sizeInBytes[0]);
        }
        return new SteamAuthTicket(ticket);
    }
    
    public SteamAuth.BeginAuthSessionResult beginAuthSession(final ByteBuffer authTicket, final SteamID steamID) throws SteamException {
        if (!authTicket.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        final int result = beginAuthSession(this.pointer, authTicket, authTicket.position(), authTicket.remaining(), steamID.handle);
        return SteamAuth.BeginAuthSessionResult.byOrdinal(result);
    }
    
    public void endAuthSession(final SteamID steamID) {
        endAuthSession(this.pointer, steamID.handle);
    }
    
    public void cancelAuthTicket(final SteamAuthTicket authTicket) {
        cancelAuthTicket(this.pointer, (int)authTicket.handle);
    }
    
    public SteamAuth.UserHasLicenseForAppResult userHasLicenseForApp(final SteamID steamID, final int appID) {
        return SteamAuth.UserHasLicenseForAppResult.byOrdinal(userHasLicenseForApp(this.pointer, steamID.handle, appID));
    }
    
    public SteamAPICall requestEncryptedAppTicket(final ByteBuffer dataToInclude) throws SteamException {
        if (!dataToInclude.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        return new SteamAPICall(requestEncryptedAppTicket(this.pointer, this.callback, dataToInclude, dataToInclude.position(), dataToInclude.remaining()));
    }
    
    public boolean getEncryptedAppTicket(final ByteBuffer ticket, final int[] sizeInBytes) throws SteamException {
        if (!ticket.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        return getEncryptedAppTicket(this.pointer, ticket, ticket.position(), ticket.remaining(), sizeInBytes);
    }
    
    public boolean isBehindNAT() {
        return isBehindNAT(this.pointer);
    }
    
    public void advertiseGame(final SteamID steamIDGameServer, final int serverIP, final short serverPort) {
        advertiseGame(this.pointer, steamIDGameServer.handle, serverIP, serverPort);
    }
    
    private static native long createCallback(final SteamUserCallbackAdapter p0);
    
    private static native long getSteamID(final long p0);
    
    private static native int initiateGameConnection(final long p0, final ByteBuffer p1, final int p2, final int p3, final long p4, final int p5, final short p6, final boolean p7);
    
    private static native void terminateGameConnection(final long p0, final int p1, final short p2);
    
    private static native void startVoiceRecording(final long p0);
    
    private static native void stopVoiceRecording(final long p0);
    
    private static native int getAvailableVoice(final long p0, final int[] p1);
    
    private static native int getVoice(final long p0, final ByteBuffer p1, final int p2, final int p3, final int[] p4);
    
    private static native int decompressVoice(final long p0, final ByteBuffer p1, final int p2, final int p3, final ByteBuffer p4, final int p5, final int p6, final int[] p7, final int p8);
    
    private static native int getVoiceOptimalSampleRate(final long p0);
    
    private static native int getAuthSessionTicket(final long p0, final ByteBuffer p1, final int p2, final int p3, final int[] p4);
    
    private static native int beginAuthSession(final long p0, final ByteBuffer p1, final int p2, final int p3, final long p4);
    
    private static native void endAuthSession(final long p0, final long p1);
    
    private static native void cancelAuthTicket(final long p0, final int p1);
    
    private static native int userHasLicenseForApp(final long p0, final long p1, final int p2);
    
    private static native long requestEncryptedAppTicket(final long p0, final long p1, final ByteBuffer p2, final int p3, final int p4);
    
    private static native boolean getEncryptedAppTicket(final long p0, final ByteBuffer p1, final int p2, final int p3, final int[] p4);
    
    private static native boolean isBehindNAT(final long p0);
    
    private static native void advertiseGame(final long p0, final long p1, final int p2, final short p3);
    
    public enum VoiceResult
    {
        OK, 
        NotInitialized, 
        NotRecording, 
        NoData, 
        BufferTooSmall, 
        DataCorrupted, 
        Restricted, 
        UnsupportedCodec, 
        ReceiverOutOfDate, 
        ReceiverDidNotAnswer;
        
        private static final VoiceResult[] values;
        
        static VoiceResult byOrdinal(final int voiceResult) {
            return VoiceResult.values[voiceResult];
        }
        
        static {
            values = values();
        }
    }
}
