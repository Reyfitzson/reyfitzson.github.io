// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public class SteamControllerDigitalActionHandle extends SteamNativeHandle
{
    SteamControllerDigitalActionHandle(final long handle) {
        super(handle);
    }
}
