// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public enum SteamUniverse
{
    Invalid(0), 
    Public(1), 
    Beta(2), 
    Internal(3), 
    Dev(4);
    
    private final int value;
    private static final SteamUniverse[] values;
    
    private SteamUniverse(final int value) {
        this.value = value;
    }
    
    static SteamUniverse byValue(final int value) {
        for (final SteamUniverse type : SteamUniverse.values) {
            if (type.value == value) {
                return type;
            }
        }
        return SteamUniverse.Invalid;
    }
    
    static {
        values = values();
    }
}
