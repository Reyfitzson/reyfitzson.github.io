// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public class SteamControllerDigitalActionData
{
    boolean state;
    boolean active;
    
    public boolean getState() {
        return this.state;
    }
    
    public boolean getActive() {
        return this.active;
    }
}
