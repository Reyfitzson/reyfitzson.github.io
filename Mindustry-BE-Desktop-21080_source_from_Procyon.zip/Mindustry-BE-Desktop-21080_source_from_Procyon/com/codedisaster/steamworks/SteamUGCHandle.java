// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public class SteamUGCHandle extends SteamNativeHandle
{
    public SteamUGCHandle(final long handle) {
        super(handle);
    }
}
