// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public class SteamMatchmakingServerNetAdr
{
    short connectionPort;
    short queryPort;
    int ip;
    
    SteamMatchmakingServerNetAdr() {
    }
    
    public SteamMatchmakingServerNetAdr(final int ip, final short queryPort, final short connectionPort) {
        this.ip = ip;
        this.queryPort = queryPort;
        this.connectionPort = connectionPort;
    }
    
    public short getConnectionPort() {
        return this.connectionPort;
    }
    
    public short getQueryPort() {
        return this.queryPort;
    }
    
    public int getIP() {
        return this.ip;
    }
    
    public String getConnectionAddressString() {
        return toString(this.ip, this.connectionPort);
    }
    
    public String getQueryAddressString() {
        return toString(this.ip, this.queryPort);
    }
    
    private static String toString(final int ip, final short port) {
        return String.format("%d.%d.%d.%d:%d", ip >> 24 & 0xFF, ip >> 16 & 0xFF, ip >> 8 & 0xFF, ip & 0xFF, port);
    }
}
