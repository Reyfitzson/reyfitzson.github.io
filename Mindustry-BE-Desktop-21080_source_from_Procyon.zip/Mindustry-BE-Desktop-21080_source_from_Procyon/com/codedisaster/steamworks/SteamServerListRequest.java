// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public class SteamServerListRequest extends SteamNativeHandle
{
    SteamServerListRequest(final long handle) {
        super(handle);
    }
    
    public boolean isValid() {
        return this.handle != 0L;
    }
}
