// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

import java.util.Iterator;
import java.util.Collection;

public class SteamFriends extends SteamInterface
{
    public SteamFriends(final SteamFriendsCallback callback) {
        super(SteamAPI.getSteamFriendsPointer(), createCallback(new SteamFriendsCallbackAdapter(callback)));
    }
    
    public String getPersonaName() {
        return getPersonaName(this.pointer);
    }
    
    public SteamAPICall setPersonaName(final String personaName) {
        return new SteamAPICall(setPersonaName(this.pointer, this.callback, personaName));
    }
    
    public PersonaState getPersonaState() {
        return PersonaState.byOrdinal(getPersonaState(this.pointer));
    }
    
    public int getFriendCount(final FriendFlags friendFlag) {
        return getFriendCount(this.pointer, friendFlag.bits);
    }
    
    public int getFriendCount(final Collection<FriendFlags> friendFlags) {
        return getFriendCount(this.pointer, FriendFlags.asBits(friendFlags));
    }
    
    public SteamID getFriendByIndex(final int friend, final FriendFlags friendFlag) {
        return new SteamID(getFriendByIndex(this.pointer, friend, friendFlag.bits));
    }
    
    public SteamID getFriendByIndex(final int friend, final Collection<FriendFlags> friendFlags) {
        return new SteamID(getFriendByIndex(this.pointer, friend, FriendFlags.asBits(friendFlags)));
    }
    
    public FriendRelationship getFriendRelationship(final SteamID steamIDFriend) {
        return FriendRelationship.byOrdinal(getFriendRelationship(this.pointer, steamIDFriend.handle));
    }
    
    public PersonaState getFriendPersonaState(final SteamID steamIDFriend) {
        return PersonaState.byOrdinal(getFriendPersonaState(this.pointer, steamIDFriend.handle));
    }
    
    public String getFriendPersonaName(final SteamID steamIDFriend) {
        return getFriendPersonaName(this.pointer, steamIDFriend.handle);
    }
    
    public boolean getFriendGamePlayed(final SteamID steamIDFriend, final FriendGameInfo friendGameInfo) {
        return getFriendGamePlayed(this.pointer, steamIDFriend.handle, friendGameInfo);
    }
    
    public void setInGameVoiceSpeaking(final SteamID steamID, final boolean speaking) {
        setInGameVoiceSpeaking(this.pointer, steamID.handle, speaking);
    }
    
    public int getSmallFriendAvatar(final SteamID steamID) {
        return getSmallFriendAvatar(this.pointer, steamID.handle);
    }
    
    public int getMediumFriendAvatar(final SteamID steamID) {
        return getMediumFriendAvatar(this.pointer, steamID.handle);
    }
    
    public int getLargeFriendAvatar(final SteamID steamID) {
        return getLargeFriendAvatar(this.pointer, steamID.handle);
    }
    
    public boolean requestUserInformation(final SteamID steamID, final boolean requireNameOnly) {
        return requestUserInformation(this.pointer, steamID.handle, requireNameOnly);
    }
    
    public void activateGameOverlay(final OverlayDialog dialog) {
        activateGameOverlay(this.pointer, dialog.id);
    }
    
    public void activateGameOverlayToUser(final OverlayToUserDialog dialog, final SteamID steamID) {
        activateGameOverlayToUser(this.pointer, dialog.id, steamID.handle);
    }
    
    public void activateGameOverlayToWebPage(final String url) {
        activateGameOverlayToWebPage(this.pointer, url);
    }
    
    public void activateGameOverlayToStore(final int appID, final OverlayToStoreFlag flag) {
        activateGameOverlayToStore(this.pointer, appID, flag.ordinal());
    }
    
    public void activateGameOverlayInviteDialog(final SteamID steamIDLobby) {
        activateGameOverlayInviteDialog(this.pointer, steamIDLobby.handle);
    }
    
    public boolean setRichPresence(final String key, final String value) {
        return setRichPresence(this.pointer, key, (value != null) ? value : "");
    }
    
    public void clearRichPresence() {
        clearRichPresence(this.pointer);
    }
    
    public String getFriendRichPresence(final SteamID steamIDFriend, final String key) {
        return getFriendRichPresence(this.pointer, steamIDFriend.handle, key);
    }
    
    public int getFriendRichPresenceKeyCount(final SteamID steamIDFriend) {
        return getFriendRichPresenceKeyCount(this.pointer, steamIDFriend.handle);
    }
    
    public String getFriendRichPresenceKeyByIndex(final SteamID steamIDFriend, final int index) {
        return getFriendRichPresenceKeyByIndex(this.pointer, steamIDFriend.handle, index);
    }
    
    public void requestFriendRichPresence(final SteamID steamIDFriend) {
        requestFriendRichPresence(this.pointer, steamIDFriend.handle);
    }
    
    public boolean inviteUserToGame(final SteamID steamIDFriend, final String connectString) {
        return inviteUserToGame(this.pointer, steamIDFriend.handle, connectString);
    }
    
    private static native long createCallback(final SteamFriendsCallbackAdapter p0);
    
    private static native String getPersonaName(final long p0);
    
    private static native long setPersonaName(final long p0, final long p1, final String p2);
    
    private static native int getPersonaState(final long p0);
    
    private static native int getFriendCount(final long p0, final int p1);
    
    private static native long getFriendByIndex(final long p0, final int p1, final int p2);
    
    private static native int getFriendRelationship(final long p0, final long p1);
    
    private static native int getFriendPersonaState(final long p0, final long p1);
    
    private static native String getFriendPersonaName(final long p0, final long p1);
    
    private static native boolean getFriendGamePlayed(final long p0, final long p1, final FriendGameInfo p2);
    
    private static native void setInGameVoiceSpeaking(final long p0, final long p1, final boolean p2);
    
    private static native int getSmallFriendAvatar(final long p0, final long p1);
    
    private static native int getMediumFriendAvatar(final long p0, final long p1);
    
    private static native int getLargeFriendAvatar(final long p0, final long p1);
    
    private static native boolean requestUserInformation(final long p0, final long p1, final boolean p2);
    
    private static native void activateGameOverlay(final long p0, final String p1);
    
    private static native void activateGameOverlayToUser(final long p0, final String p1, final long p2);
    
    private static native void activateGameOverlayToWebPage(final long p0, final String p1);
    
    private static native void activateGameOverlayToStore(final long p0, final int p1, final int p2);
    
    private static native void activateGameOverlayInviteDialog(final long p0, final long p1);
    
    private static native boolean setRichPresence(final long p0, final String p1, final String p2);
    
    private static native void clearRichPresence(final long p0);
    
    private static native String getFriendRichPresence(final long p0, final long p1, final String p2);
    
    private static native int getFriendRichPresenceKeyCount(final long p0, final long p1);
    
    private static native String getFriendRichPresenceKeyByIndex(final long p0, final long p1, final int p2);
    
    private static native void requestFriendRichPresence(final long p0, final long p1);
    
    private static native boolean inviteUserToGame(final long p0, final long p1, final String p2);
    
    public enum FriendRelationship
    {
        None, 
        Blocked, 
        Recipient, 
        Friend, 
        RequestInitiator, 
        Ignored, 
        IgnoredFriend, 
        Suggested_DEPRECATED, 
        Max;
        
        private static final FriendRelationship[] values;
        
        static FriendRelationship byOrdinal(final int friendRelationship) {
            return FriendRelationship.values[friendRelationship];
        }
        
        static {
            values = values();
        }
    }
    
    public enum PersonaState
    {
        Offline, 
        Online, 
        Busy, 
        Away, 
        Snooze, 
        LookingToTrade, 
        LookingToPlay;
        
        private static final PersonaState[] values;
        
        static PersonaState byOrdinal(final int personaState) {
            return PersonaState.values[personaState];
        }
        
        static {
            values = values();
        }
    }
    
    public enum FriendFlags
    {
        None(0), 
        Blocked(1), 
        FriendshipRequested(2), 
        Immediate(4), 
        ClanMember(8), 
        OnGameServer(16), 
        RequestingFriendship(128), 
        RequestingInfo(256), 
        Ignored(512), 
        IgnoredFriend(1024), 
        ChatMember(4096), 
        All(65535);
        
        private final int bits;
        
        private FriendFlags(final int bits) {
            this.bits = bits;
        }
        
        static int asBits(final Collection<FriendFlags> friendFlags) {
            int bits = 0;
            for (final FriendFlags flags : friendFlags) {
                bits |= flags.bits;
            }
            return bits;
        }
    }
    
    public enum PersonaChange
    {
        Name(1), 
        Status(2), 
        ComeOnline(4), 
        GoneOffline(8), 
        GamePlayed(16), 
        GameServer(32), 
        Avatar(64), 
        JoinedSource(128), 
        LeftSource(256), 
        RelationshipChanged(512), 
        NameFirstSet(1024), 
        FacebookInfo(2048), 
        Nickname(4096), 
        SteamLevel(8192);
        
        private final int bits;
        
        private PersonaChange(final int bits) {
            this.bits = bits;
        }
        
        static boolean isSet(final PersonaChange value, final int bitMask) {
            return (value.bits & bitMask) == value.bits;
        }
    }
    
    public static class FriendGameInfo
    {
        private long gameID;
        private int gameIP;
        private short gamePort;
        private short queryPort;
        private long steamIDLobby;
        
        public long getGameID() {
            return this.gameID;
        }
        
        public int getGameIP() {
            return this.gameIP;
        }
        
        public short getGamePort() {
            return this.gamePort;
        }
        
        public short getQueryPort() {
            return this.queryPort;
        }
        
        public SteamID getSteamIDLobby() {
            return new SteamID(this.steamIDLobby);
        }
    }
    
    public enum OverlayDialog
    {
        Friends("Friends"), 
        Community("Community"), 
        Players("Players"), 
        Settings("Settings"), 
        OfficialGameGroup("OfficialGameGroup"), 
        Stats("Stats"), 
        Achievements("Achievements");
        
        private final String id;
        
        private OverlayDialog(final String id) {
            this.id = id;
        }
    }
    
    public enum OverlayToUserDialog
    {
        SteamID("steamid"), 
        Chat("chat"), 
        JoinTrade("jointrade"), 
        Stats("stats"), 
        Achievements("achievements"), 
        FriendAdd("friendadd"), 
        FriendRemove("friendremove"), 
        FriendRequestAccept("friendrequestaccept"), 
        FriendRequestIgnore("friendrequestignore");
        
        private final String id;
        
        private OverlayToUserDialog(final String id) {
            this.id = id;
        }
    }
    
    public enum OverlayToStoreFlag
    {
        None, 
        AddToCart, 
        AddToCartAndShow;
    }
}
