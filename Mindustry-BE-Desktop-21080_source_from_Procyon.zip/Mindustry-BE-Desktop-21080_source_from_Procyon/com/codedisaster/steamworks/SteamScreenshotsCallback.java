// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public interface SteamScreenshotsCallback
{
    void onScreenshotReady(final SteamScreenshotHandle p0, final SteamResult p1);
    
    void onScreenshotRequested();
}
