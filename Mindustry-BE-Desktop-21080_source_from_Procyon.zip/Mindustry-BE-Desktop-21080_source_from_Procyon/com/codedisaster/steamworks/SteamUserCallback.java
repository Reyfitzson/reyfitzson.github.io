// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public interface SteamUserCallback
{
    void onValidateAuthTicket(final SteamID p0, final SteamAuth.AuthSessionResponse p1, final SteamID p2);
    
    void onMicroTxnAuthorization(final int p0, final long p1, final boolean p2);
    
    void onEncryptedAppTicket(final SteamResult p0);
}
