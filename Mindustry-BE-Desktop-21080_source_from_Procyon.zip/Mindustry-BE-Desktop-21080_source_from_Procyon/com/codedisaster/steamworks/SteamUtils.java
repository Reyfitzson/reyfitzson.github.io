// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

import java.nio.ByteBuffer;

public class SteamUtils extends SteamInterface
{
    private SteamUtilsCallbackAdapter callbackAdapter;
    
    public SteamUtils(final SteamUtilsCallback callback) {
        super(SteamAPI.getSteamUtilsPointer());
        this.callbackAdapter = new SteamUtilsCallbackAdapter(callback);
        this.setCallback(createCallback(this.callbackAdapter));
    }
    
    public int getSecondsSinceAppActive() {
        return getSecondsSinceAppActive(this.pointer);
    }
    
    public int getSecondsSinceComputerActive() {
        return getSecondsSinceComputerActive(this.pointer);
    }
    
    public SteamUniverse getConnectedUniverse() {
        return SteamUniverse.byValue(getConnectedUniverse(this.pointer));
    }
    
    public int getServerRealTime() {
        return getServerRealTime(this.pointer);
    }
    
    public int getImageWidth(final int image) {
        return getImageWidth(this.pointer, image);
    }
    
    public int getImageHeight(final int image) {
        return getImageHeight(this.pointer, image);
    }
    
    public boolean getImageSize(final int image, final int[] size) {
        return getImageSize(this.pointer, image, size);
    }
    
    public boolean getImageRGBA(final int image, final ByteBuffer dest) throws SteamException {
        if (!dest.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        return getImageRGBA(this.pointer, image, dest, dest.position(), dest.remaining());
    }
    
    public int getAppID() {
        return getAppID(this.pointer);
    }
    
    public void setOverlayNotificationPosition(final NotificationPosition position) {
        setOverlayNotificationPosition(this.pointer, position.ordinal());
    }
    
    public boolean isAPICallCompleted(final SteamAPICall handle, final boolean[] result) {
        return isAPICallCompleted(this.pointer, handle.handle, result);
    }
    
    public SteamAPICallFailure getAPICallFailureReason(final SteamAPICall handle) {
        return SteamAPICallFailure.byValue(getAPICallFailureReason(this.pointer, handle.handle));
    }
    
    public void setWarningMessageHook(final SteamAPIWarningMessageHook messageHook) {
        this.callbackAdapter.setWarningMessageHook(messageHook);
        enableWarningMessageHook(this.callback, messageHook != null);
    }
    
    public boolean isOverlayEnabled() {
        return isOverlayEnabled(this.pointer);
    }
    
    private static native long createCallback(final SteamUtilsCallbackAdapter p0);
    
    private static native int getSecondsSinceAppActive(final long p0);
    
    private static native int getSecondsSinceComputerActive(final long p0);
    
    private static native int getConnectedUniverse(final long p0);
    
    private static native int getServerRealTime(final long p0);
    
    private static native String getIPCountry(final long p0);
    
    private static native int getImageWidth(final long p0, final int p1);
    
    private static native int getImageHeight(final long p0, final int p1);
    
    private static native boolean getImageSize(final long p0, final int p1, final int[] p2);
    
    private static native boolean getImageRGBA(final long p0, final int p1, final ByteBuffer p2, final int p3, final int p4);
    
    private static native int getAppID(final long p0);
    
    private static native void setOverlayNotificationPosition(final long p0, final int p1);
    
    private static native boolean isAPICallCompleted(final long p0, final long p1, final boolean[] p2);
    
    private static native int getAPICallFailureReason(final long p0, final long p1);
    
    private static native void enableWarningMessageHook(final long p0, final boolean p1);
    
    private static native boolean isOverlayEnabled(final long p0);
    
    public enum SteamAPICallFailure
    {
        None(-1), 
        SteamGone(0), 
        NetworkFailure(1), 
        InvalidHandle(2), 
        MismatchedCallback(3);
        
        private final int code;
        private static final SteamAPICallFailure[] values;
        
        private SteamAPICallFailure(final int code) {
            this.code = code;
        }
        
        static SteamAPICallFailure byValue(final int code) {
            for (final SteamAPICallFailure value : SteamAPICallFailure.values) {
                if (value.code == code) {
                    return value;
                }
            }
            return SteamAPICallFailure.None;
        }
        
        static {
            values = values();
        }
    }
    
    public enum NotificationPosition
    {
        TopLeft, 
        TopRight, 
        BottomLeft, 
        BottomRight;
    }
}
