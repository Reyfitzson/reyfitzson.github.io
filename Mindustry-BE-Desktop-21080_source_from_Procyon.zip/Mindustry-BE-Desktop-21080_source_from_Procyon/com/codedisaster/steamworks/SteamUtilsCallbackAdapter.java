// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

class SteamUtilsCallbackAdapter extends SteamCallbackAdapter<SteamUtilsCallback>
{
    private SteamAPIWarningMessageHook messageHook;
    
    SteamUtilsCallbackAdapter(final SteamUtilsCallback callback) {
        super(callback);
    }
    
    void setWarningMessageHook(final SteamAPIWarningMessageHook messageHook) {
        this.messageHook = messageHook;
    }
    
    void onWarningMessage(final int severity, final String message) {
        if (this.messageHook != null) {
            this.messageHook.onWarningMessage(severity, message);
        }
    }
    
    void onSteamShutdown() {
        ((SteamUtilsCallback)this.callback).onSteamShutdown();
    }
}
