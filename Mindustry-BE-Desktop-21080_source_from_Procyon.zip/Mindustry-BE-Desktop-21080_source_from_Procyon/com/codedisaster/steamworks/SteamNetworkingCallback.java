// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public interface SteamNetworkingCallback
{
    void onP2PSessionConnectFail(final SteamID p0, final SteamNetworking.P2PSessionError p1);
    
    void onP2PSessionRequest(final SteamID p0);
}
