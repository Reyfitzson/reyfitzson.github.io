// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

import java.nio.ByteBuffer;

public class SteamRemoteStorage extends SteamInterface
{
    public SteamRemoteStorage(final SteamRemoteStorageCallback callback) {
        super(SteamAPI.getSteamRemoteStoragePointer(), createCallback(new SteamRemoteStorageCallbackAdapter(callback)));
    }
    
    public boolean fileWrite(final String file, final ByteBuffer data) throws SteamException {
        if (!data.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        return fileWrite(this.pointer, file, data, data.position(), data.remaining());
    }
    
    public boolean fileRead(final String file, final ByteBuffer buffer) throws SteamException {
        if (!buffer.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        return fileRead(this.pointer, file, buffer, buffer.position(), buffer.remaining());
    }
    
    public SteamAPICall fileWriteAsync(final String file, final ByteBuffer data) throws SteamException {
        if (!data.isDirect()) {
            throw new SteamException("Direct buffer required!");
        }
        return new SteamAPICall(fileWriteAsync(this.pointer, this.callback, file, data, data.position(), data.remaining()));
    }
    
    public SteamAPICall fileReadAsync(final String file, final int offset, final int toRead) {
        return new SteamAPICall(fileReadAsync(this.pointer, this.callback, file, offset, toRead));
    }
    
    public boolean fileReadAsyncComplete(final SteamAPICall readCall, final ByteBuffer buffer, final int toRead) {
        return fileReadAsyncComplete(this.pointer, readCall.handle, buffer, buffer.position(), toRead);
    }
    
    public boolean fileForget(final String file) {
        return fileForget(this.pointer, file);
    }
    
    public boolean fileDelete(final String file) {
        return fileDelete(this.pointer, file);
    }
    
    public SteamAPICall fileShare(final String file) {
        return new SteamAPICall(fileShare(this.pointer, this.callback, file));
    }
    
    public boolean setSyncPlatforms(final String file, final RemoteStoragePlatform remoteStoragePlatform) {
        return setSyncPlatforms(this.pointer, file, remoteStoragePlatform.mask);
    }
    
    public SteamUGCFileWriteStreamHandle fileWriteStreamOpen(final String name) {
        return new SteamUGCFileWriteStreamHandle(fileWriteStreamOpen(this.pointer, name));
    }
    
    public boolean fileWriteStreamWriteChunk(final SteamUGCFileWriteStreamHandle stream, final ByteBuffer data) {
        return fileWriteStreamWriteChunk(this.pointer, stream.handle, data, data.position(), data.remaining());
    }
    
    public boolean fileWriteStreamClose(final SteamUGCFileWriteStreamHandle stream) {
        return fileWriteStreamClose(this.pointer, stream.handle);
    }
    
    public boolean fileWriteStreamCancel(final SteamUGCFileWriteStreamHandle stream) {
        return fileWriteStreamCancel(this.pointer, stream.handle);
    }
    
    public boolean fileExists(final String file) {
        return fileExists(this.pointer, file);
    }
    
    public boolean filePersisted(final String file) {
        return filePersisted(this.pointer, file);
    }
    
    public int getFileSize(final String file) {
        return getFileSize(this.pointer, file);
    }
    
    public long getFileTimestamp(final String file) {
        return getFileTimestamp(this.pointer, file);
    }
    
    public RemoteStoragePlatform[] getSyncPlatforms(final String file) {
        final int mask = getSyncPlatforms(this.pointer, file);
        return RemoteStoragePlatform.byMask(mask);
    }
    
    public int getFileCount() {
        return getFileCount(this.pointer);
    }
    
    public String getFileNameAndSize(final int index, final int[] sizes) {
        return getFileNameAndSize(this.pointer, index, sizes);
    }
    
    public boolean getQuota(final long[] totalBytes, final long[] availableBytes) {
        return getQuota(this.pointer, totalBytes, availableBytes);
    }
    
    public boolean isCloudEnabledForAccount() {
        return isCloudEnabledForAccount(this.pointer);
    }
    
    public boolean isCloudEnabledForApp() {
        return isCloudEnabledForApp(this.pointer);
    }
    
    public void setCloudEnabledForApp(final boolean enabled) {
        setCloudEnabledForApp(this.pointer, enabled);
    }
    
    public SteamAPICall ugcDownload(final SteamUGCHandle fileHandle, final int priority) {
        return new SteamAPICall(ugcDownload(this.pointer, this.callback, fileHandle.handle, priority));
    }
    
    public boolean getUGCDownloadProgress(final SteamUGCHandle fileHandle, final int[] bytesDownloaded, final int[] bytesExpected) {
        return getUGCDownloadProgress(this.pointer, fileHandle.handle, bytesDownloaded, bytesExpected);
    }
    
    public int ugcRead(final SteamUGCHandle fileHandle, final ByteBuffer buffer, final int dataToRead, final int offset, final UGCReadAction action) {
        return ugcRead(this.pointer, fileHandle.handle, buffer, buffer.position(), dataToRead, offset, action.ordinal());
    }
    
    public int getCachedUGCCount() {
        return getCachedUGCCount(this.pointer);
    }
    
    public SteamUGCHandle getCachedUGCHandle(final int cachedContent) {
        return new SteamUGCHandle(getCachedUGCHandle(this.pointer, cachedContent));
    }
    
    public SteamAPICall publishWorkshopFile(final String file, final String previewFile, final int consumerAppID, final String title, final String description, final PublishedFileVisibility visibility, final String[] tags, final WorkshopFileType workshopFileType) {
        return new SteamAPICall(publishWorkshopFile(this.pointer, this.callback, file, previewFile, consumerAppID, title, description, visibility.ordinal(), tags, (tags != null) ? tags.length : 0, workshopFileType.ordinal()));
    }
    
    public SteamPublishedFileUpdateHandle createPublishedFileUpdateRequest(final SteamPublishedFileID publishedFileID) {
        return new SteamPublishedFileUpdateHandle(createPublishedFileUpdateRequest(this.pointer, publishedFileID.handle));
    }
    
    public boolean updatePublishedFileFile(final SteamPublishedFileUpdateHandle updateHandle, final String file) {
        return updatePublishedFileFile(this.pointer, updateHandle.handle, file);
    }
    
    public boolean updatePublishedFilePreviewFile(final SteamPublishedFileUpdateHandle updateHandle, final String previewFile) {
        return updatePublishedFilePreviewFile(this.pointer, updateHandle.handle, previewFile);
    }
    
    public boolean updatePublishedFileTitle(final SteamPublishedFileUpdateHandle updateHandle, final String title) {
        return updatePublishedFileTitle(this.pointer, updateHandle.handle, title);
    }
    
    public boolean updatePublishedFileDescription(final SteamPublishedFileUpdateHandle updateHandle, final String description) {
        return updatePublishedFileDescription(this.pointer, updateHandle.handle, description);
    }
    
    public boolean updatePublishedFileVisibility(final SteamPublishedFileUpdateHandle updateHandle, final PublishedFileVisibility visibility) {
        return updatePublishedFileVisibility(this.pointer, updateHandle.handle, visibility.ordinal());
    }
    
    public boolean updatePublishedFileTags(final SteamPublishedFileUpdateHandle updateHandle, final String[] tags) {
        return updatePublishedFileTags(this.pointer, updateHandle.handle, tags, (tags != null) ? tags.length : 0);
    }
    
    public SteamAPICall commitPublishedFileUpdate(final SteamPublishedFileUpdateHandle updateHandle) {
        return new SteamAPICall(commitPublishedFileUpdate(this.pointer, this.callback, updateHandle.handle));
    }
    
    private static native long createCallback(final SteamRemoteStorageCallbackAdapter p0);
    
    private static native boolean fileWrite(final long p0, final String p1, final ByteBuffer p2, final int p3, final int p4);
    
    private static native boolean fileRead(final long p0, final String p1, final ByteBuffer p2, final int p3, final int p4);
    
    private static native long fileWriteAsync(final long p0, final long p1, final String p2, final ByteBuffer p3, final int p4, final int p5);
    
    private static native long fileReadAsync(final long p0, final long p1, final String p2, final int p3, final int p4);
    
    private static native boolean fileReadAsyncComplete(final long p0, final long p1, final ByteBuffer p2, final long p3, final int p4);
    
    private static native boolean fileForget(final long p0, final String p1);
    
    private static native boolean fileDelete(final long p0, final String p1);
    
    private static native long fileShare(final long p0, final long p1, final String p2);
    
    private static native boolean setSyncPlatforms(final long p0, final String p1, final int p2);
    
    private static native long fileWriteStreamOpen(final long p0, final String p1);
    
    private static native boolean fileWriteStreamWriteChunk(final long p0, final long p1, final ByteBuffer p2, final int p3, final int p4);
    
    private static native boolean fileWriteStreamClose(final long p0, final long p1);
    
    private static native boolean fileWriteStreamCancel(final long p0, final long p1);
    
    private static native boolean fileExists(final long p0, final String p1);
    
    private static native boolean filePersisted(final long p0, final String p1);
    
    private static native int getFileSize(final long p0, final String p1);
    
    private static native long getFileTimestamp(final long p0, final String p1);
    
    private static native int getSyncPlatforms(final long p0, final String p1);
    
    private static native int getFileCount(final long p0);
    
    private static native String getFileNameAndSize(final long p0, final int p1, final int[] p2);
    
    private static native boolean getQuota(final long p0, final long[] p1, final long[] p2);
    
    private static native boolean isCloudEnabledForAccount(final long p0);
    
    private static native boolean isCloudEnabledForApp(final long p0);
    
    private static native void setCloudEnabledForApp(final long p0, final boolean p1);
    
    private static native long ugcDownload(final long p0, final long p1, final long p2, final int p3);
    
    private static native boolean getUGCDownloadProgress(final long p0, final long p1, final int[] p2, final int[] p3);
    
    private static native int ugcRead(final long p0, final long p1, final ByteBuffer p2, final int p3, final int p4, final int p5, final int p6);
    
    private static native int getCachedUGCCount(final long p0);
    
    private static native long getCachedUGCHandle(final long p0, final int p1);
    
    private static native long publishWorkshopFile(final long p0, final long p1, final String p2, final String p3, final int p4, final String p5, final String p6, final int p7, final String[] p8, final int p9, final int p10);
    
    private static native long createPublishedFileUpdateRequest(final long p0, final long p1);
    
    private static native boolean updatePublishedFileFile(final long p0, final long p1, final String p2);
    
    private static native boolean updatePublishedFilePreviewFile(final long p0, final long p1, final String p2);
    
    private static native boolean updatePublishedFileTitle(final long p0, final long p1, final String p2);
    
    private static native boolean updatePublishedFileDescription(final long p0, final long p1, final String p2);
    
    private static native boolean updatePublishedFileVisibility(final long p0, final long p1, final int p2);
    
    private static native boolean updatePublishedFileTags(final long p0, final long p1, final String[] p2, final int p3);
    
    private static native long commitPublishedFileUpdate(final long p0, final long p1, final long p2);
    
    public enum RemoteStoragePlatform
    {
        None(0), 
        Windows(1), 
        OSX(2), 
        PS3(4), 
        Linux(8), 
        Reserved2(16), 
        All(-1);
        
        private final int mask;
        private static final RemoteStoragePlatform[] values;
        
        private RemoteStoragePlatform(final int mask) {
            this.mask = mask;
        }
        
        static RemoteStoragePlatform[] byMask(final int mask) {
            final int bits = Integer.bitCount(mask);
            final RemoteStoragePlatform[] result = new RemoteStoragePlatform[bits];
            int idx = 0;
            for (final RemoteStoragePlatform value : RemoteStoragePlatform.values) {
                if ((value.mask & mask) != 0x0) {
                    result[idx++] = value;
                }
            }
            return result;
        }
        
        static {
            values = values();
        }
    }
    
    public enum UGCReadAction
    {
        ContinueReadingUntilFinished, 
        ContinueReading, 
        Close;
    }
    
    public enum PublishedFileVisibility
    {
        Public, 
        FriendsOnly, 
        Private;
    }
    
    public enum WorkshopFileType
    {
        Community, 
        Microtransaction, 
        Collection, 
        Art, 
        Video, 
        Screenshot, 
        Game, 
        Software, 
        Concept, 
        WebGuide, 
        IntegratedGuide, 
        Merch, 
        ControllerBinding, 
        SteamworksAccessInvite, 
        SteamVideo, 
        GameManagedItem;
        
        private static final WorkshopFileType[] values;
        
        static WorkshopFileType byOrdinal(final int ordinal) {
            return WorkshopFileType.values[ordinal];
        }
        
        static {
            values = values();
        }
    }
}
