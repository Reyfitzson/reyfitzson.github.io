// 
// Decompiled by Procyon v0.5.36
// 

package com.codedisaster.steamworks;

public abstract class SteamNativeHandle
{
    long handle;
    
    SteamNativeHandle(final long handle) {
        this.handle = handle;
    }
    
    public static <T extends SteamNativeHandle> long getNativeHandle(final T handle) {
        return handle.handle;
    }
    
    public long handle() {
        return this.handle;
    }
    
    @Override
    public int hashCode() {
        return Long.valueOf(this.handle).hashCode();
    }
    
    @Override
    public boolean equals(final Object other) {
        return other instanceof SteamNativeHandle && this.handle == ((SteamNativeHandle)other).handle;
    }
    
    @Override
    public String toString() {
        return Long.toHexString(this.handle);
    }
}
