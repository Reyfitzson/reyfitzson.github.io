// 
// Decompiled by Procyon v0.5.36
// 

package arc.input;

import arc.struct.IntFloatMap;
import arc.struct.IntSet;

public class KeyboardDevice extends InputDevice implements InputProcessor
{
    private final IntSet pressed;
    private final IntSet lastFramePressed;
    private final IntFloatMap axes;
    
    public KeyboardDevice() {
        this.pressed = new IntSet();
        this.lastFramePressed = new IntSet();
        this.axes = new IntFloatMap();
    }
    
    @Override
    public void postUpdate() {
        this.lastFramePressed.clear();
        this.lastFramePressed.addAll(this.pressed);
        this.axes.clear();
    }
    
    @Override
    public boolean isPressed(final KeyCode key) {
        if (key == KeyCode.anyKey) {
            return this.pressed.size > 0;
        }
        return this.pressed.contains(key.ordinal());
    }
    
    @Override
    public boolean isTapped(final KeyCode key) {
        return this.isPressed(key) && !this.lastFramePressed.contains(key.ordinal());
    }
    
    @Override
    public boolean isReleased(final KeyCode key) {
        return !this.isPressed(key) && this.lastFramePressed.contains(key.ordinal());
    }
    
    @Override
    public float getAxis(final KeyCode keyCode) {
        return this.axes.get(keyCode.ordinal(), 0.0f);
    }
    
    @Override
    public boolean keyDown(final KeyCode key) {
        this.pressed.add(key.ordinal());
        return false;
    }
    
    @Override
    public boolean keyUp(final KeyCode key) {
        this.pressed.remove(key.ordinal());
        return false;
    }
    
    @Override
    public boolean touchDown(final int screenX, final int screenY, final int pointer, final KeyCode button) {
        this.keyDown(button);
        return false;
    }
    
    @Override
    public boolean touchUp(final int screenX, final int screenY, final int pointer, final KeyCode button) {
        if (pointer == 0) {
            this.keyUp(button);
        }
        return false;
    }
    
    @Override
    public boolean scrolled(final float amountX, final float amountY) {
        this.axes.put(KeyCode.scroll.ordinal(), -amountY);
        return false;
    }
    
    @Override
    public String name() {
        return "Keyboard";
    }
    
    @Override
    public DeviceType type() {
        return DeviceType.keyboard;
    }
}
