// 
// Decompiled by Procyon v0.5.36
// 

package arc.input;

import arc.math.geom.Vec3;

public abstract class Controller extends InputDevice
{
    public Vec3 accelerometer() {
        return Vec3.Zero;
    }
    
    public abstract int index();
    
    @Override
    public void postUpdate() {
    }
    
    @Override
    public DeviceType type() {
        return DeviceType.controller;
    }
}
