// 
// Decompiled by Procyon v0.5.36
// 

package arc.input;

public interface InputProcessor
{
    default void connected(final InputDevice device) {
    }
    
    default void disconnected(final InputDevice device) {
    }
    
    default boolean keyDown(final KeyCode keycode) {
        return false;
    }
    
    default boolean keyUp(final KeyCode keycode) {
        return false;
    }
    
    default boolean keyTyped(final char character) {
        return false;
    }
    
    default boolean touchDown(final int screenX, final int screenY, final int pointer, final KeyCode button) {
        return false;
    }
    
    default boolean touchUp(final int screenX, final int screenY, final int pointer, final KeyCode button) {
        return false;
    }
    
    default boolean touchDragged(final int screenX, final int screenY, final int pointer) {
        return false;
    }
    
    default boolean mouseMoved(final int screenX, final int screenY) {
        return false;
    }
    
    default boolean scrolled(final float amountX, final float amountY) {
        return false;
    }
}
