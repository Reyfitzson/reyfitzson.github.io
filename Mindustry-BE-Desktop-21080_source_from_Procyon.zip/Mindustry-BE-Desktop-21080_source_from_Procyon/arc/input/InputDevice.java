// 
// Decompiled by Procyon v0.5.36
// 

package arc.input;

public abstract class InputDevice
{
    public void postUpdate() {
    }
    
    public void preUpdate() {
    }
    
    public abstract String name();
    
    public abstract DeviceType type();
    
    public abstract boolean isPressed(final KeyCode p0);
    
    public abstract boolean isTapped(final KeyCode p0);
    
    public abstract boolean isReleased(final KeyCode p0);
    
    public abstract float getAxis(final KeyCode p0);
    
    public enum DeviceType
    {
        keyboard, 
        controller;
    }
}
