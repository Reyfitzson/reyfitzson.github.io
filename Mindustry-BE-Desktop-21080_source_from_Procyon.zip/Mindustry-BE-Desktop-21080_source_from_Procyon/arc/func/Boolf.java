// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Boolf<T>
{
    boolean get(final T p0);
}
