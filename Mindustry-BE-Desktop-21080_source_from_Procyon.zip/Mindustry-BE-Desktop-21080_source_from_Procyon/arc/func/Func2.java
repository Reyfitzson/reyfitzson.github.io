// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Func2<P1, P2, R>
{
    R get(final P1 p0, final P2 p1);
}
