// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Floatc2
{
    void get(final float p0, final float p1);
}
