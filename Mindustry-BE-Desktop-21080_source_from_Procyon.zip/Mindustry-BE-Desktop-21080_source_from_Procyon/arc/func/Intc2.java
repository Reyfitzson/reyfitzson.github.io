// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Intc2
{
    void get(final int p0, final int p1);
}
