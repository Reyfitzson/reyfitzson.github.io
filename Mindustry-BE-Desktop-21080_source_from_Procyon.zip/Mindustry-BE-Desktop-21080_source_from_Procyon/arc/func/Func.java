// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Func<P, R>
{
    R get(final P p0);
}
