// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Func3<P1, P2, P3, R>
{
    R get(final P1 p0, final P2 p1, final P3 p2);
}
