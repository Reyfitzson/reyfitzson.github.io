// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Intc4
{
    void get(final int p0, final int p1, final int p2, final int p3);
}
