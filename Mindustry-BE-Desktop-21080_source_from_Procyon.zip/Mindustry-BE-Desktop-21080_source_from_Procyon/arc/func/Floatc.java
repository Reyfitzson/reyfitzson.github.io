// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Floatc
{
    void get(final float p0);
}
