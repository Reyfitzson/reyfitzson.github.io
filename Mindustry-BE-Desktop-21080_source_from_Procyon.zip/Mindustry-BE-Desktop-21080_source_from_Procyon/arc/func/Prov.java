// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Prov<T>
{
    T get();
}
