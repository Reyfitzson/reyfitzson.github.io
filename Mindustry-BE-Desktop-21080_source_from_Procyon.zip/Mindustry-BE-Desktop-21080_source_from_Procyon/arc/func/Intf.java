// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Intf<T>
{
    int get(final T p0);
}
