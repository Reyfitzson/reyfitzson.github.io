// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Cons2<T, N>
{
    void get(final T p0, final N p1);
}
