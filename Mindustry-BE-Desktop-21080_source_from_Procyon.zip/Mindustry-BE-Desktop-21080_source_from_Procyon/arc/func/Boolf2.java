// 
// Decompiled by Procyon v0.5.36
// 

package arc.func;

public interface Boolf2<A, B>
{
    boolean get(final A p0, final B p1);
}
