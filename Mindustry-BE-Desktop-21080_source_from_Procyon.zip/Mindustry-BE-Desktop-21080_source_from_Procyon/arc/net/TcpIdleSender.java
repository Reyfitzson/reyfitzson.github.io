// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

public abstract class TcpIdleSender implements NetListener
{
    boolean started;
    
    @Override
    public void idle(final Connection connection) {
        if (!this.started) {
            this.started = true;
            this.start();
        }
        final Object object = this.next();
        if (object == null) {
            connection.removeListener(this);
        }
        else {
            connection.sendTCP(object);
        }
    }
    
    protected void start() {
    }
    
    protected abstract Object next();
}
