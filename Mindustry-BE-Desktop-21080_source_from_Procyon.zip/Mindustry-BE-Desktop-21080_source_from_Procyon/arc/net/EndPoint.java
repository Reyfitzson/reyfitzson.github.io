// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import java.io.IOException;

public interface EndPoint extends Runnable
{
    void addListener(final NetListener p0);
    
    void removeListener(final NetListener p0);
    
    void run();
    
    void start();
    
    void stop();
    
    void close();
    
    void update(final int p0) throws IOException;
    
    Thread getUpdateThread();
}
