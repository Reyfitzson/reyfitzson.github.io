// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import java.nio.ByteBuffer;

public interface NetSerializer
{
    void write(final ByteBuffer p0, final Object p1);
    
    Object read(final ByteBuffer p0);
    
    default int getLengthLength() {
        return 2;
    }
    
    default void writeLength(final ByteBuffer buffer, final int length) {
        buffer.putShort((short)length);
    }
    
    default int readLength(final ByteBuffer buffer) {
        return buffer.getShort();
    }
}
