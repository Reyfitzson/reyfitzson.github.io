// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import java.net.SocketException;
import java.net.SocketAddress;
import java.net.Socket;
import java.io.IOException;
import java.nio.channels.Selector;
import java.nio.channels.SelectionKey;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

class TcpConnection
{
    SocketChannel socketChannel;
    int keepAliveMillis;
    final ByteBuffer readBuffer;
    final ByteBuffer writeBuffer;
    boolean bufferPositionFix;
    int timeoutMillis;
    float idleThreshold;
    final NetSerializer serialization;
    private SelectionKey selectionKey;
    private volatile long lastWriteTime;
    private volatile long lastReadTime;
    private int currentObjectLength;
    private final Object writeLock;
    
    public TcpConnection(final NetSerializer serialization, final int writeBufferSize, final int objectBufferSize) {
        this.keepAliveMillis = 8000;
        this.timeoutMillis = 12000;
        this.idleThreshold = 0.1f;
        this.writeLock = new Object();
        this.serialization = serialization;
        this.writeBuffer = ByteBuffer.allocate(writeBufferSize);
        (this.readBuffer = ByteBuffer.allocate(objectBufferSize)).flip();
    }
    
    public SelectionKey accept(final Selector selector, final SocketChannel socketChannel) throws IOException {
        this.writeBuffer.clear();
        this.readBuffer.clear();
        this.readBuffer.flip();
        this.currentObjectLength = 0;
        try {
            (this.socketChannel = socketChannel).configureBlocking(false);
            final Socket socket = socketChannel.socket();
            socket.setTcpNoDelay(true);
            this.selectionKey = socketChannel.register(selector, 1);
            final long currentTimeMillis = System.currentTimeMillis();
            this.lastWriteTime = currentTimeMillis;
            this.lastReadTime = currentTimeMillis;
            return this.selectionKey;
        }
        catch (IOException ex) {
            this.close();
            throw ex;
        }
    }
    
    public void connect(final Selector selector, final SocketAddress remoteAddress, final int timeout) throws IOException {
        this.close();
        this.writeBuffer.clear();
        this.readBuffer.clear();
        this.readBuffer.flip();
        this.currentObjectLength = 0;
        try {
            final SocketChannel socketChannel = selector.provider().openSocketChannel();
            final Socket socket = socketChannel.socket();
            socket.setTcpNoDelay(true);
            socket.connect(remoteAddress, timeout);
            socketChannel.configureBlocking(false);
            this.socketChannel = socketChannel;
            (this.selectionKey = socketChannel.register(selector, 1)).attach(this);
            final long currentTimeMillis = System.currentTimeMillis();
            this.lastWriteTime = currentTimeMillis;
            this.lastReadTime = currentTimeMillis;
        }
        catch (IOException ex) {
            this.close();
            final IOException ioEx = new IOException("Unable to connect to: " + remoteAddress, ex);
            throw ioEx;
        }
    }
    
    public Object readObject() throws IOException {
        final SocketChannel socketChannel = this.socketChannel;
        if (socketChannel == null) {
            throw new SocketException("Connection is closed.");
        }
        if (this.currentObjectLength == 0) {
            final int lengthLength = this.serialization.getLengthLength();
            if (this.readBuffer.remaining() < lengthLength) {
                this.readBuffer.compact();
                final int bytesRead = socketChannel.read(this.readBuffer);
                this.readBuffer.flip();
                if (bytesRead == -1) {
                    throw new SocketException("Connection is closed.");
                }
                this.lastReadTime = System.currentTimeMillis();
                if (this.readBuffer.remaining() < lengthLength) {
                    return null;
                }
            }
            this.currentObjectLength = this.serialization.readLength(this.readBuffer);
            if (this.currentObjectLength <= 0) {
                throw new ArcNetException("Invalid object length: " + this.currentObjectLength);
            }
            if (this.currentObjectLength > this.readBuffer.capacity()) {
                throw new ArcNetException("Unable to read object larger than read buffer: " + this.currentObjectLength);
            }
        }
        final int length = this.currentObjectLength;
        if (this.readBuffer.remaining() < length) {
            this.readBuffer.compact();
            final int bytesRead = socketChannel.read(this.readBuffer);
            this.readBuffer.flip();
            if (bytesRead == -1) {
                throw new SocketException("Connection is closed.");
            }
            this.lastReadTime = System.currentTimeMillis();
            if (this.readBuffer.remaining() < length) {
                return null;
            }
        }
        this.currentObjectLength = 0;
        final int startPosition = this.readBuffer.position();
        final int oldLimit = this.readBuffer.limit();
        this.readBuffer.limit(startPosition + length);
        Object object;
        try {
            object = this.serialization.read(this.readBuffer);
        }
        catch (Exception ex) {
            throw new ArcNetException("Error during deserialization.", ex);
        }
        this.readBuffer.limit(oldLimit);
        if (this.readBuffer.position() - startPosition != length) {
            throw new ArcNetException("Incorrect number of bytes (" + (startPosition + length - this.readBuffer.position()) + " remaining) used to deserialize object: " + object);
        }
        return object;
    }
    
    public void writeOperation() throws IOException {
        synchronized (this.writeLock) {
            if (this.writeToSocket()) {
                this.selectionKey.interestOps(1);
            }
            this.lastWriteTime = System.currentTimeMillis();
        }
    }
    
    private boolean writeToSocket() throws IOException {
        final SocketChannel socketChannel = this.socketChannel;
        if (socketChannel == null) {
            throw new SocketException("Connection is closed.");
        }
        final ByteBuffer buffer = this.writeBuffer;
        buffer.flip();
        while (buffer.hasRemaining()) {
            if (this.bufferPositionFix) {
                buffer.compact();
                buffer.flip();
            }
            if (socketChannel.write(buffer) == 0) {
                break;
            }
        }
        buffer.compact();
        return buffer.position() == 0;
    }
    
    public int send(final Object object) throws IOException {
        final SocketChannel socketChannel = this.socketChannel;
        if (socketChannel == null) {
            throw new SocketException("Connection is closed.");
        }
        synchronized (this.writeLock) {
            final int start = this.writeBuffer.position();
            final int lengthLength = this.serialization.getLengthLength();
            try {
                this.writeBuffer.position(this.writeBuffer.position() + lengthLength);
                this.serialization.write(this.writeBuffer, object);
            }
            catch (Throwable ex) {
                throw new ArcNetException("Error serializing object of type: " + object.getClass().getName(), ex);
            }
            final int end = this.writeBuffer.position();
            this.writeBuffer.position(start);
            this.serialization.writeLength(this.writeBuffer, end - lengthLength - start);
            this.writeBuffer.position(end);
            if (start == 0 && !this.writeToSocket()) {
                this.selectionKey.interestOps(5);
            }
            else {
                this.selectionKey.selector().wakeup();
            }
            this.lastWriteTime = System.currentTimeMillis();
            return end - start;
        }
    }
    
    public void close() {
        try {
            if (this.socketChannel != null) {
                this.socketChannel.close();
                this.socketChannel = null;
                if (this.selectionKey != null) {
                    this.selectionKey.selector().wakeup();
                }
            }
        }
        catch (IOException ex) {}
    }
    
    public boolean needsKeepAlive(final long time) {
        return this.socketChannel != null && this.keepAliveMillis > 0 && time - this.lastWriteTime > this.keepAliveMillis;
    }
    
    public boolean isTimedOut(final long time) {
        return this.socketChannel != null && this.timeoutMillis > 0 && time - this.lastReadTime > this.timeoutMillis;
    }
}
