// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

public class ArcNetException extends RuntimeException
{
    public ArcNetException() {
    }
    
    public ArcNetException(final String message, final Throwable cause) {
        super(message, cause);
    }
    
    public ArcNetException(final String message) {
        super(message);
    }
    
    public ArcNetException(final Throwable cause) {
        super(cause);
    }
}
