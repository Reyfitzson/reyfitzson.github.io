// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import arc.func.Cons;

public class ArcNet
{
    public static Cons<Throwable> errorHandler;
    
    public static void handleError(final Throwable e) {
        ArcNet.errorHandler.get(e);
    }
    
    static {
        ArcNet.errorHandler = (e -> {});
    }
}
