// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

public interface FrameworkMessage
{
    public static final KeepAlive keepAlive = new KeepAlive();
    
    public static class RegisterTCP implements FrameworkMessage
    {
        public int connectionID;
    }
    
    public static class RegisterUDP implements FrameworkMessage
    {
        public int connectionID;
    }
    
    public static class KeepAlive implements FrameworkMessage
    {
    }
    
    public static class DiscoverHost implements FrameworkMessage
    {
    }
    
    public static class Ping implements FrameworkMessage
    {
        public int id;
        public boolean isReply;
    }
}
