// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import java.io.IOException;
import java.io.InputStream;

public abstract class InputStreamSender extends TcpIdleSender
{
    private final InputStream input;
    private final byte[] chunk;
    
    public InputStreamSender(final InputStream input, final int chunkSize) {
        this.input = input;
        this.chunk = new byte[chunkSize];
    }
    
    @Override
    protected final Object next() {
        try {
            int total = 0;
            while (total < this.chunk.length) {
                final int count = this.input.read(this.chunk, total, this.chunk.length - total);
                if (count < 0) {
                    if (total == 0) {
                        return null;
                    }
                    final byte[] partial = new byte[total];
                    System.arraycopy(this.chunk, 0, partial, 0, total);
                    return this.next(partial);
                }
                else {
                    total += count;
                }
            }
        }
        catch (IOException ex) {
            throw new ArcNetException(ex);
        }
        return this.next(this.chunk);
    }
    
    protected abstract Object next(final byte[] p0);
}
