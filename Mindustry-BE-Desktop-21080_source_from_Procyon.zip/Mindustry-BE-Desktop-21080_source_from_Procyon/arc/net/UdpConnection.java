// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import java.net.SocketException;
import java.io.IOException;
import java.net.SocketAddress;
import java.nio.channels.Selector;
import java.nio.channels.SelectionKey;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.net.InetSocketAddress;

class UdpConnection
{
    InetSocketAddress connectedAddress;
    DatagramChannel datagramChannel;
    int keepAliveMillis;
    final ByteBuffer readBuffer;
    final ByteBuffer writeBuffer;
    private final NetSerializer serialization;
    private SelectionKey selectionKey;
    private final Object writeLock;
    private long lastCommunicationTime;
    
    public UdpConnection(final NetSerializer serialization, final int bufferSize) {
        this.keepAliveMillis = 19000;
        this.writeLock = new Object();
        this.serialization = serialization;
        this.readBuffer = ByteBuffer.allocate(bufferSize);
        this.writeBuffer = ByteBuffer.allocateDirect(bufferSize);
    }
    
    public void bind(final Selector selector, final InetSocketAddress localPort) throws IOException {
        this.close();
        this.readBuffer.clear();
        this.writeBuffer.clear();
        try {
            this.datagramChannel = selector.provider().openDatagramChannel();
            this.datagramChannel.socket().bind(localPort);
            this.datagramChannel.configureBlocking(false);
            this.selectionKey = this.datagramChannel.register(selector, 1);
            this.lastCommunicationTime = System.currentTimeMillis();
        }
        catch (IOException ex) {
            this.close();
            throw ex;
        }
    }
    
    public void connect(final Selector selector, final InetSocketAddress remoteAddress) throws IOException {
        this.close();
        this.readBuffer.clear();
        this.writeBuffer.clear();
        try {
            this.datagramChannel = selector.provider().openDatagramChannel();
            this.datagramChannel.socket().bind(null);
            this.datagramChannel.socket().connect(remoteAddress);
            this.datagramChannel.configureBlocking(false);
            this.selectionKey = this.datagramChannel.register(selector, 1);
            this.lastCommunicationTime = System.currentTimeMillis();
            this.connectedAddress = remoteAddress;
        }
        catch (IOException ex) {
            this.close();
            throw new IOException("Unable to connect to: " + remoteAddress, ex);
        }
    }
    
    public InetSocketAddress readFromAddress() throws IOException {
        final DatagramChannel datagramChannel = this.datagramChannel;
        if (datagramChannel == null) {
            throw new SocketException("Connection is closed.");
        }
        this.lastCommunicationTime = System.currentTimeMillis();
        if (!datagramChannel.isConnected()) {
            return (InetSocketAddress)datagramChannel.receive(this.readBuffer);
        }
        datagramChannel.read(this.readBuffer);
        return this.connectedAddress;
    }
    
    public Object readObject() {
        this.readBuffer.flip();
        try {
            final Object object = this.serialization.read(this.readBuffer);
            if (this.readBuffer.hasRemaining()) {
                throw new ArcNetException("Incorrect number of bytes (" + this.readBuffer.remaining() + " remaining) used to deserialize object: " + object);
            }
            return object;
        }
        catch (Exception ex) {
            throw new ArcNetException("Error during deserialization.", ex);
        }
        finally {
            this.readBuffer.clear();
        }
    }
    
    public int send(final Object object, final SocketAddress address) throws IOException {
        final DatagramChannel datagramChannel = this.datagramChannel;
        if (datagramChannel == null) {
            throw new SocketException("Connection is closed.");
        }
        synchronized (this.writeLock) {
            try {
                try {
                    this.serialization.write(this.writeBuffer, object);
                }
                catch (Exception ex) {
                    throw new ArcNetException("Error serializing object of type: " + object.getClass().getName(), ex);
                }
                this.writeBuffer.flip();
                final int length = this.writeBuffer.limit();
                datagramChannel.send(this.writeBuffer, address);
                this.lastCommunicationTime = System.currentTimeMillis();
                final boolean wasFullWrite = !this.writeBuffer.hasRemaining();
                return wasFullWrite ? length : -1;
            }
            finally {
                this.writeBuffer.clear();
            }
        }
    }
    
    public void close() {
        this.connectedAddress = null;
        try {
            if (this.datagramChannel != null) {
                this.datagramChannel.close();
                this.datagramChannel = null;
                if (this.selectionKey != null) {
                    this.selectionKey.selector().wakeup();
                }
            }
        }
        catch (IOException ex) {}
    }
    
    public boolean needsKeepAlive(final long time) {
        return this.connectedAddress != null && this.keepAliveMillis > 0 && time - this.lastCommunicationTime > this.keepAliveMillis;
    }
}
