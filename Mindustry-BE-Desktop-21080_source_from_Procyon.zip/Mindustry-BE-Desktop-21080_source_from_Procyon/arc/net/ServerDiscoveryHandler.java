// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import java.nio.ByteBuffer;
import java.io.IOException;
import java.net.InetAddress;

public interface ServerDiscoveryHandler
{
    void onDiscoverReceived(final InetAddress p0, final ReponseHandler p1) throws IOException;
    
    public interface ReponseHandler
    {
        void respond(final ByteBuffer p0) throws IOException;
    }
}
