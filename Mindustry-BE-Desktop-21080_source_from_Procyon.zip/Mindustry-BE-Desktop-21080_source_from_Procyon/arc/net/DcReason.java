// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

public enum DcReason
{
    timeout, 
    closed, 
    error;
}
