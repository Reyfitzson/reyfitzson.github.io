// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import arc.util.async.Threads;
import java.net.DatagramPacket;
import java.net.MulticastSocket;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.SelectionKey;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.net.InetAddress;
import arc.struct.IntMap;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.Selector;

public class Server implements EndPoint
{
    private final NetSerializer serializer;
    private final int writeBufferSize;
    private final int objectBufferSize;
    private final Selector selector;
    private int emptySelects;
    private ServerSocketChannel serverChannel;
    private UdpConnection udp;
    private Connection[] connections;
    private IntMap<Connection> pendingConnections;
    NetListener[] listeners;
    private Object listenerLock;
    private int nextConnectionID;
    private volatile boolean shutdown;
    private final Object updateLock;
    private Thread updateThread;
    private int multicastPort;
    protected InetAddress multicastGroup;
    protected DiscoveryReceiver discoveryReceiver;
    protected ServerDiscoveryHandler discoveryHandler;
    private NetListener dispatchListener;
    
    public Server(final int writeBufferSize, final int objectBufferSize, final NetSerializer serializer) {
        this.connections = new Connection[0];
        this.pendingConnections = new IntMap<Connection>();
        this.listeners = new NetListener[0];
        this.listenerLock = new Object();
        this.nextConnectionID = 1;
        this.updateLock = new Object();
        this.multicastPort = 21010;
        this.dispatchListener = new NetListener() {
            @Override
            public void connected(final Connection connection) {
                final NetListener[] listeners = Server.this.listeners;
                for (int i = 0, n = listeners.length; i < n; ++i) {
                    listeners[i].connected(connection);
                }
            }
            
            @Override
            public void disconnected(final Connection connection, final DcReason reason) {
                Server.this.removeConnection(connection);
                final NetListener[] listeners = Server.this.listeners;
                for (int i = 0, n = listeners.length; i < n; ++i) {
                    listeners[i].disconnected(connection, reason);
                }
            }
            
            @Override
            public void received(final Connection connection, final Object object) {
                final NetListener[] listeners = Server.this.listeners;
                for (int i = 0, n = listeners.length; i < n; ++i) {
                    listeners[i].received(connection, object);
                }
            }
            
            @Override
            public void idle(final Connection connection) {
                final NetListener[] listeners = Server.this.listeners;
                for (int i = 0, n = listeners.length; i < n; ++i) {
                    listeners[i].idle(connection);
                }
            }
        };
        this.writeBufferSize = writeBufferSize;
        this.objectBufferSize = objectBufferSize;
        this.serializer = serializer;
        this.discoveryHandler = ((address, handler) -> handler.respond(ByteBuffer.allocate(0)));
        try {
            this.selector = Selector.open();
        }
        catch (IOException ex) {
            throw new RuntimeException("Error opening the selector.", ex);
        }
    }
    
    public void setMulticast(final String group, final int multicastPort) {
        this.multicastPort = multicastPort;
        try {
            this.multicastGroup = InetAddress.getByName(group);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void setDiscoveryHandler(final ServerDiscoveryHandler newDiscoveryHandler) {
        this.discoveryHandler = newDiscoveryHandler;
    }
    
    public void bind(final int tcpPort) throws IOException {
        this.bind(new InetSocketAddress(tcpPort), null);
    }
    
    public void bind(final int tcpPort, final int udpPort) throws IOException {
        this.bind(new InetSocketAddress(tcpPort), new InetSocketAddress(udpPort));
    }
    
    public void bind(final InetSocketAddress tcpPort, final InetSocketAddress udpPort) throws IOException {
        this.close();
        synchronized (this.updateLock) {
            this.selector.wakeup();
            try {
                this.serverChannel = this.selector.provider().openServerSocketChannel();
                this.serverChannel.socket().bind(tcpPort);
                this.serverChannel.configureBlocking(false);
                this.serverChannel.register(this.selector, 16);
                if (udpPort != null) {
                    (this.udp = new UdpConnection(this.serializer, this.objectBufferSize)).bind(this.selector, udpPort);
                }
                if (this.multicastGroup != null && (udpPort == null || this.multicastPort != udpPort.getPort())) {
                    (this.discoveryReceiver = new DiscoveryReceiver(this.multicastPort)).start();
                }
            }
            catch (IOException ex) {
                this.close();
                throw ex;
            }
        }
    }
    
    @Override
    public void update(final int timeout) throws IOException {
        this.updateThread = Thread.currentThread();
        synchronized (this.updateLock) {
        }
        // monitorexit(this.updateLock)
        final long startTime = System.currentTimeMillis();
        int select;
        if (timeout > 0) {
            select = this.selector.select(timeout);
        }
        else {
            select = this.selector.selectNow();
        }
        if (select == 0) {
            ++this.emptySelects;
            if (this.emptySelects == 100) {
                this.emptySelects = 0;
                final long elapsedTime = System.currentTimeMillis() - startTime;
                try {
                    if (elapsedTime < 25L) {
                        Thread.sleep(25L - elapsedTime);
                    }
                }
                catch (InterruptedException ex7) {}
            }
        }
        else {
            this.emptySelects = 0;
            final Set<SelectionKey> keys = this.selector.selectedKeys();
            synchronized (keys) {
                final UdpConnection udp = this.udp;
                final Iterator<SelectionKey> iter = keys.iterator();
                while (iter.hasNext()) {
                    this.keepAlive();
                    final SelectionKey selectionKey = iter.next();
                    iter.remove();
                    Connection fromConnection = (Connection)selectionKey.attachment();
                    try {
                        final int ops = selectionKey.readyOps();
                        if (fromConnection != null) {
                            if (udp != null && fromConnection.udpRemoteAddress == null) {
                                fromConnection.close(DcReason.error);
                            }
                            else {
                                if ((ops & 0x1) == 0x1) {
                                    try {
                                        while (true) {
                                            final Object object = fromConnection.tcp.readObject();
                                            if (object == null) {
                                                break;
                                            }
                                            fromConnection.notifyReceived(object);
                                        }
                                    }
                                    catch (IOException | ArcNetException ex8) {
                                        final Exception ex6;
                                        final Exception ex = ex6;
                                        ArcNet.handleError(new ArcNetException("Error reading TCP from connection: " + fromConnection, ex));
                                        fromConnection.close((ex.getMessage() != null && ex.getMessage().contains("closed")) ? DcReason.closed : DcReason.error);
                                    }
                                }
                                if ((ops & 0x4) != 0x4) {
                                    continue;
                                }
                                try {
                                    fromConnection.tcp.writeOperation();
                                }
                                catch (IOException ex2) {
                                    fromConnection.close((ex2.getMessage() != null && ex2.getMessage().contains("closed")) ? DcReason.closed : DcReason.error);
                                }
                            }
                        }
                        else if ((ops & 0x10) == 0x10) {
                            final ServerSocketChannel serverChannel = this.serverChannel;
                            if (serverChannel == null) {
                                continue;
                            }
                            try {
                                final SocketChannel socketChannel = serverChannel.accept();
                                if (socketChannel == null) {
                                    continue;
                                }
                                this.acceptOperation(socketChannel);
                            }
                            catch (IOException ex3) {
                                ArcNet.handleError(ex3);
                            }
                        }
                        else if (udp == null) {
                            selectionKey.channel().close();
                        }
                        else {
                            InetSocketAddress fromAddress;
                            try {
                                fromAddress = udp.readFromAddress();
                            }
                            catch (IOException ex3) {
                                ArcNet.handleError(ex3);
                                continue;
                            }
                            if (fromAddress == null) {
                                continue;
                            }
                            final Connection[] connections3;
                            final Connection[] connections = connections3 = this.connections;
                            for (final Connection connection : connections3) {
                                if (fromAddress.equals(connection.udpRemoteAddress)) {
                                    fromConnection = connection;
                                    break;
                                }
                            }
                            Object object2;
                            try {
                                object2 = udp.readObject();
                            }
                            catch (ArcNetException ex4) {
                                ArcNet.handleError(new ArcNetException("Error reading UDP from connection: " + ((fromConnection == null) ? fromAddress : fromAddress), ex4));
                                continue;
                            }
                            if (object2 instanceof FrameworkMessage) {
                                if (object2 instanceof FrameworkMessage.RegisterUDP) {
                                    final int fromConnectionID = ((FrameworkMessage.RegisterUDP)object2).connectionID;
                                    final Connection connection2 = this.pendingConnections.remove(fromConnectionID);
                                    if (connection2 == null) {
                                        continue;
                                    }
                                    if (connection2.udpRemoteAddress != null) {
                                        continue;
                                    }
                                    connection2.udpRemoteAddress = fromAddress;
                                    this.addConnection(connection2);
                                    connection2.sendTCP(new FrameworkMessage.RegisterUDP());
                                    connection2.notifyConnected();
                                    continue;
                                }
                                else if (object2 instanceof FrameworkMessage.DiscoverHost) {
                                    try {
                                        this.discoveryHandler.onDiscoverReceived(fromAddress.getAddress(), buff -> udp.datagramChannel.send(buff, fromAddress));
                                    }
                                    catch (IOException ex9) {}
                                    continue;
                                }
                            }
                            if (fromConnection == null) {
                                continue;
                            }
                            fromConnection.notifyReceived(object2);
                        }
                    }
                    catch (CancelledKeyException ex5) {
                        if (fromConnection != null) {
                            fromConnection.close(DcReason.error);
                        }
                        else {
                            selectionKey.channel().close();
                        }
                    }
                }
            }
        }
        final long time = System.currentTimeMillis();
        final Connection[] connections2 = this.connections;
        for (int i = 0, n = connections2.length; i < n; ++i) {
            final Connection connection3 = connections2[i];
            if (connection3.tcp.isTimedOut(time)) {
                connection3.close(DcReason.timeout);
            }
            else if (connection3.tcp.needsKeepAlive(time)) {
                connection3.sendTCP(FrameworkMessage.keepAlive);
            }
            if (connection3.isIdle()) {
                connection3.notifyIdle();
            }
        }
    }
    
    private void keepAlive() {
        final long time = System.currentTimeMillis();
        final Connection[] connections = this.connections;
        for (int i = 0, n = connections.length; i < n; ++i) {
            final Connection connection = connections[i];
            if (connection.tcp.needsKeepAlive(time)) {
                connection.sendTCP(FrameworkMessage.keepAlive);
            }
        }
    }
    
    @Override
    public void run() {
        this.shutdown = false;
        while (!this.shutdown) {
            try {
                this.update(250);
            }
            catch (IOException ex) {
                this.close();
            }
        }
    }
    
    @Override
    public void start() {
        new Thread(this, "Server").start();
    }
    
    @Override
    public void stop() {
        if (this.shutdown) {
            return;
        }
        this.shutdown = true;
        this.close();
    }
    
    private void acceptOperation(final SocketChannel socketChannel) {
        final Connection connection = this.newConnection();
        connection.initialize(this.serializer, this.writeBufferSize, this.objectBufferSize);
        connection.endPoint = this;
        final UdpConnection udp = this.udp;
        if (udp != null) {
            connection.udp = udp;
        }
        try {
            final SelectionKey selectionKey = connection.tcp.accept(this.selector, socketChannel);
            selectionKey.attach(connection);
            final int id = this.nextConnectionID++;
            if (this.nextConnectionID == -1) {
                this.nextConnectionID = 1;
            }
            connection.id = id;
            connection.setConnected(true);
            connection.addListener(this.dispatchListener);
            if (udp == null) {
                this.addConnection(connection);
            }
            else {
                this.pendingConnections.put(id, connection);
            }
            final FrameworkMessage.RegisterTCP registerConnection = new FrameworkMessage.RegisterTCP();
            registerConnection.connectionID = id;
            connection.sendTCP(registerConnection);
            if (udp == null) {
                connection.notifyConnected();
            }
        }
        catch (IOException ex) {
            connection.close(DcReason.error);
        }
    }
    
    protected Connection newConnection() {
        return new Connection();
    }
    
    private void addConnection(final Connection connection) {
        final Connection[] newConnections = new Connection[this.connections.length + 1];
        newConnections[0] = connection;
        System.arraycopy(this.connections, 0, newConnections, 1, this.connections.length);
        this.connections = newConnections;
    }
    
    void removeConnection(final Connection connection) {
        final ArrayList<Connection> temp = new ArrayList<Connection>(Arrays.asList(this.connections));
        temp.remove(connection);
        this.connections = temp.toArray(new Connection[0]);
        this.pendingConnections.remove(connection.id);
    }
    
    public void sendToAllTCP(final Object object) {
        final Connection[] connections = this.connections;
        for (int i = 0, n = connections.length; i < n; ++i) {
            final Connection connection = connections[i];
            connection.sendTCP(object);
        }
    }
    
    public void sendToAllExceptTCP(final int connectionID, final Object object) {
        final Connection[] connections = this.connections;
        for (int i = 0, n = connections.length; i < n; ++i) {
            final Connection connection = connections[i];
            if (connection.id != connectionID) {
                connection.sendTCP(object);
            }
        }
    }
    
    public void sendToTCP(final int connectionID, final Object object) {
        final Connection[] connections = this.connections;
        for (int i = 0, n = connections.length; i < n; ++i) {
            final Connection connection = connections[i];
            if (connection.id == connectionID) {
                connection.sendTCP(object);
                break;
            }
        }
    }
    
    public void sendToAllUDP(final Object object) {
        final Connection[] connections = this.connections;
        for (int i = 0, n = connections.length; i < n; ++i) {
            final Connection connection = connections[i];
            connection.sendUDP(object);
        }
    }
    
    public void sendToAllExceptUDP(final int connectionID, final Object object) {
        final Connection[] connections = this.connections;
        for (int i = 0, n = connections.length; i < n; ++i) {
            final Connection connection = connections[i];
            if (connection.id != connectionID) {
                connection.sendUDP(object);
            }
        }
    }
    
    public void sendToUDP(final int connectionID, final Object object) {
        final Connection[] connections = this.connections;
        for (int i = 0, n = connections.length; i < n; ++i) {
            final Connection connection = connections[i];
            if (connection.id == connectionID) {
                connection.sendUDP(object);
                break;
            }
        }
    }
    
    @Override
    public void addListener(final NetListener listener) {
        if (listener == null) {
            throw new IllegalArgumentException("listener cannot be null.");
        }
        synchronized (this.listenerLock) {
            final NetListener[] listeners = this.listeners;
            final int n = listeners.length;
            for (int i = 0; i < n; ++i) {
                if (listener == listeners[i]) {
                    return;
                }
            }
            final NetListener[] newListeners = new NetListener[n + 1];
            newListeners[0] = listener;
            System.arraycopy(listeners, 0, newListeners, 1, n);
            this.listeners = newListeners;
        }
    }
    
    @Override
    public void removeListener(final NetListener listener) {
        if (listener == null) {
            throw new IllegalArgumentException("listener cannot be null.");
        }
        synchronized (this.listenerLock) {
            final NetListener[] listeners = this.listeners;
            final int n = listeners.length;
            final NetListener[] newListeners = new NetListener[n - 1];
            int i = 0;
            int ii = 0;
            while (i < n) {
                final NetListener copyListener = listeners[i];
                if (listener != copyListener) {
                    if (ii == n - 1) {
                        return;
                    }
                    newListeners[ii++] = copyListener;
                }
                ++i;
            }
            this.listeners = newListeners;
        }
    }
    
    @Override
    public void close() {
        final Connection[] connections = this.connections;
        for (int i = 0, n = connections.length; i < n; ++i) {
            connections[i].close(DcReason.closed);
        }
        this.connections = new Connection[0];
        final ServerSocketChannel serverChannel = this.serverChannel;
        if (serverChannel != null) {
            try {
                serverChannel.close();
            }
            catch (IOException ex) {}
            this.serverChannel = null;
        }
        if (this.discoveryReceiver != null) {
            this.discoveryReceiver.close();
            this.discoveryReceiver = null;
        }
        final UdpConnection udp = this.udp;
        if (udp != null) {
            udp.close();
            this.udp = null;
        }
        synchronized (this.updateLock) {
        }
        // monitorexit(this.updateLock)
        this.selector.wakeup();
        try {
            this.selector.selectNow();
        }
        catch (IOException ex2) {}
    }
    
    public void dispose() throws IOException {
        this.close();
        this.selector.close();
    }
    
    @Override
    public Thread getUpdateThread() {
        return this.updateThread;
    }
    
    public Connection[] getConnections() {
        return this.connections;
    }
    
    class DiscoveryReceiver
    {
        MulticastSocket socket;
        Thread multicastThread;
        int multicastPort;
        
        DiscoveryReceiver(final int multicastPort) {
            this.socket = null;
            this.multicastPort = multicastPort;
        }
        
        void close() {
            try {
                if (this.multicastThread != null) {
                    this.multicastThread.interrupt();
                }
                if (this.socket != null) {
                    this.socket.leaveGroup(Server.this.multicastGroup);
                    this.socket.close();
                }
            }
            catch (IOException e) {
                ArcNet.handleError(e);
            }
        }
        
        void start() {
            DatagramPacket packet;
            byte[] data;
            DatagramPacket out;
            final DatagramPacket datagramPacket;
            this.multicastThread = Threads.daemon("Server Multicast Discovery", () -> {
                try {
                    (this.socket = new MulticastSocket(this.multicastPort)).joinGroup(Server.this.multicastGroup);
                    packet = new DatagramPacket(new byte[512], 512);
                    while (true) {
                        this.socket.receive(packet);
                        Server.this.discoveryHandler.onDiscoverReceived(packet.getAddress(), buffer -> {
                            data = buffer.array();
                            out = new DatagramPacket(data, data.length);
                            out.setSocketAddress(datagramPacket.getSocketAddress());
                            this.socket.send(out);
                        });
                    }
                }
                catch (IOException e) {
                    ArcNet.handleError(e);
                }
            });
        }
    }
}
