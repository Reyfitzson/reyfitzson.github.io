// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import java.net.DatagramPacket;

public interface ClientDiscoveryHandler
{
    DatagramPacket newDatagramPacket();
    
    void discoveredHost(final DatagramPacket p0);
    
    void finish();
}
