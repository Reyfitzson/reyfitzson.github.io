// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import arc.func.Cons;
import java.net.InterfaceAddress;
import java.util.Collections;
import java.net.NetworkInterface;
import java.nio.ByteBuffer;
import java.net.DatagramSocket;
import java.util.Iterator;
import java.util.Set;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.SelectionKey;
import java.net.SocketTimeoutException;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
import java.io.IOException;
import java.net.DatagramPacket;
import arc.func.Prov;
import arc.util.async.AsyncExecutor;
import java.net.InetAddress;
import java.nio.channels.Selector;

public class Client extends Connection implements EndPoint
{
    private final NetSerializer serialization;
    private Selector selector;
    private int emptySelects;
    private volatile boolean tcpRegistered;
    private volatile boolean udpRegistered;
    private Object tcpRegistrationLock;
    private Object udpRegistrationLock;
    private volatile boolean shutdown;
    private final Object updateLock;
    private Thread updateThread;
    private int connectTimeout;
    private InetAddress connectHost;
    private int connectTcpPort;
    private int connectUdpPort;
    private boolean isClosed;
    private AsyncExecutor discoverExecutor;
    private Prov<DatagramPacket> discoveryPacket;
    
    public Client(final int writeBufferSize, final int objectBufferSize, final NetSerializer serialization) {
        this.tcpRegistrationLock = new Object();
        this.udpRegistrationLock = new Object();
        this.updateLock = new Object();
        this.discoverExecutor = new AsyncExecutor(6);
        this.discoveryPacket = (() -> new DatagramPacket(new byte[256], 256));
        ((Connection)(this.endPoint = this)).initialize(this.serialization = serialization, writeBufferSize, objectBufferSize);
        try {
            this.selector = Selector.open();
        }
        catch (IOException ex) {
            throw new RuntimeException("Error opening selector.", ex);
        }
    }
    
    public void setDiscoveryPacket(final Prov<DatagramPacket> discoveryPacket) {
        this.discoveryPacket = discoveryPacket;
    }
    
    public void connect(final int timeout, final String host, final int tcpPort) throws IOException {
        this.connect(timeout, InetAddress.getByName(host), tcpPort, -1);
    }
    
    public void connect(final int timeout, final String host, final int tcpPort, final int udpPort) throws IOException {
        this.connect(timeout, InetAddress.getByName(host), tcpPort, udpPort);
    }
    
    public void connect(final int timeout, final InetAddress host, final int tcpPort) throws IOException {
        this.connect(timeout, host, tcpPort, -1);
    }
    
    public void connect(final int timeout, final InetAddress host, final int tcpPort, final int udpPort) throws IOException {
        if (host == null) {
            throw new IllegalArgumentException("host cannot be null.");
        }
        if (Thread.currentThread() == this.getUpdateThread()) {
            throw new IllegalStateException("Cannot connect on the connection's update thread.");
        }
        this.connectTimeout = timeout;
        this.connectHost = host;
        this.connectTcpPort = tcpPort;
        this.connectUdpPort = udpPort;
        this.close();
        this.id = -1;
        try {
            if (udpPort != -1) {
                this.udp = new UdpConnection(this.serialization, this.tcp.readBuffer.capacity());
            }
            final long endTime;
            synchronized (this.updateLock) {
                this.tcpRegistered = false;
                this.selector.wakeup();
                endTime = System.currentTimeMillis() + timeout;
                this.tcp.connect(this.selector, new InetSocketAddress(host, tcpPort), 5000);
            }
            synchronized (this.tcpRegistrationLock) {
                while (!this.tcpRegistered && System.currentTimeMillis() < endTime) {
                    try {
                        this.tcpRegistrationLock.wait(100L);
                    }
                    catch (InterruptedException ex2) {}
                }
                if (!this.tcpRegistered) {
                    throw new SocketTimeoutException("Connected, but timed out during TCP registration.\nNote: Client#update must be called in a separate thread during connect.");
                }
            }
            if (udpPort != -1) {
                final InetSocketAddress udpAddress = new InetSocketAddress(host, udpPort);
                synchronized (this.updateLock) {
                    this.udpRegistered = false;
                    this.selector.wakeup();
                    this.udp.connect(this.selector, udpAddress);
                }
                synchronized (this.udpRegistrationLock) {
                    while (!this.udpRegistered && System.currentTimeMillis() < endTime) {
                        final FrameworkMessage.RegisterUDP registerUDP = new FrameworkMessage.RegisterUDP();
                        registerUDP.connectionID = this.id;
                        this.udp.send(registerUDP, udpAddress);
                        try {
                            this.udpRegistrationLock.wait(100L);
                        }
                        catch (InterruptedException ex3) {}
                    }
                    if (!this.udpRegistered) {
                        throw new SocketTimeoutException("Connected, but timed out during UDP registration: " + host + ":" + udpPort);
                    }
                }
            }
        }
        catch (IOException ex) {
            this.close();
            throw ex;
        }
    }
    
    public void reconnect() throws IOException {
        this.reconnect(this.connectTimeout);
    }
    
    public void reconnect(final int timeout) throws IOException {
        if (this.connectHost == null) {
            throw new IllegalStateException("This client has never been connected.");
        }
        this.connect(timeout, this.connectHost, this.connectTcpPort, this.connectUdpPort);
    }
    
    @Override
    public void update(final int timeout) throws IOException {
        this.updateThread = Thread.currentThread();
        synchronized (this.updateLock) {
        }
        // monitorexit(this.updateLock)
        final long startTime = System.currentTimeMillis();
        int select = 0;
        if (timeout > 0) {
            select = this.selector.select(timeout);
        }
        else {
            select = this.selector.selectNow();
        }
        if (select == 0) {
            ++this.emptySelects;
            if (this.emptySelects == 100) {
                this.emptySelects = 0;
                final long elapsedTime = System.currentTimeMillis() - startTime;
                try {
                    if (elapsedTime < 25L) {
                        Thread.sleep(25L - elapsedTime);
                    }
                }
                catch (InterruptedException ex) {}
            }
        }
        else {
            this.emptySelects = 0;
            this.isClosed = false;
            final Set<SelectionKey> keys = this.selector.selectedKeys();
            synchronized (keys) {
                final Iterator<SelectionKey> iter = keys.iterator();
                while (iter.hasNext()) {
                    this.keepAlive();
                    final SelectionKey selectionKey = iter.next();
                    iter.remove();
                    try {
                        final int ops = selectionKey.readyOps();
                        if ((ops & 0x1) == 0x1) {
                            if (selectionKey.attachment() == this.tcp) {
                                while (true) {
                                    final Object object = this.tcp.readObject();
                                    if (object == null) {
                                        break;
                                    }
                                    if (!this.tcpRegistered) {
                                        if (!(object instanceof FrameworkMessage.RegisterTCP)) {
                                            continue;
                                        }
                                        this.id = ((FrameworkMessage.RegisterTCP)object).connectionID;
                                        synchronized (this.tcpRegistrationLock) {
                                            this.tcpRegistered = true;
                                            this.tcpRegistrationLock.notifyAll();
                                            if (this.udp == null) {
                                                this.setConnected(true);
                                            }
                                        }
                                        if (this.udp != null) {
                                            continue;
                                        }
                                        this.notifyConnected();
                                    }
                                    else if (this.udp != null && !this.udpRegistered) {
                                        if (!(object instanceof FrameworkMessage.RegisterUDP)) {
                                            continue;
                                        }
                                        synchronized (this.udpRegistrationLock) {
                                            this.udpRegistered = true;
                                            this.udpRegistrationLock.notifyAll();
                                            this.setConnected(true);
                                        }
                                        this.notifyConnected();
                                    }
                                    else {
                                        if (!this.isConnected) {
                                            continue;
                                        }
                                        this.notifyReceived(object);
                                    }
                                }
                            }
                            else {
                                if (this.udp.readFromAddress() == null) {
                                    continue;
                                }
                                final Object object = this.udp.readObject();
                                if (object == null) {
                                    continue;
                                }
                                this.notifyReceived(object);
                            }
                        }
                        if ((ops & 0x4) != 0x4) {
                            continue;
                        }
                        this.tcp.writeOperation();
                    }
                    catch (CancelledKeyException ex2) {}
                }
            }
        }
        if (this.isConnected) {
            final long time = System.currentTimeMillis();
            if (this.tcp.isTimedOut(time)) {
                this.close();
            }
            else {
                this.keepAlive();
            }
            if (this.isIdle()) {
                this.notifyIdle();
            }
        }
    }
    
    void keepAlive() {
        if (!this.isConnected) {
            return;
        }
        final long time = System.currentTimeMillis();
        if (this.tcp.needsKeepAlive(time)) {
            this.sendTCP(FrameworkMessage.keepAlive);
        }
        if (this.udp != null && this.udpRegistered && this.udp.needsKeepAlive(time)) {
            this.sendUDP(FrameworkMessage.keepAlive);
        }
    }
    
    @Override
    public void run() {
        this.shutdown = false;
        while (!this.shutdown) {
            try {
                this.update(250);
                continue;
            }
            catch (IOException ex2) {
                this.close();
                continue;
            }
            catch (ArcNetException ex) {
                this.lastProtocolError = ex;
                this.close();
                throw ex;
            }
            break;
        }
    }
    
    @Override
    public void start() {
        if (this.updateThread != null) {
            this.shutdown = true;
            try {
                this.updateThread.join(5000L);
            }
            catch (InterruptedException ex) {}
        }
        (this.updateThread = new Thread(this, "Client")).setDaemon(true);
        this.updateThread.start();
    }
    
    @Override
    public void stop() {
        if (this.shutdown) {
            return;
        }
        this.close();
        this.shutdown = true;
        this.selector.wakeup();
    }
    
    @Override
    public void close() {
        super.close(DcReason.closed);
        synchronized (this.updateLock) {
        }
        // monitorexit(this.updateLock)
        if (!this.isClosed) {
            this.isClosed = true;
            this.selector.wakeup();
        }
    }
    
    public void dispose() throws IOException {
        this.close();
        this.selector.close();
    }
    
    public void setKeepAliveUDP(final int keepAliveMillis) {
        if (this.udp == null) {
            throw new IllegalStateException("Not connected via UDP.");
        }
        this.udp.keepAliveMillis = keepAliveMillis;
    }
    
    @Override
    public Thread getUpdateThread() {
        return this.updateThread;
    }
    
    public NetSerializer getSerialization() {
        return this.serialization;
    }
    
    private void broadcast(final int udpPort, final DatagramSocket socket) throws IOException {
        final ByteBuffer dataBuffer = ByteBuffer.allocate(64);
        this.serialization.write(dataBuffer, new FrameworkMessage.DiscoverHost());
        dataBuffer.flip();
        final byte[] data = new byte[dataBuffer.limit()];
        dataBuffer.get(data);
        for (final NetworkInterface iface : Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!iface.isUp()) {
                continue;
            }
            for (final InterfaceAddress baseAddress : iface.getInterfaceAddresses()) {
                final InetAddress address = baseAddress.getBroadcast();
                if (address == null) {
                    continue;
                }
                socket.send(new DatagramPacket(data, data.length, address, udpPort));
            }
        }
    }
    
    public void discoverHosts(final int udpPort, final String multicastGroup, final int multicastPort, final int timeoutMillis, final Cons<DatagramPacket> handler, final Runnable done) {
        final boolean[] isDone = { false };
        DatagramSocket socket;
        DatagramPacket packet;
        final Throwable t2;
        final Object o;
        this.discoverExecutor.submit(() -> {
            try {
                socket = new DatagramSocket();
                try {
                    socket.setBroadcast(true);
                    this.broadcast(udpPort, socket);
                    socket.setSoTimeout(timeoutMillis);
                    while (true) {
                        packet = this.discoveryPacket.get();
                        socket.receive(packet);
                        handler.get(packet);
                    }
                }
                catch (Throwable t) {
                    throw t;
                }
                finally {
                    if (socket != null) {
                        if (t2 != null) {
                            try {
                                socket.close();
                            }
                            catch (Throwable exception) {
                                t2.addSuppressed(exception);
                            }
                        }
                        else {
                            socket.close();
                        }
                    }
                }
            }
            finally {
                synchronized (o) {
                    if (!o[0]) {
                        o[0] = true;
                        done.run();
                    }
                }
            }
        });
        DatagramSocket socket2;
        ByteBuffer dataBuffer;
        byte[] data;
        DatagramPacket packet2;
        final Throwable t4;
        final Object o2;
        this.discoverExecutor.submit(() -> {
            try {
                socket2 = new DatagramSocket();
                try {
                    dataBuffer = ByteBuffer.allocate(64);
                    this.serialization.write(dataBuffer, new FrameworkMessage.DiscoverHost());
                    dataBuffer.flip();
                    data = new byte[dataBuffer.limit()];
                    dataBuffer.get(data);
                    socket2.send(new DatagramPacket(data, data.length, InetAddress.getByName(multicastGroup), multicastPort));
                    socket2.setSoTimeout(timeoutMillis);
                    while (true) {
                        packet2 = this.discoveryPacket.get();
                        socket2.receive(packet2);
                        handler.get(packet2);
                    }
                }
                catch (Throwable t3) {
                    throw t3;
                }
                finally {
                    if (socket2 != null) {
                        if (t4 != null) {
                            try {
                                socket2.close();
                            }
                            catch (Throwable exception2) {
                                t4.addSuppressed(exception2);
                            }
                        }
                        else {
                            socket2.close();
                        }
                    }
                }
            }
            finally {
                synchronized (o2) {
                    if (!o2[0]) {
                        o2[0] = true;
                        done.run();
                    }
                }
            }
        });
    }
}
