// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import java.net.Socket;
import java.nio.channels.SocketChannel;
import java.net.SocketAddress;
import java.net.SocketException;
import java.io.IOException;
import java.net.InetSocketAddress;

public class Connection
{
    int id;
    private String name;
    EndPoint endPoint;
    TcpConnection tcp;
    UdpConnection udp;
    InetSocketAddress udpRemoteAddress;
    private NetListener[] listeners;
    private final Object listenerLock;
    private int lastPingID;
    private long lastPingSendTime;
    private int returnTripTime;
    volatile boolean isConnected;
    volatile ArcNetException lastProtocolError;
    private Object arbitraryData;
    
    protected Connection() {
        this.id = -1;
        this.listeners = new NetListener[0];
        this.listenerLock = new Object();
    }
    
    void initialize(final NetSerializer serialization, final int writeBufferSize, final int objectBufferSize) {
        this.tcp = new TcpConnection(serialization, writeBufferSize, objectBufferSize);
    }
    
    public int getID() {
        return this.id;
    }
    
    public boolean isConnected() {
        return this.isConnected;
    }
    
    public ArcNetException getLastProtocolError() {
        return this.lastProtocolError;
    }
    
    public int sendTCP(final Object object) {
        if (object == null) {
            throw new IllegalArgumentException("object cannot be null.");
        }
        try {
            return this.tcp.send(object);
        }
        catch (IOException | ArcNetException ex3) {
            final Exception ex2;
            final Exception ex = ex2;
            this.close(DcReason.error);
            ArcNet.handleError(ex);
            return 0;
        }
    }
    
    public int sendUDP(final Object object) {
        if (object == null) {
            throw new IllegalArgumentException("object cannot be null.");
        }
        SocketAddress address = this.udpRemoteAddress;
        if (address == null && this.udp != null) {
            address = this.udp.connectedAddress;
        }
        if (address == null && this.isConnected) {
            throw new IllegalStateException("Connection is not connected via UDP.");
        }
        try {
            if (address == null) {
                throw new SocketException("Connection is closed.");
            }
            return this.udp.send(object, address);
        }
        catch (IOException | ArcNetException ex3) {
            final Exception ex2;
            final Exception ex = ex2;
            this.close(DcReason.error);
            ArcNet.handleError(ex);
            return 0;
        }
    }
    
    public void close(final DcReason reason) {
        final boolean wasConnected = this.isConnected;
        this.isConnected = false;
        this.tcp.close();
        if (this.udp != null && this.udp.connectedAddress != null) {
            this.udp.close();
        }
        if (wasConnected) {
            this.notifyDisconnected(reason);
        }
        this.setConnected(false);
    }
    
    public void updateReturnTripTime() {
        final FrameworkMessage.Ping ping = new FrameworkMessage.Ping();
        ping.id = this.lastPingID++;
        this.lastPingSendTime = System.currentTimeMillis();
        this.sendTCP(ping);
    }
    
    public int getReturnTripTime() {
        return this.returnTripTime;
    }
    
    public void setKeepAliveTCP(final int keepAliveMillis) {
        this.tcp.keepAliveMillis = keepAliveMillis;
    }
    
    public void setTimeout(final int timeoutMillis) {
        this.tcp.timeoutMillis = timeoutMillis;
    }
    
    public void addListener(final NetListener listener) {
        if (listener == null) {
            throw new IllegalArgumentException("listener cannot be null.");
        }
        synchronized (this.listenerLock) {
            final NetListener[] listeners = this.listeners;
            final int n = listeners.length;
            for (int i = 0; i < n; ++i) {
                if (listener == listeners[i]) {
                    return;
                }
            }
            final NetListener[] newListeners = new NetListener[n + 1];
            newListeners[0] = listener;
            System.arraycopy(listeners, 0, newListeners, 1, n);
            this.listeners = newListeners;
        }
    }
    
    public void removeListener(final NetListener listener) {
        if (listener == null) {
            throw new IllegalArgumentException("listener cannot be null.");
        }
        synchronized (this.listenerLock) {
            final NetListener[] listeners = this.listeners;
            final int n = listeners.length;
            if (n == 0) {
                return;
            }
            final NetListener[] newListeners = new NetListener[n - 1];
            int i = 0;
            int ii = 0;
            while (i < n) {
                final NetListener copyListener = listeners[i];
                if (listener != copyListener) {
                    if (ii == n - 1) {
                        return;
                    }
                    newListeners[ii++] = copyListener;
                }
                ++i;
            }
            this.listeners = newListeners;
        }
    }
    
    void notifyConnected() {
        final NetListener[] listeners = this.listeners;
        for (int i = 0, n = listeners.length; i < n; ++i) {
            listeners[i].connected(this);
        }
    }
    
    void notifyDisconnected(final DcReason reason) {
        final NetListener[] listeners = this.listeners;
        for (int i = 0, n = listeners.length; i < n; ++i) {
            listeners[i].disconnected(this, reason);
        }
    }
    
    void notifyIdle() {
        final NetListener[] listeners = this.listeners;
        for (int i = 0, n = listeners.length; i < n; ++i) {
            listeners[i].idle(this);
            if (!this.isIdle()) {
                break;
            }
        }
    }
    
    void notifyReceived(final Object object) {
        if (object instanceof FrameworkMessage.Ping) {
            final FrameworkMessage.Ping ping = (FrameworkMessage.Ping)object;
            if (ping.isReply) {
                if (ping.id == this.lastPingID - 1) {
                    this.returnTripTime = (int)(System.currentTimeMillis() - this.lastPingSendTime);
                }
            }
            else {
                ping.isReply = true;
                this.sendTCP(ping);
            }
        }
        final NetListener[] listeners = this.listeners;
        for (int i = 0, n = listeners.length; i < n; ++i) {
            listeners[i].received(this, object);
        }
    }
    
    public EndPoint getEndPoint() {
        return this.endPoint;
    }
    
    public InetSocketAddress getRemoteAddressTCP() {
        final SocketChannel socketChannel = this.tcp.socketChannel;
        if (socketChannel != null) {
            final Socket socket = this.tcp.socketChannel.socket();
            if (socket != null) {
                return (InetSocketAddress)socket.getRemoteSocketAddress();
            }
        }
        return null;
    }
    
    public InetSocketAddress getRemoteAddressUDP() {
        final InetSocketAddress connectedAddress = this.udp.connectedAddress;
        if (connectedAddress != null) {
            return connectedAddress;
        }
        return this.udpRemoteAddress;
    }
    
    public void setBufferPositionFix(final boolean bufferPositionFix) {
        this.tcp.bufferPositionFix = bufferPositionFix;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public int getTcpWriteBufferSize() {
        return this.tcp.writeBuffer.position();
    }
    
    public boolean isIdle() {
        return this.tcp.writeBuffer.position() / (float)this.tcp.writeBuffer.capacity() < this.tcp.idleThreshold;
    }
    
    public void setIdleThreshold(final float idleThreshold) {
        this.tcp.idleThreshold = idleThreshold;
    }
    
    @Override
    public String toString() {
        if (this.name != null) {
            return this.name;
        }
        return "Connection " + this.id;
    }
    
    void setConnected(final boolean isConnected) {
        this.isConnected = isConnected;
        if (isConnected && this.name == null) {
            this.name = "Connection " + this.id;
        }
    }
    
    public Object getArbitraryData() {
        return this.arbitraryData;
    }
    
    public void setArbitraryData(final Object arbitraryData) {
        this.arbitraryData = arbitraryData;
    }
}
