// 
// Decompiled by Procyon v0.5.36
// 

package arc.net;

import java.util.concurrent.TimeUnit;
import java.util.LinkedList;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

public interface NetListener
{
    default void connected(final Connection connection) {
    }
    
    default void disconnected(final Connection connection, final DcReason reason) {
    }
    
    default void received(final Connection connection, final Object object) {
    }
    
    default void idle(final Connection connection) {
    }
    
    public abstract static class QueuedListener implements NetListener
    {
        final NetListener listener;
        
        public QueuedListener(final NetListener listener) {
            if (listener == null) {
                throw new IllegalArgumentException("listener cannot be null.");
            }
            this.listener = listener;
        }
        
        @Override
        public void connected(final Connection connection) {
            this.queue(() -> this.listener.connected(connection));
        }
        
        @Override
        public void disconnected(final Connection connection, final DcReason reason) {
            this.queue(() -> this.listener.disconnected(connection, reason));
        }
        
        @Override
        public void received(final Connection connection, final Object object) {
            this.queue(() -> this.listener.received(connection, object));
        }
        
        @Override
        public void idle(final Connection connection) {
            this.queue(() -> this.listener.idle(connection));
        }
        
        protected abstract void queue(final Runnable p0);
    }
    
    public static class ThreadedListener extends QueuedListener
    {
        protected final ExecutorService threadPool;
        
        public ThreadedListener(final NetListener listener) {
            this(listener, Executors.newFixedThreadPool(1));
        }
        
        public ThreadedListener(final NetListener listener, final ExecutorService threadPool) {
            super(listener);
            if (threadPool == null) {
                throw new IllegalArgumentException("threadPool cannot be null.");
            }
            this.threadPool = threadPool;
        }
        
        public void queue(final Runnable runnable) {
            this.threadPool.execute(runnable);
        }
    }
    
    public static class LagListener extends QueuedListener
    {
        private final ScheduledExecutorService threadPool;
        private final int lagMillisMin;
        private final int lagMillisMax;
        final LinkedList<Runnable> runnables;
        
        public LagListener(final int lagMillisMin, final int lagMillisMax, final NetListener listener) {
            super(listener);
            this.runnables = new LinkedList<Runnable>();
            this.lagMillisMin = lagMillisMin;
            this.lagMillisMax = lagMillisMax;
            this.threadPool = Executors.newScheduledThreadPool(1);
        }
        
        public void queue(final Runnable runnable) {
            synchronized (this.runnables) {
                this.runnables.addFirst(runnable);
            }
            final int lag = this.lagMillisMin + (int)(Math.random() * (this.lagMillisMax - this.lagMillisMin));
            final Runnable runnable2;
            this.threadPool.schedule(() -> {
                synchronized (this.runnables) {
                    runnable2 = this.runnables.removeLast();
                }
                runnable2.run();
            }, lag, TimeUnit.MILLISECONDS);
        }
    }
}
