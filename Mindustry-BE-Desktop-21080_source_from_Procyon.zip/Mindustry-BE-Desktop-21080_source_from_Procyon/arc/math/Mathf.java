// 
// Decompiled by Procyon v0.5.36
// 

package arc.math;

import arc.math.geom.Position;
import arc.util.Time;
import arc.math.geom.Vec2;

public final class Mathf
{
    public static final int[] signs;
    public static final int[] one;
    public static final boolean[] booleans;
    public static final float FLOAT_ROUNDING_ERROR = 1.0E-6f;
    public static final float PI = 3.1415927f;
    public static final float pi = 3.1415927f;
    public static final float PI2 = 6.2831855f;
    public static final float E = 2.7182817f;
    public static final float sqrt2;
    public static final float sqrt3;
    public static final float radiansToDegrees = 57.295776f;
    public static final float radDeg = 57.295776f;
    public static final float degreesToRadians = 0.017453292f;
    public static final float degRad = 0.017453292f;
    private static final int SIN_BITS = 14;
    private static final int SIN_MASK = 16383;
    private static final int SIN_COUNT = 16384;
    private static final float radFull = 6.2831855f;
    private static final float degFull = 360.0f;
    private static final float radToIndex = 2607.5945f;
    private static final float degToIndex = 45.511112f;
    private static final int BIG_ENOUGH_INT = 16384;
    private static final double BIG_ENOUGH_FLOOR = 16384.0;
    private static final double CEIL = 0.9999999;
    private static final double BIG_ENOUGH_ROUND = 16384.5;
    private static final Rand seedr;
    private static final Vec2 v1;
    private static final Vec2 v2;
    private static final Vec2 v3;
    public static Rand rand;
    
    public static float sin(final float radians) {
        return Sin.table[(int)(radians * 2607.5945f) & 0x3FFF];
    }
    
    public static float cos(final float radians) {
        return Sin.table[(int)((radians + 1.5707964f) * 2607.5945f) & 0x3FFF];
    }
    
    public static float sinDeg(final float degrees) {
        return Sin.table[(int)(degrees * 45.511112f) & 0x3FFF];
    }
    
    public static float cosDeg(final float degrees) {
        return Sin.table[(int)((degrees + 90.0f) * 45.511112f) & 0x3FFF];
    }
    
    public static float absin(final float scl, final float mag) {
        return absin(Time.time, scl, mag);
    }
    
    public static float absin(final float in, final float scl, final float mag) {
        return (sin(in, scl * 2.0f, mag) + mag) / 2.0f;
    }
    
    public static float tan(final float radians, final float scl, final float mag) {
        return sin(radians / scl) / cos(radians / scl) * mag;
    }
    
    public static float sin(final float scl, final float mag) {
        return sin(Time.time / scl) * mag;
    }
    
    public static float sin(final float radians, final float scl, final float mag) {
        return sin(radians / scl) * mag;
    }
    
    public static float cos(final float radians, final float scl, final float mag) {
        return cos(radians / scl) * mag;
    }
    
    public static float angle(final float x, final float y) {
        float result = atan2(x, y) * 57.295776f;
        if (result < 0.0f) {
            result += 360.0f;
        }
        return result;
    }
    
    public static float angleExact(final float x, final float y) {
        float result = (float)Math.atan2(y, x) * 57.295776f;
        if (result < 0.0f) {
            result += 360.0f;
        }
        return result;
    }
    
    public static float wrapAngleAroundZero(final float a) {
        if (a >= 0.0f) {
            float rotation = a % 6.2831855f;
            if (rotation > 3.1415927f) {
                rotation -= 6.2831855f;
            }
            return rotation;
        }
        float rotation = -a % 6.2831855f;
        if (rotation > 3.1415927f) {
            rotation -= 6.2831855f;
        }
        return -rotation;
    }
    
    public static float atan2(final float x, final float y) {
        if (Math.abs(x) < 1.0E-7f) {
            if (y > 0.0f) {
                return 1.5707964f;
            }
            if (y == 0.0f) {
                return 0.0f;
            }
            return -1.5707964f;
        }
        else {
            final float z = y / x;
            if (Math.abs(z) >= 1.0f) {
                final float atan = 1.5707964f - z / (z * z + 0.28f);
                return (y < 0.0f) ? (atan - 3.1415927f) : atan;
            }
            final float atan = z / (1.0f + 0.28f * z * z);
            if (x < 0.0f) {
                return atan + ((y < 0.0f) ? -3.1415927f : 3.1415927f);
            }
            return atan;
        }
    }
    
    public static int digits(final int n) {
        return (n < 100000) ? ((n < 100) ? ((n < 10) ? 1 : 2) : ((n < 1000) ? 3 : ((n < 10000) ? 4 : 5))) : ((n < 10000000) ? ((n < 1000000) ? 6 : 7) : ((n < 100000000) ? 8 : ((n < 1000000000) ? 9 : 10)));
    }
    
    public static int digits(final long n) {
        return (n == 0L) ? 1 : ((int)(Math.log10((double)n) + 1.0));
    }
    
    public static float sqrt(final float x) {
        return (float)Math.sqrt(x);
    }
    
    public static float sqr(final float x) {
        return x * x;
    }
    
    public static float map(final float value, final float froma, final float toa, final float fromb, final float tob) {
        return fromb + (value - froma) * (tob - fromb) / (toa - froma);
    }
    
    public static float map(final float value, final float from, final float to) {
        return map(value, 0.0f, 1.0f, from, to);
    }
    
    public static int sign(final float f) {
        return (f < 0.0f) ? -1 : 1;
    }
    
    public static int sign(final boolean b) {
        return b ? 1 : -1;
    }
    
    public static int num(final boolean b) {
        return b ? 1 : 0;
    }
    
    public static float pow(final float a, final float b) {
        return (float)Math.pow(a, b);
    }
    
    public static int pow(final int a, final int b) {
        return (int)Math.ceil(Math.pow(a, b));
    }
    
    public static float range(final float range) {
        return random(-range, range);
    }
    
    public static int range(final int range) {
        return random(-range, range);
    }
    
    public static float range(final float min, final float max) {
        if (chance(0.5)) {
            return random(min, max);
        }
        return -random(min, max);
    }
    
    public static boolean chanceDelta(final double d) {
        return Mathf.rand.nextFloat() < d * Time.delta;
    }
    
    public static boolean chance(final double d) {
        return Mathf.rand.nextFloat() < d;
    }
    
    public static int random(final int range) {
        return Mathf.rand.nextInt(range + 1);
    }
    
    public static int random(final int start, final int end) {
        return start + Mathf.rand.nextInt(end - start + 1);
    }
    
    public static long random(final long range) {
        return (long)(Mathf.rand.nextDouble() * range);
    }
    
    public static long random(final long start, final long end) {
        return start + (long)(Mathf.rand.nextDouble() * (end - start));
    }
    
    public static boolean randomBoolean() {
        return Mathf.rand.nextBoolean();
    }
    
    public static boolean randomBoolean(final float chance) {
        return random() < chance;
    }
    
    public static float random() {
        return Mathf.rand.nextFloat();
    }
    
    public static float random(final float range) {
        return Mathf.rand.nextFloat() * range;
    }
    
    public static float random(final float start, final float end) {
        return start + Mathf.rand.nextFloat() * (end - start);
    }
    
    public static int randomSign() {
        return 0x1 | Mathf.rand.nextInt() >> 31;
    }
    
    public static int randomSeed(final long seed, final int min, final int max) {
        Mathf.seedr.setSeed(seed);
        if (isPowerOfTwo(max)) {
            Mathf.seedr.nextInt();
        }
        return Mathf.seedr.nextInt(max - min + 1) + min;
    }
    
    public static float randomSeed(final long seed, final float min, final float max) {
        Mathf.seedr.setSeed(seed);
        return min + Mathf.seedr.nextFloat() * (max - min);
    }
    
    public static float randomSeed(final long seed) {
        Mathf.seedr.setSeed(seed * 99999L);
        return Mathf.seedr.nextFloat();
    }
    
    public static float randomSeed(final long seed, final float max) {
        Mathf.seedr.setSeed(seed * 99999L);
        return Mathf.seedr.nextFloat() * max;
    }
    
    public static float randomSeedRange(final long seed, final float range) {
        Mathf.seedr.setSeed(seed * 99999L);
        return range * (Mathf.seedr.nextFloat() - 0.5f) * 2.0f;
    }
    
    public static float randomTriangular() {
        return Mathf.rand.nextFloat() - Mathf.rand.nextFloat();
    }
    
    public static float randomTriangular(final float max) {
        return (Mathf.rand.nextFloat() - Mathf.rand.nextFloat()) * max;
    }
    
    public static float randomTriangular(final float min, final float max) {
        return randomTriangular(min, max, (min + max) * 0.5f);
    }
    
    public static float randomTriangular(final float min, final float max, final float mode) {
        final float u = Mathf.rand.nextFloat();
        final float d = max - min;
        if (u <= (mode - min) / d) {
            return min + (float)Math.sqrt(u * d * (mode - min));
        }
        return max - (float)Math.sqrt((1.0f - u) * d * (max - mode));
    }
    
    public static int nextPowerOfTwo(int value) {
        if (value == 0) {
            return 1;
        }
        value = (--value | value >> 1);
        value |= value >> 2;
        value |= value >> 4;
        value |= value >> 8;
        value |= value >> 16;
        return value + 1;
    }
    
    public static boolean isPowerOfTwo(final int value) {
        return value != 0 && (value & value - 1) == 0x0;
    }
    
    public static short clamp(final short value, final short min, final short max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }
    
    public static int clamp(final int value, final int min, final int max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }
    
    public static long clamp(final long value, final long min, final long max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }
    
    public static float clamp(final float value, final float min, final float max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }
    
    public static float clamp(final float value) {
        return clamp(value, 0.0f, 1.0f);
    }
    
    public static double clamp(final double value, final double min, final double max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }
    
    public static float maxZero(final float val) {
        return Math.max(val, 0.0f);
    }
    
    public static float approach(final float from, final float to, final float speed) {
        return from + clamp(to - from, -speed, speed);
    }
    
    public static float approachDelta(final float from, final float to, final float speed) {
        return approach(from, to, Time.delta * speed);
    }
    
    public static float lerp(final float fromValue, final float toValue, final float progress) {
        return fromValue + (toValue - fromValue) * progress;
    }
    
    public static float lerpDelta(final float fromValue, final float toValue, final float progress) {
        return lerp(fromValue, toValue, clamp(progress * Time.delta));
    }
    
    public static float slerpRad(final float fromRadians, final float toRadians, final float progress) {
        final float delta = (toRadians - fromRadians + 6.2831855f + 3.1415927f) % 6.2831855f - 3.1415927f;
        return (fromRadians + delta * progress + 6.2831855f) % 6.2831855f;
    }
    
    public static float slerp(final float fromDegrees, final float toDegrees, final float progress) {
        final float delta = (toDegrees - fromDegrees + 360.0f + 180.0f) % 360.0f - 180.0f;
        return (fromDegrees + delta * progress + 360.0f) % 360.0f;
    }
    
    public static float slerpDelta(final float fromDegrees, final float toDegrees, final float progress) {
        return slerp(fromDegrees, toDegrees, clamp(progress * Time.delta));
    }
    
    public static int floor(final float value) {
        return (int)(value + 16384.0) - 16384;
    }
    
    public static int floorPositive(final float value) {
        return (int)value;
    }
    
    public static int ceil(final float value) {
        return 16384 - (int)(16384.0 - value);
    }
    
    public static int ceilPositive(final float value) {
        return (int)(value + 0.9999999);
    }
    
    public static int round(final float value) {
        return (int)(value + 16384.5) - 16384;
    }
    
    public static int round(final int value, final int step) {
        return value / step * step;
    }
    
    public static float round(final float value, final float step) {
        return (int)(value / step) * step;
    }
    
    public static int round(final float value, final int step) {
        return (int)(value / step) * step;
    }
    
    public static int roundPositive(final float value) {
        return (int)(value + 0.5f);
    }
    
    public static boolean zero(final float value) {
        return Math.abs(value) <= 1.0E-6f;
    }
    
    public static boolean zero(final double value) {
        return Math.abs(value) <= 9.999999974752427E-7;
    }
    
    public static boolean zero(final float value, final float tolerance) {
        return Math.abs(value) <= tolerance;
    }
    
    public static boolean equal(final float a, final float b) {
        return Math.abs(a - b) <= 1.0E-6f;
    }
    
    public static boolean equal(final float a, final float b, final float tolerance) {
        return Math.abs(a - b) <= tolerance;
    }
    
    public static float log(final float a, final float value) {
        return (float)(Math.log(value) / Math.log(a));
    }
    
    public static float log2(final float value) {
        return (float)Math.log(value) / 0.30103f;
    }
    
    public static float mod(final float f, final float n) {
        return (f % n + n) % n;
    }
    
    public static int mod(final int x, final int n) {
        return (x % n + n) % n;
    }
    
    public static float slope(final float fin) {
        return 1.0f - Math.abs(fin - 0.5f) * 2.0f;
    }
    
    public static float curve(final float f, final float offset) {
        if (f < offset) {
            return 0.0f;
        }
        return (f - offset) / (1.0f - offset);
    }
    
    public static float curve(final float f, final float from, final float to) {
        if (f < from) {
            return 0.0f;
        }
        if (f > to) {
            return 1.0f;
        }
        return (f - from) / (to - from);
    }
    
    public static float curveMargin(final float f, final float margin) {
        return curveMargin(f, margin, margin);
    }
    
    public static float curveMargin(final float f, final float marginLeft, final float marginRight) {
        if (f < marginLeft) {
            return f / marginLeft * 0.5f;
        }
        if (f > 1.0f - marginRight) {
            return (f - 1.0f + marginRight) / marginRight * 0.5f + 0.5f;
        }
        return 0.5f;
    }
    
    public static float len(final float x, final float y) {
        return (float)Math.sqrt(x * x + y * y);
    }
    
    public static float len2(final float x, final float y) {
        return x * x + y * y;
    }
    
    public static float dot(final float x1, final float y1, final float x2, final float y2) {
        return x1 * x2 + y1 * y2;
    }
    
    public static float dst(final float x1, final float y1) {
        return (float)Math.sqrt(x1 * x1 + y1 * y1);
    }
    
    public static float dst2(final float x1, final float y1) {
        return x1 * x1 + y1 * y1;
    }
    
    public static float dst(final float x1, final float y1, final float x2, final float y2) {
        final float x_d = x2 - x1;
        final float y_d = y2 - y1;
        return (float)Math.sqrt(x_d * x_d + y_d * y_d);
    }
    
    public static float dst2(final float x1, final float y1, final float x2, final float y2) {
        final float x_d = x2 - x1;
        final float y_d = y2 - y1;
        return x_d * x_d + y_d * y_d;
    }
    
    public static float dstm(final float x1, final float y1, final float x2, final float y2) {
        return Math.abs(x1 - x2) + Math.abs(y1 - y2);
    }
    
    public static Vec2 arrive(final Position pos, final Position target, final Vec2 curVel, final float radius, final float tolerance, final float speed, final float smoothTime) {
        return arrive(pos.getX(), pos.getY(), target.getX(), target.getY(), curVel, radius, tolerance, speed, smoothTime);
    }
    
    public static Vec2 arrive(final float x, final float y, final float destX, final float destY, final Vec2 curVel, final float radius, final float tolerance, final float speed, final float accel) {
        final Vec2 toTarget = Mathf.v1.set(destX, destY).sub(x, y);
        final float distance = toTarget.len();
        if (distance <= tolerance) {
            return Mathf.v3.setZero();
        }
        float targetSpeed = speed;
        if (distance <= radius) {
            targetSpeed *= distance / radius;
        }
        return toTarget.sub(curVel.x / accel, curVel.y / accel).limit(targetSpeed);
    }
    
    public static boolean within(final float x1, final float y1, final float x2, final float y2, final float dst) {
        return dst2(x1, y1, x2, y2) < dst * dst;
    }
    
    public static boolean within(final float x1, final float y1, final float dst) {
        return x1 * x1 + y1 * y1 < dst * dst;
    }
    
    static {
        signs = new int[] { -1, 1 };
        one = new int[] { 1 };
        booleans = new boolean[] { true, false };
        sqrt2 = sqrt(2.0f);
        sqrt3 = sqrt(3.0f);
        seedr = new Rand();
        v1 = new Vec2();
        v2 = new Vec2();
        v3 = new Vec2();
        Mathf.rand = new Rand();
    }
    
    private static class Sin
    {
        static final float[] table;
        
        static {
            table = new float[16384];
            for (int i = 0; i < 16384; ++i) {
                Sin.table[i] = (float)Math.sin((i + 0.5f) / 16384.0f * 6.2831855f);
            }
            for (int i = 0; i < 360; i += 90) {
                Sin.table[(int)(i * 45.511112f) & 0x3FFF] = (float)Math.sin(i * 0.017453292f);
            }
        }
    }
}
