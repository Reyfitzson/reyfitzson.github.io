// 
// Decompiled by Procyon v0.5.36
// 

package arc.math;

import arc.func.Floatc2;
import arc.func.Floatc;
import arc.func.Intc;
import arc.Core;
import arc.math.geom.Vec2;

public class Angles
{
    private static final Rand random;
    private static final Vec2 rv;
    
    public static float forwardDistance(final float angle1, final float angle2) {
        return Math.abs(angle1 - angle2);
    }
    
    public static float backwardDistance(final float angle1, final float angle2) {
        return 360.0f - Math.abs(angle1 - angle2);
    }
    
    public static boolean within(final float a, final float b, final float margin) {
        return angleDist(a, b) <= margin;
    }
    
    public static float angleDist(final float a, final float b) {
        return Math.min((a - b < 0.0f) ? (a - b + 360.0f) : (a - b), (b - a < 0.0f) ? (b - a + 360.0f) : (b - a));
    }
    
    public static boolean near(final float a, final float b, final float range) {
        return angleDist(a, b) < range;
    }
    
    public static float moveToward(float angle, float to, final float speed) {
        if (Math.abs(angleDist(angle, to)) < speed) {
            return to;
        }
        angle = Mathf.mod(angle, 360.0f);
        to = Mathf.mod(to, 360.0f);
        if (angle > to == backwardDistance(angle, to) > forwardDistance(angle, to)) {
            angle -= speed;
        }
        else {
            angle += speed;
        }
        return angle;
    }
    
    public static float angle(final float x, final float y) {
        return angle(0.0f, 0.0f, x, y);
    }
    
    public static float angle(final float x, final float y, final float x2, final float y2) {
        float ang = Mathf.atan2(x2 - x, y2 - y) * 57.295776f;
        if (ang < 0.0f) {
            ang += 360.0f;
        }
        return ang;
    }
    
    public static float trnsx(final float angle, final float len) {
        return len * Mathf.cosDeg(angle);
    }
    
    public static float trnsy(final float angle, final float len) {
        return len * Mathf.sinDeg(angle);
    }
    
    public static float trnsx(final float angle, final float x, final float y) {
        return Angles.rv.set(x, y).rotate(angle).x;
    }
    
    public static float trnsy(final float angle, final float x, final float y) {
        return Angles.rv.set(x, y).rotate(angle).y;
    }
    
    public static float mouseAngle(final float cx, final float cy) {
        final Vec2 avector = Core.camera.project(cx, cy);
        return angle(avector.x, avector.y, (float)Core.input.mouseX(), (float)Core.input.mouseY());
    }
    
    public static void loop(final int max, final Intc i) {
        for (int j = 0; j < max; ++j) {
            i.get(j);
        }
    }
    
    public static void circle(final int points, final float offset, final Floatc cons) {
        for (int i = 0; i < points; ++i) {
            cons.get(offset + i * 360.0f / points);
        }
    }
    
    public static void circle(final int points, final Floatc cons) {
        for (int i = 0; i < points; ++i) {
            cons.get(i * 360.0f / points);
        }
    }
    
    public static void circleVectors(final int points, final float length, final Floatc2 pos) {
        for (int i = 0; i < points; ++i) {
            final float f = i * 360.0f / points;
            pos.get(trnsx(f, length), trnsy(f, length));
        }
    }
    
    public static void circleVectors(final int points, final float length, final float offset, final Floatc2 pos) {
        for (int i = 0; i < points; ++i) {
            final float f = i * 360.0f / points + offset;
            pos.get(trnsx(f, length), trnsy(f, length));
        }
    }
    
    public static void shotgun(final int points, final float spacing, final float offset, final Floatc cons) {
        for (int i = 0; i < points; ++i) {
            cons.get(i * spacing - (points - 1) * spacing / 2.0f + offset);
        }
    }
    
    public static void randVectors(final long seed, final int amount, final float length, final Floatc2 cons) {
        Angles.random.setSeed(seed);
        for (int i = 0; i < amount; ++i) {
            final float vang = Angles.random.nextFloat() * 360.0f;
            Angles.rv.set(length, 0.0f).rotate(vang);
            cons.get(Angles.rv.x, Angles.rv.y);
        }
    }
    
    public static void randLenVectors(final long seed, final int amount, final float length, final Floatc2 cons) {
        Angles.random.setSeed(seed);
        for (int i = 0; i < amount; ++i) {
            final float scl = length * Angles.random.nextFloat();
            final float vang = Angles.random.nextFloat() * 360.0f;
            Angles.rv.set(scl, 0.0f).rotate(vang);
            cons.get(Angles.rv.x, Angles.rv.y);
        }
    }
    
    public static void randLenVectors(final long seed, final int amount, final float minLength, final float length, final Floatc2 cons) {
        Angles.random.setSeed(seed);
        for (int i = 0; i < amount; ++i) {
            final float scl = minLength + length * Angles.random.nextFloat();
            final float vang = Angles.random.nextFloat() * 360.0f;
            Angles.rv.set(scl, 0.0f).rotate(vang);
            cons.get(Angles.rv.x, Angles.rv.y);
        }
    }
    
    public static void randLenVectors(final long seed, final int amount, final float length, final float angle, final float range, final Floatc2 cons) {
        Angles.random.setSeed(seed);
        for (int i = 0; i < amount; ++i) {
            final float scl = length * Angles.random.nextFloat();
            final float vang = angle + Angles.random.nextFloat() * range * 2.0f - range;
            Angles.rv.set(scl, 0.0f).rotate(vang);
            cons.get(Angles.rv.x, Angles.rv.y);
        }
    }
    
    public static void randLenVectors(final long seed, final float fin, final int amount, final float length, final ParticleConsumer cons) {
        Angles.random.setSeed(seed);
        for (int i = 0; i < amount; ++i) {
            final float l = Angles.random.nextFloat();
            final float scl = length * l * fin;
            final float vang = Angles.random.nextFloat() * 360.0f;
            Angles.rv.set(scl, 0.0f).rotate(vang);
            cons.accept(Angles.rv.x, Angles.rv.y, fin * l, (1.0f - fin) * l);
        }
    }
    
    public static void randLenVectors(final long seed, final float fin, final int amount, final float length, final float angle, final float range, final ParticleConsumer cons) {
        Angles.random.setSeed(seed);
        for (int i = 0; i < amount; ++i) {
            final float scl = length * Angles.random.nextFloat() * fin;
            final float vang = angle + Angles.random.nextFloat() * range * 2.0f - range;
            Angles.rv.set(scl, 0.0f).rotate(vang);
            cons.accept(Angles.rv.x, Angles.rv.y, fin * Angles.random.nextFloat(), 0.0f);
        }
    }
    
    static {
        random = new Rand();
        rv = new Vec2();
    }
    
    public interface ParticleConsumer
    {
        void accept(final float p0, final float p1, final float p2, final float p3);
    }
}
