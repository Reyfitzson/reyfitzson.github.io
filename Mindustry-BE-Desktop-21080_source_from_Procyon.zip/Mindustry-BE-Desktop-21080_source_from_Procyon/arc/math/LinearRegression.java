// 
// Decompiled by Procyon v0.5.36
// 

package arc.math;

import arc.math.geom.Vec2;
import arc.struct.Seq;

public class LinearRegression
{
    public float intercept;
    public float slope;
    
    public void calculate(final Seq<Vec2> v) {
        final int n = v.size;
        float sumx = 0.0f;
        float sumy = 0.0f;
        for (int i = 0; i < n; ++i) {
            sumx += v.get(i).x;
            sumy += v.get(i).y;
        }
        final float xbar = sumx / n;
        final float ybar = sumy / n;
        float xxbar = 0.0f;
        float xybar = 0.0f;
        for (int j = 0; j < n; ++j) {
            xxbar += (v.get(j).x - xbar) * (v.get(j).x - xbar);
            xybar += (v.get(j).x - xbar) * (v.get(j).y - ybar);
        }
        this.slope = xybar / xxbar;
        this.intercept = ybar - this.slope * xbar;
    }
    
    public float predict(final float x) {
        return this.slope * x + this.intercept;
    }
}
