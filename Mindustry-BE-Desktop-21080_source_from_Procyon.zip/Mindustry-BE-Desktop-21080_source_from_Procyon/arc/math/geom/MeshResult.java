// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

import arc.struct.IntSeq;
import arc.struct.FloatSeq;

public class MeshResult
{
    public FloatSeq vertices;
    public IntSeq indices;
    
    public MeshResult() {
        this.vertices = new FloatSeq();
        this.indices = new IntSeq();
    }
}
