// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

public class Segment
{
    public final Vec3 a;
    public final Vec3 b;
    
    public Segment(final Vec3 a, final Vec3 b) {
        this.a = new Vec3();
        this.b = new Vec3();
        this.a.set(a);
        this.b.set(b);
    }
    
    public Segment(final float aX, final float aY, final float aZ, final float bX, final float bY, final float bZ) {
        this.a = new Vec3();
        this.b = new Vec3();
        this.a.set(aX, aY, aZ);
        this.b.set(bX, bY, bZ);
    }
    
    public float len() {
        return this.a.dst(this.b);
    }
    
    public float len2() {
        return this.a.dst2(this.b);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }
        final Segment s = (Segment)o;
        return this.a.equals(s.a) && this.b.equals(s.b);
    }
    
    @Override
    public int hashCode() {
        final int prime = 71;
        int result = 1;
        result = 71 * result + this.a.hashCode();
        result = 71 * result + this.b.hashCode();
        return result;
    }
}
