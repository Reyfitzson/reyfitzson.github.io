// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

public interface Shape2D
{
    boolean contains(final Vec2 p0);
    
    boolean contains(final float p0, final float p1);
}
