// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

public class Ray
{
    public final Vec3 origin;
    public final Vec3 direction;
    
    public Ray() {
        this.origin = new Vec3();
        this.direction = new Vec3();
    }
    
    public Ray(final Vec3 origin, final Vec3 direction) {
        this.origin = new Vec3();
        this.direction = new Vec3();
        this.origin.set(origin);
        this.direction.set(direction).nor();
    }
    
    public Ray cpy() {
        return new Ray(this.origin, this.direction);
    }
    
    public Vec3 getEndPoint(final Vec3 out, final float distance) {
        return out.set(this.direction).scl(distance).add(this.origin);
    }
    
    public Ray set(final Vec3 origin, final Vec3 direction) {
        this.origin.set(origin);
        this.direction.set(direction);
        return this;
    }
    
    public Ray set(final float x, final float y, final float z, final float dx, final float dy, final float dz) {
        this.origin.set(x, y, z);
        this.direction.set(dx, dy, dz);
        return this;
    }
    
    public Ray set(final Ray ray) {
        this.origin.set(ray.origin);
        this.direction.set(ray.direction);
        return this;
    }
    
    @Override
    public String toString() {
        return "ray [" + this.origin + ":" + this.direction + "]";
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }
        final Ray r = (Ray)o;
        return this.direction.equals(r.direction) && this.origin.equals(r.origin);
    }
    
    @Override
    public int hashCode() {
        final int prime = 73;
        int result = 1;
        result = 73 * result + this.direction.hashCode();
        result = 73 * result + this.origin.hashCode();
        return result;
    }
}
