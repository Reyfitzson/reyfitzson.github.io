// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

import arc.math.Mathf;
import arc.struct.IntSeq;
import arc.struct.FloatSeq;

public class Icosphere
{
    private static final float t;
    private static final Vec3[] baseVert;
    private static final int[][] baseFace;
    
    public static MeshResult create(final int level) {
        final MeshResult data = new MeshResult();
        for (final Vec3 v : Icosphere.baseVert) {
            data.vertices.add(v.x, v.y, v.z);
        }
        for (final int[] f : Icosphere.baseFace) {
            subdivide(f[0], f[1], f[2], data.vertices, data.indices, level);
        }
        return data;
    }
    
    private static void subdivide(final int v1, final int v2, final int v3, final FloatSeq vertices, final IntSeq faces, final int level) {
        if (level == 0) {
            faces.add(v1, v2, v3);
        }
        else {
            final float a1 = vertices.get(3 * v1) + vertices.get(3 * v2);
            final float a2 = vertices.get(3 * v1 + 1) + vertices.get(3 * v2 + 1);
            final float a3 = vertices.get(3 * v1 + 2) + vertices.get(3 * v2 + 2);
            float length = Vec3.len(a1, a2, a3);
            final int indexA = vertices.size / 3;
            vertices.add(a1 / length, a2 / length, a3 / length);
            final float b1 = vertices.get(3 * v3) + vertices.get(3 * v2);
            final float b2 = vertices.get(3 * v3 + 1) + vertices.get(3 * v2 + 1);
            final float b3 = vertices.get(3 * v3 + 2) + vertices.get(3 * v2 + 2);
            length = Vec3.len(b1, b2, b3);
            final int indexB = vertices.size / 3;
            vertices.add(b1 / length, b2 / length, b3 / length);
            final float c1 = vertices.get(3 * v1) + vertices.get(3 * v3);
            final float c2 = vertices.get(3 * v1 + 1) + vertices.get(3 * v3 + 1);
            final float c3 = vertices.get(3 * v1 + 2) + vertices.get(3 * v3 + 2);
            length = Vec3.len(c1, c2, c3);
            final int indexC = vertices.size / 3;
            vertices.add(c1 / length, c2 / length, c3 / length);
            subdivide(v1, indexA, indexC, vertices, faces, level - 1);
            subdivide(indexA, v2, indexB, vertices, faces, level - 1);
            subdivide(indexC, indexB, v3, vertices, faces, level - 1);
            subdivide(indexA, indexB, indexC, vertices, faces, level - 1);
        }
    }
    
    private static Vec3 v(final float x, final float y, final float z) {
        return new Vec3(x, y, z).nor();
    }
    
    static {
        t = (Mathf.sqrt(5.0f) - 1.0f) / 2.0f;
        baseVert = new Vec3[] { v(-1.0f, -Icosphere.t, 0.0f), v(0.0f, 1.0f, Icosphere.t), v(0.0f, 1.0f, -Icosphere.t), v(1.0f, Icosphere.t, 0.0f), v(1.0f, -Icosphere.t, 0.0f), v(0.0f, -1.0f, -Icosphere.t), v(0.0f, -1.0f, Icosphere.t), v(Icosphere.t, 0.0f, 1.0f), v(-Icosphere.t, 0.0f, 1.0f), v(Icosphere.t, 0.0f, -1.0f), v(-Icosphere.t, 0.0f, -1.0f), v(-1.0f, Icosphere.t, 0.0f) };
        baseFace = new int[][] { { 3, 7, 1 }, { 4, 7, 3 }, { 6, 7, 4 }, { 8, 7, 6 }, { 7, 8, 1 }, { 9, 4, 3 }, { 2, 9, 3 }, { 2, 3, 1 }, { 11, 2, 1 }, { 10, 2, 11 }, { 10, 9, 2 }, { 9, 5, 4 }, { 6, 4, 5 }, { 0, 6, 5 }, { 0, 11, 8 }, { 11, 1, 8 }, { 10, 0, 5 }, { 10, 5, 9 }, { 0, 8, 6 }, { 0, 10, 11 } };
    }
}
