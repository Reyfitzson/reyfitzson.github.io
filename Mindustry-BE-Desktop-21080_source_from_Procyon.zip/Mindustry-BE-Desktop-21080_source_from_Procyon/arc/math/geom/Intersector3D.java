// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

import java.util.Arrays;
import java.util.List;
import arc.math.Mathf;

public class Intersector3D
{
    private static final Vec3 v0;
    private static final Vec3 v1;
    private static final Vec3 v2;
    private static final Plane p;
    private static final Vec3 i;
    static Vec3 best;
    static Vec3 tmp;
    static Vec3 tmp1;
    static Vec3 tmp2;
    static Vec3 tmp3;
    static Vec3 intersection;
    
    public static boolean intersectRayPlane(final Ray ray, final Plane plane, final Vec3 intersection) {
        final float denom = ray.direction.dot(plane.getNormal());
        if (denom != 0.0f) {
            final float t = -(ray.origin.dot(plane.getNormal()) + plane.getD()) / denom;
            if (t < 0.0f) {
                return false;
            }
            if (intersection != null) {
                intersection.set(ray.origin).add(Intersector3D.v0.set(ray.direction).scl(t));
            }
            return true;
        }
        else {
            if (plane.testPoint(ray.origin) == Plane.PlaneSide.onPlane) {
                if (intersection != null) {
                    intersection.set(ray.origin);
                }
                return true;
            }
            return false;
        }
    }
    
    public static float intersectLinePlane(final float x, final float y, final float z, final float x2, final float y2, final float z2, final Plane plane, final Vec3 intersection) {
        final Vec3 direction = Intersector3D.tmp.set(x2, y2, z2).sub(x, y, z);
        final Vec3 origin = Intersector3D.tmp2.set(x, y, z);
        final float denom = direction.dot(plane.getNormal());
        if (denom != 0.0f) {
            final float t = -(origin.dot(plane.getNormal()) + plane.getD()) / denom;
            if (intersection != null) {
                intersection.set(origin).add(direction.scl(t));
            }
            return t;
        }
        if (plane.testPoint(origin) == Plane.PlaneSide.onPlane) {
            if (intersection != null) {
                intersection.set(origin);
            }
            return 0.0f;
        }
        return -1.0f;
    }
    
    public static boolean intersectRayTriangle(final Ray ray, final Vec3 t1, final Vec3 t2, final Vec3 t3, final Vec3 intersection) {
        final Vec3 edge1 = Intersector3D.v0.set(t2).sub(t1);
        final Vec3 edge2 = Intersector3D.v1.set(t3).sub(t1);
        final Vec3 pvec = Intersector3D.v2.set(ray.direction).crs(edge2);
        float det = edge1.dot(pvec);
        if (Mathf.zero(det)) {
            Intersector3D.p.set(t1, t2, t3);
            if (Intersector3D.p.testPoint(ray.origin) == Plane.PlaneSide.onPlane && Intersector.isInTriangle(ray.origin, t1, t2, t3)) {
                if (intersection != null) {
                    intersection.set(ray.origin);
                }
                return true;
            }
            return false;
        }
        else {
            det = 1.0f / det;
            final Vec3 tvec = Intersector3D.i.set(ray.origin).sub(t1);
            final float u = tvec.dot(pvec) * det;
            if (u < 0.0f || u > 1.0f) {
                return false;
            }
            final Vec3 qvec = tvec.crs(edge1);
            final float v = ray.direction.dot(qvec) * det;
            if (v < 0.0f || u + v > 1.0f) {
                return false;
            }
            final float t4 = edge2.dot(qvec) * det;
            if (t4 < 0.0f) {
                return false;
            }
            if (intersection != null) {
                if (t4 <= 1.0E-6f) {
                    intersection.set(ray.origin);
                }
                else {
                    ray.getEndPoint(intersection, t4);
                }
            }
            return true;
        }
    }
    
    public static boolean intersectRaySphere(final Ray ray, final Vec3 center, final float radius, final Vec3 intersection) {
        final float len = ray.direction.dot(center.x - ray.origin.x, center.y - ray.origin.y, center.z - ray.origin.z);
        if (len < 0.0f) {
            return false;
        }
        final float dst2 = center.dst2(ray.origin.x + ray.direction.x * len, ray.origin.y + ray.direction.y * len, ray.origin.z + ray.direction.z * len);
        final float r2 = radius * radius;
        if (dst2 > r2) {
            return false;
        }
        if (intersection != null) {
            intersection.set(ray.direction).scl(len - (float)Math.sqrt(r2 - dst2)).add(ray.origin);
        }
        return true;
    }
    
    public static boolean intersectRayBounds(final Ray ray, final BoundingBox box, final Vec3 intersection) {
        if (box.contains(ray.origin)) {
            if (intersection != null) {
                intersection.set(ray.origin);
            }
            return true;
        }
        float lowest = 0.0f;
        boolean hit = false;
        if (ray.origin.x <= box.min.x && ray.direction.x > 0.0f) {
            final float t = (box.min.x - ray.origin.x) / ray.direction.x;
            if (t >= 0.0f) {
                Intersector3D.v2.set(ray.direction).scl(t).add(ray.origin);
                if (Intersector3D.v2.y >= box.min.y && Intersector3D.v2.y <= box.max.y && Intersector3D.v2.z >= box.min.z && Intersector3D.v2.z <= box.max.z && (!hit || t < lowest)) {
                    hit = true;
                    lowest = t;
                }
            }
        }
        if (ray.origin.x >= box.max.x && ray.direction.x < 0.0f) {
            final float t = (box.max.x - ray.origin.x) / ray.direction.x;
            if (t >= 0.0f) {
                Intersector3D.v2.set(ray.direction).scl(t).add(ray.origin);
                if (Intersector3D.v2.y >= box.min.y && Intersector3D.v2.y <= box.max.y && Intersector3D.v2.z >= box.min.z && Intersector3D.v2.z <= box.max.z && (!hit || t < lowest)) {
                    hit = true;
                    lowest = t;
                }
            }
        }
        if (ray.origin.y <= box.min.y && ray.direction.y > 0.0f) {
            final float t = (box.min.y - ray.origin.y) / ray.direction.y;
            if (t >= 0.0f) {
                Intersector3D.v2.set(ray.direction).scl(t).add(ray.origin);
                if (Intersector3D.v2.x >= box.min.x && Intersector3D.v2.x <= box.max.x && Intersector3D.v2.z >= box.min.z && Intersector3D.v2.z <= box.max.z && (!hit || t < lowest)) {
                    hit = true;
                    lowest = t;
                }
            }
        }
        if (ray.origin.y >= box.max.y && ray.direction.y < 0.0f) {
            final float t = (box.max.y - ray.origin.y) / ray.direction.y;
            if (t >= 0.0f) {
                Intersector3D.v2.set(ray.direction).scl(t).add(ray.origin);
                if (Intersector3D.v2.x >= box.min.x && Intersector3D.v2.x <= box.max.x && Intersector3D.v2.z >= box.min.z && Intersector3D.v2.z <= box.max.z && (!hit || t < lowest)) {
                    hit = true;
                    lowest = t;
                }
            }
        }
        if (ray.origin.z <= box.min.z && ray.direction.z > 0.0f) {
            final float t = (box.min.z - ray.origin.z) / ray.direction.z;
            if (t >= 0.0f) {
                Intersector3D.v2.set(ray.direction).scl(t).add(ray.origin);
                if (Intersector3D.v2.x >= box.min.x && Intersector3D.v2.x <= box.max.x && Intersector3D.v2.y >= box.min.y && Intersector3D.v2.y <= box.max.y && (!hit || t < lowest)) {
                    hit = true;
                    lowest = t;
                }
            }
        }
        if (ray.origin.z >= box.max.z && ray.direction.z < 0.0f) {
            final float t = (box.max.z - ray.origin.z) / ray.direction.z;
            if (t >= 0.0f) {
                Intersector3D.v2.set(ray.direction).scl(t).add(ray.origin);
                if (Intersector3D.v2.x >= box.min.x && Intersector3D.v2.x <= box.max.x && Intersector3D.v2.y >= box.min.y && Intersector3D.v2.y <= box.max.y && (!hit || t < lowest)) {
                    hit = true;
                    lowest = t;
                }
            }
        }
        if (hit && intersection != null) {
            intersection.set(ray.direction).scl(lowest).add(ray.origin);
            if (intersection.x < box.min.x) {
                intersection.x = box.min.x;
            }
            else if (intersection.x > box.max.x) {
                intersection.x = box.max.x;
            }
            if (intersection.y < box.min.y) {
                intersection.y = box.min.y;
            }
            else if (intersection.y > box.max.y) {
                intersection.y = box.max.y;
            }
            if (intersection.z < box.min.z) {
                intersection.z = box.min.z;
            }
            else if (intersection.z > box.max.z) {
                intersection.z = box.max.z;
            }
        }
        return hit;
    }
    
    public static boolean intersectRayBoundsFast(final Ray ray, final BoundingBox box) {
        return intersectRayBoundsFast(ray, box.getCenter(Intersector3D.tmp1), box.getDimensions(Intersector3D.tmp2));
    }
    
    public static boolean intersectRayBoundsFast(final Ray ray, final Vec3 center, final Vec3 dimensions) {
        final float divX = 1.0f / ray.direction.x;
        final float divY = 1.0f / ray.direction.y;
        final float divZ = 1.0f / ray.direction.z;
        float minx = (center.x - dimensions.x * 0.5f - ray.origin.x) * divX;
        float maxx = (center.x + dimensions.x * 0.5f - ray.origin.x) * divX;
        if (minx > maxx) {
            final float t = minx;
            minx = maxx;
            maxx = t;
        }
        float miny = (center.y - dimensions.y * 0.5f - ray.origin.y) * divY;
        float maxy = (center.y + dimensions.y * 0.5f - ray.origin.y) * divY;
        if (miny > maxy) {
            final float t2 = miny;
            miny = maxy;
            maxy = t2;
        }
        float minz = (center.z - dimensions.z * 0.5f - ray.origin.z) * divZ;
        float maxz = (center.z + dimensions.z * 0.5f - ray.origin.z) * divZ;
        if (minz > maxz) {
            final float t3 = minz;
            minz = maxz;
            maxz = t3;
        }
        final float min = Math.max(Math.max(minx, miny), minz);
        final float max = Math.min(Math.min(maxx, maxy), maxz);
        return max >= 0.0f && max >= min;
    }
    
    public static boolean intersectSegmentPlane(final Vec3 start, final Vec3 end, final Plane plane, final Vec3 intersection) {
        final Vec3 dir = Intersector3D.v0.set(end).sub(start);
        final float denom = dir.dot(plane.getNormal());
        if (denom == 0.0f) {
            return false;
        }
        final float t = -(start.dot(plane.getNormal()) + plane.getD()) / denom;
        if (t < 0.0f || t > 1.0f) {
            return false;
        }
        intersection.set(start).add(dir.scl(t));
        return true;
    }
    
    public static boolean intersectRayTriangles(final Ray ray, final float[] triangles, final Vec3 intersection) {
        float min_dist = Float.MAX_VALUE;
        boolean hit = false;
        if (triangles.length / 3 % 3 != 0) {
            throw new RuntimeException("triangle list size is not a multiple of 3");
        }
        for (int i = 0; i < triangles.length - 6; i += 9) {
            final boolean result = intersectRayTriangle(ray, Intersector3D.tmp1.set(triangles[i], triangles[i + 1], triangles[i + 2]), Intersector3D.tmp2.set(triangles[i + 3], triangles[i + 4], triangles[i + 5]), Intersector3D.tmp3.set(triangles[i + 6], triangles[i + 7], triangles[i + 8]), Intersector3D.tmp);
            if (result) {
                final float dist = ray.origin.dst2(Intersector3D.tmp);
                if (dist < min_dist) {
                    min_dist = dist;
                    Intersector3D.best.set(Intersector3D.tmp);
                    hit = true;
                }
            }
        }
        if (!hit) {
            return false;
        }
        if (intersection != null) {
            intersection.set(Intersector3D.best);
        }
        return true;
    }
    
    public static boolean intersectRayTriangles(final Ray ray, final float[] vertices, final short[] indices, final int vertexSize, final Vec3 intersection) {
        float min_dist = Float.MAX_VALUE;
        boolean hit = false;
        if (indices.length % 3 != 0) {
            throw new RuntimeException("triangle list size is not a multiple of 3");
        }
        for (int i = 0; i < indices.length; i += 3) {
            final int i2 = indices[i] * vertexSize;
            final int i3 = indices[i + 1] * vertexSize;
            final int i4 = indices[i + 2] * vertexSize;
            final boolean result = intersectRayTriangle(ray, Intersector3D.tmp1.set(vertices[i2], vertices[i2 + 1], vertices[i2 + 2]), Intersector3D.tmp2.set(vertices[i3], vertices[i3 + 1], vertices[i3 + 2]), Intersector3D.tmp3.set(vertices[i4], vertices[i4 + 1], vertices[i4 + 2]), Intersector3D.tmp);
            if (result) {
                final float dist = ray.origin.dst2(Intersector3D.tmp);
                if (dist < min_dist) {
                    min_dist = dist;
                    Intersector3D.best.set(Intersector3D.tmp);
                    hit = true;
                }
            }
        }
        if (!hit) {
            return false;
        }
        if (intersection != null) {
            intersection.set(Intersector3D.best);
        }
        return true;
    }
    
    public static boolean intersectRayTriangles(final Ray ray, final List<Vec3> triangles, final Vec3 intersection) {
        float min_dist = Float.MAX_VALUE;
        boolean hit = false;
        if (triangles.size() % 3 != 0) {
            throw new RuntimeException("triangle list size is not a multiple of 3");
        }
        for (int i = 0; i < triangles.size() - 2; i += 3) {
            final boolean result = intersectRayTriangle(ray, triangles.get(i), triangles.get(i + 1), triangles.get(i + 2), Intersector3D.tmp);
            if (result) {
                final float dist = ray.origin.dst2(Intersector3D.tmp);
                if (dist < min_dist) {
                    min_dist = dist;
                    Intersector3D.best.set(Intersector3D.tmp);
                    hit = true;
                }
            }
        }
        if (!hit) {
            return false;
        }
        if (intersection != null) {
            intersection.set(Intersector3D.best);
        }
        return true;
    }
    
    public static void splitTriangle(final float[] triangle, final Plane plane, final SplitTriangle split) {
        final int stride = triangle.length / 3;
        final boolean r1 = plane.testPoint(triangle[0], triangle[1], triangle[2]) == Plane.PlaneSide.back;
        final boolean r2 = plane.testPoint(triangle[stride], triangle[1 + stride], triangle[2 + stride]) == Plane.PlaneSide.back;
        final boolean r3 = plane.testPoint(triangle[stride * 2], triangle[1 + stride * 2], triangle[2 + stride * 2]) == Plane.PlaneSide.back;
        split.reset();
        if (r1 == r2 && r2 == r3) {
            split.total = 1;
            if (r1) {
                split.numBack = 1;
                System.arraycopy(triangle, 0, split.back, 0, triangle.length);
            }
            else {
                split.numFront = 1;
                System.arraycopy(triangle, 0, split.front, 0, triangle.length);
            }
            return;
        }
        split.total = 3;
        split.numFront = ((!r1 + !r2 + !r3) ? 1 : 0);
        split.numBack = split.total - split.numFront;
        split.setSide(!r1);
        int first = 0;
        int second = stride;
        if (r1 != r2) {
            splitEdge(triangle, first, second, stride, plane, split.edgeSplit, 0);
            split.add(triangle, first, stride);
            split.add(split.edgeSplit, 0, stride);
            split.setSide(!split.getSide());
            split.add(split.edgeSplit, 0, stride);
        }
        else {
            split.add(triangle, first, stride);
        }
        first = stride;
        second = stride + stride;
        if (r2 != r3) {
            splitEdge(triangle, first, second, stride, plane, split.edgeSplit, 0);
            split.add(triangle, first, stride);
            split.add(split.edgeSplit, 0, stride);
            split.setSide(!split.getSide());
            split.add(split.edgeSplit, 0, stride);
        }
        else {
            split.add(triangle, first, stride);
        }
        first = stride + stride;
        second = 0;
        if (r3 != r1) {
            splitEdge(triangle, first, second, stride, plane, split.edgeSplit, 0);
            split.add(triangle, first, stride);
            split.add(split.edgeSplit, 0, stride);
            split.setSide(!split.getSide());
            split.add(split.edgeSplit, 0, stride);
        }
        else {
            split.add(triangle, first, stride);
        }
        if (split.numFront == 2) {
            System.arraycopy(split.front, stride * 2, split.front, stride * 3, stride * 2);
            System.arraycopy(split.front, 0, split.front, stride * 5, stride);
        }
        else {
            System.arraycopy(split.back, stride * 2, split.back, stride * 3, stride * 2);
            System.arraycopy(split.back, 0, split.back, stride * 5, stride);
        }
    }
    
    private static void splitEdge(final float[] vertices, final int s, final int e, final int stride, final Plane plane, final float[] split, final int offset) {
        final float t = intersectLinePlane(vertices[s], vertices[s + 1], vertices[s + 2], vertices[e], vertices[e + 1], vertices[e + 2], plane, Intersector3D.intersection);
        split[offset] = Intersector3D.intersection.x;
        split[offset + 1] = Intersector3D.intersection.y;
        split[offset + 2] = Intersector3D.intersection.z;
        for (int i = 3; i < stride; ++i) {
            final float a = vertices[s + i];
            final float b = vertices[e + i];
            split[offset + i] = a + t * (b - a);
        }
    }
    
    static {
        v0 = new Vec3();
        v1 = new Vec3();
        v2 = new Vec3();
        p = new Plane(new Vec3(), 0.0f);
        i = new Vec3();
        Intersector3D.best = new Vec3();
        Intersector3D.tmp = new Vec3();
        Intersector3D.tmp1 = new Vec3();
        Intersector3D.tmp2 = new Vec3();
        Intersector3D.tmp3 = new Vec3();
        Intersector3D.intersection = new Vec3();
    }
    
    public static class SplitTriangle
    {
        public float[] front;
        public float[] back;
        public int numFront;
        public int numBack;
        public int total;
        float[] edgeSplit;
        boolean frontCurrent;
        int frontOffset;
        int backOffset;
        
        public SplitTriangle(final int numAttributes) {
            this.frontCurrent = false;
            this.frontOffset = 0;
            this.backOffset = 0;
            this.front = new float[numAttributes * 3 * 2];
            this.back = new float[numAttributes * 3 * 2];
            this.edgeSplit = new float[numAttributes];
        }
        
        @Override
        public String toString() {
            return "SplitTriangle [front=" + Arrays.toString(this.front) + ", back=" + Arrays.toString(this.back) + ", numFront=" + this.numFront + ", numBack=" + this.numBack + ", total=" + this.total + "]";
        }
        
        boolean getSide() {
            return this.frontCurrent;
        }
        
        void setSide(final boolean front) {
            this.frontCurrent = front;
        }
        
        void add(final float[] vertex, final int offset, final int stride) {
            if (this.frontCurrent) {
                System.arraycopy(vertex, offset, this.front, this.frontOffset, stride);
                this.frontOffset += stride;
            }
            else {
                System.arraycopy(vertex, offset, this.back, this.backOffset, stride);
                this.backOffset += stride;
            }
        }
        
        void reset() {
            this.frontCurrent = false;
            this.frontOffset = 0;
            this.backOffset = 0;
            this.numFront = 0;
            this.numBack = 0;
            this.total = 0;
        }
    }
}
