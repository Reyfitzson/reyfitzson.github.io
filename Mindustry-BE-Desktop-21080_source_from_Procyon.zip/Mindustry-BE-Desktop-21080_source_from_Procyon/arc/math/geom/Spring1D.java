// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

public class Spring1D
{
    public float value;
    public float target;
    public float velocity;
    public float damping;
    public float frequency;
    
    public Spring1D(final float damping, final float frequency) {
        this.damping = damping;
        this.frequency = frequency;
    }
    
    public void update(final float deltaTime) {
        float angularFrequency = this.frequency;
        angularFrequency *= 6.2831855f;
        final float f = 1.0f + 2.0f * deltaTime * this.damping * angularFrequency;
        final float oo = angularFrequency * angularFrequency;
        final float hoo = deltaTime * oo;
        final float hhoo = deltaTime * hoo;
        final float detInv = 1.0f / (f + hhoo);
        final float detX = f * this.value + deltaTime * this.velocity + hhoo * this.target;
        final float detV = this.velocity + hoo * (this.target - this.value);
        this.value = detX * detInv;
        this.velocity = detV * detInv;
    }
}
