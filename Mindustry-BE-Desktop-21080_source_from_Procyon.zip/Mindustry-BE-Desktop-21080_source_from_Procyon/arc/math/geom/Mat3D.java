// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

import arc.math.Mathf;
import arc.math.Affine2;
import arc.math.Mat;

public class Mat3D
{
    public static final int M00 = 0;
    public static final int M01 = 4;
    public static final int M02 = 8;
    public static final int M03 = 12;
    public static final int M10 = 1;
    public static final int M11 = 5;
    public static final int M12 = 9;
    public static final int M13 = 13;
    public static final int M20 = 2;
    public static final int M21 = 6;
    public static final int M22 = 10;
    public static final int M23 = 14;
    public static final int M30 = 3;
    public static final int M31 = 7;
    public static final int M32 = 11;
    public static final int M33 = 15;
    private static final float[] tmp;
    public final float[] val;
    static Quat quat;
    static Quat quat2;
    static final Vec3 l_vez;
    static final Vec3 l_vex;
    static final Vec3 l_vey;
    static final Vec3 tmpVec;
    static final Mat3D tmpMat;
    static final Vec3 right;
    static final Vec3 tmpForward;
    static final Vec3 tmpUp;
    
    public Mat3D() {
        (this.val = new float[16])[0] = 1.0f;
        this.val[5] = 1.0f;
        this.val[10] = 1.0f;
        this.val[15] = 1.0f;
    }
    
    public Mat3D(final Mat3D matrix) {
        this.val = new float[16];
        this.set(matrix);
    }
    
    public Mat3D(final float[] values) {
        this.val = new float[16];
        this.set(values);
    }
    
    public Mat3D(final Quat quat) {
        this.val = new float[16];
        this.set(quat);
    }
    
    public Mat3D(final Vec3 position, final Quat rotation, final Vec3 scale) {
        this.val = new float[16];
        this.set(position, rotation, scale);
    }
    
    public Mat3D set(final Mat3D matrix) {
        return this.set(matrix.val);
    }
    
    public Mat3D set(final float[] values) {
        System.arraycopy(values, 0, this.val, 0, this.val.length);
        return this;
    }
    
    public Mat3D set(final Quat quat) {
        return this.set(quat.x, quat.y, quat.z, quat.w);
    }
    
    public Mat3D set(final float quaternionX, final float quaternionY, final float quaternionZ, final float quaternionW) {
        return this.set(0.0f, 0.0f, 0.0f, quaternionX, quaternionY, quaternionZ, quaternionW);
    }
    
    public Mat3D set(final Vec3 position, final Quat orientation) {
        return this.set(position.x, position.y, position.z, orientation.x, orientation.y, orientation.z, orientation.w);
    }
    
    public Mat3D set(final float translationX, final float translationY, final float translationZ, final float quaternionX, final float quaternionY, final float quaternionZ, final float quaternionW) {
        final float xs = quaternionX * 2.0f;
        final float ys = quaternionY * 2.0f;
        final float zs = quaternionZ * 2.0f;
        final float wx = quaternionW * xs;
        final float wy = quaternionW * ys;
        final float wz = quaternionW * zs;
        final float xx = quaternionX * xs;
        final float xy = quaternionX * ys;
        final float xz = quaternionX * zs;
        final float yy = quaternionY * ys;
        final float yz = quaternionY * zs;
        final float zz = quaternionZ * zs;
        this.val[0] = 1.0f - (yy + zz);
        this.val[4] = xy - wz;
        this.val[8] = xz + wy;
        this.val[12] = translationX;
        this.val[1] = xy + wz;
        this.val[5] = 1.0f - (xx + zz);
        this.val[9] = yz - wx;
        this.val[13] = translationY;
        this.val[2] = xz - wy;
        this.val[6] = yz + wx;
        this.val[10] = 1.0f - (xx + yy);
        this.val[14] = translationZ;
        this.val[3] = 0.0f;
        this.val[7] = 0.0f;
        this.val[11] = 0.0f;
        this.val[15] = 1.0f;
        return this;
    }
    
    public Mat3D set(final Vec3 position, final Quat orientation, final Vec3 scale) {
        return this.set(position.x, position.y, position.z, orientation.x, orientation.y, orientation.z, orientation.w, scale.x, scale.y, scale.z);
    }
    
    public Mat3D set(final float translationX, final float translationY, final float translationZ, final float quaternionX, final float quaternionY, final float quaternionZ, final float quaternionW, final float scaleX, final float scaleY, final float scaleZ) {
        final float xs = quaternionX * 2.0f;
        final float ys = quaternionY * 2.0f;
        final float zs = quaternionZ * 2.0f;
        final float wx = quaternionW * xs;
        final float wy = quaternionW * ys;
        final float wz = quaternionW * zs;
        final float xx = quaternionX * xs;
        final float xy = quaternionX * ys;
        final float xz = quaternionX * zs;
        final float yy = quaternionY * ys;
        final float yz = quaternionY * zs;
        final float zz = quaternionZ * zs;
        this.val[0] = scaleX * (1.0f - (yy + zz));
        this.val[4] = scaleY * (xy - wz);
        this.val[8] = scaleZ * (xz + wy);
        this.val[12] = translationX;
        this.val[1] = scaleX * (xy + wz);
        this.val[5] = scaleY * (1.0f - (xx + zz));
        this.val[9] = scaleZ * (yz - wx);
        this.val[13] = translationY;
        this.val[2] = scaleX * (xz - wy);
        this.val[6] = scaleY * (yz + wx);
        this.val[10] = scaleZ * (1.0f - (xx + yy));
        this.val[14] = translationZ;
        this.val[3] = 0.0f;
        this.val[7] = 0.0f;
        this.val[11] = 0.0f;
        this.val[15] = 1.0f;
        return this;
    }
    
    public Mat3D set(final Vec3 xAxis, final Vec3 yAxis, final Vec3 zAxis, final Vec3 pos) {
        this.val[0] = xAxis.x;
        this.val[4] = xAxis.y;
        this.val[8] = xAxis.z;
        this.val[1] = yAxis.x;
        this.val[5] = yAxis.y;
        this.val[9] = yAxis.z;
        this.val[2] = zAxis.x;
        this.val[6] = zAxis.y;
        this.val[10] = zAxis.z;
        this.val[12] = pos.x;
        this.val[13] = pos.y;
        this.val[14] = pos.z;
        this.val[3] = 0.0f;
        this.val[7] = 0.0f;
        this.val[11] = 0.0f;
        this.val[15] = 1.0f;
        return this;
    }
    
    public Mat3D cpy() {
        return new Mat3D(this);
    }
    
    public Mat3D trn(final Vec3 vector) {
        final float[] val = this.val;
        final int n = 12;
        val[n] += vector.x;
        final float[] val2 = this.val;
        final int n2 = 13;
        val2[n2] += vector.y;
        final float[] val3 = this.val;
        final int n3 = 14;
        val3[n3] += vector.z;
        return this;
    }
    
    public Mat3D trn(final float x, final float y, final float z) {
        final float[] val = this.val;
        final int n = 12;
        val[n] += x;
        final float[] val2 = this.val;
        final int n2 = 13;
        val2[n2] += y;
        final float[] val3 = this.val;
        final int n3 = 14;
        val3[n3] += z;
        return this;
    }
    
    public float[] getValues() {
        return this.val;
    }
    
    public Mat3D mul(final Mat3D matrix) {
        mul(this.val, matrix.val);
        return this;
    }
    
    public Mat3D mulLeft(final Mat3D matrix) {
        Mat3D.tmpMat.set(matrix);
        mul(Mat3D.tmpMat.val, this.val);
        return this.set(Mat3D.tmpMat);
    }
    
    public Mat3D tra() {
        Mat3D.tmp[0] = this.val[0];
        Mat3D.tmp[4] = this.val[1];
        Mat3D.tmp[8] = this.val[2];
        Mat3D.tmp[12] = this.val[3];
        Mat3D.tmp[1] = this.val[4];
        Mat3D.tmp[5] = this.val[5];
        Mat3D.tmp[9] = this.val[6];
        Mat3D.tmp[13] = this.val[7];
        Mat3D.tmp[2] = this.val[8];
        Mat3D.tmp[6] = this.val[9];
        Mat3D.tmp[10] = this.val[10];
        Mat3D.tmp[14] = this.val[11];
        Mat3D.tmp[3] = this.val[12];
        Mat3D.tmp[7] = this.val[13];
        Mat3D.tmp[11] = this.val[14];
        Mat3D.tmp[15] = this.val[15];
        return this.set(Mat3D.tmp);
    }
    
    public Mat3D idt() {
        this.val[0] = 1.0f;
        this.val[4] = 0.0f;
        this.val[8] = 0.0f;
        this.val[12] = 0.0f;
        this.val[1] = 0.0f;
        this.val[5] = 1.0f;
        this.val[9] = 0.0f;
        this.val[13] = 0.0f;
        this.val[2] = 0.0f;
        this.val[6] = 0.0f;
        this.val[10] = 1.0f;
        this.val[14] = 0.0f;
        this.val[3] = 0.0f;
        this.val[7] = 0.0f;
        this.val[11] = 0.0f;
        this.val[15] = 1.0f;
        return this;
    }
    
    public Mat3D inv() {
        final float l_det = this.val[3] * this.val[6] * this.val[9] * this.val[12] - this.val[2] * this.val[7] * this.val[9] * this.val[12] - this.val[3] * this.val[5] * this.val[10] * this.val[12] + this.val[1] * this.val[7] * this.val[10] * this.val[12] + this.val[2] * this.val[5] * this.val[11] * this.val[12] - this.val[1] * this.val[6] * this.val[11] * this.val[12] - this.val[3] * this.val[6] * this.val[8] * this.val[13] + this.val[2] * this.val[7] * this.val[8] * this.val[13] + this.val[3] * this.val[4] * this.val[10] * this.val[13] - this.val[0] * this.val[7] * this.val[10] * this.val[13] - this.val[2] * this.val[4] * this.val[11] * this.val[13] + this.val[0] * this.val[6] * this.val[11] * this.val[13] + this.val[3] * this.val[5] * this.val[8] * this.val[14] - this.val[1] * this.val[7] * this.val[8] * this.val[14] - this.val[3] * this.val[4] * this.val[9] * this.val[14] + this.val[0] * this.val[7] * this.val[9] * this.val[14] + this.val[1] * this.val[4] * this.val[11] * this.val[14] - this.val[0] * this.val[5] * this.val[11] * this.val[14] - this.val[2] * this.val[5] * this.val[8] * this.val[15] + this.val[1] * this.val[6] * this.val[8] * this.val[15] + this.val[2] * this.val[4] * this.val[9] * this.val[15] - this.val[0] * this.val[6] * this.val[9] * this.val[15] - this.val[1] * this.val[4] * this.val[10] * this.val[15] + this.val[0] * this.val[5] * this.val[10] * this.val[15];
        if (l_det == 0.0f) {
            throw new RuntimeException("non-invertible matrix");
        }
        final float inv_det = 1.0f / l_det;
        Mat3D.tmp[0] = this.val[9] * this.val[14] * this.val[7] - this.val[13] * this.val[10] * this.val[7] + this.val[13] * this.val[6] * this.val[11] - this.val[5] * this.val[14] * this.val[11] - this.val[9] * this.val[6] * this.val[15] + this.val[5] * this.val[10] * this.val[15];
        Mat3D.tmp[4] = this.val[12] * this.val[10] * this.val[7] - this.val[8] * this.val[14] * this.val[7] - this.val[12] * this.val[6] * this.val[11] + this.val[4] * this.val[14] * this.val[11] + this.val[8] * this.val[6] * this.val[15] - this.val[4] * this.val[10] * this.val[15];
        Mat3D.tmp[8] = this.val[8] * this.val[13] * this.val[7] - this.val[12] * this.val[9] * this.val[7] + this.val[12] * this.val[5] * this.val[11] - this.val[4] * this.val[13] * this.val[11] - this.val[8] * this.val[5] * this.val[15] + this.val[4] * this.val[9] * this.val[15];
        Mat3D.tmp[12] = this.val[12] * this.val[9] * this.val[6] - this.val[8] * this.val[13] * this.val[6] - this.val[12] * this.val[5] * this.val[10] + this.val[4] * this.val[13] * this.val[10] + this.val[8] * this.val[5] * this.val[14] - this.val[4] * this.val[9] * this.val[14];
        Mat3D.tmp[1] = this.val[13] * this.val[10] * this.val[3] - this.val[9] * this.val[14] * this.val[3] - this.val[13] * this.val[2] * this.val[11] + this.val[1] * this.val[14] * this.val[11] + this.val[9] * this.val[2] * this.val[15] - this.val[1] * this.val[10] * this.val[15];
        Mat3D.tmp[5] = this.val[8] * this.val[14] * this.val[3] - this.val[12] * this.val[10] * this.val[3] + this.val[12] * this.val[2] * this.val[11] - this.val[0] * this.val[14] * this.val[11] - this.val[8] * this.val[2] * this.val[15] + this.val[0] * this.val[10] * this.val[15];
        Mat3D.tmp[9] = this.val[12] * this.val[9] * this.val[3] - this.val[8] * this.val[13] * this.val[3] - this.val[12] * this.val[1] * this.val[11] + this.val[0] * this.val[13] * this.val[11] + this.val[8] * this.val[1] * this.val[15] - this.val[0] * this.val[9] * this.val[15];
        Mat3D.tmp[13] = this.val[8] * this.val[13] * this.val[2] - this.val[12] * this.val[9] * this.val[2] + this.val[12] * this.val[1] * this.val[10] - this.val[0] * this.val[13] * this.val[10] - this.val[8] * this.val[1] * this.val[14] + this.val[0] * this.val[9] * this.val[14];
        Mat3D.tmp[2] = this.val[5] * this.val[14] * this.val[3] - this.val[13] * this.val[6] * this.val[3] + this.val[13] * this.val[2] * this.val[7] - this.val[1] * this.val[14] * this.val[7] - this.val[5] * this.val[2] * this.val[15] + this.val[1] * this.val[6] * this.val[15];
        Mat3D.tmp[6] = this.val[12] * this.val[6] * this.val[3] - this.val[4] * this.val[14] * this.val[3] - this.val[12] * this.val[2] * this.val[7] + this.val[0] * this.val[14] * this.val[7] + this.val[4] * this.val[2] * this.val[15] - this.val[0] * this.val[6] * this.val[15];
        Mat3D.tmp[10] = this.val[4] * this.val[13] * this.val[3] - this.val[12] * this.val[5] * this.val[3] + this.val[12] * this.val[1] * this.val[7] - this.val[0] * this.val[13] * this.val[7] - this.val[4] * this.val[1] * this.val[15] + this.val[0] * this.val[5] * this.val[15];
        Mat3D.tmp[14] = this.val[12] * this.val[5] * this.val[2] - this.val[4] * this.val[13] * this.val[2] - this.val[12] * this.val[1] * this.val[6] + this.val[0] * this.val[13] * this.val[6] + this.val[4] * this.val[1] * this.val[14] - this.val[0] * this.val[5] * this.val[14];
        Mat3D.tmp[3] = this.val[9] * this.val[6] * this.val[3] - this.val[5] * this.val[10] * this.val[3] - this.val[9] * this.val[2] * this.val[7] + this.val[1] * this.val[10] * this.val[7] + this.val[5] * this.val[2] * this.val[11] - this.val[1] * this.val[6] * this.val[11];
        Mat3D.tmp[7] = this.val[4] * this.val[10] * this.val[3] - this.val[8] * this.val[6] * this.val[3] + this.val[8] * this.val[2] * this.val[7] - this.val[0] * this.val[10] * this.val[7] - this.val[4] * this.val[2] * this.val[11] + this.val[0] * this.val[6] * this.val[11];
        Mat3D.tmp[11] = this.val[8] * this.val[5] * this.val[3] - this.val[4] * this.val[9] * this.val[3] - this.val[8] * this.val[1] * this.val[7] + this.val[0] * this.val[9] * this.val[7] + this.val[4] * this.val[1] * this.val[11] - this.val[0] * this.val[5] * this.val[11];
        Mat3D.tmp[15] = this.val[4] * this.val[9] * this.val[2] - this.val[8] * this.val[5] * this.val[2] + this.val[8] * this.val[1] * this.val[6] - this.val[0] * this.val[9] * this.val[6] - this.val[4] * this.val[1] * this.val[10] + this.val[0] * this.val[5] * this.val[10];
        this.val[0] = Mat3D.tmp[0] * inv_det;
        this.val[4] = Mat3D.tmp[4] * inv_det;
        this.val[8] = Mat3D.tmp[8] * inv_det;
        this.val[12] = Mat3D.tmp[12] * inv_det;
        this.val[1] = Mat3D.tmp[1] * inv_det;
        this.val[5] = Mat3D.tmp[5] * inv_det;
        this.val[9] = Mat3D.tmp[9] * inv_det;
        this.val[13] = Mat3D.tmp[13] * inv_det;
        this.val[2] = Mat3D.tmp[2] * inv_det;
        this.val[6] = Mat3D.tmp[6] * inv_det;
        this.val[10] = Mat3D.tmp[10] * inv_det;
        this.val[14] = Mat3D.tmp[14] * inv_det;
        this.val[3] = Mat3D.tmp[3] * inv_det;
        this.val[7] = Mat3D.tmp[7] * inv_det;
        this.val[11] = Mat3D.tmp[11] * inv_det;
        this.val[15] = Mat3D.tmp[15] * inv_det;
        return this;
    }
    
    public float det() {
        return this.val[3] * this.val[6] * this.val[9] * this.val[12] - this.val[2] * this.val[7] * this.val[9] * this.val[12] - this.val[3] * this.val[5] * this.val[10] * this.val[12] + this.val[1] * this.val[7] * this.val[10] * this.val[12] + this.val[2] * this.val[5] * this.val[11] * this.val[12] - this.val[1] * this.val[6] * this.val[11] * this.val[12] - this.val[3] * this.val[6] * this.val[8] * this.val[13] + this.val[2] * this.val[7] * this.val[8] * this.val[13] + this.val[3] * this.val[4] * this.val[10] * this.val[13] - this.val[0] * this.val[7] * this.val[10] * this.val[13] - this.val[2] * this.val[4] * this.val[11] * this.val[13] + this.val[0] * this.val[6] * this.val[11] * this.val[13] + this.val[3] * this.val[5] * this.val[8] * this.val[14] - this.val[1] * this.val[7] * this.val[8] * this.val[14] - this.val[3] * this.val[4] * this.val[9] * this.val[14] + this.val[0] * this.val[7] * this.val[9] * this.val[14] + this.val[1] * this.val[4] * this.val[11] * this.val[14] - this.val[0] * this.val[5] * this.val[11] * this.val[14] - this.val[2] * this.val[5] * this.val[8] * this.val[15] + this.val[1] * this.val[6] * this.val[8] * this.val[15] + this.val[2] * this.val[4] * this.val[9] * this.val[15] - this.val[0] * this.val[6] * this.val[9] * this.val[15] - this.val[1] * this.val[4] * this.val[10] * this.val[15] + this.val[0] * this.val[5] * this.val[10] * this.val[15];
    }
    
    public float det3x3() {
        return this.val[0] * this.val[5] * this.val[10] + this.val[4] * this.val[9] * this.val[2] + this.val[8] * this.val[1] * this.val[6] - this.val[0] * this.val[9] * this.val[6] - this.val[4] * this.val[1] * this.val[10] - this.val[8] * this.val[5] * this.val[2];
    }
    
    public Mat3D setToProjection(final float near, final float far, final float fovy, final float aspectRatio) {
        this.idt();
        final float l_fd = (float)(1.0 / Math.tan(fovy * 0.017453292519943295 / 2.0));
        final float l_a1 = (far + near) / (near - far);
        final float l_a2 = 2.0f * far * near / (near - far);
        this.val[0] = l_fd / aspectRatio;
        this.val[1] = 0.0f;
        this.val[2] = 0.0f;
        this.val[3] = 0.0f;
        this.val[4] = 0.0f;
        this.val[5] = l_fd;
        this.val[6] = 0.0f;
        this.val[7] = 0.0f;
        this.val[8] = 0.0f;
        this.val[9] = 0.0f;
        this.val[10] = l_a1;
        this.val[11] = -1.0f;
        this.val[12] = 0.0f;
        this.val[13] = 0.0f;
        this.val[14] = l_a2;
        this.val[15] = 0.0f;
        return this;
    }
    
    public Mat3D setToProjection(final float left, final float right, final float bottom, final float top, final float near, final float far) {
        final float x = 2.0f * near / (right - left);
        final float y = 2.0f * near / (top - bottom);
        final float a = (right + left) / (right - left);
        final float b = (top + bottom) / (top - bottom);
        final float l_a1 = (far + near) / (near - far);
        final float l_a2 = 2.0f * far * near / (near - far);
        this.val[0] = x;
        this.val[1] = 0.0f;
        this.val[2] = 0.0f;
        this.val[3] = 0.0f;
        this.val[4] = 0.0f;
        this.val[5] = y;
        this.val[6] = 0.0f;
        this.val[7] = 0.0f;
        this.val[8] = a;
        this.val[9] = b;
        this.val[10] = l_a1;
        this.val[11] = -1.0f;
        this.val[12] = 0.0f;
        this.val[13] = 0.0f;
        this.val[14] = l_a2;
        this.val[15] = 0.0f;
        return this;
    }
    
    public Mat3D setToOrtho2D(final float x, final float y, final float width, final float height) {
        this.setToOrtho(x, x + width, y, y + height, 0.0f, 1.0f);
        return this;
    }
    
    public Mat3D setToOrtho2D(final float x, final float y, final float width, final float height, final float near, final float far) {
        this.setToOrtho(x, x + width, y, y + height, near, far);
        return this;
    }
    
    public Mat3D setToOrtho(final float left, final float right, final float bottom, final float top, final float near, final float far) {
        this.idt();
        final float x_orth = 2.0f / (right - left);
        final float y_orth = 2.0f / (top - bottom);
        final float z_orth = -2.0f / (far - near);
        final float tx = -(right + left) / (right - left);
        final float ty = -(top + bottom) / (top - bottom);
        final float tz = -(far + near) / (far - near);
        this.val[0] = x_orth;
        this.val[1] = 0.0f;
        this.val[2] = 0.0f;
        this.val[3] = 0.0f;
        this.val[4] = 0.0f;
        this.val[5] = y_orth;
        this.val[6] = 0.0f;
        this.val[7] = 0.0f;
        this.val[8] = 0.0f;
        this.val[9] = 0.0f;
        this.val[10] = z_orth;
        this.val[11] = 0.0f;
        this.val[12] = tx;
        this.val[13] = ty;
        this.val[14] = tz;
        this.val[15] = 1.0f;
        return this;
    }
    
    public Mat3D setTranslation(final Vec3 vector) {
        this.val[12] = vector.x;
        this.val[13] = vector.y;
        this.val[14] = vector.z;
        return this;
    }
    
    public Mat3D setTranslation(final float x, final float y, final float z) {
        this.val[12] = x;
        this.val[13] = y;
        this.val[14] = z;
        return this;
    }
    
    public Mat3D setToTranslation(final Vec3 vector) {
        this.idt();
        this.val[12] = vector.x;
        this.val[13] = vector.y;
        this.val[14] = vector.z;
        return this;
    }
    
    public Mat3D setToTranslation(final float x, final float y, final float z) {
        this.idt();
        this.val[12] = x;
        this.val[13] = y;
        this.val[14] = z;
        return this;
    }
    
    public Mat3D setToTranslationAndScaling(final Vec3 translation, final Vec3 scaling) {
        this.idt();
        this.val[12] = translation.x;
        this.val[13] = translation.y;
        this.val[14] = translation.z;
        this.val[0] = scaling.x;
        this.val[5] = scaling.y;
        this.val[10] = scaling.z;
        return this;
    }
    
    public Mat3D setToTranslationAndScaling(final float translationX, final float translationY, final float translationZ, final float scalingX, final float scalingY, final float scalingZ) {
        this.idt();
        this.val[12] = translationX;
        this.val[13] = translationY;
        this.val[14] = translationZ;
        this.val[0] = scalingX;
        this.val[5] = scalingY;
        this.val[10] = scalingZ;
        return this;
    }
    
    public Mat3D setToRotation(final Vec3 axis, final float degrees) {
        if (degrees == 0.0f) {
            this.idt();
            return this;
        }
        return this.set(Mat3D.quat.set(axis, degrees));
    }
    
    public Mat3D setToRotationRad(final Vec3 axis, final float radians) {
        if (radians == 0.0f) {
            this.idt();
            return this;
        }
        return this.set(Mat3D.quat.setFromAxisRad(axis, radians));
    }
    
    public Mat3D setToRotation(final float axisX, final float axisY, final float axisZ, final float degrees) {
        if (degrees == 0.0f) {
            this.idt();
            return this;
        }
        return this.set(Mat3D.quat.setFromAxis(axisX, axisY, axisZ, degrees));
    }
    
    public Mat3D setToRotationRad(final float axisX, final float axisY, final float axisZ, final float radians) {
        if (radians == 0.0f) {
            this.idt();
            return this;
        }
        return this.set(Mat3D.quat.setFromAxisRad(axisX, axisY, axisZ, radians));
    }
    
    public Mat3D setToRotation(final Vec3 v1, final Vec3 v2) {
        return this.set(Mat3D.quat.setFromCross(v1, v2));
    }
    
    public Mat3D setToRotation(final float x1, final float y1, final float z1, final float x2, final float y2, final float z2) {
        return this.set(Mat3D.quat.setFromCross(x1, y1, z1, x2, y2, z2));
    }
    
    public Mat3D setFromEulerAngles(final float yaw, final float pitch, final float roll) {
        Mat3D.quat.setEulerAngles(yaw, pitch, roll);
        return this.set(Mat3D.quat);
    }
    
    public Mat3D setFromEulerAnglesRad(final float yaw, final float pitch, final float roll) {
        Mat3D.quat.setEulerAnglesRad(yaw, pitch, roll);
        return this.set(Mat3D.quat);
    }
    
    public Mat3D setToScaling(final Vec3 vector) {
        this.idt();
        this.val[0] = vector.x;
        this.val[5] = vector.y;
        this.val[10] = vector.z;
        return this;
    }
    
    public Mat3D setToScaling(final float x, final float y, final float z) {
        this.idt();
        this.val[0] = x;
        this.val[5] = y;
        this.val[10] = z;
        return this;
    }
    
    public Mat3D setToLookAt(final Vec3 direction, final Vec3 up) {
        Mat3D.l_vez.set(direction).nor();
        Mat3D.l_vex.set(direction).nor();
        Mat3D.l_vex.crs(up).nor();
        Mat3D.l_vey.set(Mat3D.l_vex).crs(Mat3D.l_vez).nor();
        this.idt();
        this.val[0] = Mat3D.l_vex.x;
        this.val[4] = Mat3D.l_vex.y;
        this.val[8] = Mat3D.l_vex.z;
        this.val[1] = Mat3D.l_vey.x;
        this.val[5] = Mat3D.l_vey.y;
        this.val[9] = Mat3D.l_vey.z;
        this.val[2] = -Mat3D.l_vez.x;
        this.val[6] = -Mat3D.l_vez.y;
        this.val[10] = -Mat3D.l_vez.z;
        return this;
    }
    
    public Mat3D setToLookAt(final Vec3 position, final Vec3 target, final Vec3 up) {
        Mat3D.tmpVec.set(target).sub(position);
        this.setToLookAt(Mat3D.tmpVec, up);
        this.mul(Mat3D.tmpMat.setToTranslation(-position.x, -position.y, -position.z));
        return this;
    }
    
    public Mat3D setToWorld(final Vec3 position, final Vec3 forward, final Vec3 up) {
        Mat3D.tmpForward.set(forward).nor();
        Mat3D.right.set(Mat3D.tmpForward).crs(up).nor();
        Mat3D.tmpUp.set(Mat3D.right).crs(Mat3D.tmpForward).nor();
        this.set(Mat3D.right, Mat3D.tmpUp, Mat3D.tmpForward.scl(-1.0f), position);
        return this;
    }
    
    @Override
    public String toString() {
        return "[" + this.val[0] + "|" + this.val[4] + "|" + this.val[8] + "|" + this.val[12] + "]\n[" + this.val[1] + "|" + this.val[5] + "|" + this.val[9] + "|" + this.val[13] + "]\n[" + this.val[2] + "|" + this.val[6] + "|" + this.val[10] + "|" + this.val[14] + "]\n[" + this.val[3] + "|" + this.val[7] + "|" + this.val[11] + "|" + this.val[15] + "]\n";
    }
    
    public Mat3D lerp(final Mat3D matrix, final float alpha) {
        for (int i = 0; i < 16; ++i) {
            this.val[i] = this.val[i] * (1.0f - alpha) + matrix.val[i] * alpha;
        }
        return this;
    }
    
    public Mat3D avg(final Mat3D other, final float w) {
        this.getScale(Mat3D.tmpVec);
        other.getScale(Mat3D.tmpForward);
        this.getRotation(Mat3D.quat);
        other.getRotation(Mat3D.quat2);
        this.getTranslation(Mat3D.tmpUp);
        other.getTranslation(Mat3D.right);
        this.setToScaling(Mat3D.tmpVec.scl(w).add(Mat3D.tmpForward.scl(1.0f - w)));
        this.rotate(Mat3D.quat.slerp(Mat3D.quat2, 1.0f - w));
        this.setTranslation(Mat3D.tmpUp.scl(w).add(Mat3D.right.scl(1.0f - w)));
        return this;
    }
    
    public Mat3D avg(final Mat3D[] t) {
        final float w = 1.0f / t.length;
        Mat3D.tmpVec.set(t[0].getScale(Mat3D.tmpUp).scl(w));
        Mat3D.quat.set(t[0].getRotation(Mat3D.quat2).exp(w));
        Mat3D.tmpForward.set(t[0].getTranslation(Mat3D.tmpUp).scl(w));
        for (int i = 1; i < t.length; ++i) {
            Mat3D.tmpVec.add(t[i].getScale(Mat3D.tmpUp).scl(w));
            Mat3D.quat.mul(t[i].getRotation(Mat3D.quat2).exp(w));
            Mat3D.tmpForward.add(t[i].getTranslation(Mat3D.tmpUp).scl(w));
        }
        Mat3D.quat.nor();
        this.setToScaling(Mat3D.tmpVec);
        this.rotate(Mat3D.quat);
        this.setTranslation(Mat3D.tmpForward);
        return this;
    }
    
    public Mat3D avg(final Mat3D[] t, final float[] w) {
        Mat3D.tmpVec.set(t[0].getScale(Mat3D.tmpUp).scl(w[0]));
        Mat3D.quat.set(t[0].getRotation(Mat3D.quat2).exp(w[0]));
        Mat3D.tmpForward.set(t[0].getTranslation(Mat3D.tmpUp).scl(w[0]));
        for (int i = 1; i < t.length; ++i) {
            Mat3D.tmpVec.add(t[i].getScale(Mat3D.tmpUp).scl(w[i]));
            Mat3D.quat.mul(t[i].getRotation(Mat3D.quat2).exp(w[i]));
            Mat3D.tmpForward.add(t[i].getTranslation(Mat3D.tmpUp).scl(w[i]));
        }
        Mat3D.quat.nor();
        this.setToScaling(Mat3D.tmpVec);
        this.rotate(Mat3D.quat);
        this.setTranslation(Mat3D.tmpForward);
        return this;
    }
    
    public Mat3D set(final Mat mat) {
        this.val[0] = mat.val[0];
        this.val[1] = mat.val[1];
        this.val[2] = mat.val[2];
        this.val[3] = 0.0f;
        this.val[4] = mat.val[3];
        this.val[5] = mat.val[4];
        this.val[6] = mat.val[5];
        this.val[7] = 0.0f;
        this.val[8] = 0.0f;
        this.val[9] = 0.0f;
        this.val[10] = 1.0f;
        this.val[11] = 0.0f;
        this.val[12] = mat.val[6];
        this.val[13] = mat.val[7];
        this.val[14] = 0.0f;
        this.val[15] = mat.val[8];
        return this;
    }
    
    public Mat3D set(final Affine2 affine) {
        this.val[0] = affine.m00;
        this.val[1] = affine.m10;
        this.val[2] = 0.0f;
        this.val[3] = 0.0f;
        this.val[4] = affine.m01;
        this.val[5] = affine.m11;
        this.val[6] = 0.0f;
        this.val[7] = 0.0f;
        this.val[8] = 0.0f;
        this.val[9] = 0.0f;
        this.val[10] = 1.0f;
        this.val[11] = 0.0f;
        this.val[12] = affine.m02;
        this.val[13] = affine.m12;
        this.val[14] = 0.0f;
        this.val[15] = 1.0f;
        return this;
    }
    
    public Mat3D setAsAffine(final Affine2 affine) {
        this.val[0] = affine.m00;
        this.val[1] = affine.m10;
        this.val[4] = affine.m01;
        this.val[5] = affine.m11;
        this.val[12] = affine.m02;
        this.val[13] = affine.m12;
        return this;
    }
    
    public Mat3D setAsAffine(final Mat3D mat) {
        this.val[0] = mat.val[0];
        this.val[1] = mat.val[1];
        this.val[4] = mat.val[4];
        this.val[5] = mat.val[5];
        this.val[12] = mat.val[12];
        this.val[13] = mat.val[13];
        return this;
    }
    
    public Mat3D scl(final Vec3 scale) {
        final float[] val = this.val;
        final int n = 0;
        val[n] *= scale.x;
        final float[] val2 = this.val;
        final int n2 = 5;
        val2[n2] *= scale.y;
        final float[] val3 = this.val;
        final int n3 = 10;
        val3[n3] *= scale.z;
        return this;
    }
    
    public Mat3D scl(final float x, final float y, final float z) {
        final float[] val = this.val;
        final int n = 0;
        val[n] *= x;
        final float[] val2 = this.val;
        final int n2 = 5;
        val2[n2] *= y;
        final float[] val3 = this.val;
        final int n3 = 10;
        val3[n3] *= z;
        return this;
    }
    
    public Mat3D scl(final float scale) {
        final float[] val = this.val;
        final int n = 0;
        val[n] *= scale;
        final float[] val2 = this.val;
        final int n2 = 5;
        val2[n2] *= scale;
        final float[] val3 = this.val;
        final int n3 = 10;
        val3[n3] *= scale;
        return this;
    }
    
    public Vec3 getTranslation(final Vec3 position) {
        position.x = this.val[12];
        position.y = this.val[13];
        position.z = this.val[14];
        return position;
    }
    
    public Quat getRotation(final Quat rotation, final boolean normalizeAxes) {
        return rotation.setFromMatrix(normalizeAxes, this);
    }
    
    public Quat getRotation(final Quat rotation) {
        return rotation.setFromMatrix(this);
    }
    
    public float getScaleXSquared() {
        return this.val[0] * this.val[0] + this.val[4] * this.val[4] + this.val[8] * this.val[8];
    }
    
    public float getScaleYSquared() {
        return this.val[1] * this.val[1] + this.val[5] * this.val[5] + this.val[9] * this.val[9];
    }
    
    public float getScaleZSquared() {
        return this.val[2] * this.val[2] + this.val[6] * this.val[6] + this.val[10] * this.val[10];
    }
    
    public float getScaleX() {
        return (Mathf.zero(this.val[4]) && Mathf.zero(this.val[8])) ? Math.abs(this.val[0]) : ((float)Math.sqrt(this.getScaleXSquared()));
    }
    
    public float getScaleY() {
        return (Mathf.zero(this.val[1]) && Mathf.zero(this.val[9])) ? Math.abs(this.val[5]) : ((float)Math.sqrt(this.getScaleYSquared()));
    }
    
    public float getScaleZ() {
        return (Mathf.zero(this.val[2]) && Mathf.zero(this.val[6])) ? Math.abs(this.val[10]) : ((float)Math.sqrt(this.getScaleZSquared()));
    }
    
    public Vec3 getScale(final Vec3 scale) {
        return scale.set(this.getScaleX(), this.getScaleY(), this.getScaleZ());
    }
    
    public Mat3D toNormalMatrix() {
        this.val[12] = 0.0f;
        this.val[13] = 0.0f;
        this.val[14] = 0.0f;
        return this.inv().tra();
    }
    
    public static void mul(final float[] mata, final float[] matb) {
        Mat3D.tmp[0] = mata[0] * matb[0] + mata[4] * matb[1] + mata[8] * matb[2] + mata[12] * matb[3];
        Mat3D.tmp[4] = mata[0] * matb[4] + mata[4] * matb[5] + mata[8] * matb[6] + mata[12] * matb[7];
        Mat3D.tmp[8] = mata[0] * matb[8] + mata[4] * matb[9] + mata[8] * matb[10] + mata[12] * matb[11];
        Mat3D.tmp[12] = mata[0] * matb[12] + mata[4] * matb[13] + mata[8] * matb[14] + mata[12] * matb[15];
        Mat3D.tmp[1] = mata[1] * matb[0] + mata[5] * matb[1] + mata[9] * matb[2] + mata[13] * matb[3];
        Mat3D.tmp[5] = mata[1] * matb[4] + mata[5] * matb[5] + mata[9] * matb[6] + mata[13] * matb[7];
        Mat3D.tmp[9] = mata[1] * matb[8] + mata[5] * matb[9] + mata[9] * matb[10] + mata[13] * matb[11];
        Mat3D.tmp[13] = mata[1] * matb[12] + mata[5] * matb[13] + mata[9] * matb[14] + mata[13] * matb[15];
        Mat3D.tmp[2] = mata[2] * matb[0] + mata[6] * matb[1] + mata[10] * matb[2] + mata[14] * matb[3];
        Mat3D.tmp[6] = mata[2] * matb[4] + mata[6] * matb[5] + mata[10] * matb[6] + mata[14] * matb[7];
        Mat3D.tmp[10] = mata[2] * matb[8] + mata[6] * matb[9] + mata[10] * matb[10] + mata[14] * matb[11];
        Mat3D.tmp[14] = mata[2] * matb[12] + mata[6] * matb[13] + mata[10] * matb[14] + mata[14] * matb[15];
        Mat3D.tmp[3] = mata[3] * matb[0] + mata[7] * matb[1] + mata[11] * matb[2] + mata[15] * matb[3];
        Mat3D.tmp[7] = mata[3] * matb[4] + mata[7] * matb[5] + mata[11] * matb[6] + mata[15] * matb[7];
        Mat3D.tmp[11] = mata[3] * matb[8] + mata[7] * matb[9] + mata[11] * matb[10] + mata[15] * matb[11];
        Mat3D.tmp[15] = mata[3] * matb[12] + mata[7] * matb[13] + mata[11] * matb[14] + mata[15] * matb[15];
        System.arraycopy(Mat3D.tmp, 0, mata, 0, 16);
    }
    
    public static void mulVec(final float[] mat, final float[] vec) {
        final float x = vec[0] * mat[0] + vec[1] * mat[4] + vec[2] * mat[8] + mat[12];
        final float y = vec[0] * mat[1] + vec[1] * mat[5] + vec[2] * mat[9] + mat[13];
        final float z = vec[0] * mat[2] + vec[1] * mat[6] + vec[2] * mat[10] + mat[14];
        vec[0] = x;
        vec[1] = y;
        vec[2] = z;
    }
    
    public static void prj(final float[] mat, final float[] vec) {
        final float invw = 1.0f / (vec[0] * mat[3] + vec[1] * mat[7] + vec[2] * mat[11] + mat[15]);
        final float x = (vec[0] * mat[0] + vec[1] * mat[4] + vec[2] * mat[8] + mat[12]) * invw;
        final float y = (vec[0] * mat[1] + vec[1] * mat[5] + vec[2] * mat[9] + mat[13]) * invw;
        final float z = (vec[0] * mat[2] + vec[1] * mat[6] + vec[2] * mat[10] + mat[14]) * invw;
        vec[0] = x;
        vec[1] = y;
        vec[2] = z;
    }
    
    public static void rot(final float[] mat, final float[] vec) {
        final float x = vec[0] * mat[0] + vec[1] * mat[4] + vec[2] * mat[8];
        final float y = vec[0] * mat[1] + vec[1] * mat[5] + vec[2] * mat[9];
        final float z = vec[0] * mat[2] + vec[1] * mat[6] + vec[2] * mat[10];
        vec[0] = x;
        vec[1] = y;
        vec[2] = z;
    }
    
    public static boolean inv(final float[] val) {
        final float ldet = det(val);
        if (ldet == 0.0f) {
            return false;
        }
        Mat3D.tmp[0] = val[9] * val[14] * val[7] - val[13] * val[10] * val[7] + val[13] * val[6] * val[11] - val[5] * val[14] * val[11] - val[9] * val[6] * val[15] + val[5] * val[10] * val[15];
        Mat3D.tmp[4] = val[12] * val[10] * val[7] - val[8] * val[14] * val[7] - val[12] * val[6] * val[11] + val[4] * val[14] * val[11] + val[8] * val[6] * val[15] - val[4] * val[10] * val[15];
        Mat3D.tmp[8] = val[8] * val[13] * val[7] - val[12] * val[9] * val[7] + val[12] * val[5] * val[11] - val[4] * val[13] * val[11] - val[8] * val[5] * val[15] + val[4] * val[9] * val[15];
        Mat3D.tmp[12] = val[12] * val[9] * val[6] - val[8] * val[13] * val[6] - val[12] * val[5] * val[10] + val[4] * val[13] * val[10] + val[8] * val[5] * val[14] - val[4] * val[9] * val[14];
        Mat3D.tmp[1] = val[13] * val[10] * val[3] - val[9] * val[14] * val[3] - val[13] * val[2] * val[11] + val[1] * val[14] * val[11] + val[9] * val[2] * val[15] - val[1] * val[10] * val[15];
        Mat3D.tmp[5] = val[8] * val[14] * val[3] - val[12] * val[10] * val[3] + val[12] * val[2] * val[11] - val[0] * val[14] * val[11] - val[8] * val[2] * val[15] + val[0] * val[10] * val[15];
        Mat3D.tmp[9] = val[12] * val[9] * val[3] - val[8] * val[13] * val[3] - val[12] * val[1] * val[11] + val[0] * val[13] * val[11] + val[8] * val[1] * val[15] - val[0] * val[9] * val[15];
        Mat3D.tmp[13] = val[8] * val[13] * val[2] - val[12] * val[9] * val[2] + val[12] * val[1] * val[10] - val[0] * val[13] * val[10] - val[8] * val[1] * val[14] + val[0] * val[9] * val[14];
        Mat3D.tmp[2] = val[5] * val[14] * val[3] - val[13] * val[6] * val[3] + val[13] * val[2] * val[7] - val[1] * val[14] * val[7] - val[5] * val[2] * val[15] + val[1] * val[6] * val[15];
        Mat3D.tmp[6] = val[12] * val[6] * val[3] - val[4] * val[14] * val[3] - val[12] * val[2] * val[7] + val[0] * val[14] * val[7] + val[4] * val[2] * val[15] - val[0] * val[6] * val[15];
        Mat3D.tmp[10] = val[4] * val[13] * val[3] - val[12] * val[5] * val[3] + val[12] * val[1] * val[7] - val[0] * val[13] * val[7] - val[4] * val[1] * val[15] + val[0] * val[5] * val[15];
        Mat3D.tmp[14] = val[12] * val[5] * val[2] - val[4] * val[13] * val[2] - val[12] * val[1] * val[6] + val[0] * val[13] * val[6] + val[4] * val[1] * val[14] - val[0] * val[5] * val[14];
        Mat3D.tmp[3] = val[9] * val[6] * val[3] - val[5] * val[10] * val[3] - val[9] * val[2] * val[7] + val[1] * val[10] * val[7] + val[5] * val[2] * val[11] - val[1] * val[6] * val[11];
        Mat3D.tmp[7] = val[4] * val[10] * val[3] - val[8] * val[6] * val[3] + val[8] * val[2] * val[7] - val[0] * val[10] * val[7] - val[4] * val[2] * val[11] + val[0] * val[6] * val[11];
        Mat3D.tmp[11] = val[8] * val[5] * val[3] - val[4] * val[9] * val[3] - val[8] * val[1] * val[7] + val[0] * val[9] * val[7] + val[4] * val[1] * val[11] - val[0] * val[5] * val[11];
        Mat3D.tmp[15] = val[4] * val[9] * val[2] - val[8] * val[5] * val[2] + val[8] * val[1] * val[6] - val[0] * val[9] * val[6] - val[4] * val[1] * val[10] + val[0] * val[5] * val[10];
        final float inv_det = 1.0f / ldet;
        val[0] = Mat3D.tmp[0] * inv_det;
        val[4] = Mat3D.tmp[4] * inv_det;
        val[8] = Mat3D.tmp[8] * inv_det;
        val[12] = Mat3D.tmp[12] * inv_det;
        val[1] = Mat3D.tmp[1] * inv_det;
        val[5] = Mat3D.tmp[5] * inv_det;
        val[9] = Mat3D.tmp[9] * inv_det;
        val[13] = Mat3D.tmp[13] * inv_det;
        val[2] = Mat3D.tmp[2] * inv_det;
        val[6] = Mat3D.tmp[6] * inv_det;
        val[10] = Mat3D.tmp[10] * inv_det;
        val[14] = Mat3D.tmp[14] * inv_det;
        val[3] = Mat3D.tmp[3] * inv_det;
        val[7] = Mat3D.tmp[7] * inv_det;
        val[11] = Mat3D.tmp[11] * inv_det;
        val[15] = Mat3D.tmp[15] * inv_det;
        return true;
    }
    
    public static float det(final float[] val) {
        return val[3] * val[6] * val[9] * val[12] - val[2] * val[7] * val[9] * val[12] - val[3] * val[5] * val[10] * val[12] + val[1] * val[7] * val[10] * val[12] + val[2] * val[5] * val[11] * val[12] - val[1] * val[6] * val[11] * val[12] - val[3] * val[6] * val[8] * val[13] + val[2] * val[7] * val[8] * val[13] + val[3] * val[4] * val[10] * val[13] - val[0] * val[7] * val[10] * val[13] - val[2] * val[4] * val[11] * val[13] + val[0] * val[6] * val[11] * val[13] + val[3] * val[5] * val[8] * val[14] - val[1] * val[7] * val[8] * val[14] - val[3] * val[4] * val[9] * val[14] + val[0] * val[7] * val[9] * val[14] + val[1] * val[4] * val[11] * val[14] - val[0] * val[5] * val[11] * val[14] - val[2] * val[5] * val[8] * val[15] + val[1] * val[6] * val[8] * val[15] + val[2] * val[4] * val[9] * val[15] - val[0] * val[6] * val[9] * val[15] - val[1] * val[4] * val[10] * val[15] + val[0] * val[5] * val[10] * val[15];
    }
    
    public Mat3D translate(final Vec3 translation) {
        return this.translate(translation.x, translation.y, translation.z);
    }
    
    public Mat3D translate(final float x, final float y, final float z) {
        Mat3D.tmp[0] = 1.0f;
        Mat3D.tmp[4] = 0.0f;
        Mat3D.tmp[8] = 0.0f;
        Mat3D.tmp[12] = x;
        Mat3D.tmp[1] = 0.0f;
        Mat3D.tmp[5] = 1.0f;
        Mat3D.tmp[9] = 0.0f;
        Mat3D.tmp[13] = y;
        Mat3D.tmp[2] = 0.0f;
        Mat3D.tmp[6] = 0.0f;
        Mat3D.tmp[10] = 1.0f;
        Mat3D.tmp[14] = z;
        Mat3D.tmp[3] = 0.0f;
        Mat3D.tmp[7] = 0.0f;
        Mat3D.tmp[11] = 0.0f;
        Mat3D.tmp[15] = 1.0f;
        mul(this.val, Mat3D.tmp);
        return this;
    }
    
    public Mat3D rotate(final Vec3 axis, final float degrees) {
        if (degrees == 0.0f) {
            return this;
        }
        Mat3D.quat.set(axis, degrees);
        return this.rotate(Mat3D.quat);
    }
    
    public Mat3D rotateRad(final Vec3 axis, final float radians) {
        if (radians == 0.0f) {
            return this;
        }
        Mat3D.quat.setFromAxisRad(axis, radians);
        return this.rotate(Mat3D.quat);
    }
    
    public Mat3D rotate(final float axisX, final float axisY, final float axisZ, final float degrees) {
        if (degrees == 0.0f) {
            return this;
        }
        Mat3D.quat.setFromAxis(axisX, axisY, axisZ, degrees);
        return this.rotate(Mat3D.quat);
    }
    
    public Mat3D rotateRad(final float axisX, final float axisY, final float axisZ, final float radians) {
        if (radians == 0.0f) {
            return this;
        }
        Mat3D.quat.setFromAxisRad(axisX, axisY, axisZ, radians);
        return this.rotate(Mat3D.quat);
    }
    
    public Mat3D rotate(final Quat rotation) {
        rotation.toMatrix(Mat3D.tmp);
        mul(this.val, Mat3D.tmp);
        return this;
    }
    
    public Mat3D rotate(final Vec3 v1, final Vec3 v2) {
        return this.rotate(Mat3D.quat.setFromCross(v1, v2));
    }
    
    public Mat3D scale(final float scaleX, final float scaleY, final float scaleZ) {
        Mat3D.tmp[0] = scaleX;
        Mat3D.tmp[4] = 0.0f;
        Mat3D.tmp[8] = 0.0f;
        Mat3D.tmp[12] = 0.0f;
        Mat3D.tmp[1] = 0.0f;
        Mat3D.tmp[5] = scaleY;
        Mat3D.tmp[9] = 0.0f;
        Mat3D.tmp[13] = 0.0f;
        Mat3D.tmp[2] = 0.0f;
        Mat3D.tmp[6] = 0.0f;
        Mat3D.tmp[10] = scaleZ;
        Mat3D.tmp[14] = 0.0f;
        Mat3D.tmp[3] = 0.0f;
        Mat3D.tmp[7] = 0.0f;
        Mat3D.tmp[11] = 0.0f;
        Mat3D.tmp[15] = 1.0f;
        mul(this.val, Mat3D.tmp);
        return this;
    }
    
    public void extract4x3Matrix(final float[] dst) {
        dst[0] = this.val[0];
        dst[1] = this.val[1];
        dst[2] = this.val[2];
        dst[3] = this.val[4];
        dst[4] = this.val[5];
        dst[5] = this.val[6];
        dst[6] = this.val[8];
        dst[7] = this.val[9];
        dst[8] = this.val[10];
        dst[9] = this.val[12];
        dst[10] = this.val[13];
        dst[11] = this.val[14];
    }
    
    public boolean hasRotationOrScaling() {
        return !Mathf.equal(this.val[0], 1.0f) || !Mathf.equal(this.val[5], 1.0f) || !Mathf.equal(this.val[10], 1.0f) || !Mathf.zero(this.val[4]) || !Mathf.zero(this.val[8]) || !Mathf.zero(this.val[1]) || !Mathf.zero(this.val[9]) || !Mathf.zero(this.val[2]) || !Mathf.zero(this.val[6]);
    }
    
    public static Vec3 prj(final Vec3 v, final Mat3D matrix) {
        final float[] lmat = matrix.val;
        final float lw = 1.0f / (v.x * lmat[3] + v.y * lmat[7] + v.z * lmat[11] + lmat[15]);
        return v.set((v.x * lmat[0] + v.y * lmat[4] + v.z * lmat[8] + lmat[12]) * lw, (v.x * lmat[1] + v.y * lmat[5] + v.z * lmat[9] + lmat[13]) * lw, (v.x * lmat[2] + v.y * lmat[6] + v.z * lmat[10] + lmat[14]) * lw);
    }
    
    public static Vec3 rot(final Vec3 v, final Mat3D matrix) {
        final float[] lmat = matrix.val;
        return v.set(v.x * lmat[0] + v.y * lmat[4] + v.z * lmat[8], v.x * lmat[1] + v.y * lmat[5] + v.z * lmat[9], v.x * lmat[2] + v.y * lmat[6] + v.z * lmat[10]);
    }
    
    public static Vec3 unrotate(final Vec3 v, final Mat3D matrix) {
        final float[] lmat = matrix.val;
        return v.set(v.x * lmat[0] + v.y * lmat[1] + v.z * lmat[2], v.x * lmat[4] + v.y * lmat[5] + v.z * lmat[6], v.x * lmat[8] + v.y * lmat[9] + v.z * lmat[10]);
    }
    
    public static Vec3 untransform(final Vec3 v, final Mat3D matrix) {
        final float[] lmat = matrix.val;
        v.x -= lmat[12];
        v.y -= lmat[12];
        v.z -= lmat[12];
        return v.set(v.x * lmat[0] + v.y * lmat[1] + v.z * lmat[2], v.x * lmat[4] + v.y * lmat[5] + v.z * lmat[6], v.x * lmat[8] + v.y * lmat[9] + v.z * lmat[10]);
    }
    
    static {
        tmp = new float[16];
        Mat3D.quat = new Quat();
        Mat3D.quat2 = new Quat();
        l_vez = new Vec3();
        l_vex = new Vec3();
        l_vey = new Vec3();
        tmpVec = new Vec3();
        tmpMat = new Mat3D();
        right = new Vec3();
        tmpForward = new Vec3();
        tmpUp = new Vec3();
    }
}
