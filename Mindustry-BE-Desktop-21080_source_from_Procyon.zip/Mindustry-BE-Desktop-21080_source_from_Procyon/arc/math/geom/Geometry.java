// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

import arc.func.Floatc4;
import arc.func.Floatc2;
import arc.struct.IntSeq;
import java.util.Iterator;
import arc.struct.FloatSeq;
import arc.struct.Seq;
import arc.func.Intc2;
import arc.math.Mathf;

public final class Geometry
{
    public static final Point2[] d4;
    public static final Point2[] d4c;
    public static final int[] d4x;
    public static final int[] d4y;
    public static final Point2[] d8;
    public static final Point2[] d8edge;
    private static final Vec2 tmp1;
    private static final Vec2 tmp2;
    private static final Vec2 tmp3;
    
    public static Point2 d4(final int i) {
        return Geometry.d4[Mathf.mod(i, 4)];
    }
    
    public static int d4x(final int i) {
        return Geometry.d4x[Mathf.mod(i, 4)];
    }
    
    public static int d4y(final int i) {
        return Geometry.d4y[Mathf.mod(i, 4)];
    }
    
    public static Point2 d8(final int i) {
        return Geometry.d8[Mathf.mod(i, 8)];
    }
    
    public static Point2 d8edge(final int i) {
        return Geometry.d8edge[Mathf.mod(i, 4)];
    }
    
    public static void circle(final int x, final int y, final int radius, final Intc2 cons) {
        for (int dx = -radius; dx <= radius; ++dx) {
            for (int dy = -radius; dy <= radius; ++dy) {
                if (Mathf.within((float)dx, (float)dy, (float)radius)) {
                    cons.get(dx + x, dy + y);
                }
            }
        }
    }
    
    public static void circle(final int x, final int y, final int width, final int height, final int radius, final Intc2 cons) {
        for (int dx = -radius; dx <= radius; ++dx) {
            for (int dy = -radius; dy <= radius; ++dy) {
                final int wx = dx + x;
                final int wy = dy + y;
                if (wx >= 0 && wy >= 0 && wx < width && wy < height && Mathf.within((float)dx, (float)dy, (float)radius)) {
                    cons.get(wx, wy);
                }
            }
        }
    }
    
    public static FloatSeq vectorsToFloats(final Seq<Vec2> result) {
        final FloatSeq out = new FloatSeq(result.size * 2);
        result.each(v -> out.add(v.x, v.y));
        return out;
    }
    
    public static <T extends Position> T findClosest(final float x, final float y, final T[] list) {
        T closest = null;
        float cdist = 0.0f;
        for (final T t : list) {
            final float dst = t.dst(x, y);
            if (closest == null || dst < cdist) {
                closest = t;
                cdist = dst;
            }
        }
        return closest;
    }
    
    public static <T extends Position> T findClosest(final float x, final float y, final Iterable<T> list) {
        T closest = null;
        float cdist = 0.0f;
        for (final T t : list) {
            final float dst = t.dst(x, y);
            if (closest == null || dst < cdist) {
                closest = t;
                cdist = dst;
            }
        }
        return closest;
    }
    
    public static <T extends Position> T findFurthest(final float x, final float y, final Iterable<T> list) {
        T closest = null;
        float cdist = 0.0f;
        for (final T t : list) {
            final float dst = t.dst(x, y);
            if (closest == null || dst > cdist) {
                closest = t;
                cdist = dst;
            }
        }
        return closest;
    }
    
    public static Vec2[] pixelCircle(final float tindex) {
        return pixelCircle(tindex, (index, x, y) -> Mathf.dst((float)x, (float)y, index, index) < index - 0.5f);
    }
    
    public static Vec2[] pixelCircle(final float index, final SolidChecker checker) {
        final int size = (int)(index * 2.0f);
        final IntSeq ints = new IntSeq();
        for (int x = -1; x < size + 1; ++x) {
            for (int y = -1; y < size + 1; ++y) {
                if ((checker.solid(index, x, y) || checker.solid(index, x - 1, y) || checker.solid(index, x, y - 1) || checker.solid(index, x - 1, y - 1)) && (!checker.solid(index, x, y) || !checker.solid(index, x - 1, y) || !checker.solid(index, x, y - 1) || !checker.solid(index, x - 1, y - 1))) {
                    ints.add(x + y * (size + 1));
                }
            }
        }
        final Seq<Vec2> path = new Seq<Vec2>();
        int cindex = 0;
        while (ints.size > 0) {
            final int x2 = ints.get(cindex) % (size + 1);
            final int y2 = ints.get(cindex) / (size + 1);
            path.add(new Vec2((float)(x2 - size / 2), (float)(y2 - size / 2)));
            ints.removeIndex(cindex);
            for (int i = 0; i < ints.size; ++i) {
                final int x3 = ints.get(i) % (size + 1);
                final int y3 = ints.get(i) / (size + 1);
                if (Math.abs(x3 - x2) <= 1 && Math.abs(y3 - y2) <= 1 && (Math.abs(x3 - x2) != 1 || Math.abs(y3 - y2) != 1)) {
                    cindex = i;
                    break;
                }
            }
        }
        return path.toArray(Vec2.class);
    }
    
    public static float[] regPoly(final int amount, final float size) {
        final float[] v = new float[amount * 2];
        final Vec2 vec = new Vec2(1.0f, 1.0f);
        vec.setLength(size);
        for (int i = 0; i < amount; ++i) {
            vec.setAngle(360.0f / amount * i + 90.0f);
            v[i * 2] = vec.x;
            v[i * 2 + 1] = vec.y;
        }
        return v;
    }
    
    public static float iterateLine(final float start, final float x1, final float y1, final float x2, final float y2, final float segment, final Floatc2 pos) {
        final float len = Mathf.dst(x1, y1, x2, y2);
        final int steps = (int)(len / segment);
        final float step = 1.0f / steps;
        float offset = len;
        Geometry.tmp2.set(x2, y2);
        for (int i = 0; i < steps; ++i) {
            final float s = step * i;
            Geometry.tmp1.set(x1, y1);
            Geometry.tmp1.lerp(Geometry.tmp2, s);
            pos.get(Geometry.tmp1.x, Geometry.tmp1.y);
            offset -= step;
        }
        return offset;
    }
    
    public static void iteratePolySegments(final float[] vertices, final Floatc4 it) {
        for (int i = 0; i < vertices.length; i += 2) {
            final float x = vertices[i];
            final float y = vertices[i + 1];
            float x2;
            float y2;
            if (i == vertices.length - 2) {
                x2 = vertices[0];
                y2 = vertices[1];
            }
            else {
                x2 = vertices[i + 2];
                y2 = vertices[i + 3];
            }
            it.get(x, y, x2, y2);
        }
    }
    
    public static void iteratePolygon(final Floatc2 path, final float[] vertices) {
        for (int i = 0; i < vertices.length; i += 2) {
            final float x = vertices[i];
            final float y = vertices[i + 1];
            path.get(x, y);
        }
    }
    
    public static Point2[] getD4Points() {
        return Geometry.d4;
    }
    
    public static Point2[] getD8Points() {
        return Geometry.d8;
    }
    
    public static Point2[] getD8EdgePoints() {
        return Geometry.d8edge;
    }
    
    public static boolean raycast(final int x0f, final int y0f, final int x1, final int y1, final Raycaster cons) {
        int x2 = x0f;
        int y2 = y0f;
        final int dx = Math.abs(x1 - x2);
        final int dy = Math.abs(y1 - y2);
        final int sx = (x2 < x1) ? 1 : -1;
        final int sy = (y2 < y1) ? 1 : -1;
        int err = dx - dy;
        while (!cons.accept(x2, y2)) {
            if (x2 == x1 && y2 == y1) {
                return false;
            }
            final int e2 = 2 * err;
            if (e2 > -dy) {
                err -= dy;
                x2 += sx;
            }
            if (e2 >= dx) {
                continue;
            }
            err += dx;
            y2 += sy;
        }
        return true;
    }
    
    public static Vec2 raycastRect(final float startx, final float starty, final float endx, final float endy, final Rect rect) {
        return raycastRect(startx, starty, endx, endy, rect.x + rect.width / 2.0f, rect.y + rect.height / 2.0f, rect.width / 2.0f, rect.height / 2.0f);
    }
    
    public static Vec2 raycastRect(final float startx, final float starty, final float endx, final float endy, final float x, final float y, final float halfx, final float halfy) {
        final float deltax = endx - startx;
        final float deltay = endy - starty;
        final Vec2 hit = Geometry.tmp1;
        final float paddingX = 0.0f;
        final float paddingY = 0.0f;
        final float scaleX = 1.0f / deltax;
        final float scaleY = 1.0f / deltay;
        final int signX = Mathf.sign(scaleX);
        final int signY = Mathf.sign(scaleY);
        final float nearTimeX = (x - signX * (halfx + paddingX) - startx) * scaleX;
        final float nearTimeY = (y - signY * (halfy + paddingY) - starty) * scaleY;
        final float farTimeX = (x + signX * (halfx + paddingX) - startx) * scaleX;
        final float farTimeY = (y + signY * (halfy + paddingY) - starty) * scaleY;
        if (nearTimeX > farTimeY || nearTimeY > farTimeX) {
            return null;
        }
        final float nearTime = Math.max(nearTimeX, nearTimeY);
        final float farTime = Math.min(farTimeX, farTimeY);
        if (nearTime >= 1.0f || farTime <= 0.0f) {
            return null;
        }
        final float htime = Mathf.clamp(nearTime);
        final float hdeltax = htime * deltax;
        final float hdeltay = htime * deltay;
        hit.x = startx + hdeltax;
        hit.y = starty + hdeltay;
        return hit;
    }
    
    public static Vec2 overlap(final Rect a, final Rect b, final boolean x) {
        float penetration = 0.0f;
        final float ax = a.x + a.width / 2.0f;
        final float bx = b.x + b.width / 2.0f;
        final float ay = a.y + a.height / 2.0f;
        final float by = b.y + b.height / 2.0f;
        final float nx = ax - bx;
        final float ny = ay - by;
        final float aex = a.width / 2.0f;
        final float bex = b.width / 2.0f;
        final float xoverlap = aex + bex - Math.abs(nx);
        if (Math.abs(xoverlap) > 0.0f) {
            final float aey = a.height / 2.0f;
            final float bey = b.height / 2.0f;
            final float yoverlap = aey + bey - Math.abs(ny);
            if (Math.abs(yoverlap) > 0.0f) {
                if (Math.abs(xoverlap) < Math.abs(yoverlap)) {
                    Geometry.tmp1.x = ((nx < 0.0f) ? 1.0f : -1.0f);
                    Geometry.tmp1.y = 0.0f;
                    penetration = xoverlap;
                }
                else {
                    Geometry.tmp1.x = 0.0f;
                    Geometry.tmp1.y = ((ny < 0.0f) ? 1.0f : -1.0f);
                    penetration = yoverlap;
                }
            }
        }
        final float m = Math.max(penetration, 0.0f);
        final float cx = m * Geometry.tmp1.x;
        final float cy = m * Geometry.tmp1.y;
        Geometry.tmp1.x = -cx;
        Geometry.tmp1.y = -cy;
        return Geometry.tmp1;
    }
    
    public static Vec2 toBarycoord(final Vec2 p, final Vec2 a, final Vec2 b, final Vec2 c, final Vec2 barycentricOut) {
        final Vec2 v0 = Geometry.tmp1.set(b).sub(a);
        final Vec2 v2 = Geometry.tmp2.set(c).sub(a);
        final Vec2 v3 = Geometry.tmp3.set(p).sub(a);
        final float d00 = v0.dot(v0);
        final float d2 = v0.dot(v2);
        final float d3 = v2.dot(v2);
        final float d4 = v3.dot(v0);
        final float d5 = v3.dot(v2);
        final float denom = d00 * d3 - d2 * d2;
        barycentricOut.x = (d3 * d4 - d2 * d5) / denom;
        barycentricOut.y = (d00 * d5 - d2 * d4) / denom;
        return barycentricOut;
    }
    
    public static boolean barycoordInsideTriangle(final Vec2 barycentric) {
        return barycentric.x >= 0.0f && barycentric.y >= 0.0f && barycentric.x + barycentric.y <= 1.0f;
    }
    
    public static Vec2 fromBarycoord(final Vec2 barycentric, final Vec2 a, final Vec2 b, final Vec2 c, final Vec2 interpolatedOut) {
        final float u = 1.0f - barycentric.x - barycentric.y;
        interpolatedOut.x = u * a.x + barycentric.x * b.x + barycentric.y * c.x;
        interpolatedOut.y = u * a.y + barycentric.x * b.y + barycentric.y * c.y;
        return interpolatedOut;
    }
    
    public static float fromBarycoord(final Vec2 barycentric, final float a, final float b, final float c) {
        final float u = 1.0f - barycentric.x - barycentric.y;
        return u * a + barycentric.x * b + barycentric.y * c;
    }
    
    public static float lowestPositiveRoot(final float a, final float b, final float c) {
        final float det = b * b - 4.0f * a * c;
        if (det < 0.0f) {
            return Float.NaN;
        }
        final float sqrtD = (float)Math.sqrt(det);
        final float invA = 1.0f / (2.0f * a);
        float r1 = (-b - sqrtD) * invA;
        float r2 = (-b + sqrtD) * invA;
        if (r1 > r2) {
            final float tmp = r2;
            r2 = r1;
            r1 = tmp;
        }
        if (r1 > 0.0f) {
            return r1;
        }
        if (r2 > 0.0f) {
            return r2;
        }
        return Float.NaN;
    }
    
    public static boolean colinear(final float x1, final float y1, final float x2, final float y2, final float x3, final float y3) {
        final float dx21 = x2 - x1;
        final float dy21 = y2 - y1;
        final float dx22 = x3 - x2;
        final float dy22 = y3 - y2;
        final float det = dx22 * dy21 - dx21 * dy22;
        return Math.abs(det) < 1.0E-6f;
    }
    
    public static Vec2 triangleCentroid(final float x1, final float y1, final float x2, final float y2, final float x3, final float y3, final Vec2 centroid) {
        centroid.x = (x1 + x2 + x3) / 3.0f;
        centroid.y = (y1 + y2 + y3) / 3.0f;
        return centroid;
    }
    
    public static Vec2 triangleCircumcenter(final float x1, final float y1, final float x2, final float y2, final float x3, final float y3, final Vec2 circumcenter) {
        final float dx21 = x2 - x1;
        final float dy21 = y2 - y1;
        final float dx22 = x3 - x2;
        final float dy22 = y3 - y2;
        final float dx23 = x1 - x3;
        final float dy23 = y1 - y3;
        float det = dx22 * dy21 - dx21 * dy22;
        if (Math.abs(det) < 1.0E-6f) {
            throw new IllegalArgumentException("Triangle points must not be colinear.");
        }
        det *= 2.0f;
        final float sqr1 = x1 * x1 + y1 * y1;
        final float sqr2 = x2 * x2 + y2 * y2;
        final float sqr3 = x3 * x3 + y3 * y3;
        circumcenter.set((sqr1 * dy22 + sqr2 * dy23 + sqr3 * dy21) / det, -(sqr1 * dx22 + sqr2 * dx23 + sqr3 * dx21) / det);
        return circumcenter;
    }
    
    public static float triangleCircumradius(final float x1, final float y1, final float x2, final float y2, final float x3, final float y3) {
        float x4;
        float y4;
        if (Math.abs(y2 - y1) < 1.0E-6f) {
            final float m2 = -(x3 - x2) / (y3 - y2);
            final float mx2 = (x2 + x3) / 2.0f;
            final float my2 = (y2 + y3) / 2.0f;
            x4 = (x2 + x1) / 2.0f;
            y4 = m2 * (x4 - mx2) + my2;
        }
        else if (Math.abs(y3 - y2) < 1.0E-6f) {
            final float m3 = -(x2 - x1) / (y2 - y1);
            final float mx3 = (x1 + x2) / 2.0f;
            final float my3 = (y1 + y2) / 2.0f;
            x4 = (x3 + x2) / 2.0f;
            y4 = m3 * (x4 - mx3) + my3;
        }
        else {
            final float m3 = -(x2 - x1) / (y2 - y1);
            final float m2 = -(x3 - x2) / (y3 - y2);
            final float mx3 = (x1 + x2) / 2.0f;
            final float mx2 = (x2 + x3) / 2.0f;
            final float my3 = (y1 + y2) / 2.0f;
            final float my2 = (y2 + y3) / 2.0f;
            x4 = (m3 * mx3 - m2 * mx2 + my2 - my3) / (m3 - m2);
            y4 = m3 * (x4 - mx3) + my3;
        }
        final float dx = x1 - x4;
        final float dy = y1 - y4;
        return (float)Math.sqrt(dx * dx + dy * dy);
    }
    
    public static float triangleQuality(final float x1, final float y1, final float x2, final float y2, final float x3, final float y3) {
        final float length1 = (float)Math.sqrt(x1 * x1 + y1 * y1);
        final float length2 = (float)Math.sqrt(x2 * x2 + y2 * y2);
        final float length3 = (float)Math.sqrt(x3 * x3 + y3 * y3);
        return Math.min(length1, Math.min(length2, length3)) / triangleCircumradius(x1, y1, x2, y2, x3, y3);
    }
    
    public static float triangleArea(final float x1, final float y1, final float x2, final float y2, final float x3, final float y3) {
        return Math.abs((x1 - x3) * (y2 - y1) - (x1 - x2) * (y3 - y1)) * 0.5f;
    }
    
    public static Vec2 quadrilateralCentroid(final float x1, final float y1, final float x2, final float y2, final float x3, final float y3, final float x4, final float y4, final Vec2 centroid) {
        final float avgX1 = (x1 + x2 + x3) / 3.0f;
        final float avgY1 = (y1 + y2 + y3) / 3.0f;
        final float avgX2 = (x1 + x4 + x3) / 3.0f;
        final float avgY2 = (y1 + y4 + y3) / 3.0f;
        centroid.x = avgX1 - (avgX1 - avgX2) / 2.0f;
        centroid.y = avgY1 - (avgY1 - avgY2) / 2.0f;
        return centroid;
    }
    
    public static Vec2 polygonCentroid(final float[] polygon, final int offset, final int count, final Vec2 centroid) {
        if (count < 6) {
            throw new IllegalArgumentException("A polygon must have 3 or more coordinate pairs.");
        }
        float x = 0.0f;
        float y = 0.0f;
        float signedArea = 0.0f;
        int i = offset;
        for (int n = offset + count - 2; i < n; i += 2) {
            final float x2 = polygon[i];
            final float y2 = polygon[i + 1];
            final float x3 = polygon[i + 2];
            final float y3 = polygon[i + 3];
            final float a = x2 * y3 - x3 * y2;
            signedArea += a;
            x += (x2 + x3) * a;
            y += (y2 + y3) * a;
        }
        final float x4 = polygon[i];
        final float y4 = polygon[i + 1];
        final float x5 = polygon[offset];
        final float y5 = polygon[offset + 1];
        final float a2 = x4 * y5 - x5 * y4;
        signedArea += a2;
        x += (x4 + x5) * a2;
        y += (y4 + y5) * a2;
        if (signedArea == 0.0f) {
            centroid.x = 0.0f;
            centroid.y = 0.0f;
        }
        else {
            signedArea *= 0.5f;
            centroid.x = x / (6.0f * signedArea);
            centroid.y = y / (6.0f * signedArea);
        }
        return centroid;
    }
    
    public static float polygonArea(final float[] polygon, final int offset, final int count) {
        float area = 0.0f;
        for (int i = offset, n = offset + count; i < n; i += 2) {
            final int y1 = i + 1;
            int x2 = (i + 2) % n;
            if (x2 < offset) {
                x2 += offset;
            }
            int y2 = (i + 3) % n;
            if (y2 < offset) {
                y2 += offset;
            }
            area += polygon[i] * polygon[y2];
            area -= polygon[x2] * polygon[y1];
        }
        area *= 0.5f;
        return area;
    }
    
    public static void ensureCCW(final float[] polygon) {
        ensureCCW(polygon, 0, polygon.length);
    }
    
    public static void ensureCCW(final float[] polygon, final int offset, final int count) {
        if (!isClockwise(polygon, offset, count)) {
            return;
        }
        final int lastX = offset + count - 2;
        for (int i = offset, n = offset + count / 2; i < n; i += 2) {
            final int other = lastX - i;
            final float x = polygon[i];
            final float y = polygon[i + 1];
            polygon[i] = polygon[other];
            polygon[i + 1] = polygon[other + 1];
            polygon[other] = x;
            polygon[other + 1] = y;
        }
    }
    
    public static boolean isClockwise(final float[] polygon, final int offset, final int count) {
        if (count <= 2) {
            return false;
        }
        float area = 0.0f;
        for (int i = offset, n = offset + count - 3; i < n; i += 2) {
            final float p1x = polygon[i];
            final float p1y = polygon[i + 1];
            final float p2x = polygon[i + 2];
            final float p2y = polygon[i + 3];
            area += p1x * p2y - p2x * p1y;
        }
        final float p1x = polygon[offset + count - 2];
        final float p1y = polygon[offset + count - 1];
        final float p2x = polygon[offset];
        final float p2y = polygon[offset + 1];
        return area + p1x * p2y - p2x * p1y < 0.0f;
    }
    
    static {
        d4 = new Point2[] { new Point2(1, 0), new Point2(0, 1), new Point2(-1, 0), new Point2(0, -1) };
        d4c = new Point2[] { new Point2(1, 0), new Point2(0, 1), new Point2(-1, 0), new Point2(0, -1), new Point2(0, 0) };
        d4x = new int[] { 1, 0, -1, 0 };
        d4y = new int[] { 0, 1, 0, -1 };
        d8 = new Point2[] { new Point2(1, 0), new Point2(1, 1), new Point2(0, 1), new Point2(-1, 1), new Point2(-1, 0), new Point2(-1, -1), new Point2(0, -1), new Point2(1, -1) };
        d8edge = new Point2[] { new Point2(1, 1), new Point2(-1, 1), new Point2(-1, -1), new Point2(1, -1) };
        tmp1 = new Vec2();
        tmp2 = new Vec2();
        tmp3 = new Vec2();
    }
    
    public interface SolidChecker
    {
        boolean solid(final float p0, final int p1, final int p2);
    }
    
    public interface Raycaster
    {
        boolean accept(final int p0, final int p1);
    }
}
