// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

public class Point2
{
    public int x;
    public int y;
    
    public Point2() {
    }
    
    public Point2(final int x, final int y) {
        this.x = x;
        this.y = y;
    }
    
    public Point2(final Point2 point) {
        this.x = point.x;
        this.y = point.y;
    }
    
    public static Point2 unpack(final int pos) {
        return new Point2((short)(pos >>> 16), (short)(pos & 0xFFFF));
    }
    
    public static int pack(final int x, final int y) {
        return (short)x << 16 | ((short)y & 0xFFFF);
    }
    
    public static short x(final int pos) {
        return (short)(pos >>> 16);
    }
    
    public static short y(final int pos) {
        return (short)(pos & 0xFFFF);
    }
    
    public int pack() {
        return pack(this.x, this.y);
    }
    
    public Point2 set(final Point2 point) {
        this.x = point.x;
        this.y = point.y;
        return this;
    }
    
    public Point2 set(final int x, final int y) {
        this.x = x;
        this.y = y;
        return this;
    }
    
    public float dst2(final Point2 other) {
        final int xd = other.x - this.x;
        final int yd = other.y - this.y;
        return (float)(xd * xd + yd * yd);
    }
    
    public float dst2(final int x, final int y) {
        final int xd = x - this.x;
        final int yd = y - this.y;
        return (float)(xd * xd + yd * yd);
    }
    
    public float dst(final Point2 other) {
        final int xd = other.x - this.x;
        final int yd = other.y - this.y;
        return (float)Math.sqrt(xd * xd + yd * yd);
    }
    
    public float dst(final int x, final int y) {
        final int xd = x - this.x;
        final int yd = y - this.y;
        return (float)Math.sqrt(xd * xd + yd * yd);
    }
    
    public Point2 add(final Point2 other) {
        this.x += other.x;
        this.y += other.y;
        return this;
    }
    
    public Point2 add(final int x, final int y) {
        this.x += x;
        this.y += y;
        return this;
    }
    
    public Point2 sub(final Point2 other) {
        this.x -= other.x;
        this.y -= other.y;
        return this;
    }
    
    public Point2 sub(final int x, final int y) {
        this.x -= x;
        this.y -= y;
        return this;
    }
    
    public Point2 cpy() {
        return new Point2(this);
    }
    
    public Point2 rotate(final int steps) {
        for (int i = 0; i < Math.abs(steps); ++i) {
            final int x = this.x;
            if (steps >= 0) {
                this.x = -this.y;
                this.y = x;
            }
            else {
                this.x = this.y;
                this.y = -x;
            }
        }
        return this;
    }
    
    public boolean equals(final int x, final int y) {
        return this.x == x && this.y == y;
    }
    
    public static boolean equals(final int x, final int y, final int ox, final int oy) {
        return x == ox && y == oy;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }
        final Point2 g = (Point2)o;
        return this.x == g.x && this.y == g.y;
    }
    
    @Override
    public int hashCode() {
        return this.x * 49471 + this.y * 37345;
    }
    
    @Override
    public String toString() {
        return "(" + this.x + ", " + this.y + ")";
    }
}
