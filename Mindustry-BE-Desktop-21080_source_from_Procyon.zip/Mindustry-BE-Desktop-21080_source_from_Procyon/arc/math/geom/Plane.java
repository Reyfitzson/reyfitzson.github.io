// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

public class Plane
{
    public final Vec3 normal;
    public float d;
    
    public Plane() {
        this.normal = new Vec3();
        this.d = 0.0f;
    }
    
    public Plane(final Vec3 normal, final float d) {
        this.normal = new Vec3();
        this.d = 0.0f;
        this.normal.set(normal).nor();
        this.d = d;
    }
    
    public Plane(final Vec3 normal, final Vec3 point) {
        this.normal = new Vec3();
        this.d = 0.0f;
        this.normal.set(normal).nor();
        this.d = -this.normal.dot(point);
    }
    
    public Plane(final Vec3 point1, final Vec3 point2, final Vec3 point3) {
        this.normal = new Vec3();
        this.d = 0.0f;
        this.set(point1, point2, point3);
    }
    
    public void set(final Vec3 point1, final Vec3 point2, final Vec3 point3) {
        this.normal.set(point1).sub(point2).crs(point2.x - point3.x, point2.y - point3.y, point2.z - point3.z).nor();
        this.d = -point1.dot(this.normal);
    }
    
    public void set(final float nx, final float ny, final float nz, final float d) {
        this.normal.set(nx, ny, nz);
        this.d = d;
    }
    
    public Vec3 project(final Vec3 v) {
        final float npd = this.normal.dot(v) + this.d;
        return v.sub(npd * this.normal.x, npd * this.normal.y, npd * this.normal.z);
    }
    
    public float distance(final Vec3 point) {
        return this.normal.dot(point) + this.d;
    }
    
    public PlaneSide testPoint(final Vec3 point) {
        final float dist = this.normal.dot(point) + this.d;
        if (dist == 0.0f) {
            return PlaneSide.onPlane;
        }
        if (dist < 0.0f) {
            return PlaneSide.back;
        }
        return PlaneSide.front;
    }
    
    public PlaneSide testPoint(final float x, final float y, final float z) {
        final float dist = this.normal.dot(x, y, z) + this.d;
        if (dist == 0.0f) {
            return PlaneSide.onPlane;
        }
        if (dist < 0.0f) {
            return PlaneSide.back;
        }
        return PlaneSide.front;
    }
    
    public boolean isFrontFacing(final Vec3 direction) {
        final float dot = this.normal.dot(direction);
        return dot <= 0.0f;
    }
    
    public Vec3 getNormal() {
        return this.normal;
    }
    
    public float getD() {
        return this.d;
    }
    
    public void set(final Vec3 point, final Vec3 normal) {
        this.normal.set(normal);
        this.d = -point.dot(normal);
    }
    
    public void set(final float pointX, final float pointY, final float pointZ, final float norX, final float norY, final float norZ) {
        this.normal.set(norX, norY, norZ);
        this.d = -(pointX * norX + pointY * norY + pointZ * norZ);
    }
    
    public void set(final Plane plane) {
        this.normal.set(plane.normal);
        this.d = plane.d;
    }
    
    @Override
    public String toString() {
        return this.normal.toString() + ", " + this.d;
    }
    
    public enum PlaneSide
    {
        onPlane, 
        back, 
        front;
    }
}
