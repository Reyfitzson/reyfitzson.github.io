// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

import arc.struct.ShortSeq;
import arc.struct.FloatSeq;
import arc.struct.IntSeq;

public class ConvexHull
{
    private final IntSeq quicksortStack;
    private final FloatSeq hull;
    private final IntSeq indices;
    private final ShortSeq originalIndices;
    private float[] sortedPoints;
    
    public ConvexHull() {
        this.quicksortStack = new IntSeq();
        this.hull = new FloatSeq();
        this.indices = new IntSeq();
        this.originalIndices = new ShortSeq(false, 0);
    }
    
    public FloatSeq computePolygon(final FloatSeq points, final boolean sorted) {
        return this.computePolygon(points.items, 0, points.size, sorted);
    }
    
    public FloatSeq computePolygon(final float[] polygon, final boolean sorted) {
        return this.computePolygon(polygon, 0, polygon.length, sorted);
    }
    
    public FloatSeq computePolygon(float[] points, int offset, final int count, final boolean sorted) {
        final int end = offset + count;
        if (!sorted) {
            if (this.sortedPoints == null || this.sortedPoints.length < count) {
                this.sortedPoints = new float[count];
            }
            System.arraycopy(points, offset, this.sortedPoints, 0, count);
            points = this.sortedPoints;
            offset = 0;
            this.sort(points, count);
        }
        final FloatSeq hull = this.hull;
        hull.clear();
        for (int i = offset; i < end; i += 2) {
            final float x = points[i];
            final float y = points[i + 1];
            while (hull.size >= 4 && this.ccw(x, y) <= 0.0f) {
                final FloatSeq floatSeq = hull;
                floatSeq.size -= 2;
            }
            hull.add(x);
            hull.add(y);
        }
        int i = end - 4;
        final int t = hull.size + 2;
        while (i >= offset) {
            final float x2 = points[i];
            final float y2 = points[i + 1];
            while (hull.size >= t && this.ccw(x2, y2) <= 0.0f) {
                final FloatSeq floatSeq2 = hull;
                floatSeq2.size -= 2;
            }
            hull.add(x2);
            hull.add(y2);
            i -= 2;
        }
        return hull;
    }
    
    public IntSeq computeIndices(final FloatSeq points, final boolean sorted, final boolean yDown) {
        return this.computeIndices(points.items, 0, points.size, sorted, yDown);
    }
    
    public IntSeq computeIndices(final float[] polygon, final boolean sorted, final boolean yDown) {
        return this.computeIndices(polygon, 0, polygon.length, sorted, yDown);
    }
    
    public IntSeq computeIndices(float[] points, int offset, final int count, final boolean sorted, final boolean yDown) {
        final int end = offset + count;
        if (!sorted) {
            if (this.sortedPoints == null || this.sortedPoints.length < count) {
                this.sortedPoints = new float[count];
            }
            System.arraycopy(points, offset, this.sortedPoints, 0, count);
            points = this.sortedPoints;
            offset = 0;
            this.sortWithIndices(points, count, yDown);
        }
        final IntSeq indices = this.indices;
        indices.clear();
        final FloatSeq hull = this.hull;
        hull.clear();
        for (int i = offset, index = i / 2; i < end; i += 2, ++index) {
            final float x = points[i];
            final float y = points[i + 1];
            while (hull.size >= 4 && this.ccw(x, y) <= 0.0f) {
                final FloatSeq floatSeq = hull;
                floatSeq.size -= 2;
                final IntSeq intSeq = indices;
                --intSeq.size;
            }
            hull.add(x);
            hull.add(y);
            indices.add(index);
        }
        int i = end - 4;
        int index = i / 2;
        final int t = hull.size + 2;
        while (i >= offset) {
            final float x2 = points[i];
            final float y2 = points[i + 1];
            while (hull.size >= t && this.ccw(x2, y2) <= 0.0f) {
                final FloatSeq floatSeq2 = hull;
                floatSeq2.size -= 2;
                final IntSeq intSeq2 = indices;
                --intSeq2.size;
            }
            hull.add(x2);
            hull.add(y2);
            indices.add(index);
            i -= 2;
            --index;
        }
        if (!sorted) {
            final short[] originalIndicesArray = this.originalIndices.items;
            final int[] indicesArray = indices.items;
            for (int j = 0, n = indices.size; j < n; ++j) {
                indicesArray[j] = originalIndicesArray[indicesArray[j]];
            }
        }
        return indices;
    }
    
    private float ccw(final float p3x, final float p3y) {
        final FloatSeq hull = this.hull;
        final int size = hull.size;
        final float p1x = hull.get(size - 4);
        final float p1y = hull.get(size - 3);
        final float p2x = hull.get(size - 2);
        final float p2y = hull.peek();
        return (p2x - p1x) * (p3y - p1y) - (p2y - p1y) * (p3x - p1x);
    }
    
    private void sort(final float[] values, final int count) {
        int lower = 0;
        int upper = count - 1;
        final IntSeq stack = this.quicksortStack;
        stack.add(lower);
        stack.add(upper - 1);
        while (stack.size > 0) {
            upper = stack.pop();
            lower = stack.pop();
            if (upper <= lower) {
                continue;
            }
            final int i = this.quicksortPartition(values, lower, upper);
            if (i - lower > upper - i) {
                stack.add(lower);
                stack.add(i - 2);
            }
            stack.add(i + 2);
            stack.add(upper);
            if (upper - i < i - lower) {
                continue;
            }
            stack.add(lower);
            stack.add(i - 2);
        }
    }
    
    private int quicksortPartition(final float[] values, final int lower, final int upper) {
        final float x = values[lower];
        final float y = values[lower + 1];
        int up = upper;
        int down = lower;
        while (down < up) {
            while (down < up && values[down] <= x) {
                down += 2;
            }
            while (values[up] > x || (values[up] == x && values[up + 1] < y)) {
                up -= 2;
            }
            if (down < up) {
                float temp = values[down];
                values[down] = values[up];
                values[up] = temp;
                temp = values[down + 1];
                values[down + 1] = values[up + 1];
                values[up + 1] = temp;
            }
        }
        values[lower] = values[up];
        values[up] = x;
        values[lower + 1] = values[up + 1];
        values[up + 1] = y;
        return up;
    }
    
    private void sortWithIndices(final float[] values, final int count, final boolean yDown) {
        final int pointCount = count / 2;
        this.originalIndices.clear();
        this.originalIndices.ensureCapacity(pointCount);
        final short[] originalIndicesArray = this.originalIndices.items;
        for (short i = 0; i < pointCount; ++i) {
            originalIndicesArray[i] = i;
        }
        int lower = 0;
        int upper = count - 1;
        final IntSeq stack = this.quicksortStack;
        stack.add(lower);
        stack.add(upper - 1);
        while (stack.size > 0) {
            upper = stack.pop();
            lower = stack.pop();
            if (upper <= lower) {
                continue;
            }
            final int j = this.quicksortPartitionWithIndices(values, lower, upper, yDown, originalIndicesArray);
            if (j - lower > upper - j) {
                stack.add(lower);
                stack.add(j - 2);
            }
            stack.add(j + 2);
            stack.add(upper);
            if (upper - j < j - lower) {
                continue;
            }
            stack.add(lower);
            stack.add(j - 2);
        }
    }
    
    private int quicksortPartitionWithIndices(final float[] values, final int lower, final int upper, final boolean yDown, final short[] originalIndices) {
        final float x = values[lower];
        final float y = values[lower + 1];
        int up = upper;
        int down = lower;
        while (down < up) {
            while (down < up && values[down] <= x) {
                down += 2;
            }
            if (yDown) {
                while (values[up] > x || (values[up] == x && values[up + 1] < y)) {
                    up -= 2;
                }
            }
            else {
                while (values[up] > x || (values[up] == x && values[up + 1] > y)) {
                    up -= 2;
                }
            }
            if (down < up) {
                float temp = values[down];
                values[down] = values[up];
                values[up] = temp;
                temp = values[down + 1];
                values[down + 1] = values[up + 1];
                values[up + 1] = temp;
                final short tempIndex = originalIndices[down / 2];
                originalIndices[down / 2] = originalIndices[up / 2];
                originalIndices[up / 2] = tempIndex;
            }
        }
        values[lower] = values[up];
        values[up] = x;
        values[lower + 1] = values[up + 1];
        values[up + 1] = y;
        final short tempIndex = originalIndices[lower / 2];
        originalIndices[lower / 2] = originalIndices[up / 2];
        originalIndices[up / 2] = tempIndex;
        return up;
    }
}
