// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

import arc.func.Cons;
import java.util.Iterator;
import arc.struct.Seq;

public class QuadTree<T extends QuadTreeObject>
{
    protected final Rect tmp;
    protected static final int maxObjectsPerNode = 5;
    public Rect bounds;
    public Seq<T> objects;
    public QuadTree<T> botLeft;
    public QuadTree<T> botRight;
    public QuadTree<T> topLeft;
    public QuadTree<T> topRight;
    public boolean leaf;
    
    public QuadTree(final Rect bounds) {
        this.tmp = new Rect();
        this.objects = new Seq<T>(false);
        this.leaf = true;
        this.bounds = bounds;
    }
    
    private void split() {
        if (!this.leaf) {
            return;
        }
        final float subW = this.bounds.width / 2.0f;
        final float subH = this.bounds.height / 2.0f;
        if (this.botLeft == null) {
            this.botLeft = this.newChild(new Rect(this.bounds.x, this.bounds.y, subW, subH));
            this.botRight = this.newChild(new Rect(this.bounds.x + subW, this.bounds.y, subW, subH));
            this.topLeft = this.newChild(new Rect(this.bounds.x, this.bounds.y + subH, subW, subH));
            this.topRight = this.newChild(new Rect(this.bounds.x + subW, this.bounds.y + subH, subW, subH));
        }
        this.leaf = false;
        final Iterator<T> iterator = this.objects.iterator();
        while (iterator.hasNext()) {
            final T obj = iterator.next();
            this.hitbox(obj);
            final QuadTree<T> child = this.getFittingChild(this.tmp);
            if (child != null) {
                child.insert(obj);
                iterator.remove();
            }
        }
    }
    
    private void unsplit() {
        if (this.leaf) {
            return;
        }
        this.objects.addAll((Seq<? extends T>)this.botLeft.objects);
        this.objects.addAll((Seq<? extends T>)this.botRight.objects);
        this.objects.addAll((Seq<? extends T>)this.topLeft.objects);
        this.objects.addAll((Seq<? extends T>)this.topRight.objects);
        this.leaf = true;
    }
    
    public void insert(final T obj) {
        this.hitbox(obj);
        if (!this.bounds.overlaps(this.tmp)) {
            return;
        }
        if (this.leaf && this.objects.size + 1 > 5) {
            this.split();
        }
        if (this.leaf) {
            this.objects.add(obj);
        }
        else {
            this.hitbox(obj);
            final QuadTree<T> child = this.getFittingChild(this.tmp);
            if (child != null) {
                child.insert(obj);
            }
            else {
                this.objects.add(obj);
            }
        }
    }
    
    public void remove(final T obj) {
        if (this.leaf) {
            this.objects.remove(obj, true);
        }
        else {
            this.hitbox(obj);
            final QuadTree<T> child = this.getFittingChild(this.tmp);
            if (child != null) {
                child.remove(obj);
            }
            else {
                this.objects.remove(obj, true);
            }
            if (this.getTotalObjectCount() <= 5) {
                this.unsplit();
            }
        }
    }
    
    public void clear() {
        this.objects.clear();
        if (!this.leaf) {
            this.topLeft.clear();
            this.topRight.clear();
            this.botLeft.clear();
            this.botRight.clear();
        }
        this.leaf = true;
    }
    
    private QuadTree<T> getFittingChild(final Rect boundingBox) {
        final float verticalMidpoint = this.bounds.x + this.bounds.width / 2.0f;
        final float horizontalMidpoint = this.bounds.y + this.bounds.height / 2.0f;
        final boolean topQuadrant = boundingBox.y > horizontalMidpoint;
        final boolean bottomQuadrant = boundingBox.y < horizontalMidpoint && boundingBox.y + boundingBox.height < horizontalMidpoint;
        if (boundingBox.x < verticalMidpoint && boundingBox.x + boundingBox.width < verticalMidpoint) {
            if (topQuadrant) {
                return this.topLeft;
            }
            if (bottomQuadrant) {
                return this.botLeft;
            }
        }
        else if (boundingBox.x > verticalMidpoint) {
            if (topQuadrant) {
                return this.topRight;
            }
            if (bottomQuadrant) {
                return this.botRight;
            }
        }
        return null;
    }
    
    public void intersect(final float x, final float y, final float width, final float height, final Cons<T> out) {
        if (!this.leaf) {
            if (this.topLeft.bounds.overlaps(x, y, width, height)) {
                this.topLeft.intersect(x, y, width, height, out);
            }
            if (this.topRight.bounds.overlaps(x, y, width, height)) {
                this.topRight.intersect(x, y, width, height, out);
            }
            if (this.botLeft.bounds.overlaps(x, y, width, height)) {
                this.botLeft.intersect(x, y, width, height, out);
            }
            if (this.botRight.bounds.overlaps(x, y, width, height)) {
                this.botRight.intersect(x, y, width, height, out);
            }
        }
        final Seq<?> objects = this.objects;
        for (int i = 0; i < objects.size; ++i) {
            final T item = (T)objects.items[i];
            this.hitbox(item);
            if (this.tmp.overlaps(x, y, width, height)) {
                out.get(item);
            }
        }
    }
    
    public void intersect(final Rect rect, final Cons<T> out) {
        this.intersect(rect.x, rect.y, rect.width, rect.height, out);
    }
    
    public void intersect(final Rect toCheck, final Seq<T> out) {
        if (!this.leaf) {
            if (this.topLeft.bounds.overlaps(toCheck)) {
                this.topLeft.intersect(toCheck, out);
            }
            if (this.topRight.bounds.overlaps(toCheck)) {
                this.topRight.intersect(toCheck, out);
            }
            if (this.botLeft.bounds.overlaps(toCheck)) {
                this.botLeft.intersect(toCheck, out);
            }
            if (this.botRight.bounds.overlaps(toCheck)) {
                this.botRight.intersect(toCheck, out);
            }
        }
        final Seq<?> objects = this.objects;
        for (int i = 0; i < objects.size; ++i) {
            final T item = (T)objects.items[i];
            this.hitbox(item);
            if (this.tmp.overlaps(toCheck)) {
                out.add(item);
            }
        }
    }
    
    public int getTotalObjectCount() {
        int count = this.objects.size;
        if (!this.leaf) {
            count += this.botLeft.getTotalObjectCount() + this.topRight.getTotalObjectCount() + this.topLeft.getTotalObjectCount() + this.botRight.getTotalObjectCount();
        }
        return count;
    }
    
    protected QuadTree<T> newChild(final Rect rect) {
        return new QuadTree<T>(rect);
    }
    
    protected void hitbox(final T t) {
        t.hitbox(this.tmp);
    }
    
    public interface QuadTreeObject
    {
        void hitbox(final Rect p0);
    }
}
