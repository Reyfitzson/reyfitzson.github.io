// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

import arc.util.ArcRuntimeException;
import arc.math.Interp;
import arc.math.Mathf;
import arc.math.Mat;

public class Vec3 implements Vector<Vec3>
{
    public static final Vec3 X;
    public static final Vec3 Y;
    public static final Vec3 Z;
    public static final Vec3 Zero;
    private static final Mat tmpMat;
    public float x;
    public float y;
    public float z;
    
    public Vec3() {
    }
    
    public Vec3(final float x, final float y, final float z) {
        this.set(x, y, z);
    }
    
    public Vec3(final double x, final double y, final double z) {
        this((float)x, (float)y, (float)z);
    }
    
    public Vec3(final Vec3 vector) {
        this.set(vector);
    }
    
    public Vec3(final float[] values) {
        this.set(values[0], values[1], values[2]);
    }
    
    public Vec3(final Vec2 vector, final float z) {
        this.set(vector.x, vector.y, z);
    }
    
    public static float len(final float x, final float y, final float z) {
        return (float)Math.sqrt(x * x + y * y + z * z);
    }
    
    public static float len2(final float x, final float y, final float z) {
        return x * x + y * y + z * z;
    }
    
    public static float dst(final float x1, final float y1, final float z1, final float x2, final float y2, final float z2) {
        final float a = x2 - x1;
        final float b = y2 - y1;
        final float c = z2 - z1;
        return (float)Math.sqrt(a * a + b * b + c * c);
    }
    
    public static float dst2(final float x1, final float y1, final float z1, final float x2, final float y2, final float z2) {
        final float a = x2 - x1;
        final float b = y2 - y1;
        final float c = z2 - z1;
        return a * a + b * b + c * c;
    }
    
    public static float dot(final float x1, final float y1, final float z1, final float x2, final float y2, final float z2) {
        return x1 * x2 + y1 * y2 + z1 * z2;
    }
    
    public Vec3 set(final float x, final float y, final float z) {
        this.x = x;
        this.y = y;
        this.z = z;
        return this;
    }
    
    @Override
    public Vec3 div(final Vec3 other) {
        this.x /= other.x;
        this.y /= other.y;
        this.z /= other.z;
        return this;
    }
    
    @Override
    public Vec3 set(final Vec3 vector) {
        return this.set(vector.x, vector.y, vector.z);
    }
    
    public Vec3 set(final float[] values) {
        return this.set(values[0], values[1], values[2]);
    }
    
    public Vec3 set(final float[] values, final int offset) {
        return this.set(values[offset], values[offset + 1], values[offset + 2]);
    }
    
    public Vec3 set(final Vec2 vector, final float z) {
        return this.set(vector.x, vector.y, z);
    }
    
    public Vec3 setFromSpherical(final float azimuthalAngle, final float polarAngle) {
        final float cosPolar = Mathf.cos(polarAngle);
        final float sinPolar = Mathf.sin(polarAngle);
        final float cosAzim = Mathf.cos(azimuthalAngle);
        final float sinAzim = Mathf.sin(azimuthalAngle);
        return this.set(cosAzim * sinPolar, sinAzim * sinPolar, cosPolar);
    }
    
    @Override
    public Vec3 setToRandomDirection() {
        final float u = Mathf.random();
        final float v = Mathf.random();
        final float theta = 6.2831855f * u;
        final float phi = (float)Math.acos(2.0f * v - 1.0f);
        return this.setFromSpherical(theta, phi);
    }
    
    @Override
    public Vec3 cpy() {
        return new Vec3(this);
    }
    
    @Override
    public Vec3 add(final Vec3 vector) {
        return this.add(vector.x, vector.y, vector.z);
    }
    
    public Vec3 cpy(final Vec3 dest) {
        return dest.set(this);
    }
    
    public Vec3 add(final Vec3 vector, final float scale) {
        return this.add(vector.x * scale, vector.y * scale, vector.z * scale);
    }
    
    public Vec3 sun(final Vec3 vector, final float scale) {
        return this.sub(vector.x * scale, vector.y * scale, vector.z * scale);
    }
    
    public Vec3 add(final float x, final float y, final float z) {
        return this.set(this.x + x, this.y + y, this.z + z);
    }
    
    public Vec3 add(final float values) {
        return this.set(this.x + values, this.y + values, this.z + values);
    }
    
    @Override
    public Vec3 sub(final Vec3 a_vec) {
        return this.sub(a_vec.x, a_vec.y, a_vec.z);
    }
    
    public Vec3 sub(final float x, final float y, final float z) {
        return this.set(this.x - x, this.y - y, this.z - z);
    }
    
    public Vec3 sub(final float value) {
        return this.set(this.x - value, this.y - value, this.z - value);
    }
    
    @Override
    public Vec3 scl(final float scalar) {
        return this.set(this.x * scalar, this.y * scalar, this.z * scalar);
    }
    
    @Override
    public Vec3 scl(final Vec3 other) {
        return this.set(this.x * other.x, this.y * other.y, this.z * other.z);
    }
    
    public Vec3 scl(final float vx, final float vy, final float vz) {
        return this.set(this.x * vx, this.y * vy, this.z * vz);
    }
    
    @Override
    public Vec3 mulAdd(final Vec3 vec, final float scalar) {
        this.x += vec.x * scalar;
        this.y += vec.y * scalar;
        this.z += vec.z * scalar;
        return this;
    }
    
    @Override
    public Vec3 mulAdd(final Vec3 vec, final Vec3 mulVec) {
        this.x += vec.x * mulVec.x;
        this.y += vec.y * mulVec.y;
        this.z += vec.z * mulVec.z;
        return this;
    }
    
    @Override
    public float len() {
        return (float)Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
    }
    
    @Override
    public float len2() {
        return this.x * this.x + this.y * this.y + this.z * this.z;
    }
    
    public boolean idt(final Vec3 vector) {
        return this.x == vector.x && this.y == vector.y && this.z == vector.z;
    }
    
    @Override
    public float dst(final Vec3 vector) {
        final float a = vector.x - this.x;
        final float b = vector.y - this.y;
        final float c = vector.z - this.z;
        return (float)Math.sqrt(a * a + b * b + c * c);
    }
    
    public float dst(final float x, final float y, final float z) {
        final float a = x - this.x;
        final float b = y - this.y;
        final float c = z - this.z;
        return (float)Math.sqrt(a * a + b * b + c * c);
    }
    
    @Override
    public float dst2(final Vec3 point) {
        final float a = point.x - this.x;
        final float b = point.y - this.y;
        final float c = point.z - this.z;
        return a * a + b * b + c * c;
    }
    
    public float dst2(final float x, final float y, final float z) {
        final float a = x - this.x;
        final float b = y - this.y;
        final float c = z - this.z;
        return a * a + b * b + c * c;
    }
    
    public boolean within(final Vec3 v, final float dst) {
        return this.dst2(v) < dst * dst;
    }
    
    @Override
    public Vec3 nor() {
        final float len2 = this.len2();
        if (len2 == 0.0f || len2 == 1.0f) {
            return this;
        }
        return this.scl(1.0f / (float)Math.sqrt(len2));
    }
    
    @Override
    public float dot(final Vec3 vector) {
        return this.x * vector.x + this.y * vector.y + this.z * vector.z;
    }
    
    public float angleRad(final Vec3 vector) {
        final float l = this.len();
        final float l2 = vector.len();
        return (float)Math.acos(dot(this.x / l, this.y / l, this.z / l, vector.x / l2, vector.y / l2, vector.z / l2));
    }
    
    public float angle(final Vec3 vector) {
        return this.angleRad(vector) * 57.295776f;
    }
    
    public float dot(final float x, final float y, final float z) {
        return this.x * x + this.y * y + this.z * z;
    }
    
    public Vec3 crs(final Vec3 vector) {
        return this.set(this.y * vector.z - this.z * vector.y, this.z * vector.x - this.x * vector.z, this.x * vector.y - this.y * vector.x);
    }
    
    public Vec3 crs(final float x, final float y, final float z) {
        return this.set(this.y * z - this.z * y, this.z * x - this.x * z, this.x * y - this.y * x);
    }
    
    public Vec3 mul4x3(final float[] matrix) {
        return this.set(this.x * matrix[0] + this.y * matrix[3] + this.z * matrix[6] + matrix[9], this.x * matrix[1] + this.y * matrix[4] + this.z * matrix[7] + matrix[10], this.x * matrix[2] + this.y * matrix[5] + this.z * matrix[8] + matrix[11]);
    }
    
    public Vec3 mul(final Mat matrix) {
        final float[] l_mat = matrix.val;
        return this.set(this.x * l_mat[0] + this.y * l_mat[3] + this.z * l_mat[6], this.x * l_mat[1] + this.y * l_mat[4] + this.z * l_mat[7], this.x * l_mat[2] + this.y * l_mat[5] + this.z * l_mat[8]);
    }
    
    public Vec3 traMul(final Mat matrix) {
        final float[] l_mat = matrix.val;
        return this.set(this.x * l_mat[0] + this.y * l_mat[1] + this.z * l_mat[2], this.x * l_mat[3] + this.y * l_mat[4] + this.z * l_mat[5], this.x * l_mat[6] + this.y * l_mat[7] + this.z * l_mat[8]);
    }
    
    public Vec3 rotate(final Vec3 axis, final float degrees) {
        Vec3.tmpMat.setToRotation(axis, degrees);
        return this.mul(Vec3.tmpMat);
    }
    
    @Override
    public boolean isUnit() {
        return this.isUnit(1.0E-9f);
    }
    
    @Override
    public boolean isUnit(final float margin) {
        return Math.abs(this.len2() - 1.0f) < margin;
    }
    
    @Override
    public boolean isZero() {
        return this.x == 0.0f && this.y == 0.0f && this.z == 0.0f;
    }
    
    @Override
    public boolean isZero(final float margin) {
        return this.len2() < margin;
    }
    
    @Override
    public boolean isOnLine(final Vec3 other, final float epsilon) {
        return len2(this.y * other.z - this.z * other.y, this.z * other.x - this.x * other.z, this.x * other.y - this.y * other.x) <= epsilon;
    }
    
    @Override
    public boolean isOnLine(final Vec3 other) {
        return len2(this.y * other.z - this.z * other.y, this.z * other.x - this.x * other.z, this.x * other.y - this.y * other.x) <= 1.0E-6f;
    }
    
    @Override
    public boolean isCollinear(final Vec3 other, final float epsilon) {
        return this.isOnLine(other, epsilon) && this.hasSameDirection(other);
    }
    
    @Override
    public boolean isCollinear(final Vec3 other) {
        return this.isOnLine(other) && this.hasSameDirection(other);
    }
    
    @Override
    public boolean isCollinearOpposite(final Vec3 other, final float epsilon) {
        return this.isOnLine(other, epsilon) && this.hasOppositeDirection(other);
    }
    
    @Override
    public boolean isCollinearOpposite(final Vec3 other) {
        return this.isOnLine(other) && this.hasOppositeDirection(other);
    }
    
    @Override
    public boolean isPerpendicular(final Vec3 vector) {
        return Mathf.zero(this.dot(vector));
    }
    
    @Override
    public boolean isPerpendicular(final Vec3 vector, final float epsilon) {
        return Mathf.zero(this.dot(vector), epsilon);
    }
    
    @Override
    public boolean hasSameDirection(final Vec3 vector) {
        return this.dot(vector) > 0.0f;
    }
    
    @Override
    public boolean hasOppositeDirection(final Vec3 vector) {
        return this.dot(vector) < 0.0f;
    }
    
    @Override
    public Vec3 lerp(final Vec3 target, final float alpha) {
        this.x += alpha * (target.x - this.x);
        this.y += alpha * (target.y - this.y);
        this.z += alpha * (target.z - this.z);
        return this;
    }
    
    @Override
    public Vec3 interpolate(final Vec3 target, final float alpha, final Interp interpolator) {
        return this.lerp(target, interpolator.apply(0.0f, 1.0f, alpha));
    }
    
    public Vec3 slerp(final Vec3 target, final float alpha) {
        final float dot = this.dot(target);
        if (dot > 0.9995 || dot < -0.9995) {
            return this.lerp(target, alpha);
        }
        final float theta0 = (float)Math.acos(dot);
        final float theta2 = theta0 * alpha;
        final float st = (float)Math.sin(theta2);
        final float tx = target.x - this.x * dot;
        final float ty = target.y - this.y * dot;
        final float tz = target.z - this.z * dot;
        final float l2 = tx * tx + ty * ty + tz * tz;
        final float dl = st * ((l2 < 1.0E-4f) ? 1.0f : (1.0f / (float)Math.sqrt(l2)));
        return this.scl((float)Math.cos(theta2)).add(tx * dl, ty * dl, tz * dl).nor();
    }
    
    @Override
    public String toString() {
        return "(" + this.x + "," + this.y + "," + this.z + ")";
    }
    
    public Vec3 fromString(final String v) {
        final int s0 = v.indexOf(44, 1);
        final int s2 = v.indexOf(44, s0 + 1);
        if (s0 != -1 && s2 != -1 && v.charAt(0) == '(' && v.charAt(v.length() - 1) == ')') {
            try {
                final float x = Float.parseFloat(v.substring(1, s0));
                final float y = Float.parseFloat(v.substring(s0 + 1, s2));
                final float z = Float.parseFloat(v.substring(s2 + 1, v.length() - 1));
                return this.set(x, y, z);
            }
            catch (NumberFormatException ex) {}
        }
        throw new ArcRuntimeException("Malformed Vec3: " + v);
    }
    
    @Override
    public Vec3 limit(final float limit) {
        return this.limit2(limit * limit);
    }
    
    @Override
    public Vec3 limit2(final float limit2) {
        final float len2 = this.len2();
        if (len2 > limit2) {
            this.scl((float)Math.sqrt(limit2 / len2));
        }
        return this;
    }
    
    @Override
    public Vec3 setLength(final float len) {
        return this.setLength2(len * len);
    }
    
    @Override
    public Vec3 setLength2(final float len2) {
        final float oldLen2 = this.len2();
        return (oldLen2 == 0.0f || oldLen2 == len2) ? this : this.scl((float)Math.sqrt(len2 / oldLen2));
    }
    
    @Override
    public Vec3 clamp(final float min, final float max) {
        final float len2 = this.len2();
        if (len2 == 0.0f) {
            return this;
        }
        final float max2 = max * max;
        if (len2 > max2) {
            return this.scl((float)Math.sqrt(max2 / len2));
        }
        final float min2 = min * min;
        if (len2 < min2) {
            return this.scl((float)Math.sqrt(min2 / len2));
        }
        return this;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = 31 * result + Float.floatToIntBits(this.x);
        result = 31 * result + Float.floatToIntBits(this.y);
        result = 31 * result + Float.floatToIntBits(this.z);
        return result;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        final Vec3 other = (Vec3)obj;
        return Float.floatToIntBits(this.x) == Float.floatToIntBits(other.x) && Float.floatToIntBits(this.y) == Float.floatToIntBits(other.y) && Float.floatToIntBits(this.z) == Float.floatToIntBits(other.z);
    }
    
    @Override
    public boolean epsilonEquals(final Vec3 other, final float epsilon) {
        return other != null && Math.abs(other.x - this.x) <= epsilon && Math.abs(other.y - this.y) <= epsilon && Math.abs(other.z - this.z) <= epsilon;
    }
    
    public boolean epsilonEquals(final float x, final float y, final float z, final float epsilon) {
        return Math.abs(x - this.x) <= epsilon && Math.abs(y - this.y) <= epsilon && Math.abs(z - this.z) <= epsilon;
    }
    
    public boolean epsilonEquals(final Vec3 other) {
        return this.epsilonEquals(other, 1.0E-6f);
    }
    
    public boolean epsilonEquals(final float x, final float y, final float z) {
        return this.epsilonEquals(x, y, z, 1.0E-6f);
    }
    
    @Override
    public Vec3 setZero() {
        this.x = 0.0f;
        this.y = 0.0f;
        this.z = 0.0f;
        return this;
    }
    
    static {
        X = new Vec3(1.0f, 0.0f, 0.0f);
        Y = new Vec3(0.0f, 1.0f, 0.0f);
        Z = new Vec3(0.0f, 0.0f, 1.0f);
        Zero = new Vec3(0.0f, 0.0f, 0.0f);
        tmpMat = new Mat();
    }
}
