// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

import arc.math.Mathf;
import arc.math.Angles;

public interface Position
{
    float getX();
    
    float getY();
    
    default float angleTo(final Position other) {
        return Angles.angle(this.getX(), this.getY(), other.getX(), other.getY());
    }
    
    default float angleTo(final float x, final float y) {
        return Angles.angle(this.getX(), this.getY(), x, y);
    }
    
    default float dst2(final Position other) {
        return this.dst2(other.getX(), other.getY());
    }
    
    default float dst(final Position other) {
        return this.dst(other.getX(), other.getY());
    }
    
    default float dst(final float x, final float y) {
        final float xd = this.getX() - x;
        final float yd = this.getY() - y;
        return Mathf.sqrt(xd * xd + yd * yd);
    }
    
    default float dst2(final float x, final float y) {
        final float xd = this.getX() - x;
        final float yd = this.getY() - y;
        return xd * xd + yd * yd;
    }
    
    default boolean within(final Position other, final float dst) {
        return this.within(other.getX(), other.getY(), dst);
    }
    
    default boolean within(final float x, final float y, final float dst) {
        return Mathf.dst2(this.getX(), this.getY(), x, y) < dst * dst;
    }
}
