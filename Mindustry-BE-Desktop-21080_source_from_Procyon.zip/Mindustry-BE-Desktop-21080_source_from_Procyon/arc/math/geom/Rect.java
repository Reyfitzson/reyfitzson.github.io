// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

import arc.util.ArcRuntimeException;

public class Rect implements Shape2D
{
    public static final Rect tmp;
    public static final Rect tmp2;
    private static final long serialVersionUID = 5733252015138115702L;
    public float x;
    public float y;
    public float width;
    public float height;
    
    public Rect() {
    }
    
    public Rect(final float x, final float y, final float width, final float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    
    public Rect(final Rect rect) {
        this.x = rect.x;
        this.y = rect.y;
        this.width = rect.width;
        this.height = rect.height;
    }
    
    public Rect setCentered(final float x, final float y, final float size) {
        return this.set(x - size / 2.0f, y - size / 2.0f, size, size);
    }
    
    public Rect setCentered(final float x, final float y, final float width, final float height) {
        return this.set(x - width / 2.0f, y - height / 2.0f, width, height);
    }
    
    public Rect set(final float x, final float y, final float width, final float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        return this;
    }
    
    public float getX() {
        return this.x;
    }
    
    public Rect setX(final float x) {
        this.x = x;
        return this;
    }
    
    public float getY() {
        return this.y;
    }
    
    public Rect setY(final float y) {
        this.y = y;
        return this;
    }
    
    public float getWidth() {
        return this.width;
    }
    
    public Rect setWidth(final float width) {
        this.width = width;
        return this;
    }
    
    public float getHeight() {
        return this.height;
    }
    
    public Rect setHeight(final float height) {
        this.height = height;
        return this;
    }
    
    public Vec2 getPosition(final Vec2 position) {
        return position.set(this.x, this.y);
    }
    
    public Rect setPosition(final Vec2 position) {
        this.x = position.x;
        this.y = position.y;
        return this;
    }
    
    public Rect setPosition(final float x, final float y) {
        this.x = x;
        this.y = y;
        return this;
    }
    
    public Rect move(final float cx, final float cy) {
        this.x += cx;
        this.y += cy;
        return this;
    }
    
    public Rect setSize(final float width, final float height) {
        this.width = width;
        this.height = height;
        return this;
    }
    
    public Rect setSize(final float sizeXY) {
        this.width = sizeXY;
        this.height = sizeXY;
        return this;
    }
    
    public Vec2 getSize(final Vec2 size) {
        return size.set(this.width, this.height);
    }
    
    @Override
    public boolean contains(final float x, final float y) {
        return this.x <= x && this.x + this.width >= x && this.y <= y && this.y + this.height >= y;
    }
    
    @Override
    public boolean contains(final Vec2 point) {
        return this.contains(point.x, point.y);
    }
    
    public boolean contains(final Circle circle) {
        return circle.x - circle.radius >= this.x && circle.x + circle.radius <= this.x + this.width && circle.y - circle.radius >= this.y && circle.y + circle.radius <= this.y + this.height;
    }
    
    public boolean contains(final Rect rect) {
        final float xmin = rect.x;
        final float xmax = xmin + rect.width;
        final float ymin = rect.y;
        final float ymax = ymin + rect.height;
        return xmin > this.x && xmin < this.x + this.width && xmax > this.x && xmax < this.x + this.width && ymin > this.y && ymin < this.y + this.height && ymax > this.y && ymax < this.y + this.height;
    }
    
    public boolean overlaps(final Rect r) {
        return this.x < r.x + r.width && this.x + this.width > r.x && this.y < r.y + r.height && this.y + this.height > r.y;
    }
    
    public boolean overlaps(final float rx, final float ry, final float rwidth, final float rheight) {
        return this.x < rx + rwidth && this.x + this.width > rx && this.y < ry + rheight && this.y + this.height > ry;
    }
    
    public Rect set(final Rect rect) {
        this.x = rect.x;
        this.y = rect.y;
        this.width = rect.width;
        this.height = rect.height;
        return this;
    }
    
    public Rect grow(final float amount) {
        return this.grow(amount, amount);
    }
    
    public Rect grow(final float amountX, final float amountY) {
        this.x -= amountX / 2.0f;
        this.y -= amountY / 2.0f;
        this.width += amountX;
        this.height += amountY;
        return this;
    }
    
    public Rect merge(final Rect rect) {
        final float minX = Math.min(this.x, rect.x);
        final float maxX = Math.max(this.x + this.width, rect.x + rect.width);
        this.x = minX;
        this.width = maxX - minX;
        final float minY = Math.min(this.y, rect.y);
        final float maxY = Math.max(this.y + this.height, rect.y + rect.height);
        this.y = minY;
        this.height = maxY - minY;
        return this;
    }
    
    public Rect merge(final float x, final float y) {
        final float minX = Math.min(this.x, x);
        final float maxX = Math.max(this.x + this.width, x);
        this.x = minX;
        this.width = maxX - minX;
        final float minY = Math.min(this.y, y);
        final float maxY = Math.max(this.y + this.height, y);
        this.y = minY;
        this.height = maxY - minY;
        return this;
    }
    
    public Rect merge(final Vec2 vec) {
        return this.merge(vec.x, vec.y);
    }
    
    public Rect merge(final Vec2[] vecs) {
        float minX = this.x;
        float maxX = this.x + this.width;
        float minY = this.y;
        float maxY = this.y + this.height;
        for (int i = 0; i < vecs.length; ++i) {
            final Vec2 v = vecs[i];
            minX = Math.min(minX, v.x);
            maxX = Math.max(maxX, v.x);
            minY = Math.min(minY, v.y);
            maxY = Math.max(maxY, v.y);
        }
        this.x = minX;
        this.width = maxX - minX;
        this.y = minY;
        this.height = maxY - minY;
        return this;
    }
    
    public float getAspectRatio() {
        return (this.height == 0.0f) ? Float.NaN : (this.width / this.height);
    }
    
    public Vec2 getCenter(final Vec2 vector) {
        vector.x = this.x + this.width / 2.0f;
        vector.y = this.y + this.height / 2.0f;
        return vector;
    }
    
    public Rect setCenter(final float x, final float y) {
        this.setPosition(x - this.width / 2.0f, y - this.height / 2.0f);
        return this;
    }
    
    public Rect setCenter(final Vec2 position) {
        this.setPosition(position.x - this.width / 2.0f, position.y - this.height / 2.0f);
        return this;
    }
    
    public Rect fitOutside(final Rect rect) {
        final float ratio = this.getAspectRatio();
        if (ratio > rect.getAspectRatio()) {
            this.setSize(rect.height * ratio, rect.height);
        }
        else {
            this.setSize(rect.width, rect.width / ratio);
        }
        this.setPosition(rect.x + rect.width / 2.0f - this.width / 2.0f, rect.y + rect.height / 2.0f - this.height / 2.0f);
        return this;
    }
    
    public Rect fitInside(final Rect rect) {
        final float ratio = this.getAspectRatio();
        if (ratio < rect.getAspectRatio()) {
            this.setSize(rect.height * ratio, rect.height);
        }
        else {
            this.setSize(rect.width, rect.width / ratio);
        }
        this.setPosition(rect.x + rect.width / 2.0f - this.width / 2.0f, rect.y + rect.height / 2.0f - this.height / 2.0f);
        return this;
    }
    
    @Override
    public String toString() {
        return "[" + this.x + "," + this.y + "," + this.width + "," + this.height + "]";
    }
    
    public Rect fromString(final String v) {
        final int s0 = v.indexOf(44, 1);
        final int s2 = v.indexOf(44, s0 + 1);
        final int s3 = v.indexOf(44, s2 + 1);
        if (s0 != -1 && s2 != -1 && s3 != -1 && v.charAt(0) == '[' && v.charAt(v.length() - 1) == ']') {
            try {
                final float x = Float.parseFloat(v.substring(1, s0));
                final float y = Float.parseFloat(v.substring(s0 + 1, s2));
                final float width = Float.parseFloat(v.substring(s2 + 1, s3));
                final float height = Float.parseFloat(v.substring(s3 + 1, v.length() - 1));
                return this.set(x, y, width, height);
            }
            catch (NumberFormatException ex) {}
        }
        throw new ArcRuntimeException("Malformed Rectangle: " + v);
    }
    
    public float area() {
        return this.width * this.height;
    }
    
    public float perimeter() {
        return 2.0f * (this.width + this.height);
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = 31 * result + Float.floatToRawIntBits(this.height);
        result = 31 * result + Float.floatToRawIntBits(this.width);
        result = 31 * result + Float.floatToRawIntBits(this.x);
        result = 31 * result + Float.floatToRawIntBits(this.y);
        return result;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        final Rect other = (Rect)obj;
        return Float.floatToRawIntBits(this.height) == Float.floatToRawIntBits(other.height) && Float.floatToRawIntBits(this.width) == Float.floatToRawIntBits(other.width) && Float.floatToRawIntBits(this.x) == Float.floatToRawIntBits(other.x) && Float.floatToRawIntBits(this.y) == Float.floatToRawIntBits(other.y);
    }
    
    static {
        tmp = new Rect();
        tmp2 = new Rect();
    }
}
