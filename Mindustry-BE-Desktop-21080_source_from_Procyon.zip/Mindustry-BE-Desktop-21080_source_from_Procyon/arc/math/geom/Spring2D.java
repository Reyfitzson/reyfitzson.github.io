// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

public class Spring2D
{
    public Vec2 value;
    public Vec2 target;
    public Vec2 velocity;
    public float damping;
    public float frequency;
    
    public Spring2D(final float damping, final float frequency) {
        this.value = new Vec2();
        this.target = new Vec2();
        this.velocity = new Vec2();
        this.damping = damping;
        this.frequency = frequency;
    }
    
    public void update(final float deltaTime) {
        float angularFrequency = this.frequency;
        angularFrequency *= 6.2831855f;
        final float f = 1.0f + 2.0f * deltaTime * this.damping * angularFrequency;
        final float oo = angularFrequency * angularFrequency;
        final float hoo = deltaTime * oo;
        final float hhoo = deltaTime * hoo;
        final float detInv = 1.0f / (f + hhoo);
        float detX = f * this.value.x + deltaTime * this.velocity.x + hhoo * this.target.x;
        float detV = this.velocity.x + hoo * (this.target.x - this.value.x);
        this.value.x = detX * detInv;
        this.velocity.x = detV * detInv;
        detX = f * this.value.y + deltaTime * this.velocity.y + hhoo * this.target.y;
        detV = this.velocity.y + hoo * (this.target.y - this.value.y);
        this.value.y = detX * detInv;
        this.velocity.y = detV * detInv;
    }
}
