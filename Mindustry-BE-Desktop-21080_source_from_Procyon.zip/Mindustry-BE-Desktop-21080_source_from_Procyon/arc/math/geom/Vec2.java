// 
// Decompiled by Procyon v0.5.36
// 

package arc.math.geom;

import arc.math.Interp;
import arc.util.Time;
import arc.math.Angles;
import arc.math.Mat;
import arc.util.ArcRuntimeException;
import arc.math.Mathf;

public class Vec2 implements Vector<Vec2>, Position
{
    public static final Vec2 X;
    public static final Vec2 Y;
    public static final Vec2 ZERO;
    public float x;
    public float y;
    
    public Vec2() {
    }
    
    public Vec2(final float x, final float y) {
        this.x = x;
        this.y = y;
    }
    
    public Vec2(final Vec2 v) {
        this.set(v);
    }
    
    public Vec2 trns(final float angle, final float amount) {
        return this.set(amount, 0.0f).rotate(angle);
    }
    
    public Vec2 trns(final float angle, final float x, final float y) {
        return this.set(x, y).rotate(angle);
    }
    
    public Vec2 trnsExact(final float angle, final float amount) {
        return this.set(amount, 0.0f).rotateRadExact(angle * 0.017453292f);
    }
    
    public Vec2 snap() {
        return this.set((float)(int)this.x, (float)(int)this.y);
    }
    
    @Override
    public Vec2 div(final Vec2 other) {
        this.x /= other.x;
        this.y /= other.y;
        return this;
    }
    
    @Override
    public Vec2 cpy() {
        return new Vec2(this);
    }
    
    @Override
    public float len() {
        return (float)Math.sqrt(this.x * this.x + this.y * this.y);
    }
    
    @Override
    public float len2() {
        return this.x * this.x + this.y * this.y;
    }
    
    @Override
    public Vec2 set(final Vec2 v) {
        this.x = v.x;
        this.y = v.y;
        return this;
    }
    
    public Vec2 set(final Position v) {
        this.x = v.getX();
        this.y = v.getY();
        return this;
    }
    
    public Vec2 set(final float x, final float y) {
        this.x = x;
        this.y = y;
        return this;
    }
    
    public Vec2 set(final Vec3 other) {
        this.x = other.x;
        this.y = other.y;
        return this;
    }
    
    public Vec2 sub(final Position v) {
        return this.sub(v.getX(), v.getY());
    }
    
    @Override
    public Vec2 sub(final Vec2 v) {
        this.x -= v.x;
        this.y -= v.y;
        return this;
    }
    
    public Vec2 sub(final float x, final float y) {
        this.x -= x;
        this.y -= y;
        return this;
    }
    
    public Vec2 sub(final Vec3 v) {
        return this.sub(v.x, v.y);
    }
    
    @Override
    public Vec2 nor() {
        final float len = this.len();
        if (len != 0.0f) {
            this.x /= len;
            this.y /= len;
        }
        return this;
    }
    
    @Override
    public Vec2 add(final Vec2 v) {
        this.x += v.x;
        this.y += v.y;
        return this;
    }
    
    public Vec2 add(final Position pos) {
        return this.add(pos.getX(), pos.getY());
    }
    
    public Vec2 add(final Vec2 vec, final float scl) {
        this.x += vec.x * scl;
        this.y += vec.y * scl;
        return this;
    }
    
    public Vec2 add(final float x, final float y) {
        this.x += x;
        this.y += y;
        return this;
    }
    
    @Override
    public float dot(final Vec2 v) {
        return this.x * v.x + this.y * v.y;
    }
    
    public float dot(final float ox, final float oy) {
        return this.x * ox + this.y * oy;
    }
    
    @Override
    public Vec2 scl(final float scalar) {
        this.x *= scalar;
        this.y *= scalar;
        return this;
    }
    
    public Vec2 inv() {
        return this.scl(-1.0f);
    }
    
    public Vec2 scl(final float x, final float y) {
        this.x *= x;
        this.y *= y;
        return this;
    }
    
    @Override
    public Vec2 scl(final Vec2 v) {
        this.x *= v.x;
        this.y *= v.y;
        return this;
    }
    
    @Override
    public Vec2 mulAdd(final Vec2 vec, final float scalar) {
        this.x += vec.x * scalar;
        this.y += vec.y * scalar;
        return this;
    }
    
    @Override
    public Vec2 mulAdd(final Vec2 vec, final Vec2 mulVec) {
        this.x += vec.x * mulVec.x;
        this.y += vec.y * mulVec.y;
        return this;
    }
    
    @Override
    public float dst(final Vec2 v) {
        final float x_d = v.x - this.x;
        final float y_d = v.y - this.y;
        return (float)Math.sqrt(x_d * x_d + y_d * y_d);
    }
    
    @Override
    public float dst(final float x, final float y) {
        final float x_d = x - this.x;
        final float y_d = y - this.y;
        return (float)Math.sqrt(x_d * x_d + y_d * y_d);
    }
    
    @Override
    public float dst2(final Vec2 v) {
        final float x_d = v.x - this.x;
        final float y_d = v.y - this.y;
        return x_d * x_d + y_d * y_d;
    }
    
    @Override
    public float dst2(final float x, final float y) {
        final float xd = x - this.x;
        final float yd = y - this.y;
        return xd * xd + yd * yd;
    }
    
    @Override
    public Vec2 limit(final float limit) {
        return this.limit2(limit * limit);
    }
    
    @Override
    public Vec2 limit2(final float limit2) {
        final float len2 = this.len2();
        if (len2 > limit2) {
            return this.scl((float)Math.sqrt(limit2 / len2));
        }
        return this;
    }
    
    @Override
    public Vec2 clamp(final float min, final float max) {
        final float len2 = this.len2();
        if (len2 == 0.0f) {
            return this;
        }
        final float max2 = max * max;
        if (len2 > max2) {
            return this.scl((float)Math.sqrt(max2 / len2));
        }
        final float min2 = min * min;
        if (len2 < min2) {
            return this.scl((float)Math.sqrt(min2 / len2));
        }
        return this;
    }
    
    @Override
    public Vec2 setLength(final float len) {
        return this.setLength2(len * len);
    }
    
    @Override
    public Vec2 setLength2(final float len2) {
        final float oldLen2 = this.len2();
        return (oldLen2 == 0.0f || oldLen2 == len2) ? this : this.scl((float)Math.sqrt(len2 / oldLen2));
    }
    
    @Override
    public String toString() {
        return "(" + this.x + "," + this.y + ")";
    }
    
    public Vec2 clamp(final float minx, final float miny, final float maxy, final float maxx) {
        this.x = Mathf.clamp(this.x, minx, maxx);
        this.y = Mathf.clamp(this.y, miny, maxy);
        return this;
    }
    
    public Vec2 tryFromString(final String v) {
        try {
            final int s = v.indexOf(44, 1);
            if (s != -1 && v.charAt(0) == '(' && v.charAt(v.length() - 1) == ')') {
                final float x = Float.parseFloat(v.substring(1, s));
                final float y = Float.parseFloat(v.substring(s + 1, v.length() - 1));
                return this.set(x, y);
            }
        }
        catch (Throwable t) {}
        return this.setZero();
    }
    
    public Vec2 fromString(final String v) {
        final int s = v.indexOf(44, 1);
        if (s != -1 && v.charAt(0) == '(' && v.charAt(v.length() - 1) == ')') {
            try {
                final float x = Float.parseFloat(v.substring(1, s));
                final float y = Float.parseFloat(v.substring(s + 1, v.length() - 1));
                return this.set(x, y);
            }
            catch (NumberFormatException ex) {}
        }
        throw new ArcRuntimeException("Malformed Vec2: " + v);
    }
    
    public Vec2 mul(final Mat mat) {
        final float x = this.x * mat.val[0] + this.y * mat.val[3] + mat.val[6];
        final float y = this.x * mat.val[1] + this.y * mat.val[4] + mat.val[7];
        this.x = x;
        this.y = y;
        return this;
    }
    
    public float crs(final Vec2 v) {
        return this.x * v.y - this.y * v.x;
    }
    
    public float crs(final float x, final float y) {
        return this.x * y - this.y * x;
    }
    
    public float angle() {
        float angle = Mathf.atan2(this.x, this.y) * 57.295776f;
        if (angle < 0.0f) {
            angle += 360.0f;
        }
        return angle;
    }
    
    public float angle(final Vec2 reference) {
        return (float)Math.atan2(this.crs(reference), this.dot(reference)) * 57.295776f;
    }
    
    public Vec2 rnd(final float length) {
        this.setToRandomDirection().scl(length);
        return this;
    }
    
    public float angleRad() {
        return (float)Math.atan2(this.y, this.x);
    }
    
    public float angleRad(final Vec2 reference) {
        return (float)Math.atan2(this.crs(reference), this.dot(reference));
    }
    
    public Vec2 setAngle(final float degrees) {
        return this.setAngleRad(degrees * 0.017453292f);
    }
    
    public Vec2 setAngleRad(final float radians) {
        this.set(this.len(), 0.0f);
        this.rotateRad(radians);
        return this;
    }
    
    public Vec2 rotateTo(final float angle, final float speed) {
        return this.setAngle(Angles.moveToward(this.angle(), angle, speed));
    }
    
    public Vec2 rotate(final float degrees) {
        return this.rotateRad(degrees * 0.017453292f);
    }
    
    public Vec2 rotateAround(final Vec2 reference, final float degrees) {
        return this.sub(reference).rotate(degrees).add(reference);
    }
    
    public Vec2 rotateRad(final float radians) {
        final float cos = Mathf.cos(radians);
        final float sin = Mathf.sin(radians);
        final float newX = this.x * cos - this.y * sin;
        final float newY = this.x * sin + this.y * cos;
        this.x = newX;
        this.y = newY;
        return this;
    }
    
    public Vec2 rotateRadExact(final float radians) {
        final float cos = (float)Math.cos(radians);
        final float sin = (float)Math.sin(radians);
        final float newX = this.x * cos - this.y * sin;
        final float newY = this.x * sin + this.y * cos;
        this.x = newX;
        this.y = newY;
        return this;
    }
    
    public Vec2 rotateAroundRad(final Vec2 reference, final float radians) {
        return this.sub(reference).rotateRad(radians).add(reference);
    }
    
    public Vec2 rotate90(final int dir) {
        final float x = this.x;
        if (dir >= 0) {
            this.x = -this.y;
            this.y = x;
        }
        else {
            this.x = this.y;
            this.y = -x;
        }
        return this;
    }
    
    public Vec2 approachDelta(final Vec2 target, final float alpha) {
        return this.approach(target, Time.delta * alpha);
    }
    
    public Vec2 approach(final Vec2 target, final float alpha) {
        float dx = this.x - target.x;
        float dy = this.y - target.y;
        final float alpha2 = alpha * alpha;
        final float len2 = Mathf.len2(dx, dy);
        if (len2 > alpha2) {
            final float scl = Mathf.sqrt(alpha2 / len2);
            dx *= scl;
            dy *= scl;
            return this.sub(dx, dy);
        }
        return this.set(target);
    }
    
    public Vec2 lerpPast(final Vec2 target, final float alpha) {
        this.x += (target.x - this.x) * alpha;
        this.y += (target.y - this.y) * alpha;
        return this;
    }
    
    public Vec2 lerpDelta(final float tx, final float ty, float alpha) {
        alpha = Mathf.clamp(alpha * Time.delta);
        final float invAlpha = 1.0f - alpha;
        this.x = this.x * invAlpha + tx * alpha;
        this.y = this.y * invAlpha + ty * alpha;
        return this;
    }
    
    public Vec2 lerpDelta(final Position target, float alpha) {
        alpha = Mathf.clamp(alpha * Time.delta);
        final float invAlpha = 1.0f - alpha;
        this.x = this.x * invAlpha + target.getX() * alpha;
        this.y = this.y * invAlpha + target.getY() * alpha;
        return this;
    }
    
    public Vec2 lerp(final Position target, final float alpha) {
        final float invAlpha = 1.0f - alpha;
        this.x = this.x * invAlpha + target.getX() * alpha;
        this.y = this.y * invAlpha + target.getY() * alpha;
        return this;
    }
    
    public Vec2 lerp(final float tx, final float ty, final float alpha) {
        final float invAlpha = 1.0f - alpha;
        this.x = this.x * invAlpha + tx * alpha;
        this.y = this.y * invAlpha + ty * alpha;
        return this;
    }
    
    @Override
    public Vec2 lerp(final Vec2 target, final float alpha) {
        final float invAlpha = 1.0f - alpha;
        this.x = this.x * invAlpha + target.x * alpha;
        this.y = this.y * invAlpha + target.y * alpha;
        return this;
    }
    
    @Override
    public Vec2 interpolate(final Vec2 target, final float alpha, final Interp interpolation) {
        return this.lerp(target, interpolation.apply(alpha));
    }
    
    @Override
    public Vec2 setToRandomDirection() {
        final float theta = Mathf.random(0.0f, 6.2831855f);
        return this.set(Mathf.cos(theta), Mathf.sin(theta));
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = 31 * result + Float.floatToIntBits(this.x);
        result = 31 * result + Float.floatToIntBits(this.y);
        return result;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        final Vec2 other = (Vec2)obj;
        return Float.floatToIntBits(this.x) == Float.floatToIntBits(other.x) && Float.floatToIntBits(this.y) == Float.floatToIntBits(other.y);
    }
    
    @Override
    public boolean epsilonEquals(final Vec2 other, final float epsilon) {
        return other != null && Math.abs(other.x - this.x) <= epsilon && Math.abs(other.y - this.y) <= epsilon;
    }
    
    public boolean epsilonEquals(final float x, final float y, final float epsilon) {
        return Math.abs(x - this.x) <= epsilon && Math.abs(y - this.y) <= epsilon;
    }
    
    public boolean epsilonEquals(final Vec2 other) {
        return this.epsilonEquals(other, 1.0E-6f);
    }
    
    public boolean epsilonEquals(final float x, final float y) {
        return this.epsilonEquals(x, y, 1.0E-6f);
    }
    
    public boolean isNaN() {
        return Float.isNaN(this.x) || Float.isNaN(this.y);
    }
    
    public boolean isInfinite() {
        return Float.isInfinite(this.x) || Float.isInfinite(this.y);
    }
    
    @Override
    public boolean isUnit() {
        return this.isUnit(1.0E-9f);
    }
    
    @Override
    public boolean isUnit(final float margin) {
        return Math.abs(this.len2() - 1.0f) < margin;
    }
    
    @Override
    public boolean isZero() {
        return this.x == 0.0f && this.y == 0.0f;
    }
    
    @Override
    public boolean isZero(final float margin) {
        return this.len2() < margin;
    }
    
    @Override
    public boolean isOnLine(final Vec2 other) {
        return Mathf.zero(this.x * other.y - this.y * other.x);
    }
    
    @Override
    public boolean isOnLine(final Vec2 other, final float epsilon) {
        return Mathf.zero(this.x * other.y - this.y * other.x, epsilon);
    }
    
    @Override
    public boolean isCollinear(final Vec2 other, final float epsilon) {
        return this.isOnLine(other, epsilon) && this.dot(other) > 0.0f;
    }
    
    @Override
    public boolean isCollinear(final Vec2 other) {
        return this.isOnLine(other) && this.dot(other) > 0.0f;
    }
    
    @Override
    public boolean isCollinearOpposite(final Vec2 other, final float epsilon) {
        return this.isOnLine(other, epsilon) && this.dot(other) < 0.0f;
    }
    
    @Override
    public boolean isCollinearOpposite(final Vec2 other) {
        return this.isOnLine(other) && this.dot(other) < 0.0f;
    }
    
    @Override
    public boolean isPerpendicular(final Vec2 vector) {
        return Mathf.zero(this.dot(vector));
    }
    
    @Override
    public boolean isPerpendicular(final Vec2 vector, final float epsilon) {
        return Mathf.zero(this.dot(vector), epsilon);
    }
    
    @Override
    public boolean hasSameDirection(final Vec2 vector) {
        return this.dot(vector) > 0.0f;
    }
    
    @Override
    public boolean hasOppositeDirection(final Vec2 vector) {
        return this.dot(vector) < 0.0f;
    }
    
    @Override
    public Vec2 setZero() {
        this.x = 0.0f;
        this.y = 0.0f;
        return this;
    }
    
    @Override
    public float getX() {
        return this.x;
    }
    
    @Override
    public float getY() {
        return this.y;
    }
    
    static {
        X = new Vec2(1.0f, 0.0f);
        Y = new Vec2(0.0f, 1.0f);
        ZERO = new Vec2(0.0f, 0.0f);
    }
}
