// 
// Decompiled by Procyon v0.5.36
// 

package arc.math;

public interface Scaled
{
    float fin();
    
    default float fout() {
        return 1.0f - this.fin();
    }
    
    default float fout(final Interp i) {
        return i.apply(this.fout());
    }
    
    default float fout(final float margin) {
        final float f = this.fin();
        if (f >= 1.0f - margin) {
            return 1.0f - (f - (1.0f - margin)) / margin;
        }
        return 1.0f;
    }
    
    default float fin(final Interp i) {
        return i.apply(this.fin());
    }
    
    default float finpow() {
        return Interp.pow3Out.apply(this.fin());
    }
    
    default float fslope() {
        return (0.5f - Math.abs(this.fin() - 0.5f)) * 2.0f;
    }
}
