// 
// Decompiled by Procyon v0.5.36
// 

package arc.mock;

import arc.graphics.Pixmap;
import arc.graphics.GL30;
import arc.graphics.GL20;
import arc.Application;
import arc.graphics.gl.GLVersion;
import arc.Graphics;

public class MockGraphics extends Graphics
{
    long frameId;
    float deltaTime;
    long frameStart;
    int frames;
    int fps;
    long lastTime;
    GLVersion glVersion;
    
    public MockGraphics() {
        this.frameId = -1L;
        this.deltaTime = 0.0f;
        this.frameStart = 0L;
        this.frames = 0;
        this.lastTime = System.nanoTime();
        this.glVersion = new GLVersion(Application.ApplicationType.headless, "", "", "");
    }
    
    @Override
    public boolean isGL30Available() {
        return false;
    }
    
    @Override
    public GL20 getGL20() {
        return null;
    }
    
    @Override
    public void setGL20(final GL20 gl20) {
    }
    
    @Override
    public GL30 getGL30() {
        return null;
    }
    
    @Override
    public void setGL30(final GL30 gl30) {
    }
    
    @Override
    public int getWidth() {
        return 0;
    }
    
    @Override
    public int getHeight() {
        return 0;
    }
    
    @Override
    public int getBackBufferWidth() {
        return 0;
    }
    
    @Override
    public int getBackBufferHeight() {
        return 0;
    }
    
    @Override
    public long getFrameId() {
        return this.frameId;
    }
    
    @Override
    public float getDeltaTime() {
        return this.deltaTime;
    }
    
    @Override
    public int getFramesPerSecond() {
        return this.fps;
    }
    
    @Override
    public GLVersion getGLVersion() {
        return this.glVersion;
    }
    
    @Override
    public float getPpiX() {
        return 0.0f;
    }
    
    @Override
    public float getPpiY() {
        return 0.0f;
    }
    
    @Override
    public float getPpcX() {
        return 0.0f;
    }
    
    @Override
    public float getPpcY() {
        return 0.0f;
    }
    
    @Override
    public float getDensity() {
        return 0.0f;
    }
    
    @Override
    public boolean supportsDisplayModeChange() {
        return false;
    }
    
    @Override
    public DisplayMode[] getDisplayModes() {
        return new DisplayMode[0];
    }
    
    @Override
    public DisplayMode getDisplayMode() {
        return null;
    }
    
    @Override
    public boolean setFullscreenMode(final DisplayMode displayMode) {
        return false;
    }
    
    @Override
    public boolean setWindowedMode(final int width, final int height) {
        return false;
    }
    
    @Override
    public void setTitle(final String title) {
    }
    
    @Override
    public void setVSync(final boolean vsync) {
    }
    
    @Override
    public BufferFormat getBufferFormat() {
        return null;
    }
    
    @Override
    public boolean supportsExtension(final String extension) {
        return false;
    }
    
    @Override
    public boolean isContinuousRendering() {
        return false;
    }
    
    @Override
    public void setContinuousRendering(final boolean isContinuous) {
    }
    
    @Override
    public void requestRendering() {
    }
    
    @Override
    public boolean isFullscreen() {
        return false;
    }
    
    public void updateTime() {
        final long time = System.nanoTime();
        this.deltaTime = (time - this.lastTime) / 1.0E9f;
        this.lastTime = time;
        if (time - this.frameStart >= 1000000000L) {
            this.fps = this.frames;
            this.frames = 0;
            this.frameStart = time;
        }
        ++this.frames;
    }
    
    public void incrementFrameId() {
        ++this.frameId;
    }
    
    @Override
    public Cursor newCursor(final Pixmap pixmap, final int xHotspot, final int yHotspot) {
        return null;
    }
    
    public void setCursor(final Cursor cursor) {
    }
    
    public void setSystemCursor(final Cursor.SystemCursor systemCursor) {
    }
    
    @Override
    public Monitor getPrimaryMonitor() {
        return null;
    }
    
    @Override
    public Monitor getMonitor() {
        return null;
    }
    
    @Override
    public Monitor[] getMonitors() {
        return null;
    }
    
    @Override
    public DisplayMode[] getDisplayModes(final Monitor monitor) {
        return null;
    }
    
    @Override
    public DisplayMode getDisplayMode(final Monitor monitor) {
        return null;
    }
    
    @Override
    public void setUndecorated(final boolean undecorated) {
    }
    
    @Override
    public void setResizable(final boolean resizable) {
    }
}
