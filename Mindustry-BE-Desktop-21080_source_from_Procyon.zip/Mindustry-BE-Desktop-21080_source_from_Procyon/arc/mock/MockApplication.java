// 
// Decompiled by Procyon v0.5.36
// 

package arc.mock;

import arc.ApplicationListener;
import arc.struct.Seq;
import arc.Application;

public class MockApplication implements Application
{
    @Override
    public Seq<ApplicationListener> getListeners() {
        return new Seq<ApplicationListener>();
    }
    
    @Override
    public ApplicationType getType() {
        return ApplicationType.headless;
    }
    
    @Override
    public String getClipboardText() {
        return null;
    }
    
    @Override
    public void setClipboardText(final String text) {
    }
    
    @Override
    public void post(final Runnable runnable) {
    }
    
    @Override
    public void exit() {
    }
}
