// 
// Decompiled by Procyon v0.5.36
// 

package arc.mock;

import arc.audio.Audio;

public class MockAudio extends Audio
{
    @Override
    protected void initialize() {
    }
}
