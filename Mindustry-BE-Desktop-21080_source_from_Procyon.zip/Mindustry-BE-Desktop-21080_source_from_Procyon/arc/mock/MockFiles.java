// 
// Decompiled by Procyon v0.5.36
// 

package arc.mock;

import java.io.File;
import arc.files.Fi;
import arc.Files;

public class MockFiles implements Files
{
    @Override
    public Fi get(final String fileName, final FileType type) {
        return new Fi(fileName, type);
    }
    
    @Override
    public String getExternalStoragePath() {
        return System.getProperty("user.home") + File.separator;
    }
    
    @Override
    public boolean isExternalStorageAvailable() {
        return true;
    }
    
    @Override
    public String getLocalStoragePath() {
        return new File("").getAbsolutePath() + File.separator;
    }
    
    @Override
    public boolean isLocalStorageAvailable() {
        return true;
    }
}
