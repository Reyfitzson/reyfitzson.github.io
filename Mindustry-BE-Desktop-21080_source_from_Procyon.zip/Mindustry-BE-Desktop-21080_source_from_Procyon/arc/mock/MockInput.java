// 
// Decompiled by Procyon v0.5.36
// 

package arc.mock;

import arc.Input;

public class MockInput extends Input
{
    @Override
    public int mouseX() {
        return 0;
    }
    
    @Override
    public int mouseX(final int pointer) {
        return 0;
    }
    
    @Override
    public int deltaX() {
        return 0;
    }
    
    @Override
    public int deltaX(final int pointer) {
        return 0;
    }
    
    @Override
    public int mouseY() {
        return 0;
    }
    
    @Override
    public int mouseY(final int pointer) {
        return 0;
    }
    
    @Override
    public int deltaY() {
        return 0;
    }
    
    @Override
    public int deltaY(final int pointer) {
        return 0;
    }
    
    @Override
    public boolean isTouched() {
        return false;
    }
    
    @Override
    public boolean justTouched() {
        return false;
    }
    
    @Override
    public boolean isTouched(final int pointer) {
        return false;
    }
    
    @Override
    public long getCurrentEventTime() {
        return 0L;
    }
}
