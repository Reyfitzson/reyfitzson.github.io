// 
// Decompiled by Procyon v0.5.36
// 

package arc.mock;

import arc.Settings;

public class MockSettings extends Settings
{
    @Override
    public void load() {
    }
    
    @Override
    public void forceSave() {
    }
}
