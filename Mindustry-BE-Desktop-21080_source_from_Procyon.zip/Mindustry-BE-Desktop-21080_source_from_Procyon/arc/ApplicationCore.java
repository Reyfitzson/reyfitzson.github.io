// 
// Decompiled by Procyon v0.5.36
// 

package arc;

import arc.files.Fi;

public abstract class ApplicationCore implements ApplicationListener
{
    protected ApplicationListener[] modules;
    
    public ApplicationCore() {
        this.modules = new ApplicationListener[0];
    }
    
    public void add(final ApplicationListener module) {
        final ApplicationListener[] news = new ApplicationListener[this.modules.length + 1];
        news[news.length - 1] = module;
        System.arraycopy(this.modules, 0, news, 0, this.modules.length);
        this.modules = news;
    }
    
    public abstract void setup();
    
    @Override
    public void init() {
        this.setup();
        for (final ApplicationListener listener : this.modules) {
            listener.init();
        }
    }
    
    @Override
    public void resize(final int width, final int height) {
        for (final ApplicationListener listener : this.modules) {
            listener.resize(width, height);
        }
    }
    
    @Override
    public void update() {
        for (final ApplicationListener listener : this.modules) {
            listener.update();
        }
    }
    
    @Override
    public void pause() {
        for (final ApplicationListener listener : this.modules) {
            listener.pause();
        }
    }
    
    @Override
    public void resume() {
        for (final ApplicationListener listener : this.modules) {
            listener.resume();
        }
    }
    
    @Override
    public void dispose() {
        for (final ApplicationListener listener : this.modules) {
            listener.dispose();
        }
    }
    
    @Override
    public void fileDropped(final Fi file) {
        for (final ApplicationListener listener : this.modules) {
            listener.fileDropped(file);
        }
    }
}
