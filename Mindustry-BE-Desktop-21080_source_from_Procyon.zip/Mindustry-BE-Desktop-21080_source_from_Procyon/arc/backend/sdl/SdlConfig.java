// 
// Decompiled by Procyon v0.5.36
// 

package arc.backend.sdl;

import arc.Files;
import arc.graphics.Color;
import arc.graphics.gl.HdpiMode;

public class SdlConfig
{
    public int r;
    public int g;
    public int b;
    public int a;
    public int depth;
    public int stencil;
    public int samples;
    public HdpiMode hdpiMode;
    public int width;
    public int height;
    public boolean resizable;
    public boolean decorated;
    public boolean maximized;
    public boolean gl30;
    public int gl30Major;
    public int gl30Minor;
    public String title;
    public Color initialBackgroundColor;
    public boolean initialVisible;
    public boolean vSyncEnabled;
    Files.FileType windowIconFileType;
    String[] windowIconPaths;
    
    public SdlConfig() {
        this.r = 8;
        this.g = 8;
        this.b = 8;
        this.a = 8;
        this.depth = 0;
        this.stencil = 0;
        this.samples = 0;
        this.hdpiMode = HdpiMode.logical;
        this.width = 640;
        this.height = 480;
        this.resizable = true;
        this.decorated = true;
        this.maximized = false;
        this.gl30 = false;
        this.gl30Major = 3;
        this.gl30Minor = 0;
        this.title = "Arc Application";
        this.initialBackgroundColor = Color.black;
        this.initialVisible = true;
        this.vSyncEnabled = true;
    }
    
    public void setWindowIcon(final Files.FileType fileType, final String... filePaths) {
        this.windowIconFileType = fileType;
        this.windowIconPaths = filePaths;
    }
}
