// 
// Decompiled by Procyon v0.5.36
// 

package arc.backend.sdl;

import java.nio.LongBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.Buffer;
import arc.backend.sdl.jni.SDLGL;
import arc.graphics.GL30;

public class SdlGL30 extends SdlGL20 implements GL30
{
    @Override
    public void glReadBuffer(final int mode) {
        SDLGL.glReadBuffer(mode);
    }
    
    @Override
    public void glDrawRangeElements(final int mode, final int start, final int end, final int count, final int type, final int offset) {
        SDLGL.glDrawRangeElements(mode, start, end, count, type, offset);
    }
    
    @Override
    public void glDrawRangeElements(final int mode, final int start, final int end, final int count, final int type, final Buffer indices) {
        SDLGL.glDrawRangeElements(mode, start, end, count, type, indices);
    }
    
    @Override
    public void glTexImage3D(final int target, final int level, final int internalformat, final int width, final int height, final int depth, final int border, final int format, final int type, final int offset) {
        SDLGL.glTexImage3D(target, level, internalformat, width, height, depth, border, format, type, offset);
    }
    
    @Override
    public void glTexImage3D(final int target, final int level, final int internalformat, final int width, final int height, final int depth, final int border, final int format, final int type, final Buffer pixels) {
        SDLGL.glTexImage3D(target, level, internalformat, width, height, depth, border, format, type, pixels);
    }
    
    @Override
    public void glTexSubImage3D(final int target, final int level, final int xoffset, final int yoffset, final int zoffset, final int width, final int height, final int depth, final int format, final int type, final int offset) {
        SDLGL.glTexSubImage3D(target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, offset);
    }
    
    @Override
    public void glTexSubImage3D(final int target, final int level, final int xoffset, final int yoffset, final int zoffset, final int width, final int height, final int depth, final int format, final int type, final Buffer pixels) {
        SDLGL.glTexSubImage3D(target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, pixels);
    }
    
    @Override
    public void glCopyTexSubImage3D(final int target, final int level, final int xoffset, final int yoffset, final int zoffset, final int x, final int y, final int width, final int height) {
        SDLGL.glCopyTexSubImage3D(target, level, xoffset, yoffset, zoffset, x, y, width, height);
    }
    
    @Override
    public void glGenQueries(final int n, final IntBuffer ids) {
        SDLGL.glGenQueries(n, ids);
    }
    
    @Override
    public void glDeleteQueries(final int n, final IntBuffer ids) {
        SDLGL.glDeleteQueries(n, ids);
    }
    
    @Override
    public boolean glIsQuery(final int id) {
        return SDLGL.glIsQuery(id);
    }
    
    @Override
    public void glBeginQuery(final int target, final int id) {
        SDLGL.glBeginQuery(target, id);
    }
    
    @Override
    public void glEndQuery(final int target) {
        SDLGL.glEndQuery(target);
    }
    
    @Override
    public void glGetQueryiv(final int target, final int pname, final IntBuffer params) {
        SDLGL.glGetQueryiv(target, pname, params);
    }
    
    @Override
    public void glGetQueryObjectuiv(final int id, final int pname, final IntBuffer params) {
        SDLGL.glGetQueryObjectuiv(id, pname, params);
    }
    
    @Override
    public boolean glUnmapBuffer(final int target) {
        return SDLGL.glUnmapBuffer(target);
    }
    
    @Override
    public Buffer glGetBufferPointerv(final int target, final int pname) {
        return SDLGL.glGetBufferPointerv(target, pname);
    }
    
    @Override
    public void glDrawBuffers(final int n, final IntBuffer bufs) {
        SDLGL.glDrawBuffers(n, bufs);
    }
    
    @Override
    public void glUniformMatrix2x3fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        SDLGL.glUniformMatrix2x3fv(location, count, transpose, value);
    }
    
    @Override
    public void glUniformMatrix3x2fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        SDLGL.glUniformMatrix3x2fv(location, count, transpose, value);
    }
    
    @Override
    public void glUniformMatrix2x4fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        SDLGL.glUniformMatrix2x4fv(location, count, transpose, value);
    }
    
    @Override
    public void glUniformMatrix4x2fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        SDLGL.glUniformMatrix4x2fv(location, count, transpose, value);
    }
    
    @Override
    public void glUniformMatrix3x4fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        SDLGL.glUniformMatrix3x4fv(location, count, transpose, value);
    }
    
    @Override
    public void glUniformMatrix4x3fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        SDLGL.glUniformMatrix4x3fv(location, count, transpose, value);
    }
    
    @Override
    public void glBlitFramebuffer(final int srcX0, final int srcY0, final int srcX1, final int srcY1, final int dstX0, final int dstY0, final int dstX1, final int dstY1, final int mask, final int filter) {
        SDLGL.glBlitFramebuffer(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter);
    }
    
    @Override
    public void glRenderbufferStorageMultisample(final int target, final int samples, final int internalformat, final int width, final int height) {
        SDLGL.glRenderbufferStorageMultisample(target, samples, internalformat, width, height);
    }
    
    @Override
    public void glFramebufferTextureLayer(final int target, final int attachment, final int texture, final int level, final int layer) {
        SDLGL.glFramebufferTextureLayer(target, attachment, texture, level, layer);
    }
    
    @Override
    public void glFlushMappedBufferRange(final int target, final int offset, final int length) {
        SDLGL.glFlushMappedBufferRange(target, offset, length);
    }
    
    @Override
    public void glBindVertexArray(final int array) {
        SDLGL.glBindVertexArray(array);
    }
    
    @Override
    public void glDeleteVertexArrays(final int n, final IntBuffer arrays) {
        SDLGL.glDeleteVertexArrays(n, arrays);
    }
    
    @Override
    public void glGenVertexArrays(final int n, final IntBuffer arrays) {
        SDLGL.glGenVertexArrays(n, arrays);
    }
    
    @Override
    public boolean glIsVertexArray(final int array) {
        return SDLGL.glIsVertexArray(array);
    }
    
    @Override
    public void glBeginTransformFeedback(final int primitiveMode) {
        SDLGL.glBeginTransformFeedback(primitiveMode);
    }
    
    @Override
    public void glEndTransformFeedback() {
        SDLGL.glEndTransformFeedback();
    }
    
    @Override
    public void glBindBufferRange(final int target, final int index, final int buffer, final int offset, final int size) {
        SDLGL.glBindBufferRange(target, index, buffer, offset, size);
    }
    
    @Override
    public void glBindBufferBase(final int target, final int index, final int buffer) {
        SDLGL.glBindBufferBase(target, index, buffer);
    }
    
    @Override
    public void glTransformFeedbackVaryings(final int program, final String[] varyings, final int bufferMode) {
        SDLGL.glTransformFeedbackVaryings(program, varyings, bufferMode);
    }
    
    @Override
    public void glVertexAttribIPointer(final int index, final int size, final int type, final int stride, final int offset) {
        SDLGL.glVertexAttribIPointer(index, size, type, stride, offset);
    }
    
    @Override
    public void glGetVertexAttribIiv(final int index, final int pname, final IntBuffer params) {
        SDLGL.glGetVertexAttribIiv(index, pname, params);
    }
    
    @Override
    public void glGetVertexAttribIuiv(final int index, final int pname, final IntBuffer params) {
        SDLGL.glGetVertexAttribIuiv(index, pname, params);
    }
    
    @Override
    public void glVertexAttribI4i(final int index, final int x, final int y, final int z, final int w) {
        SDLGL.glVertexAttribI4i(index, x, y, z, w);
    }
    
    @Override
    public void glVertexAttribI4ui(final int index, final int x, final int y, final int z, final int w) {
        SDLGL.glVertexAttribI4ui(index, x, y, z, w);
    }
    
    @Override
    public void glGetUniformuiv(final int program, final int location, final IntBuffer params) {
        SDLGL.glGetUniformuiv(program, location, params);
    }
    
    @Override
    public int glGetFragDataLocation(final int program, final String name) {
        return SDLGL.glGetFragDataLocation(program, name);
    }
    
    @Override
    public void glUniform1uiv(final int location, final int count, final IntBuffer value) {
        SDLGL.glUniform1uiv(location, count, value);
    }
    
    @Override
    public void glUniform3uiv(final int location, final int count, final IntBuffer value) {
        SDLGL.glUniform3uiv(location, count, value);
    }
    
    @Override
    public void glUniform4uiv(final int location, final int count, final IntBuffer value) {
        SDLGL.glUniform4uiv(location, count, value);
    }
    
    @Override
    public void glClearBufferiv(final int buffer, final int drawbuffer, final IntBuffer value) {
        SDLGL.glClearBufferiv(buffer, drawbuffer, value);
    }
    
    @Override
    public void glClearBufferuiv(final int buffer, final int drawbuffer, final IntBuffer value) {
        SDLGL.glClearBufferuiv(buffer, drawbuffer, value);
    }
    
    @Override
    public void glClearBufferfv(final int buffer, final int drawbuffer, final FloatBuffer value) {
        SDLGL.glClearBufferfv(buffer, drawbuffer, value);
    }
    
    @Override
    public void glClearBufferfi(final int buffer, final int drawbuffer, final float depth, final int stencil) {
        SDLGL.glClearBufferfi(buffer, drawbuffer, depth, stencil);
    }
    
    @Override
    public String glGetStringi(final int name, final int index) {
        return SDLGL.glGetStringi(name, index);
    }
    
    @Override
    public void glCopyBufferSubData(final int readTarget, final int writeTarget, final int readOffset, final int writeOffset, final int size) {
        SDLGL.glCopyBufferSubData(readTarget, writeTarget, readOffset, writeOffset, size);
    }
    
    @Override
    public void glGetUniformIndices(final int program, final String[] uniformNames, final IntBuffer uniformIndices) {
        SDLGL.glGetUniformIndices(program, uniformNames, uniformIndices);
    }
    
    @Override
    public void glGetActiveUniformsiv(final int program, final int uniformCount, final IntBuffer uniformIndices, final int pname, final IntBuffer params) {
        SDLGL.glGetActiveUniformsiv(program, uniformCount, uniformIndices, pname, params);
    }
    
    @Override
    public int glGetUniformBlockIndex(final int program, final String uniformBlockName) {
        return SDLGL.glGetUniformBlockIndex(program, uniformBlockName);
    }
    
    @Override
    public void glGetActiveUniformBlockiv(final int program, final int uniformBlockIndex, final int pname, final IntBuffer params) {
        SDLGL.glGetActiveUniformBlockiv(program, uniformBlockIndex, pname, params);
    }
    
    @Override
    public void glGetActiveUniformBlockName(final int program, final int uniformBlockIndex, final Buffer length, final Buffer uniformBlockName) {
        SDLGL.glGetActiveUniformBlockName(program, uniformBlockIndex, length, uniformBlockName);
    }
    
    @Override
    public void glUniformBlockBinding(final int program, final int uniformBlockIndex, final int uniformBlockBinding) {
        SDLGL.glUniformBlockBinding(program, uniformBlockIndex, uniformBlockBinding);
    }
    
    @Override
    public void glDrawArraysInstanced(final int mode, final int first, final int count, final int instanceCount) {
        SDLGL.glDrawArraysInstanced(mode, first, count, instanceCount);
    }
    
    @Override
    public void glDrawElementsInstanced(final int mode, final int count, final int type, final int indicesOffset, final int instanceCount) {
        SDLGL.glDrawElementsInstanced(mode, count, type, indicesOffset, instanceCount);
    }
    
    @Override
    public void glGetInteger64v(final int pname, final LongBuffer params) {
        SDLGL.glGetInteger64v(pname, params);
    }
    
    @Override
    public void glGetBufferParameteri64v(final int target, final int pname, final LongBuffer params) {
        SDLGL.glGetBufferParameteri64v(target, pname, params);
    }
    
    @Override
    public void glGenSamplers(final int count, final IntBuffer samplers) {
        SDLGL.glGenSamplers(count, samplers);
    }
    
    @Override
    public void glDeleteSamplers(final int count, final IntBuffer samplers) {
        SDLGL.glDeleteSamplers(count, samplers);
    }
    
    @Override
    public boolean glIsSampler(final int sampler) {
        return SDLGL.glIsSampler(sampler);
    }
    
    @Override
    public void glBindSampler(final int unit, final int sampler) {
        SDLGL.glBindSampler(unit, sampler);
    }
    
    @Override
    public void glSamplerParameteri(final int sampler, final int pname, final int param) {
        SDLGL.glSamplerParameteri(sampler, pname, param);
    }
    
    @Override
    public void glSamplerParameteriv(final int sampler, final int pname, final IntBuffer param) {
        SDLGL.glSamplerParameteriv(sampler, pname, param);
    }
    
    @Override
    public void glSamplerParameterf(final int sampler, final int pname, final float param) {
        SDLGL.glSamplerParameterf(sampler, pname, param);
    }
    
    @Override
    public void glSamplerParameterfv(final int sampler, final int pname, final FloatBuffer param) {
        SDLGL.glSamplerParameterfv(sampler, pname, param);
    }
    
    @Override
    public void glGetSamplerParameteriv(final int sampler, final int pname, final IntBuffer params) {
        SDLGL.glGetSamplerParameteriv(sampler, pname, params);
    }
    
    @Override
    public void glGetSamplerParameterfv(final int sampler, final int pname, final FloatBuffer params) {
        SDLGL.glGetSamplerParameterfv(sampler, pname, params);
    }
    
    @Override
    public void glVertexAttribDivisor(final int index, final int divisor) {
        SDLGL.glVertexAttribDivisor(index, divisor);
    }
    
    @Override
    public void glBindTransformFeedback(final int target, final int id) {
        SDLGL.glBindTransformFeedback(target, id);
    }
    
    @Override
    public void glDeleteTransformFeedbacks(final int n, final IntBuffer ids) {
        SDLGL.glDeleteTransformFeedbacks(n, ids);
    }
    
    @Override
    public void glGenTransformFeedbacks(final int n, final IntBuffer ids) {
        SDLGL.glGenTransformFeedbacks(n, ids);
    }
    
    @Override
    public boolean glIsTransformFeedback(final int id) {
        return SDLGL.glIsTransformFeedback(id);
    }
    
    @Override
    public void glPauseTransformFeedback() {
        SDLGL.glPauseTransformFeedback();
    }
    
    @Override
    public void glResumeTransformFeedback() {
        SDLGL.glResumeTransformFeedback();
    }
    
    @Override
    public void glProgramParameteri(final int program, final int pname, final int value) {
        SDLGL.glProgramParameteri(program, pname, value);
    }
    
    @Override
    public void glInvalidateFramebuffer(final int target, final int numAttachments, final IntBuffer attachments) {
        SDLGL.glInvalidateFramebuffer(target, numAttachments, attachments);
    }
    
    @Override
    public void glInvalidateSubFramebuffer(final int target, final int numAttachments, final IntBuffer attachments, final int x, final int y, final int width, final int height) {
        SDLGL.glInvalidateSubFramebuffer(target, numAttachments, attachments, x, y, width, height);
    }
}
