// 
// Decompiled by Procyon v0.5.36
// 

package arc.backend.sdl;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.Buffer;
import arc.backend.sdl.jni.SDLGL;
import arc.graphics.GL20;

public class SdlGL20 implements GL20
{
    @Override
    public void glActiveTexture(final int texture) {
        SDLGL.glActiveTexture(texture);
    }
    
    @Override
    public void glBindTexture(final int target, final int texture) {
        SDLGL.glBindTexture(target, texture);
    }
    
    @Override
    public void glBlendFunc(final int sfactor, final int dfactor) {
        SDLGL.glBlendFunc(sfactor, dfactor);
    }
    
    @Override
    public void glClear(final int mask) {
        SDLGL.glClear(mask);
    }
    
    @Override
    public void glClearColor(final float red, final float green, final float blue, final float alpha) {
        SDLGL.glClearColor(red, green, blue, alpha);
    }
    
    @Override
    public void glClearDepthf(final float depth) {
        SDLGL.glClearDepthf(depth);
    }
    
    @Override
    public void glClearStencil(final int s) {
        SDLGL.glClearStencil(s);
    }
    
    @Override
    public void glColorMask(final boolean red, final boolean green, final boolean blue, final boolean alpha) {
        SDLGL.glColorMask(red, green, blue, alpha);
    }
    
    @Override
    public void glCompressedTexImage2D(final int target, final int level, final int internalformat, final int width, final int height, final int border, final int imageSize, final Buffer data) {
        SDLGL.glCompressedTexImage2D(target, level, internalformat, width, height, border, imageSize, data);
    }
    
    @Override
    public void glCompressedTexSubImage2D(final int target, final int level, final int xoffset, final int yoffset, final int width, final int height, final int format, final int imageSize, final Buffer data) {
        SDLGL.glCompressedTexSubImage2D(target, level, xoffset, yoffset, width, height, format, imageSize, data);
    }
    
    @Override
    public void glCopyTexImage2D(final int target, final int level, final int internalformat, final int x, final int y, final int width, final int height, final int border) {
        SDLGL.glCopyTexImage2D(target, level, internalformat, x, y, width, height, border);
    }
    
    @Override
    public void glCopyTexSubImage2D(final int target, final int level, final int xoffset, final int yoffset, final int x, final int y, final int width, final int height) {
        SDLGL.glCopyTexSubImage2D(target, level, xoffset, yoffset, x, y, width, height);
    }
    
    @Override
    public void glCullFace(final int mode) {
        SDLGL.glCullFace(mode);
    }
    
    @Override
    public void glDeleteTexture(final int texture) {
        SDLGL.glDeleteTexture(texture);
    }
    
    @Override
    public void glDepthFunc(final int func) {
        SDLGL.glDepthFunc(func);
    }
    
    @Override
    public void glDepthMask(final boolean flag) {
        SDLGL.glDepthMask(flag);
    }
    
    @Override
    public void glDepthRangef(final float zNear, final float zFar) {
        SDLGL.glDepthRangef(zNear, zFar);
    }
    
    @Override
    public void glDisable(final int cap) {
        SDLGL.glDisable(cap);
    }
    
    @Override
    public void glDrawArrays(final int mode, final int first, final int count) {
        SDLGL.glDrawArrays(mode, first, count);
    }
    
    @Override
    public void glDrawElements(final int mode, final int count, final int type, final Buffer indices) {
        SDLGL.glDrawElements(mode, count, type, indices);
    }
    
    @Override
    public void glEnable(final int cap) {
        SDLGL.glEnable(cap);
    }
    
    @Override
    public void glFinish() {
        SDLGL.glFinish();
    }
    
    @Override
    public void glFlush() {
        SDLGL.glFlush();
    }
    
    @Override
    public void glFrontFace(final int mode) {
        SDLGL.glFrontFace(mode);
    }
    
    @Override
    public int glGenTexture() {
        return SDLGL.glGenTexture();
    }
    
    @Override
    public int glGetError() {
        return SDLGL.glGetError();
    }
    
    @Override
    public void glGetIntegerv(final int pname, final IntBuffer params) {
        SDLGL.glGetIntegerv(pname, params);
    }
    
    @Override
    public String glGetString(final int name) {
        return SDLGL.glGetString(name);
    }
    
    @Override
    public void glHint(final int target, final int mode) {
        SDLGL.glHint(target, mode);
    }
    
    @Override
    public void glLineWidth(final float width) {
        SDLGL.glLineWidth(width);
    }
    
    @Override
    public void glPixelStorei(final int pname, final int param) {
        SDLGL.glPixelStorei(pname, param);
    }
    
    @Override
    public void glPolygonOffset(final float factor, final float units) {
        SDLGL.glPolygonOffset(factor, units);
    }
    
    @Override
    public void glReadPixels(final int x, final int y, final int width, final int height, final int format, final int type, final Buffer pixels) {
        SDLGL.glReadPixels(x, y, width, height, format, type, pixels);
    }
    
    @Override
    public void glScissor(final int x, final int y, final int width, final int height) {
        SDLGL.glScissor(x, y, width, height);
    }
    
    @Override
    public void glStencilFunc(final int func, final int ref, final int mask) {
        SDLGL.glStencilFunc(func, ref, mask);
    }
    
    @Override
    public void glStencilMask(final int mask) {
        SDLGL.glStencilMask(mask);
    }
    
    @Override
    public void glStencilOp(final int fail, final int zfail, final int zpass) {
        SDLGL.glStencilOp(fail, zfail, zpass);
    }
    
    @Override
    public void glTexImage2D(final int target, final int level, final int internalformat, final int width, final int height, final int border, final int format, final int type, final Buffer pixels) {
        SDLGL.glTexImage2D(target, level, internalformat, width, height, border, format, type, pixels);
    }
    
    @Override
    public void glTexParameterf(final int target, final int pname, final float param) {
        SDLGL.glTexParameterf(target, pname, param);
    }
    
    @Override
    public void glTexSubImage2D(final int target, final int level, final int xoffset, final int yoffset, final int width, final int height, final int format, final int type, final Buffer pixels) {
        SDLGL.glTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type, pixels);
    }
    
    @Override
    public void glViewport(final int x, final int y, final int width, final int height) {
        SDLGL.glViewport(x, y, width, height);
    }
    
    @Override
    public void glAttachShader(final int program, final int shader) {
        SDLGL.glAttachShader(program, shader);
    }
    
    @Override
    public void glBindAttribLocation(final int program, final int index, final String name) {
        SDLGL.glBindAttribLocation(program, index, name);
    }
    
    @Override
    public void glBindBuffer(final int target, final int buffer) {
        SDLGL.glBindBuffer(target, buffer);
    }
    
    @Override
    public void glBindFramebuffer(final int target, final int framebuffer) {
        SDLGL.glBindFramebuffer(target, framebuffer);
    }
    
    @Override
    public void glBindRenderbuffer(final int target, final int renderbuffer) {
        SDLGL.glBindRenderbuffer(target, renderbuffer);
    }
    
    @Override
    public void glBlendColor(final float red, final float green, final float blue, final float alpha) {
        SDLGL.glBlendColor(red, green, blue, alpha);
    }
    
    @Override
    public void glBlendEquation(final int mode) {
        SDLGL.glBlendEquation(mode);
    }
    
    @Override
    public void glBlendEquationSeparate(final int modeRGB, final int modeAlpha) {
        SDLGL.glBlendEquationSeparate(modeRGB, modeAlpha);
    }
    
    @Override
    public void glBlendFuncSeparate(final int srcRGB, final int dstRGB, final int srcAlpha, final int dstAlpha) {
        SDLGL.glBlendFuncSeparate(srcRGB, dstRGB, srcAlpha, dstAlpha);
    }
    
    @Override
    public void glBufferData(final int target, final int size, final Buffer data, final int usage) {
        SDLGL.glBufferData(target, size, data, usage);
    }
    
    @Override
    public void glBufferSubData(final int target, final int offset, final int size, final Buffer data) {
        SDLGL.glBufferSubData(target, offset, size, data);
    }
    
    @Override
    public int glCheckFramebufferStatus(final int target) {
        return SDLGL.glCheckFramebufferStatus(target);
    }
    
    @Override
    public void glCompileShader(final int shader) {
        SDLGL.glCompileShader(shader);
    }
    
    @Override
    public int glCreateProgram() {
        return SDLGL.glCreateProgram();
    }
    
    @Override
    public int glCreateShader(final int type) {
        return SDLGL.glCreateShader(type);
    }
    
    @Override
    public void glDeleteBuffer(final int buffer) {
        SDLGL.glDeleteBuffer(buffer);
    }
    
    @Override
    public void glDeleteFramebuffer(final int framebuffer) {
        SDLGL.glDeleteFramebuffer(framebuffer);
    }
    
    @Override
    public void glDeleteProgram(final int program) {
        SDLGL.glDeleteProgram(program);
    }
    
    @Override
    public void glDeleteRenderbuffer(final int renderbuffer) {
        SDLGL.glDeleteRenderbuffer(renderbuffer);
    }
    
    @Override
    public void glDeleteShader(final int shader) {
        SDLGL.glDeleteShader(shader);
    }
    
    @Override
    public void glDetachShader(final int program, final int shader) {
        SDLGL.glDetachShader(program, shader);
    }
    
    @Override
    public void glDisableVertexAttribArray(final int index) {
        SDLGL.glDisableVertexAttribArray(index);
    }
    
    @Override
    public void glDrawElements(final int mode, final int count, final int type, final int indices) {
        SDLGL.glDrawElements(mode, count, type, indices);
    }
    
    @Override
    public void glEnableVertexAttribArray(final int index) {
        SDLGL.glEnableVertexAttribArray(index);
    }
    
    @Override
    public void glFramebufferRenderbuffer(final int target, final int attachment, final int renderbuffertarget, final int renderbuffer) {
        SDLGL.glFramebufferRenderbuffer(target, attachment, renderbuffertarget, renderbuffer);
    }
    
    @Override
    public void glFramebufferTexture2D(final int target, final int attachment, final int textarget, final int texture, final int level) {
        SDLGL.glFramebufferTexture2D(target, attachment, textarget, texture, level);
    }
    
    @Override
    public int glGenBuffer() {
        return SDLGL.glGenBuffer();
    }
    
    @Override
    public void glGenerateMipmap(final int target) {
        SDLGL.glGenerateMipmap(target);
    }
    
    @Override
    public int glGenFramebuffer() {
        return SDLGL.glGenFramebuffer();
    }
    
    @Override
    public int glGenRenderbuffer() {
        return SDLGL.glGenRenderbuffer();
    }
    
    @Override
    public String glGetActiveAttrib(final int program, final int index, final IntBuffer size, final IntBuffer type) {
        return SDLGL.glGetActiveAttrib(program, index, size, type);
    }
    
    @Override
    public String glGetActiveUniform(final int program, final int index, final IntBuffer size, final IntBuffer type) {
        return SDLGL.glGetActiveUniform(program, index, size, type);
    }
    
    @Override
    public int glGetAttribLocation(final int program, final String name) {
        return SDLGL.glGetAttribLocation(program, name);
    }
    
    @Override
    public void glGetBooleanv(final int pname, final Buffer params) {
        SDLGL.glGetBooleanv(pname, params);
    }
    
    @Override
    public void glGetBufferParameteriv(final int target, final int pname, final IntBuffer params) {
        SDLGL.glGetBufferParameteriv(target, pname, params);
    }
    
    @Override
    public void glGetFloatv(final int pname, final FloatBuffer params) {
        SDLGL.glGetFloatv(pname, params);
    }
    
    @Override
    public void glGetFramebufferAttachmentParameteriv(final int target, final int attachment, final int pname, final IntBuffer params) {
        SDLGL.glGetFramebufferAttachmentParameteriv(target, attachment, pname, params);
    }
    
    @Override
    public void glGetProgramiv(final int program, final int pname, final IntBuffer params) {
        SDLGL.glGetProgramiv(program, pname, params);
    }
    
    @Override
    public String glGetProgramInfoLog(final int program) {
        return SDLGL.glGetProgramInfoLog(program);
    }
    
    @Override
    public void glGetRenderbufferParameteriv(final int target, final int pname, final IntBuffer params) {
        SDLGL.glGetRenderbufferParameteriv(target, pname, params);
    }
    
    @Override
    public void glGetShaderiv(final int shader, final int pname, final IntBuffer params) {
        SDLGL.glGetShaderiv(shader, pname, params);
    }
    
    @Override
    public String glGetShaderInfoLog(final int shader) {
        return SDLGL.glGetShaderInfoLog(shader);
    }
    
    @Override
    public void glGetShaderPrecisionFormat(final int shadertype, final int precisiontype, final IntBuffer range, final IntBuffer precision) {
        SDLGL.glGetShaderPrecisionFormat(shadertype, precisiontype, range, precision);
    }
    
    @Override
    public void glGetTexParameterfv(final int target, final int pname, final FloatBuffer params) {
        SDLGL.glGetTexParameterfv(target, pname, params);
    }
    
    @Override
    public void glGetTexParameteriv(final int target, final int pname, final IntBuffer params) {
        SDLGL.glGetTexParameteriv(target, pname, params);
    }
    
    @Override
    public void glGetUniformfv(final int program, final int location, final FloatBuffer params) {
        SDLGL.glGetUniformfv(program, location, params);
    }
    
    @Override
    public void glGetUniformiv(final int program, final int location, final IntBuffer params) {
        SDLGL.glGetUniformiv(program, location, params);
    }
    
    @Override
    public int glGetUniformLocation(final int program, final String name) {
        return SDLGL.glGetUniformLocation(program, name);
    }
    
    @Override
    public void glGetVertexAttribfv(final int index, final int pname, final FloatBuffer params) {
        SDLGL.glGetVertexAttribfv(index, pname, params);
    }
    
    @Override
    public void glGetVertexAttribiv(final int index, final int pname, final IntBuffer params) {
        SDLGL.glGetVertexAttribiv(index, pname, params);
    }
    
    @Override
    public boolean glIsBuffer(final int buffer) {
        return SDLGL.glIsBuffer(buffer);
    }
    
    @Override
    public boolean glIsEnabled(final int cap) {
        return SDLGL.glIsEnabled(cap);
    }
    
    @Override
    public boolean glIsFramebuffer(final int framebuffer) {
        return SDLGL.glIsFramebuffer(framebuffer);
    }
    
    @Override
    public boolean glIsProgram(final int program) {
        return SDLGL.glIsProgram(program);
    }
    
    @Override
    public boolean glIsRenderbuffer(final int renderbuffer) {
        return SDLGL.glIsRenderbuffer(renderbuffer);
    }
    
    @Override
    public boolean glIsShader(final int shader) {
        return SDLGL.glIsShader(shader);
    }
    
    @Override
    public boolean glIsTexture(final int texture) {
        return SDLGL.glIsTexture(texture);
    }
    
    @Override
    public void glLinkProgram(final int program) {
        SDLGL.glLinkProgram(program);
    }
    
    @Override
    public void glReleaseShaderCompiler() {
        SDLGL.glReleaseShaderCompiler();
    }
    
    @Override
    public void glRenderbufferStorage(final int target, final int internalformat, final int width, final int height) {
        SDLGL.glRenderbufferStorage(target, internalformat, width, height);
    }
    
    @Override
    public void glSampleCoverage(final float value, final boolean invert) {
        SDLGL.glSampleCoverage(value, invert);
    }
    
    @Override
    public void glShaderSource(final int shader, final String string) {
        SDLGL.glShaderSource(shader, string);
    }
    
    @Override
    public void glStencilFuncSeparate(final int face, final int func, final int ref, final int mask) {
        SDLGL.glStencilFuncSeparate(face, func, ref, mask);
    }
    
    @Override
    public void glStencilMaskSeparate(final int face, final int mask) {
        SDLGL.glStencilMaskSeparate(face, mask);
    }
    
    @Override
    public void glStencilOpSeparate(final int face, final int fail, final int zfail, final int zpass) {
        SDLGL.glStencilOpSeparate(face, fail, zfail, zpass);
    }
    
    @Override
    public void glTexParameterfv(final int target, final int pname, final FloatBuffer params) {
        SDLGL.glTexParameterfv(target, pname, params);
    }
    
    @Override
    public void glTexParameteri(final int target, final int pname, final int param) {
        SDLGL.glTexParameteri(target, pname, param);
    }
    
    @Override
    public void glTexParameteriv(final int target, final int pname, final IntBuffer params) {
        SDLGL.glTexParameteriv(target, pname, params);
    }
    
    @Override
    public void glUniform1f(final int location, final float x) {
        SDLGL.glUniform1f(location, x);
    }
    
    @Override
    public void glUniform1fv(final int location, final int count, final FloatBuffer v) {
        SDLGL.glUniform1fv(location, count, v);
    }
    
    @Override
    public void glUniform1fv(final int location, final int count, final float[] v, final int offset) {
        SDLGL.glUniform1fv(location, count, v, offset);
    }
    
    @Override
    public void glUniform1i(final int location, final int x) {
        SDLGL.glUniform1i(location, x);
    }
    
    @Override
    public void glUniform1iv(final int location, final int count, final IntBuffer v) {
        SDLGL.glUniform1iv(location, count, v);
    }
    
    @Override
    public void glUniform1iv(final int location, final int count, final int[] v, final int offset) {
        SDLGL.glUniform1iv(location, count, v, offset);
    }
    
    @Override
    public void glUniform2f(final int location, final float x, final float y) {
        SDLGL.glUniform2f(location, x, y);
    }
    
    @Override
    public void glUniform2fv(final int location, final int count, final FloatBuffer v) {
        SDLGL.glUniform2fv(location, count, v);
    }
    
    @Override
    public void glUniform2fv(final int location, final int count, final float[] v, final int offset) {
        SDLGL.glUniform2fv(location, count, v, offset);
    }
    
    @Override
    public void glUniform2i(final int location, final int x, final int y) {
        SDLGL.glUniform2i(location, x, y);
    }
    
    @Override
    public void glUniform2iv(final int location, final int count, final IntBuffer v) {
        SDLGL.glUniform2iv(location, count, v);
    }
    
    @Override
    public void glUniform2iv(final int location, final int count, final int[] v, final int offset) {
        SDLGL.glUniform2iv(location, count, v, offset);
    }
    
    @Override
    public void glUniform3f(final int location, final float x, final float y, final float z) {
        SDLGL.glUniform3f(location, x, y, z);
    }
    
    @Override
    public void glUniform3fv(final int location, final int count, final FloatBuffer v) {
        SDLGL.glUniform3fv(location, count, v);
    }
    
    @Override
    public void glUniform3fv(final int location, final int count, final float[] v, final int offset) {
        SDLGL.glUniform3fv(location, count, v, offset);
    }
    
    @Override
    public void glUniform3i(final int location, final int x, final int y, final int z) {
        SDLGL.glUniform3i(location, x, y, z);
    }
    
    @Override
    public void glUniform3iv(final int location, final int count, final IntBuffer v) {
        SDLGL.glUniform3iv(location, count, v);
    }
    
    @Override
    public void glUniform3iv(final int location, final int count, final int[] v, final int offset) {
        SDLGL.glUniform3iv(location, count, v, offset);
    }
    
    @Override
    public void glUniform4f(final int location, final float x, final float y, final float z, final float w) {
        SDLGL.glUniform4f(location, x, y, z, w);
    }
    
    @Override
    public void glUniform4fv(final int location, final int count, final FloatBuffer v) {
        SDLGL.glUniform4fv(location, count, v);
    }
    
    @Override
    public void glUniform4fv(final int location, final int count, final float[] v, final int offset) {
        SDLGL.glUniform4fv(location, count, v, offset);
    }
    
    @Override
    public void glUniform4i(final int location, final int x, final int y, final int z, final int w) {
        SDLGL.glUniform4i(location, x, y, z, w);
    }
    
    @Override
    public void glUniform4iv(final int location, final int count, final IntBuffer v) {
        SDLGL.glUniform4iv(location, count, v);
    }
    
    @Override
    public void glUniform4iv(final int location, final int count, final int[] v, final int offset) {
        SDLGL.glUniform4iv(location, count, v, offset);
    }
    
    @Override
    public void glUniformMatrix2fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        SDLGL.glUniformMatrix2fv(location, count, transpose, value);
    }
    
    @Override
    public void glUniformMatrix2fv(final int location, final int count, final boolean transpose, final float[] value, final int offset) {
        SDLGL.glUniformMatrix2fv(location, count, transpose, value, offset);
    }
    
    @Override
    public void glUniformMatrix3fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        SDLGL.glUniformMatrix3fv(location, count, transpose, value);
    }
    
    @Override
    public void glUniformMatrix3fv(final int location, final int count, final boolean transpose, final float[] value, final int offset) {
        SDLGL.glUniformMatrix3fv(location, count, transpose, value, offset);
    }
    
    @Override
    public void glUniformMatrix4fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        SDLGL.glUniformMatrix4fv(location, count, transpose, value);
    }
    
    @Override
    public void glUniformMatrix4fv(final int location, final int count, final boolean transpose, final float[] value, final int offset) {
        SDLGL.glUniformMatrix4fv(location, count, transpose, value, offset);
    }
    
    @Override
    public void glUseProgram(final int program) {
        SDLGL.glUseProgram(program);
    }
    
    @Override
    public void glValidateProgram(final int program) {
        SDLGL.glValidateProgram(program);
    }
    
    @Override
    public void glVertexAttrib1f(final int indx, final float x) {
        SDLGL.glVertexAttrib1f(indx, x);
    }
    
    @Override
    public void glVertexAttrib1fv(final int indx, final FloatBuffer values) {
        SDLGL.glVertexAttrib1fv(indx, values);
    }
    
    @Override
    public void glVertexAttrib2f(final int indx, final float x, final float y) {
        SDLGL.glVertexAttrib2f(indx, x, y);
    }
    
    @Override
    public void glVertexAttrib2fv(final int indx, final FloatBuffer values) {
        SDLGL.glVertexAttrib2fv(indx, values);
    }
    
    @Override
    public void glVertexAttrib3f(final int indx, final float x, final float y, final float z) {
        SDLGL.glVertexAttrib3f(indx, x, y, z);
    }
    
    @Override
    public void glVertexAttrib3fv(final int indx, final FloatBuffer values) {
        SDLGL.glVertexAttrib3fv(indx, values);
    }
    
    @Override
    public void glVertexAttrib4f(final int indx, final float x, final float y, final float z, final float w) {
        SDLGL.glVertexAttrib4f(indx, x, y, z, w);
    }
    
    @Override
    public void glVertexAttrib4fv(final int indx, final FloatBuffer values) {
        SDLGL.glVertexAttrib4fv(indx, values);
    }
    
    @Override
    public void glVertexAttribPointer(final int indx, final int size, final int type, final boolean normalized, final int stride, final Buffer ptr) {
        SDLGL.glVertexAttribPointer(indx, size, type, normalized, stride, ptr);
    }
    
    @Override
    public void glVertexAttribPointer(final int indx, final int size, final int type, final boolean normalized, final int stride, final int ptr) {
        SDLGL.glVertexAttribPointer(indx, size, type, normalized, stride, ptr);
    }
}
