// 
// Decompiled by Procyon v0.5.36
// 

package arc.backend.sdl.jni;

import arc.util.ArcRuntimeException;
import java.nio.LongBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.Buffer;
import arc.util.Nullable;

public class SDLGL
{
    @Nullable
    private static native String init();
    
    public static native void glActiveTexture(final int p0);
    
    public static native void glBindTexture(final int p0, final int p1);
    
    public static native void glBlendFunc(final int p0, final int p1);
    
    public static native void glClear(final int p0);
    
    public static native void glClearColor(final float p0, final float p1, final float p2, final float p3);
    
    public static native void glClearDepthf(final float p0);
    
    public static native void glClearStencil(final int p0);
    
    public static native void glColorMask(final boolean p0, final boolean p1, final boolean p2, final boolean p3);
    
    public static native void glCompressedTexImage2D(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final Buffer p7);
    
    public static native void glCompressedTexSubImage2D(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final Buffer p8);
    
    public static native void glCopyTexImage2D(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7);
    
    public static native void glCopyTexSubImage2D(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7);
    
    public static native void glCullFace(final int p0);
    
    public static native void glDeleteTexture(final int p0);
    
    public static native void glDepthFunc(final int p0);
    
    public static native void glDepthMask(final boolean p0);
    
    public static native void glDepthRangef(final float p0, final float p1);
    
    public static native void glDisable(final int p0);
    
    public static native void glDrawArrays(final int p0, final int p1, final int p2);
    
    public static native void glDrawElements(final int p0, final int p1, final int p2, final Buffer p3);
    
    public static native void glEnable(final int p0);
    
    public static native void glFinish();
    
    public static native void glFlush();
    
    public static native void glFrontFace(final int p0);
    
    public static native int glGenTexture();
    
    public static native int glGetError();
    
    public static native void glGetIntegerv(final int p0, final IntBuffer p1);
    
    public static native String glGetString(final int p0);
    
    public static native void glHint(final int p0, final int p1);
    
    public static native void glLineWidth(final float p0);
    
    public static native void glPixelStorei(final int p0, final int p1);
    
    public static native void glPolygonOffset(final float p0, final float p1);
    
    public static native void glReadPixels(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final Buffer p6);
    
    public static native void glScissor(final int p0, final int p1, final int p2, final int p3);
    
    public static native void glStencilFunc(final int p0, final int p1, final int p2);
    
    public static native void glStencilMask(final int p0);
    
    public static native void glStencilOp(final int p0, final int p1, final int p2);
    
    public static native void glTexImage2D(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final Buffer p8);
    
    public static native void glTexParameterf(final int p0, final int p1, final float p2);
    
    public static native void glTexSubImage2D(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final Buffer p8);
    
    public static native void glViewport(final int p0, final int p1, final int p2, final int p3);
    
    public static native void glAttachShader(final int p0, final int p1);
    
    public static native void glBindAttribLocation(final int p0, final int p1, final String p2);
    
    public static native void glBindBuffer(final int p0, final int p1);
    
    public static native void glBindFramebuffer(final int p0, final int p1);
    
    public static native void glBindRenderbuffer(final int p0, final int p1);
    
    public static native void glBlendColor(final float p0, final float p1, final float p2, final float p3);
    
    public static native void glBlendEquation(final int p0);
    
    public static native void glBlendEquationSeparate(final int p0, final int p1);
    
    public static native void glBlendFuncSeparate(final int p0, final int p1, final int p2, final int p3);
    
    public static native void glBufferData(final int p0, final int p1, final Buffer p2, final int p3);
    
    public static native void glBufferSubData(final int p0, final int p1, final int p2, final Buffer p3);
    
    public static native int glCheckFramebufferStatus(final int p0);
    
    public static native void glCompileShader(final int p0);
    
    public static native int glCreateProgram();
    
    public static native int glCreateShader(final int p0);
    
    public static native void glDeleteBuffer(final int p0);
    
    public static native void glDeleteFramebuffer(final int p0);
    
    public static native void glDeleteProgram(final int p0);
    
    public static native void glDeleteRenderbuffer(final int p0);
    
    public static native void glDeleteShader(final int p0);
    
    public static native void glDetachShader(final int p0, final int p1);
    
    public static native void glDisableVertexAttribArray(final int p0);
    
    public static native void glDrawElements(final int p0, final int p1, final int p2, final int p3);
    
    public static native void glEnableVertexAttribArray(final int p0);
    
    public static native void glFramebufferRenderbuffer(final int p0, final int p1, final int p2, final int p3);
    
    public static native void glFramebufferTexture2D(final int p0, final int p1, final int p2, final int p3, final int p4);
    
    public static native int glGenBuffer();
    
    public static native void glGenerateMipmap(final int p0);
    
    public static native int glGenFramebuffer();
    
    public static native int glGenRenderbuffer();
    
    public static native String glGetActiveAttrib(final int p0, final int p1, final Object p2, final Object p3);
    
    public static native String glGetActiveUniform(final int p0, final int p1, final Object p2, final Object p3);
    
    public static native int glGetAttribLocation(final int p0, final String p1);
    
    public static native void glGetBooleanv(final int p0, final Buffer p1);
    
    public static native void glGetBufferParameteriv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glGetFloatv(final int p0, final FloatBuffer p1);
    
    public static native void glGetFramebufferAttachmentParameteriv(final int p0, final int p1, final int p2, final IntBuffer p3);
    
    public static native void glGetProgramiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native String glGetProgramInfoLog(final int p0);
    
    public static native void glGetRenderbufferParameteriv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glGetShaderiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native String glGetShaderInfoLog(final int p0);
    
    public static native void glGetShaderPrecisionFormat(final int p0, final int p1, final IntBuffer p2, final IntBuffer p3);
    
    public static native void glGetTexParameterfv(final int p0, final int p1, final FloatBuffer p2);
    
    public static native void glGetTexParameteriv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glGetUniformfv(final int p0, final int p1, final FloatBuffer p2);
    
    public static native void glGetUniformiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native int glGetUniformLocation(final int p0, final String p1);
    
    public static native void glGetVertexAttribfv(final int p0, final int p1, final FloatBuffer p2);
    
    public static native void glGetVertexAttribiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native boolean glIsBuffer(final int p0);
    
    public static native boolean glIsEnabled(final int p0);
    
    public static native boolean glIsFramebuffer(final int p0);
    
    public static native boolean glIsProgram(final int p0);
    
    public static native boolean glIsRenderbuffer(final int p0);
    
    public static native boolean glIsShader(final int p0);
    
    public static native boolean glIsTexture(final int p0);
    
    public static native void glLinkProgram(final int p0);
    
    public static native void glReleaseShaderCompiler();
    
    public static native void glRenderbufferStorage(final int p0, final int p1, final int p2, final int p3);
    
    public static native void glSampleCoverage(final float p0, final boolean p1);
    
    public static native void glShaderSource(final int p0, final String p1);
    
    public static native void glStencilFuncSeparate(final int p0, final int p1, final int p2, final int p3);
    
    public static native void glStencilMaskSeparate(final int p0, final int p1);
    
    public static native void glStencilOpSeparate(final int p0, final int p1, final int p2, final int p3);
    
    public static native void glTexParameterfv(final int p0, final int p1, final FloatBuffer p2);
    
    public static native void glTexParameteri(final int p0, final int p1, final int p2);
    
    public static native void glTexParameteriv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glUniform1f(final int p0, final float p1);
    
    public static native void glUniform1fv(final int p0, final int p1, final FloatBuffer p2);
    
    public static native void glUniform1fv(final int p0, final int p1, final float[] p2, final int p3);
    
    public static native void glUniform1i(final int p0, final int p1);
    
    public static native void glUniform1iv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glUniform1iv(final int p0, final int p1, final int[] p2, final int p3);
    
    public static native void glUniform2f(final int p0, final float p1, final float p2);
    
    public static native void glUniform2fv(final int p0, final int p1, final FloatBuffer p2);
    
    public static native void glUniform2fv(final int p0, final int p1, final float[] p2, final int p3);
    
    public static native void glUniform2i(final int p0, final int p1, final int p2);
    
    public static native void glUniform2iv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glUniform2iv(final int p0, final int p1, final int[] p2, final int p3);
    
    public static native void glUniform3f(final int p0, final float p1, final float p2, final float p3);
    
    public static native void glUniform3fv(final int p0, final int p1, final FloatBuffer p2);
    
    public static native void glUniform3fv(final int p0, final int p1, final float[] p2, final int p3);
    
    public static native void glUniform3i(final int p0, final int p1, final int p2, final int p3);
    
    public static native void glUniform3iv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glUniform3iv(final int p0, final int p1, final int[] p2, final int p3);
    
    public static native void glUniform4f(final int p0, final float p1, final float p2, final float p3, final float p4);
    
    public static native void glUniform4fv(final int p0, final int p1, final FloatBuffer p2);
    
    public static native void glUniform4fv(final int p0, final int p1, final float[] p2, final int p3);
    
    public static native void glUniform4i(final int p0, final int p1, final int p2, final int p3, final int p4);
    
    public static native void glUniform4iv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glUniform4iv(final int p0, final int p1, final int[] p2, final int p3);
    
    public static native void glUniformMatrix2fv(final int p0, final int p1, final boolean p2, final FloatBuffer p3);
    
    public static native void glUniformMatrix2fv(final int p0, final int p1, final boolean p2, final float[] p3, final int p4);
    
    public static native void glUniformMatrix3fv(final int p0, final int p1, final boolean p2, final FloatBuffer p3);
    
    public static native void glUniformMatrix3fv(final int p0, final int p1, final boolean p2, final float[] p3, final int p4);
    
    public static native void glUniformMatrix4fv(final int p0, final int p1, final boolean p2, final FloatBuffer p3);
    
    public static native void glUniformMatrix4fv(final int p0, final int p1, final boolean p2, final float[] p3, final int p4);
    
    public static native void glUseProgram(final int p0);
    
    public static native void glValidateProgram(final int p0);
    
    public static native void glVertexAttrib1f(final int p0, final float p1);
    
    public static native void glVertexAttrib1fv(final int p0, final FloatBuffer p1);
    
    public static native void glVertexAttrib2f(final int p0, final float p1, final float p2);
    
    public static native void glVertexAttrib2fv(final int p0, final FloatBuffer p1);
    
    public static native void glVertexAttrib3f(final int p0, final float p1, final float p2, final float p3);
    
    public static native void glVertexAttrib3fv(final int p0, final FloatBuffer p1);
    
    public static native void glVertexAttrib4f(final int p0, final float p1, final float p2, final float p3, final float p4);
    
    public static native void glVertexAttrib4fv(final int p0, final FloatBuffer p1);
    
    public static native void glVertexAttribPointer(final int p0, final int p1, final int p2, final boolean p3, final int p4, final Object p5);
    
    public static native void glVertexAttribPointer(final int p0, final int p1, final int p2, final boolean p3, final int p4, final int p5);
    
    public static native void glReadBuffer(final int p0);
    
    public static native void glDrawRangeElements(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5);
    
    public static native void glDrawRangeElements(final int p0, final int p1, final int p2, final int p3, final int p4, final Buffer p5);
    
    public static native void glTexImage3D(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final int p8, final int p9);
    
    public static native void glTexImage3D(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final int p8, final Buffer p9);
    
    public static native void glTexSubImage3D(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final int p8, final int p9, final int p10);
    
    public static native void glTexSubImage3D(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final int p8, final int p9, final Buffer p10);
    
    public static native void glCopyTexSubImage3D(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final int p8);
    
    public static native void glGenQueries(final int p0, final IntBuffer p1);
    
    public static native void glDeleteQueries(final int p0, final IntBuffer p1);
    
    public static native boolean glIsQuery(final int p0);
    
    public static native void glBeginQuery(final int p0, final int p1);
    
    public static native void glEndQuery(final int p0);
    
    public static native void glGetQueryiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glGetQueryObjectuiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native boolean glUnmapBuffer(final int p0);
    
    public static native Buffer glGetBufferPointerv(final int p0, final int p1);
    
    public static native void glDrawBuffers(final int p0, final IntBuffer p1);
    
    public static native void glUniformMatrix2x3fv(final int p0, final int p1, final boolean p2, final FloatBuffer p3);
    
    public static native void glUniformMatrix3x2fv(final int p0, final int p1, final boolean p2, final FloatBuffer p3);
    
    public static native void glUniformMatrix2x4fv(final int p0, final int p1, final boolean p2, final FloatBuffer p3);
    
    public static native void glUniformMatrix4x2fv(final int p0, final int p1, final boolean p2, final FloatBuffer p3);
    
    public static native void glUniformMatrix3x4fv(final int p0, final int p1, final boolean p2, final FloatBuffer p3);
    
    public static native void glUniformMatrix4x3fv(final int p0, final int p1, final boolean p2, final FloatBuffer p3);
    
    public static native void glBlitFramebuffer(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final int p8, final int p9);
    
    public static native void glRenderbufferStorageMultisample(final int p0, final int p1, final int p2, final int p3, final int p4);
    
    public static native void glFramebufferTextureLayer(final int p0, final int p1, final int p2, final int p3, final int p4);
    
    public static native void glFlushMappedBufferRange(final int p0, final int p1, final int p2);
    
    public static native void glBindVertexArray(final int p0);
    
    public static native void glDeleteVertexArrays(final int p0, final IntBuffer p1);
    
    public static native void glGenVertexArrays(final int p0, final IntBuffer p1);
    
    public static native boolean glIsVertexArray(final int p0);
    
    public static native void glBeginTransformFeedback(final int p0);
    
    public static native void glEndTransformFeedback();
    
    public static native void glBindBufferRange(final int p0, final int p1, final int p2, final int p3, final int p4);
    
    public static native void glBindBufferBase(final int p0, final int p1, final int p2);
    
    public static native void glTransformFeedbackVaryings(final int p0, final String[] p1, final int p2);
    
    public static native void glVertexAttribIPointer(final int p0, final int p1, final int p2, final int p3, final int p4);
    
    public static native void glGetVertexAttribIiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glGetVertexAttribIuiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glVertexAttribI4i(final int p0, final int p1, final int p2, final int p3, final int p4);
    
    public static native void glVertexAttribI4ui(final int p0, final int p1, final int p2, final int p3, final int p4);
    
    public static native void glGetUniformuiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native int glGetFragDataLocation(final int p0, final String p1);
    
    public static native void glUniform1uiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glUniform3uiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glUniform4uiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glClearBufferiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glClearBufferuiv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glClearBufferfv(final int p0, final int p1, final FloatBuffer p2);
    
    public static native void glClearBufferfi(final int p0, final int p1, final float p2, final int p3);
    
    public static native String glGetStringi(final int p0, final int p1);
    
    public static native void glCopyBufferSubData(final int p0, final int p1, final int p2, final int p3, final int p4);
    
    public static native void glGetUniformIndices(final int p0, final String[] p1, final IntBuffer p2);
    
    public static native void glGetActiveUniformsiv(final int p0, final int p1, final IntBuffer p2, final int p3, final IntBuffer p4);
    
    public static native int glGetUniformBlockIndex(final int p0, final String p1);
    
    public static native void glGetActiveUniformBlockiv(final int p0, final int p1, final int p2, final IntBuffer p3);
    
    public static native void glGetActiveUniformBlockName(final int p0, final int p1, final Buffer p2, final Buffer p3);
    
    public static native void glUniformBlockBinding(final int p0, final int p1, final int p2);
    
    public static native void glDrawArraysInstanced(final int p0, final int p1, final int p2, final int p3);
    
    public static native void glDrawElementsInstanced(final int p0, final int p1, final int p2, final int p3, final int p4);
    
    public static native void glGetInteger64v(final int p0, final LongBuffer p1);
    
    public static native void glGetBufferParameteri64v(final int p0, final int p1, final LongBuffer p2);
    
    public static native void glGenSamplers(final int p0, final IntBuffer p1);
    
    public static native void glDeleteSamplers(final int p0, final IntBuffer p1);
    
    public static native boolean glIsSampler(final int p0);
    
    public static native void glBindSampler(final int p0, final int p1);
    
    public static native void glSamplerParameteri(final int p0, final int p1, final int p2);
    
    public static native void glSamplerParameteriv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glSamplerParameterf(final int p0, final int p1, final float p2);
    
    public static native void glSamplerParameterfv(final int p0, final int p1, final FloatBuffer p2);
    
    public static native void glGetSamplerParameteriv(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glGetSamplerParameterfv(final int p0, final int p1, final FloatBuffer p2);
    
    public static native void glVertexAttribDivisor(final int p0, final int p1);
    
    public static native void glBindTransformFeedback(final int p0, final int p1);
    
    public static native void glDeleteTransformFeedbacks(final int p0, final IntBuffer p1);
    
    public static native void glGenTransformFeedbacks(final int p0, final IntBuffer p1);
    
    public static native boolean glIsTransformFeedback(final int p0);
    
    public static native void glPauseTransformFeedback();
    
    public static native void glResumeTransformFeedback();
    
    public static native void glProgramParameteri(final int p0, final int p1, final int p2);
    
    public static native void glInvalidateFramebuffer(final int p0, final int p1, final IntBuffer p2);
    
    public static native void glInvalidateSubFramebuffer(final int p0, final int p1, final IntBuffer p2, final int p3, final int p4, final int p5, final int p6);
    
    static {
        final String errorMessage = init();
        if (errorMessage != null) {
            throw new ArcRuntimeException("GLEW failed to initialize: " + errorMessage);
        }
    }
}
