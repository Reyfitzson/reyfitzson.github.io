// 
// Decompiled by Procyon v0.5.36
// 

package arc.backend.sdl.jni;

import java.io.File;
import java.io.InputStream;
import arc.util.SharedLibraryLoader;
import arc.util.OS;
import java.nio.ByteBuffer;

public class SDL
{
    public static final int SDL_INIT_TIMER = 1;
    public static final int SDL_INIT_AUDIO = 16;
    public static final int SDL_INIT_VIDEO = 32;
    public static final int SDL_INIT_JOYSTICK = 512;
    public static final int SDL_INIT_HAPTIC = 4096;
    public static final int SDL_INIT_GAMECONTROLLER = 8192;
    public static final int SDL_INIT_EVENTS = 16384;
    public static final int SDL_INIT_NOPARACHUTE = 1048576;
    public static final int SDL_INIT_EVERYTHING = 29233;
    public static final int SDL_WINDOW_FULLSCREEN = 1;
    public static final int SDL_WINDOW_OPENGL = 2;
    public static final int SDL_WINDOW_SHOWN = 4;
    public static final int SDL_WINDOW_HIDDEN = 8;
    public static final int SDL_WINDOW_BORDERLESS = 16;
    public static final int SDL_WINDOW_RESIZABLE = 32;
    public static final int SDL_WINDOW_MINIMIZED = 64;
    public static final int SDL_WINDOW_MAXIMIZED = 128;
    public static final int SDL_WINDOW_INPUT_GRABBED = 256;
    public static final int SDL_WINDOW_INPUT_FOCUS = 512;
    public static final int SDL_WINDOW_MOUSE_FOCUS = 1024;
    public static final int SDL_WINDOW_FULLSCREEN_DESKTOP = 4097;
    public static final int SDL_WINDOW_FOREIGN = 2048;
    public static final int SDL_WINDOW_ALLOW_HIGHDPI = 8192;
    public static final int SDL_WINDOW_MOUSE_CAPTURE = 16384;
    public static final int SDL_WINDOWEVENT_NONE = 0;
    public static final int SDL_WINDOWEVENT_SHOWN = 1;
    public static final int SDL_WINDOWEVENT_HIDDEN = 2;
    public static final int SDL_WINDOWEVENT_EXPOSED = 3;
    public static final int SDL_WINDOWEVENT_MOVED = 4;
    public static final int SDL_WINDOWEVENT_RESIZED = 5;
    public static final int SDL_WINDOWEVENT_SIZE_CHANGED = 6;
    public static final int SDL_WINDOWEVENT_MINIMIZED = 7;
    public static final int SDL_WINDOWEVENT_MAXIMIZED = 8;
    public static final int SDL_WINDOWEVENT_RESTORED = 9;
    public static final int SDL_WINDOWEVENT_ENTER = 10;
    public static final int SDL_WINDOWEVENT_LEAVE = 11;
    public static final int SDL_WINDOWEVENT_FOCUS_GAINED = 12;
    public static final int SDL_WINDOWEVENT_FOCUS_LOST = 13;
    public static final int SDL_WINDOWEVENT_CLOSE = 14;
    public static final int SDL_SYSTEM_CURSOR_ARROW = 0;
    public static final int SDL_SYSTEM_CURSOR_IBEAM = 1;
    public static final int SDL_SYSTEM_CURSOR_WAIT = 2;
    public static final int SDL_SYSTEM_CURSOR_CROSSHAIR = 3;
    public static final int SDL_SYSTEM_CURSOR_WAITARROW = 4;
    public static final int SDL_SYSTEM_CURSOR_SIZENWSE = 5;
    public static final int SDL_SYSTEM_CURSOR_SIZENESW = 6;
    public static final int SDL_SYSTEM_CURSOR_SIZEWE = 7;
    public static final int SDL_SYSTEM_CURSOR_SIZENS = 8;
    public static final int SDL_SYSTEM_CURSOR_SIZEALL = 9;
    public static final int SDL_SYSTEM_CURSOR_NO = 10;
    public static final int SDL_SYSTEM_CURSOR_HAND = 11;
    public static final int SDL_NUM_SYSTEM_CURSORS = 12;
    public static final int SDL_MESSAGEBOX_ERROR = 16;
    public static final int SDL_MESSAGEBOX_WARNING = 32;
    public static final int SDL_MESSAGEBOX_INFORMATION = 64;
    public static final int SDL_BUTTON_LEFT = 1;
    public static final int SDL_BUTTON_MIDDLE = 2;
    public static final int SDL_BUTTON_RIGHT = 3;
    public static final int SDL_BUTTON_X1 = 4;
    public static final int SDL_BUTTON_X2 = 5;
    public static final int SDL_EVENT_QUIT = 0;
    public static final int SDL_EVENT_WINDOW = 1;
    public static final int SDL_EVENT_MOUSE_MOTION = 2;
    public static final int SDL_EVENT_MOUSE_BUTTON = 3;
    public static final int SDL_EVENT_MOUSE_WHEEL = 4;
    public static final int SDL_EVENT_KEYBOARD = 5;
    public static final int SDL_EVENT_TEXT_INPUT = 6;
    public static final int SDL_EVENT_OTHER = 7;
    public static final int SDL_GL_RED_SIZE = 0;
    public static final int SDL_GL_GREEN_SIZE = 1;
    public static final int SDL_GL_BLUE_SIZE = 2;
    public static final int SDL_GL_ALPHA_SIZE = 3;
    public static final int SDL_GL_BUFFER_SIZE = 4;
    public static final int SDL_GL_DOUBLEBUFFER = 5;
    public static final int SDL_GL_DEPTH_SIZE = 6;
    public static final int SDL_GL_STENCIL_SIZE = 7;
    public static final int SDL_GL_CONTEXT_MAJOR_VERSION = 17;
    public static final int SDL_GL_CONTEXT_MINOR_VERSION = 18;
    public static final int SDL_GL_MULTISAMPLEBUFFERS = 13;
    public static final int SDL_GL_MULTISAMPLESAMPLES = 14;
    public static final int SDL_GL_CONTEXT_PROFILE_CORE = 1;
    public static final int SDL_GL_CONTEXT_PROFILE_MASK = 21;
    public static final int SDL_GL_CONTEXT_FLAGS = 20;
    
    public static native int SDL_Init(final int p0);
    
    public static native int SDL_InitSubSystem(final int p0);
    
    public static native void SDL_QuitSubSystem(final int p0);
    
    public static native int SDL_WasInit(final int p0);
    
    public static native void SDL_Quit();
    
    public static native boolean SDL_SetHint(final String p0, final String p1);
    
    public static native String SDL_GetError();
    
    public static native int SDL_SetClipboardText(final String p0);
    
    public static native String SDL_GetClipboardText();
    
    public static native long SDL_CreateWindow(final String p0, final int p1, final int p2, final int p3);
    
    public static native void SDL_DestroyWindow(final long p0);
    
    public static native void SDL_SetWindowIcon(final long p0, final long p1);
    
    public static native void SDL_RestoreWindow(final long p0);
    
    public static native void SDL_MaximizeWindow(final long p0);
    
    public static native void SDL_MinimizeWindow(final long p0);
    
    public static native int SDL_SetWindowFullscreen(final long p0, final int p1);
    
    public static native void SDL_SetWindowBordered(final long p0, final boolean p1);
    
    public static native void SDL_SetWindowSize(final long p0, final int p1, final int p2);
    
    public static native int SDL_GetWindowFlags(final long p0);
    
    public static native void SDL_SetWindowTitle(final long p0, final String p1);
    
    public static native long SDL_CreateRGBSurfaceFrom(final ByteBuffer p0, final int p1, final int p2);
    
    public static native long SDL_CreateColorCursor(final long p0, final int p1, final int p2);
    
    public static native long SDL_CreateSystemCursor(final int p0);
    
    public static native void SDL_SetCursor(final long p0);
    
    public static native void SDL_FreeCursor(final long p0);
    
    public static native void SDL_FreeSurface(final long p0);
    
    public static native int SDL_ShowSimpleMessageBox(final int p0, final String p1, final String p2);
    
    public static native void SDL_StartTextInput();
    
    public static native void SDL_StopTextInput();
    
    public static native boolean SDL_PollEvent(final int[] p0);
    
    public static native int SDL_GL_SetAttribute(final int p0, final int p1);
    
    public static native boolean SDL_GL_ExtensionSupported(final String p0);
    
    public static native long SDL_GL_CreateContext(final long p0);
    
    public static native int SDL_GL_SetSwapInterval(final int p0);
    
    public static native void SDL_GL_SwapWindow(final long p0);
    
    static {
        if (OS.isWindows) {
            new SharedLibraryLoader() {
                @Override
                public String mapLibraryName(final String libraryName) {
                    return libraryName + ".dll";
                }
                
                @Override
                protected InputStream readFile(final String path) {
                    return super.readFile(OS.is64Bit ? "OpenAL.dll" : "OpenAL32.dll");
                }
            }.load("OpenAL32");
        }
        else if (OS.isLinux) {
            new SharedLibraryLoader() {
                @Override
                public String mapLibraryName(final String libraryName) {
                    return "lib" + libraryName + ".so";
                }
            }.load("openal");
        }
        new SharedLibraryLoader() {
            @Override
            protected Throwable loadFile(final String sourcePath, final String sourceCrc, final File extractedFile) {
                if (OS.isWindows) {
                    try {
                        this.extractFile(OS.is64Bit ? "OpenAL.dll" : "OpenAL32.dll", sourceCrc, new File((extractedFile.getParentFile() == null) ? "OpenAL32.dll" : (extractedFile.getParentFile() + "/OpenAL32.dll")));
                    }
                    catch (Throwable t) {}
                }
                return super.loadFile(sourcePath, sourceCrc, extractedFile);
            }
        }.load("sdl-arc");
    }
}
