// 
// Decompiled by Procyon v0.5.36
// 

package arc.backend.sdl;

import arc.util.ArcRuntimeException;
import java.io.File;
import arc.files.Fi;
import arc.Files;

public final class SdlFiles implements Files
{
    public static final String externalPath;
    public static final String localPath;
    
    @Override
    public Fi get(final String fileName, final FileType type) {
        return new SdlFi(fileName, type);
    }
    
    @Override
    public String getExternalStoragePath() {
        return SdlFiles.externalPath;
    }
    
    @Override
    public boolean isExternalStorageAvailable() {
        return true;
    }
    
    @Override
    public String getLocalStoragePath() {
        return SdlFiles.localPath;
    }
    
    @Override
    public boolean isLocalStorageAvailable() {
        return true;
    }
    
    static {
        externalPath = System.getProperty("user.home") + File.separator;
        localPath = new File("").getAbsolutePath() + File.separator;
    }
    
    public static final class SdlFi extends Fi
    {
        public SdlFi(final String fileName, final FileType type) {
            super(fileName, type);
        }
        
        public SdlFi(final File file, final FileType type) {
            super(file, type);
        }
        
        @Override
        public Fi child(final String name) {
            if (this.file.getPath().length() == 0) {
                return new SdlFi(new File(name), this.type);
            }
            return new SdlFi(new File(this.file, name), this.type);
        }
        
        @Override
        public Fi sibling(final String name) {
            if (this.file.getPath().length() == 0) {
                throw new ArcRuntimeException("Cannot get the sibling of the root.");
            }
            return new SdlFi(new File(this.file.getParent(), name), this.type);
        }
        
        @Override
        public File file() {
            if (this.type == FileType.external) {
                return new File(SdlFiles.externalPath, this.file.getPath());
            }
            if (this.type == FileType.local) {
                return new File(SdlFiles.localPath, this.file.getPath());
            }
            return this.file;
        }
    }
}
