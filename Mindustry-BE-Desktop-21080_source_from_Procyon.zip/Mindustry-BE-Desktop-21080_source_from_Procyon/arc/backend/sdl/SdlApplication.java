// 
// Decompiled by Procyon v0.5.36
// 

package arc.backend.sdl;

import arc.util.async.Threads;
import arc.func.Intp;
import java.util.Iterator;
import arc.func.Cons;
import arc.util.OS;
import arc.util.ArcNativesLoader;
import arc.backend.sdl.jni.SDL;
import arc.graphics.Pixmap;
import arc.audio.Audio;
import arc.Settings;
import arc.Net;
import arc.Core;
import arc.util.TaskQueue;
import arc.ApplicationListener;
import arc.struct.Seq;
import arc.Application;

public class SdlApplication implements Application
{
    private final Seq<ApplicationListener> listeners;
    private final TaskQueue runnables;
    private final int[] inputs;
    final SdlGraphics graphics;
    final SdlInput input;
    final SdlConfig config;
    boolean running;
    long window;
    long context;
    
    public SdlApplication(final ApplicationListener listener, final SdlConfig config) {
        this.listeners = new Seq<ApplicationListener>();
        this.runnables = new TaskQueue();
        this.inputs = new int[34];
        this.running = true;
        this.config = config;
        this.listeners.add(listener);
        this.init();
        Core.app = this;
        Core.files = new SdlFiles();
        Core.net = new Net();
        final SdlGraphics sdlGraphics = new SdlGraphics(this);
        this.graphics = sdlGraphics;
        Core.graphics = sdlGraphics;
        final SdlInput sdlInput = new SdlInput();
        this.input = sdlInput;
        Core.input = sdlInput;
        Core.settings = new Settings();
        Core.audio = new Audio();
        this.initIcon();
        this.graphics.updateSize(config.width, config.height);
        try {
            this.loop();
            this.listen(ApplicationListener::exit);
        }
        finally {
            try {
                this.cleanup();
            }
            catch (Throwable error) {
                error.printStackTrace();
            }
        }
    }
    
    private void initIcon() {
        if (this.config.windowIconPaths != null && this.config.windowIconPaths.length > 0) {
            final String path = this.config.windowIconPaths[0];
            try {
                final Pixmap p = new Pixmap(Core.files.get(path, this.config.windowIconFileType));
                final long surface = SDL.SDL_CreateRGBSurfaceFrom(p.getPixels(), p.getWidth(), p.getHeight());
                SDL.SDL_SetWindowIcon(this.window, surface);
                SDL.SDL_FreeSurface(surface);
                p.dispose();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    private void init() {
        ArcNativesLoader.load();
        this.check(() -> SDL.SDL_Init(16416));
        this.check(() -> SDL.SDL_GL_SetAttribute(17, this.config.gl30 ? this.config.gl30Major : 2));
        this.check(() -> SDL.SDL_GL_SetAttribute(18, this.config.gl30 ? this.config.gl30Minor : 0));
        if (this.config.gl30 && OS.isMac) {
            this.check(() -> SDL.SDL_GL_SetAttribute(21, 1));
        }
        this.check(() -> SDL.SDL_GL_SetAttribute(0, this.config.r));
        this.check(() -> SDL.SDL_GL_SetAttribute(1, this.config.g));
        this.check(() -> SDL.SDL_GL_SetAttribute(2, this.config.b));
        this.check(() -> SDL.SDL_GL_SetAttribute(6, this.config.depth));
        this.check(() -> SDL.SDL_GL_SetAttribute(7, this.config.stencil));
        this.check(() -> SDL.SDL_GL_SetAttribute(5, 1));
        if (this.config.samples > 0) {
            this.check(() -> SDL.SDL_GL_SetAttribute(13, 1));
            this.check(() -> SDL.SDL_GL_SetAttribute(14, this.config.samples));
        }
        int flags = 2;
        if (this.config.initialVisible) {
            flags |= 0x4;
        }
        if (!this.config.decorated) {
            flags |= 0x10;
        }
        if (this.config.resizable) {
            flags |= 0x20;
        }
        if (this.config.maximized) {
            flags |= 0x80;
        }
        this.window = SDL.SDL_CreateWindow(this.config.title, this.config.width, this.config.height, flags);
        if (this.window == 0L) {
            throw new SDLError();
        }
        this.context = SDL.SDL_GL_CreateContext(this.window);
        if (this.context == 0L) {
            throw new SDLError();
        }
        if (this.config.vSyncEnabled) {
            SDL.SDL_GL_SetSwapInterval(1);
        }
        SDL.SDL_StartTextInput();
    }
    
    private void loop() {
        this.graphics.updateSize(this.config.width, this.config.height);
        this.listen(ApplicationListener::init);
        while (this.running) {
            while (SDL.SDL_PollEvent(this.inputs)) {
                if (this.inputs[0] == 0) {
                    this.running = false;
                }
                else if (this.inputs[0] == 1) {
                    final int type = this.inputs[1];
                    if (type == 6) {
                        this.graphics.updateSize(this.inputs[2], this.inputs[3]);
                        this.listen(l -> l.resize(this.inputs[2], this.inputs[3]));
                    }
                    else if (type == 12) {
                        this.listen(ApplicationListener::resume);
                    }
                    else {
                        if (type != 13) {
                            continue;
                        }
                        this.listen(ApplicationListener::pause);
                    }
                }
                else {
                    if (this.inputs[0] != 2 && this.inputs[0] != 3 && this.inputs[0] != 4 && this.inputs[0] != 5 && this.inputs[0] != 6) {
                        continue;
                    }
                    this.input.handleInput(this.inputs);
                }
            }
            this.graphics.update();
            this.input.update();
            this.defaultUpdate();
            this.listen(ApplicationListener::update);
            this.runnables.run();
            SDL.SDL_GL_SwapWindow(this.window);
            this.input.postUpdate();
        }
    }
    
    private void listen(final Cons<ApplicationListener> cons) {
        synchronized (this.listeners) {
            for (final ApplicationListener l : this.listeners) {
                cons.get(l);
            }
        }
    }
    
    private void cleanup() {
        this.listen(l -> {
            l.pause();
            try {
                l.dispose();
            }
            catch (Throwable t) {
                t.printStackTrace();
            }
            return;
        });
        this.dispose();
        SDL.SDL_DestroyWindow(this.window);
        SDL.SDL_Quit();
    }
    
    private void check(final Intp run) {
        if (run.get() != 0) {
            throw new SDLError();
        }
    }
    
    @Override
    public boolean openFolder(final String file) {
        Threads.daemon(() -> {
            if (OS.isWindows) {
                OS.execSafe("explorer.exe /select," + file.replace("/", "\\"));
            }
            else if (OS.isLinux) {
                OS.execSafe("xdg-open " + file);
            }
            else if (OS.isMac) {
                OS.execSafe("open " + file);
            }
            return;
        });
        return true;
    }
    
    @Override
    public boolean openURI(final String url) {
        try {
            if (OS.isMac) {
                Class.forName("com.apple.eio.FileManager").getMethod("openURL", String.class).invoke(null, url);
                return true;
            }
            if (OS.isLinux) {
                return OS.execSafe("xdg-open " + url);
            }
            return OS.isWindows && OS.execSafe("rundll32 url.dll,FileProtocolHandler " + url);
        }
        catch (Throwable e) {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public Seq<ApplicationListener> getListeners() {
        return this.listeners;
    }
    
    @Override
    public ApplicationType getType() {
        return ApplicationType.desktop;
    }
    
    @Override
    public String getClipboardText() {
        return SDL.SDL_GetClipboardText();
    }
    
    @Override
    public void setClipboardText(final String text) {
        SDL.SDL_SetClipboardText(text);
    }
    
    @Override
    public void post(final Runnable runnable) {
        this.runnables.post(runnable);
    }
    
    @Override
    public void exit() {
        this.running = false;
    }
}
