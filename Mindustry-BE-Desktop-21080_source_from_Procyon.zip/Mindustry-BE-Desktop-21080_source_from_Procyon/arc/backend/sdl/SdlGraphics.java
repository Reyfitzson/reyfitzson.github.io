// 
// Decompiled by Procyon v0.5.36
// 

package arc.backend.sdl;

import arc.graphics.Pixmap;
import arc.graphics.gl.HdpiMode;
import arc.backend.sdl.jni.SDL;
import arc.util.ArcRuntimeException;
import arc.Application;
import arc.Core;
import arc.struct.ObjectMap;
import arc.graphics.gl.GLVersion;
import arc.graphics.GL30;
import arc.graphics.GL20;
import arc.Graphics;

public class SdlGraphics extends Graphics
{
    private GL20 gl20;
    private GL30 gl30;
    private GLVersion glVersion;
    private BufferFormat bufferFormat;
    private SdlApplication app;
    private ObjectMap<Cursor.SystemCursor, SdlCursor> cursors;
    private long lastFrameTime;
    private float deltaTime;
    private long frameId;
    private long frameCounterStart;
    private int frames;
    private int fps;
    int backBufferWidth;
    int backBufferHeight;
    int logicalWidth;
    int logicalHeight;
    
    SdlGraphics(final SdlApplication app) {
        this.lastFrameTime = -1L;
        this.frameCounterStart = 0L;
        this.app = app;
        final SdlGL20 gl = new SdlGL20();
        this.gl20 = gl;
        Core.gl20 = gl;
        Core.gl = gl;
        final String versionString = this.gl20.glGetString(7938);
        final String vendorString = this.gl20.glGetString(7936);
        final String rendererString = this.gl20.glGetString(7937);
        this.cursors = new ObjectMap<Cursor.SystemCursor, SdlCursor>();
        this.glVersion = new GLVersion(Application.ApplicationType.desktop, versionString, vendorString, rendererString);
        this.bufferFormat = new BufferFormat(app.config.r, app.config.g, app.config.b, app.config.a, app.config.depth, app.config.stencil, app.config.samples, false);
        if (!this.glVersion.atLeast(2, 0) || !this.supportsFBO()) {
            throw new ArcRuntimeException("OpenGL 2.0 or higher with the FBO extension is required. OpenGL version: " + versionString);
        }
        if (this.glVersion.atLeast(3, 0) && app.config.gl30) {
            final SdlGL30 gl2 = new SdlGL30();
            this.gl30 = gl2;
            Core.gl30 = gl2;
            this.gl20 = gl2;
            Core.gl20 = gl2;
            Core.gl = gl2;
        }
        this.clear(app.config.initialBackgroundColor);
        SDL.SDL_GL_SwapWindow(app.window);
    }
    
    boolean supportsFBO() {
        return this.glVersion.atLeast(3, 0) || SDL.SDL_GL_ExtensionSupported("GL_EXT_framebuffer_object");
    }
    
    void update() {
        final long time = System.nanoTime();
        if (this.lastFrameTime == -1L) {
            this.lastFrameTime = time;
        }
        this.deltaTime = (time - this.lastFrameTime) / 1.0E9f;
        this.lastFrameTime = time;
        if (time - this.frameCounterStart >= 1000000000L) {
            this.fps = this.frames;
            this.frames = 0;
            this.frameCounterStart = time;
        }
        ++this.frames;
        ++this.frameId;
    }
    
    void updateSize(final int width, final int height) {
        this.logicalWidth = width;
        this.logicalHeight = height;
        this.backBufferWidth = width;
        this.backBufferHeight = height;
        this.gl20.glViewport(0, 0, width, height);
    }
    
    @Override
    public boolean isGL30Available() {
        return this.gl30 != null;
    }
    
    @Override
    public GL20 getGL20() {
        return this.gl20;
    }
    
    @Override
    public void setGL20(final GL20 gl20) {
        this.gl20 = gl20;
        Core.gl20 = gl20;
        Core.gl = gl20;
    }
    
    @Override
    public GL30 getGL30() {
        return this.gl30;
    }
    
    @Override
    public void setGL30(final GL30 gl30) {
        this.gl30 = gl30;
        this.gl20 = gl30;
        Core.gl20 = gl30;
        Core.gl = gl30;
    }
    
    @Override
    public int getWidth() {
        if (this.app.config.hdpiMode == HdpiMode.pixels) {
            return this.backBufferWidth;
        }
        return this.logicalWidth;
    }
    
    @Override
    public int getHeight() {
        if (this.app.config.hdpiMode == HdpiMode.pixels) {
            return this.backBufferHeight;
        }
        return this.logicalHeight;
    }
    
    @Override
    public int getBackBufferWidth() {
        return this.backBufferWidth;
    }
    
    @Override
    public int getBackBufferHeight() {
        return this.backBufferHeight;
    }
    
    @Override
    public long getFrameId() {
        return this.frameId;
    }
    
    @Override
    public float getDeltaTime() {
        return this.deltaTime;
    }
    
    @Override
    public int getFramesPerSecond() {
        return this.fps;
    }
    
    @Override
    public GLVersion getGLVersion() {
        return this.glVersion;
    }
    
    @Override
    public float getPpiX() {
        return 0.0f;
    }
    
    @Override
    public float getPpiY() {
        return 0.0f;
    }
    
    @Override
    public float getPpcX() {
        return 0.0f;
    }
    
    @Override
    public float getPpcY() {
        return 0.0f;
    }
    
    @Override
    public float getDensity() {
        return 0.0f;
    }
    
    @Override
    public boolean supportsDisplayModeChange() {
        return true;
    }
    
    @Override
    public Monitor getPrimaryMonitor() {
        return this.getMonitor();
    }
    
    @Override
    public Monitor getMonitor() {
        return new Monitor(0, 0, "Monitor");
    }
    
    @Override
    public Monitor[] getMonitors() {
        return new Monitor[0];
    }
    
    @Override
    public DisplayMode[] getDisplayModes() {
        return new DisplayMode[0];
    }
    
    @Override
    public DisplayMode[] getDisplayModes(final Monitor monitor) {
        return new DisplayMode[0];
    }
    
    @Override
    public DisplayMode getDisplayMode() {
        return new DisplayMode(this.getWidth(), this.getHeight(), 60, 32);
    }
    
    @Override
    public DisplayMode getDisplayMode(final Monitor monitor) {
        return this.getDisplayMode();
    }
    
    @Override
    public boolean setFullscreenMode(final DisplayMode displayMode) {
        SDL.SDL_SetWindowFullscreen(this.app.window, 4097);
        return true;
    }
    
    @Override
    public boolean setWindowedMode(final int width, final int height) {
        SDL.SDL_SetWindowFullscreen(this.app.window, 0);
        SDL.SDL_SetWindowSize(this.app.window, width, height);
        return true;
    }
    
    @Override
    public void setTitle(final String title) {
        SDL.SDL_SetWindowTitle(this.app.window, title);
    }
    
    @Override
    public void setUndecorated(final boolean undecorated) {
        final boolean maximized = (SDL.SDL_GetWindowFlags(this.app.window) & 0x80) == 0x80;
        if (maximized) {
            SDL.SDL_RestoreWindow(this.app.window);
        }
        SDL.SDL_SetWindowBordered(this.app.window, !undecorated);
        if (maximized) {
            SDL.SDL_MaximizeWindow(this.app.window);
        }
    }
    
    @Override
    public void setResizable(final boolean resizable) {
    }
    
    @Override
    public void setVSync(final boolean vsync) {
        SDL.SDL_GL_SetSwapInterval(vsync ? 1 : 0);
    }
    
    @Override
    public BufferFormat getBufferFormat() {
        return this.bufferFormat;
    }
    
    @Override
    public boolean supportsExtension(final String extension) {
        return SDL.SDL_GL_ExtensionSupported(extension);
    }
    
    @Override
    public boolean isContinuousRendering() {
        return true;
    }
    
    @Override
    public void setContinuousRendering(final boolean isContinuous) {
    }
    
    @Override
    public void requestRendering() {
    }
    
    @Override
    public boolean isFullscreen() {
        return (SDL.SDL_GetWindowFlags(this.app.window) & 0x1) == 0x1;
    }
    
    @Override
    public Cursor newCursor(final Pixmap pixmap, final int xHotspot, final int yHotspot) {
        final long surface = SDL.SDL_CreateRGBSurfaceFrom(pixmap.getPixels(), pixmap.getWidth(), pixmap.getHeight());
        final long cursor = SDL.SDL_CreateColorCursor(surface, xHotspot, yHotspot);
        return new SdlCursor(surface, cursor);
    }
    
    @Override
    protected void setCursor(final Cursor cursor) {
        SDL.SDL_SetCursor(((SdlCursor)cursor).cursorHandle);
    }
    
    @Override
    protected void setSystemCursor(final Cursor.SystemCursor cursor) {
        if (!this.cursors.containsKey(cursor)) {
            final long handle = SDL.SDL_CreateSystemCursor(this.mapCursor(cursor));
            this.cursors.put(cursor, new SdlCursor(0L, handle));
        }
        SDL.SDL_SetCursor(this.cursors.get(cursor).cursorHandle);
    }
    
    @Override
    public void dispose() {
        super.dispose();
        this.cursors.each((ignored, value) -> value.dispose());
    }
    
    private int mapCursor(final Cursor.SystemCursor cursor) {
        switch (cursor) {
            case arrow: {
                return 0;
            }
            case ibeam: {
                return 1;
            }
            case crosshair: {
                return 3;
            }
            case hand: {
                return 11;
            }
            case horizontalResize: {
                return 7;
            }
            case verticalResize: {
                return 8;
            }
            default: {
                throw new IllegalArgumentException("this is impossible.");
            }
        }
    }
    
    public static class SdlCursor implements Cursor
    {
        final long surfaceHandle;
        final long cursorHandle;
        
        public SdlCursor(final long surfaceHandle, final long cursorHandle) {
            this.surfaceHandle = surfaceHandle;
            this.cursorHandle = cursorHandle;
        }
        
        @Override
        public void dispose() {
            if (this.cursorHandle != 0L) {
                SDL.SDL_FreeCursor(this.cursorHandle);
            }
            if (this.surfaceHandle != 0L) {
                SDL.SDL_FreeSurface(this.surfaceHandle);
            }
        }
    }
}
