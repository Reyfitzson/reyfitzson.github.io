// 
// Decompiled by Procyon v0.5.36
// 

package arc.backend.sdl;

import java.util.Iterator;
import arc.input.InputDevice;
import arc.input.InputProcessor;
import arc.util.Strings;
import arc.Core;
import arc.input.KeyCode;
import arc.input.InputEventQueue;
import arc.Input;

public class SdlInput extends Input
{
    private final InputEventQueue queue;
    private int mouseX;
    private int mouseY;
    private int deltaX;
    private int deltaY;
    private int mousePressed;
    private byte[] strcpy;
    
    public SdlInput() {
        this.queue = new InputEventQueue();
        this.strcpy = new byte[32];
    }
    
    void handleInput(final int[] input) {
        final int type = input[0];
        if (type == 5) {
            final boolean down = input[1] == 1;
            final int keycode = input[4];
            final KeyCode key = SdlScanmap.getCode(keycode);
            if (input[3] == 0) {
                if (down) {
                    this.queue.keyDown(key);
                }
                else {
                    this.queue.keyUp(key);
                }
            }
            if (down) {
                if (key == KeyCode.backspace) {
                    this.queue.keyTyped('\b');
                }
                if (key == KeyCode.tab) {
                    this.queue.keyTyped('\t');
                }
                if (key == KeyCode.enter) {
                    this.queue.keyTyped('\r');
                }
                if (key == KeyCode.forwardDel || key == KeyCode.del) {
                    this.queue.keyTyped('\u007f');
                }
            }
        }
        else if (type == 3) {
            final boolean down = input[1] == 1;
            final int keycode = input[4];
            final int x = input[2];
            final int y = Core.graphics.getHeight() - input[3];
            final KeyCode key2 = (keycode == 1) ? KeyCode.mouseLeft : ((keycode == 3) ? KeyCode.mouseRight : ((keycode == 2) ? KeyCode.mouseMiddle : ((keycode == 4) ? KeyCode.mouseBack : ((keycode == 5) ? KeyCode.mouseForward : null))));
            if (key2 != null) {
                if (down) {
                    ++this.mousePressed;
                    this.queue.keyDown(key2);
                    this.queue.touchDown(x, y, 0, key2);
                }
                else {
                    this.mousePressed = Math.max(0, this.mousePressed - 1);
                    this.queue.keyUp(key2);
                    this.queue.touchUp(x, y, 0, key2);
                }
            }
        }
        else if (type == 2) {
            final int x2 = input[1];
            final int y2 = Core.graphics.getHeight() - input[2];
            this.deltaX = x2 - this.mouseX;
            this.deltaY = y2 - this.mouseY;
            this.mouseX = x2;
            this.mouseY = y2;
            if (this.mousePressed > 0) {
                this.queue.touchDragged(this.mouseX, this.mouseY, 0);
            }
            else {
                this.queue.mouseMoved(this.mouseX, this.mouseY);
            }
        }
        else if (type == 4) {
            final int sx = input[1];
            final int sy = input[2];
            this.queue.scrolled((float)(-sx), (float)(-sy));
        }
        else if (type == 6) {
            int length = 0;
            for (int i = 0; i < 32; ++i) {
                final char c = (char)input[i + 1];
                if (c == '\0') {
                    length = i;
                    break;
                }
            }
            for (int i = 0; i < length; ++i) {
                this.strcpy[i] = (byte)input[i + 1];
            }
            final String s = new String(this.strcpy, 0, length, Strings.utf8);
            for (int j = 0; j < s.length(); ++j) {
                this.queue.keyTyped(s.charAt(j));
            }
        }
    }
    
    void update() {
        this.queue.setProcessor(this.inputMultiplexer);
        this.queue.drain();
        for (final InputDevice device : this.devices) {
            device.preUpdate();
        }
    }
    
    void postUpdate() {
        for (final InputDevice device : this.devices) {
            device.postUpdate();
        }
    }
    
    @Override
    public int mouseX() {
        return this.mouseX;
    }
    
    @Override
    public int mouseX(final int pointer) {
        return (pointer == 0) ? this.mouseX : 0;
    }
    
    @Override
    public int deltaX() {
        return this.deltaX;
    }
    
    @Override
    public int deltaX(final int pointer) {
        return (pointer == 0) ? this.deltaX : 0;
    }
    
    @Override
    public int mouseY() {
        return this.mouseY;
    }
    
    @Override
    public int mouseY(final int pointer) {
        return (pointer == 0) ? this.mouseY : 0;
    }
    
    @Override
    public int deltaY() {
        return this.deltaY;
    }
    
    @Override
    public int deltaY(final int pointer) {
        return (pointer == 0) ? this.deltaY : 0;
    }
    
    @Override
    public boolean isTouched() {
        return this.keyDown(KeyCode.mouseLeft) || this.keyDown(KeyCode.mouseRight);
    }
    
    @Override
    public boolean justTouched() {
        return this.keyTap(KeyCode.mouseLeft) || this.keyTap(KeyCode.mouseRight);
    }
    
    @Override
    public boolean isTouched(final int pointer) {
        return false;
    }
    
    @Override
    public long getCurrentEventTime() {
        return this.queue.getCurrentEventTime();
    }
}
