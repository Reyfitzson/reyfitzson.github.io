// 
// Decompiled by Procyon v0.5.36
// 

package arc;

import arc.files.Fi;

public interface Files
{
    Fi get(final String p0, final FileType p1);
    
    default Fi classpath(final String path) {
        return this.get(path, FileType.classpath);
    }
    
    default Fi internal(final String path) {
        return this.get(path, FileType.internal);
    }
    
    default Fi external(final String path) {
        return this.get(path, FileType.external);
    }
    
    default Fi absolute(final String path) {
        return this.get(path, FileType.absolute);
    }
    
    default Fi local(final String path) {
        return this.get(path, FileType.local);
    }
    
    default Fi cache(final String path) {
        return this.get(this.getCachePath(), FileType.absolute).child(path);
    }
    
    default String getCachePath() {
        return this.local("cache").absolutePath();
    }
    
    String getExternalStoragePath();
    
    boolean isExternalStorageAvailable();
    
    String getLocalStoragePath();
    
    boolean isLocalStorageAvailable();
    
    public enum FileType
    {
        classpath, 
        internal, 
        external, 
        absolute, 
        local;
    }
}
