// 
// Decompiled by Procyon v0.5.36
// 

package arc;

import arc.util.Nullable;
import arc.util.Time;
import arc.struct.Seq;
import arc.util.Disposable;

public interface Application extends Disposable
{
    Seq<ApplicationListener> getListeners();
    
    default void addListener(final ApplicationListener listener) {
        synchronized (this.getListeners()) {
            this.getListeners().add(listener);
        }
    }
    
    default void removeListener(final ApplicationListener listener) {
        synchronized (this.getListeners()) {
            this.getListeners().remove(listener);
        }
    }
    
    default void defaultUpdate() {
        Core.settings.autosave();
        Time.updateGlobal();
    }
    
    ApplicationType getType();
    
    default boolean isDesktop() {
        return this.getType() == ApplicationType.desktop;
    }
    
    default boolean isHeadless() {
        return this.getType() == ApplicationType.headless;
    }
    
    default boolean isAndroid() {
        return this.getType() == ApplicationType.android;
    }
    
    default boolean isIOS() {
        return this.getType() == ApplicationType.iOS;
    }
    
    default boolean isMobile() {
        return this.isAndroid() || this.isIOS();
    }
    
    default boolean isWeb() {
        return this.getType() == ApplicationType.web;
    }
    
    default int getVersion() {
        return 0;
    }
    
    default long getJavaHeap() {
        return Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    }
    
    default long getNativeHeap() {
        return 0L;
    }
    
    @Nullable
    String getClipboardText();
    
    void setClipboardText(final String p0);
    
    default boolean openFolder(final String file) {
        return false;
    }
    
    default boolean openURI(final String URI) {
        return false;
    }
    
    void post(final Runnable p0);
    
    void exit();
    
    default void dispose() {
        if (Core.settings != null) {
            Core.settings.autosave();
        }
        if (Core.audio != null) {
            Core.audio.dispose();
        }
    }
    
    public enum ApplicationType
    {
        android, 
        desktop, 
        headless, 
        web, 
        iOS;
    }
}
