// 
// Decompiled by Procyon v0.5.36
// 

package arc.struct;

import arc.util.Strings;

public class StringMap extends ObjectMap<String, String>
{
    public static StringMap of(final Object... values) {
        final StringMap map = new StringMap();
        for (int i = 0; i < values.length / 2; ++i) {
            map.put((String)values[i * 2], String.valueOf(values[i * 2 + 1]));
        }
        return map;
    }
    
    public StringMap() {
    }
    
    public StringMap(final ObjectMap<? extends String, ? extends String> map) {
        super(map);
    }
    
    public boolean getBool(final String name) {
        return this.get(name, "").equals("true");
    }
    
    public int getInt(final String name) {
        return this.getInt(name, 0);
    }
    
    public float getFloat(final String name) {
        return this.getFloat(name, 0.0f);
    }
    
    public long getLong(final String name) {
        return this.getLong(name, 0L);
    }
    
    public int getInt(final String name, final int def) {
        return ((ObjectMap<String, V>)this).containsKey(name) ? Strings.parseInt(this.get(name), def) : def;
    }
    
    public float getFloat(final String name, final float def) {
        return ((ObjectMap<String, V>)this).containsKey(name) ? Strings.parseFloat(this.get(name), def) : def;
    }
    
    public long getLong(final String name, final long def) {
        return ((ObjectMap<String, V>)this).containsKey(name) ? Strings.parseLong(this.get(name), def) : def;
    }
}
