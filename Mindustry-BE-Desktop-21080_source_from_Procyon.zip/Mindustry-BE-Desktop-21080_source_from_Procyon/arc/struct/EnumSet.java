// 
// Decompiled by Procyon v0.5.36
// 

package arc.struct;

import java.util.Iterator;

public class EnumSet<T extends Enum<T>> implements Iterable<T>
{
    private int i;
    private EnumSetIterator iterator;
    T[] set;
    
    EnumSet() {
        this.iterator = new EnumSetIterator();
    }
    
    public static <T extends Enum<T>> EnumSet<T> of(final T... arr) {
        final EnumSet<T> set = new EnumSet<T>();
        set.set = arr;
        for (final T t : arr) {
            final EnumSet<T> set2 = set;
            set2.i |= 1 << t.ordinal();
        }
        return set;
    }
    
    public boolean contains(final T t) {
        return (this.i & 1 << t.ordinal()) != 0x0;
    }
    
    public int size() {
        return this.set.length;
    }
    
    @Override
    public Iterator<T> iterator() {
        this.iterator.index = 0;
        return this.iterator;
    }
    
    class EnumSetIterator implements Iterator<T>
    {
        int index;
        
        EnumSetIterator() {
            this.index = 0;
        }
        
        @Override
        public boolean hasNext() {
            return this.index < EnumSet.this.set.length;
        }
        
        @Override
        public T next() {
            if (this.index >= EnumSet.this.set.length) {
                return null;
            }
            return EnumSet.this.set[this.index++];
        }
    }
}
