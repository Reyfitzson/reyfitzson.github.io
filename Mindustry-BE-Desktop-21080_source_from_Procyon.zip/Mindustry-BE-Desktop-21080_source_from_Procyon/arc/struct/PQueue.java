// 
// Decompiled by Procyon v0.5.36
// 

package arc.struct;

import arc.util.ArcRuntimeException;
import java.util.Comparator;

public class PQueue<E>
{
    private static final double CAPACITY_RATIO_LOW = 1.5;
    private static final double CAPACITY_RATIO_HI = 2.0;
    public Object[] queue;
    public int size;
    public Comparator<E> comparator;
    
    public PQueue() {
        this(12, null);
    }
    
    public PQueue(final int initialCapacity, final Comparator<E> comparator) {
        this.size = 0;
        this.queue = new Object[initialCapacity];
        this.comparator = comparator;
    }
    
    public boolean empty() {
        return this.size == 0;
    }
    
    public boolean add(final E e) {
        if (e == null) {
            throw new IllegalArgumentException("Element cannot be null.");
        }
        final int i = this.size;
        if (i >= this.queue.length) {
            this.growToSize(i + 1);
        }
        this.size = i + 1;
        if (i == 0) {
            this.queue[0] = e;
        }
        else {
            this.siftUp(i, e);
        }
        return true;
    }
    
    public E peek() {
        return (E)((this.size == 0) ? null : this.queue[0]);
    }
    
    public E get(final int index) {
        return (E)((index >= this.size) ? null : this.queue[index]);
    }
    
    public int size() {
        return this.size;
    }
    
    public void clear() {
        for (int i = 0; i < this.size; ++i) {
            this.queue[i] = null;
        }
        this.size = 0;
    }
    
    public E poll() {
        if (this.size == 0) {
            return null;
        }
        final int size = this.size - 1;
        this.size = size;
        final int s = size;
        final E result = (E)this.queue[0];
        final E x = (E)this.queue[s];
        this.queue[s] = null;
        if (s != 0) {
            this.siftDown(0, x);
        }
        return result;
    }
    
    private void siftUp(int k, final E x) {
        while (k > 0) {
            final int parent = k - 1 >>> 1;
            final E e = (E)this.queue[parent];
            if (this.compare(x, e) >= 0) {
                break;
            }
            this.queue[k] = e;
            k = parent;
        }
        this.queue[k] = x;
    }
    
    private void siftDown(int k, final E x) {
        int child;
        for (int half = this.size >>> 1; k < half; k = child) {
            child = (k << 1) + 1;
            E c = (E)this.queue[child];
            final int right = child + 1;
            if (right < this.size && this.compare(c, this.queue[right]) > 0) {
                c = (E)this.queue[child = right];
            }
            if (this.compare(x, c) <= 0) {
                break;
            }
            this.queue[k] = c;
        }
        this.queue[k] = x;
    }
    
    private int compare(final E a, final E b) {
        return (this.comparator == null) ? ((Comparable)a).compareTo(b) : this.comparator.compare(a, b);
    }
    
    private void growToSize(final int minCapacity) {
        if (minCapacity < 0) {
            throw new ArcRuntimeException("Capacity upper limit exceeded.");
        }
        final int oldCapacity = this.queue.length;
        int newCapacity = (int)((oldCapacity < 64) ? ((oldCapacity + 1) * 2.0) : (oldCapacity * 1.5));
        if (newCapacity < 0) {
            newCapacity = Integer.MAX_VALUE;
        }
        if (newCapacity < minCapacity) {
            newCapacity = minCapacity;
        }
        final Object[] newQueue = new Object[newCapacity];
        System.arraycopy(this.queue, 0, newQueue, 0, this.size);
        this.queue = newQueue;
    }
}
