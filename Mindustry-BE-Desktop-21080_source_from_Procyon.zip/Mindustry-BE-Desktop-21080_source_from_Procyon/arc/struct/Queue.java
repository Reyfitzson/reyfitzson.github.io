// 
// Decompiled by Procyon v0.5.36
// 

package arc.struct;

import arc.util.ArcRuntimeException;
import arc.func.Cons;
import java.util.Iterator;
import arc.func.Boolf;
import java.util.NoSuchElementException;
import java.lang.reflect.Array;
import arc.util.Eachable;

public class Queue<T> implements Iterable<T>, Eachable<T>
{
    public int size;
    protected T[] values;
    protected int head;
    protected int tail;
    private QueueIterable iterable;
    
    public Queue() {
        this(16);
    }
    
    public Queue(final int initialSize) {
        this.size = 0;
        this.head = 0;
        this.tail = 0;
        this.values = (T[])new Object[initialSize];
    }
    
    public Queue(final int initialSize, final Class<T> type) {
        this.size = 0;
        this.head = 0;
        this.tail = 0;
        this.values = (T[])Array.newInstance(type, initialSize);
    }
    
    public void addLast(final T object) {
        T[] values = this.values;
        if (this.size == values.length) {
            this.resize(values.length << 1);
            values = this.values;
        }
        values[this.tail++] = object;
        if (this.tail == values.length) {
            this.tail = 0;
        }
        ++this.size;
    }
    
    public void add(final T object) {
        this.addLast(object);
    }
    
    public void addFirst(final T object) {
        T[] values = this.values;
        if (this.size == values.length) {
            this.resize(values.length << 1);
            values = this.values;
        }
        int head = this.head;
        if (--head == -1) {
            head = values.length - 1;
        }
        values[head] = object;
        this.head = head;
        ++this.size;
    }
    
    public void ensureCapacity(final int additional) {
        final int needed = this.size + additional;
        if (this.values.length < needed) {
            this.resize(needed);
        }
    }
    
    protected void resize(final int newSize) {
        final T[] values = this.values;
        final int head = this.head;
        final int tail = this.tail;
        final T[] newArray = (T[])Array.newInstance(values.getClass().getComponentType(), newSize);
        if (head < tail) {
            System.arraycopy(values, head, newArray, 0, tail - head);
        }
        else if (this.size > 0) {
            final int rest = values.length - head;
            System.arraycopy(values, head, newArray, 0, rest);
            System.arraycopy(values, 0, newArray, rest, tail);
        }
        this.values = newArray;
        this.head = 0;
        this.tail = this.size;
    }
    
    public T removeFirst() {
        if (this.size == 0) {
            throw new NoSuchElementException("Queue is empty.");
        }
        final T[] values = this.values;
        final T result = values[this.head];
        values[this.head] = null;
        ++this.head;
        if (this.head == values.length) {
            this.head = 0;
        }
        --this.size;
        return result;
    }
    
    public T removeLast() {
        if (this.size == 0) {
            throw new NoSuchElementException("Queue is empty.");
        }
        final T[] values = this.values;
        int tail = this.tail;
        if (--tail == -1) {
            tail = values.length - 1;
        }
        final T result = values[tail];
        values[tail] = null;
        this.tail = tail;
        --this.size;
        return result;
    }
    
    public int indexOf(final T value, final boolean identity) {
        if (this.size == 0) {
            return -1;
        }
        final T[] values = this.values;
        final int head = this.head;
        final int tail = this.tail;
        if (identity || value == null) {
            if (head < tail) {
                for (int i = head; i < tail; ++i) {
                    if (values[i] == value) {
                        return i - head;
                    }
                }
            }
            else {
                for (int i = head, n = values.length; i < n; ++i) {
                    if (values[i] == value) {
                        return i - head;
                    }
                }
                for (int i = 0; i < tail; ++i) {
                    if (values[i] == value) {
                        return i + values.length - head;
                    }
                }
            }
        }
        else if (head < tail) {
            for (int i = head; i < tail; ++i) {
                if (value.equals(values[i])) {
                    return i - head;
                }
            }
        }
        else {
            for (int i = head, n = values.length; i < n; ++i) {
                if (value.equals(values[i])) {
                    return i - head;
                }
            }
            for (int i = 0; i < tail; ++i) {
                if (value.equals(values[i])) {
                    return i + values.length - head;
                }
            }
        }
        return -1;
    }
    
    public int indexOf(final Boolf<T> value) {
        if (this.size == 0) {
            return -1;
        }
        final T[] values = this.values;
        final int head = this.head;
        final int tail = this.tail;
        if (head < tail) {
            for (int i = head; i < tail; ++i) {
                if (value.get(values[i])) {
                    return i - head;
                }
            }
        }
        else {
            for (int i = head, n = values.length; i < n; ++i) {
                if (value.get(values[i])) {
                    return i - head;
                }
            }
            for (int i = 0; i < tail; ++i) {
                if (value.get(values[i])) {
                    return i + values.length - head;
                }
            }
        }
        return -1;
    }
    
    public boolean remove(final T value) {
        return this.remove(value, false);
    }
    
    public boolean remove(final T value, final boolean identity) {
        final int index = this.indexOf(value, identity);
        if (index == -1) {
            return false;
        }
        this.removeIndex(index);
        return true;
    }
    
    public T removeIndex(int index) {
        if (index < 0) {
            throw new IndexOutOfBoundsException("index can't be < 0: " + index);
        }
        if (index >= this.size) {
            throw new IndexOutOfBoundsException("index can't be >= size: " + index + " >= " + this.size);
        }
        final T[] values = this.values;
        final int head = this.head;
        final int tail = this.tail;
        index += head;
        T value;
        if (head < tail) {
            value = values[index];
            System.arraycopy(values, index + 1, values, index, tail - index);
            values[tail] = null;
            --this.tail;
        }
        else if (index >= values.length) {
            index -= values.length;
            value = values[index];
            System.arraycopy(values, index + 1, values, index, tail - index);
            --this.tail;
        }
        else {
            value = values[index];
            System.arraycopy(values, head, values, head + 1, index - head);
            values[head] = null;
            ++this.head;
            if (this.head == values.length) {
                this.head = 0;
            }
        }
        --this.size;
        return value;
    }
    
    public boolean isEmpty() {
        return this.size == 0;
    }
    
    public T first() {
        if (this.size == 0) {
            throw new NoSuchElementException("Queue is empty.");
        }
        return this.values[this.head];
    }
    
    public T last() {
        if (this.size == 0) {
            throw new NoSuchElementException("Queue is empty.");
        }
        final T[] values = this.values;
        int tail = this.tail;
        if (--tail == -1) {
            tail = values.length - 1;
        }
        return values[tail];
    }
    
    public T get(final int index) {
        if (index < 0) {
            throw new IndexOutOfBoundsException("index can't be < 0: " + index);
        }
        if (index >= this.size) {
            throw new IndexOutOfBoundsException("index can't be >= size: " + index + " >= " + this.size);
        }
        final T[] values = this.values;
        int i = this.head + index;
        if (i >= values.length) {
            i -= values.length;
        }
        return values[i];
    }
    
    public void clear() {
        if (this.size == 0) {
            return;
        }
        final T[] values = this.values;
        final int head = this.head;
        final int tail = this.tail;
        if (head < tail) {
            for (int i = head; i < tail; ++i) {
                values[i] = null;
            }
        }
        else {
            for (int i = head; i < values.length; ++i) {
                values[i] = null;
            }
            for (int i = 0; i < tail; ++i) {
                values[i] = null;
            }
        }
        this.head = 0;
        this.tail = 0;
        this.size = 0;
    }
    
    @Override
    public Iterator<T> iterator() {
        if (this.iterable == null) {
            this.iterable = new QueueIterable((Queue<T>)this);
        }
        return this.iterable.iterator();
    }
    
    @Override
    public void each(final Cons<? super T> c) {
        for (int i = 0; i < this.size; ++i) {
            c.get(this.get(i));
        }
    }
    
    @Override
    public String toString() {
        if (this.size == 0) {
            return "[]";
        }
        final T[] values = this.values;
        final int head = this.head;
        final int tail = this.tail;
        final StringBuilder sb = new StringBuilder(64);
        sb.append('[');
        sb.append(values[head]);
        for (int i = (head + 1) % values.length; i != tail; i = (i + 1) % values.length) {
            sb.append(", ").append(values[i]);
        }
        sb.append(']');
        return sb.toString();
    }
    
    @Override
    public int hashCode() {
        final int size = this.size;
        final T[] values = this.values;
        final int backingLength = values.length;
        int index = this.head;
        int hash = size + 1;
        for (int s = 0; s < size; ++s) {
            final T value = values[index];
            hash *= 31;
            if (value != null) {
                hash += value.hashCode();
            }
            if (++index == backingLength) {
                index = 0;
            }
        }
        return hash;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Queue)) {
            return false;
        }
        final Queue<?> q = (Queue<?>)o;
        final int size = this.size;
        if (q.size != size) {
            return false;
        }
        final T[] myValues = this.values;
        final int myBackingLength = myValues.length;
        final Object[] itsValues = (Object[])q.values;
        final int itsBackingLength = itsValues.length;
        int myIndex = this.head;
        int itsIndex = q.head;
        for (int s = 0; s < size; ++s) {
            final T myValue = myValues[myIndex];
            final Object itsValue = itsValues[itsIndex];
            if (myValue == null) {
                if (itsValue != null) {
                    return false;
                }
            }
            else if (!myValue.equals(itsValue)) {
                return false;
            }
            ++myIndex;
            ++itsIndex;
            if (myIndex == myBackingLength) {
                myIndex = 0;
            }
            if (itsIndex == itsBackingLength) {
                itsIndex = 0;
            }
        }
        return true;
    }
    
    public static class QueueIterable<T> implements Iterable<T>
    {
        final Queue<T> queue;
        final boolean allowRemove;
        private QueueIterator iterator1;
        private QueueIterator iterator2;
        
        public QueueIterable(final Queue<T> queue) {
            this(queue, true);
        }
        
        public QueueIterable(final Queue<T> queue, final boolean allowRemove) {
            this.queue = queue;
            this.allowRemove = allowRemove;
        }
        
        @Override
        public Iterator<T> iterator() {
            if (this.iterator1 == null) {
                this.iterator1 = new QueueIterator();
                this.iterator2 = new QueueIterator();
            }
            if (this.iterator1.done) {
                this.iterator1.index = 0;
                this.iterator1.done = false;
                return this.iterator1;
            }
            if (this.iterator2.done) {
                this.iterator2.index = 0;
                this.iterator2.done = false;
                return this.iterator2;
            }
            return new QueueIterator();
        }
        
        private class QueueIterator implements Iterator<T>, Iterable<T>
        {
            int index;
            boolean done;
            
            QueueIterator() {
                this.done = true;
            }
            
            @Override
            public boolean hasNext() {
                if (this.index >= QueueIterable.this.queue.size) {
                    this.done = true;
                }
                return this.index < QueueIterable.this.queue.size;
            }
            
            @Override
            public T next() {
                if (this.index >= QueueIterable.this.queue.size) {
                    throw new NoSuchElementException(String.valueOf(this.index));
                }
                return QueueIterable.this.queue.get(this.index++);
            }
            
            @Override
            public void remove() {
                if (!QueueIterable.this.allowRemove) {
                    throw new ArcRuntimeException("Remove not allowed.");
                }
                --this.index;
                QueueIterable.this.queue.removeIndex(this.index);
            }
            
            public void reset() {
                this.index = 0;
            }
            
            @Override
            public Iterator<T> iterator() {
                return this;
            }
        }
    }
}
