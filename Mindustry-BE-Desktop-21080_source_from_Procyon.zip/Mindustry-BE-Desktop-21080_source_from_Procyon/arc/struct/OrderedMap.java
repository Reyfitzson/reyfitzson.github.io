// 
// Decompiled by Procyon v0.5.36
// 

package arc.struct;

import arc.util.ArcRuntimeException;
import java.util.NoSuchElementException;
import java.util.Iterator;

public class OrderedMap<K, V> extends ObjectMap<K, V>
{
    final Seq<K> keys;
    
    public static <K, V> OrderedMap<K, V> of(final Object... values) {
        final OrderedMap<K, V> map = new OrderedMap<K, V>();
        for (int i = 0; i < values.length / 2; ++i) {
            map.put((K)values[i * 2], (V)values[i * 2 + 1]);
        }
        return map;
    }
    
    public OrderedMap() {
        this.keys = new Seq<K>();
    }
    
    public OrderedMap(final int initialCapacity) {
        super(initialCapacity);
        this.keys = new Seq<K>(this.capacity);
    }
    
    public OrderedMap(final int initialCapacity, final float loadFactor) {
        super(initialCapacity, loadFactor);
        this.keys = new Seq<K>(this.capacity);
    }
    
    public OrderedMap(final OrderedMap<? extends K, ? extends V> map) {
        super(map);
        this.keys = new Seq<K>(map.keys);
    }
    
    @Override
    public V put(final K key, final V value) {
        if (!this.containsKey(key)) {
            this.keys.add(key);
        }
        return super.put(key, value);
    }
    
    @Override
    public V remove(final K key) {
        this.keys.remove(key, false);
        return super.remove(key);
    }
    
    public V removeIndex(final int index) {
        return super.remove(this.keys.remove(index));
    }
    
    @Override
    public void clear(final int maximumCapacity) {
        this.keys.clear();
        super.clear(maximumCapacity);
    }
    
    @Override
    public void clear() {
        this.keys.clear();
        super.clear();
    }
    
    public Seq<K> orderedKeys() {
        return this.keys;
    }
    
    @Override
    public Entries<K, V> iterator() {
        return this.entries();
    }
    
    @Override
    public Entries<K, V> entries() {
        if (this.entries1 == null) {
            this.entries1 = new OrderedMapEntries(this);
            this.entries2 = new OrderedMapEntries(this);
        }
        if (!this.entries1.valid) {
            this.entries1.reset();
            this.entries1.valid = true;
            this.entries2.valid = false;
            return (Entries<K, V>)this.entries1;
        }
        this.entries2.reset();
        this.entries2.valid = true;
        this.entries1.valid = false;
        return (Entries<K, V>)this.entries2;
    }
    
    @Override
    public Values<V> values() {
        if (this.values1 == null) {
            this.values1 = new OrderedMapValues(this);
            this.values2 = new OrderedMapValues(this);
        }
        if (!this.values1.valid) {
            this.values1.reset();
            this.values1.valid = true;
            this.values2.valid = false;
            return (Values<V>)this.values1;
        }
        this.values2.reset();
        this.values2.valid = true;
        this.values1.valid = false;
        return (Values<V>)this.values2;
    }
    
    @Override
    public Keys<K> keys() {
        if (this.keys1 == null) {
            this.keys1 = new OrderedMapKeys(this);
            this.keys2 = new OrderedMapKeys(this);
        }
        if (!this.keys1.valid) {
            this.keys1.reset();
            this.keys1.valid = true;
            this.keys2.valid = false;
            return (Keys<K>)this.keys1;
        }
        this.keys2.reset();
        this.keys2.valid = true;
        this.keys1.valid = false;
        return (Keys<K>)this.keys2;
    }
    
    @Override
    public String toString() {
        if (this.size == 0) {
            return "{}";
        }
        final StringBuilder buffer = new StringBuilder(32);
        buffer.append('{');
        final Seq<K> keys = this.keys;
        for (int i = 0, n = keys.size; i < n; ++i) {
            final K key = keys.get(i);
            if (i > 0) {
                buffer.append(", ");
            }
            buffer.append(key);
            buffer.append('=');
            buffer.append(this.get(key));
        }
        buffer.append('}');
        return buffer.toString();
    }
    
    public static class OrderedMapEntries<K, V> extends Entries<K, V>
    {
        private Seq<K> keys;
        
        public OrderedMapEntries(final OrderedMap<K, V> map) {
            super(map);
            this.keys = map.keys;
        }
        
        @Override
        public void reset() {
            this.nextIndex = 0;
            this.hasNext = (this.map.size > 0);
        }
        
        @Override
        public Entry<K, V> next() {
            if (!this.hasNext) {
                throw new NoSuchElementException();
            }
            if (!this.valid) {
                throw new ArcRuntimeException("#iterator() cannot be used nested.");
            }
            this.entry.key = this.keys.get(this.nextIndex);
            this.entry.value = (V)this.map.get((K)this.entry.key);
            ++this.nextIndex;
            this.hasNext = (this.nextIndex < this.map.size);
            return this.entry;
        }
        
        @Override
        public void remove() {
            if (this.currentIndex < 0) {
                throw new IllegalStateException("next must be called before remove.");
            }
            this.map.remove((K)this.entry.key);
            --this.nextIndex;
        }
    }
    
    public static class OrderedMapKeys<K> extends Keys<K>
    {
        private Seq<K> keys;
        
        public OrderedMapKeys(final OrderedMap<K, ?> map) {
            super(map);
            this.keys = map.keys;
        }
        
        @Override
        public void reset() {
            this.nextIndex = 0;
            this.hasNext = (this.map.size > 0);
        }
        
        @Override
        public K next() {
            if (!this.hasNext) {
                throw new NoSuchElementException();
            }
            if (!this.valid) {
                throw new ArcRuntimeException("#iterator() cannot be used nested.");
            }
            final K key = this.keys.get(this.nextIndex);
            this.currentIndex = this.nextIndex;
            ++this.nextIndex;
            this.hasNext = (this.nextIndex < this.map.size);
            return key;
        }
        
        @Override
        public void remove() {
            if (this.currentIndex < 0) {
                throw new IllegalStateException("next must be called before remove.");
            }
            ((OrderedMap)this.map).removeIndex(this.nextIndex - 1);
            this.nextIndex = this.currentIndex;
            this.currentIndex = -1;
        }
    }
    
    public static class OrderedMapValues<V> extends Values<V>
    {
        private Seq keys;
        
        public OrderedMapValues(final OrderedMap<?, V> map) {
            super(map);
            this.keys = map.keys;
        }
        
        @Override
        public void reset() {
            this.nextIndex = 0;
            this.hasNext = (this.map.size > 0);
        }
        
        @Override
        public V next() {
            if (!this.hasNext) {
                throw new NoSuchElementException();
            }
            if (!this.valid) {
                throw new ArcRuntimeException("#iterator() cannot be used nested.");
            }
            final V value = (V)this.map.get(this.keys.get(this.nextIndex));
            this.currentIndex = this.nextIndex;
            ++this.nextIndex;
            this.hasNext = (this.nextIndex < this.map.size);
            return value;
        }
        
        @Override
        public void remove() {
            if (this.currentIndex < 0) {
                throw new IllegalStateException("next must be called before remove.");
            }
            ((OrderedMap)this.map).removeIndex(this.currentIndex);
            this.nextIndex = this.currentIndex;
            this.currentIndex = -1;
        }
    }
}
