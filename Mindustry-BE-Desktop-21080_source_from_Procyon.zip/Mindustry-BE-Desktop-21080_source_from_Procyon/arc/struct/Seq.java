// 
// Decompiled by Procyon v0.5.36
// 

package arc.struct;

import java.util.NoSuchElementException;
import arc.math.Rand;
import arc.util.Select;
import arc.util.ArcRuntimeException;
import arc.util.Structs;
import arc.func.Prov;
import arc.math.Mathf;
import java.util.Comparator;
import arc.func.Func2;
import arc.func.Intf;
import arc.func.Floatf;
import arc.func.Cons;
import java.util.ArrayList;
import arc.func.Func;
import arc.func.Boolf;
import java.util.Iterator;
import java.lang.reflect.Array;
import arc.util.Nullable;
import arc.util.Eachable;

public class Seq<T> implements Iterable<T>, Eachable<T>
{
    public static int iteratorsAllocated;
    public T[] items;
    public int size;
    public boolean ordered;
    @Nullable
    private SeqIterable<T> iterable;
    
    public Seq() {
        this(true, 16);
    }
    
    public Seq(final int capacity) {
        this(true, capacity);
    }
    
    public Seq(final boolean ordered) {
        this(ordered, 16);
    }
    
    public Seq(final boolean ordered, final int capacity) {
        this.ordered = ordered;
        this.items = (T[])new Object[capacity];
    }
    
    public Seq(final boolean ordered, final int capacity, final Class<?> arrayType) {
        this.ordered = ordered;
        this.items = (T[])Array.newInstance(arrayType, capacity);
    }
    
    public Seq(final Class<?> arrayType) {
        this(true, 16, arrayType);
    }
    
    public Seq(final Seq<? extends T> array) {
        this(array.ordered, array.size, array.items.getClass().getComponentType());
        this.size = array.size;
        System.arraycopy(array.items, 0, this.items, 0, this.size);
    }
    
    public Seq(final T[] array) {
        this(true, array, 0, array.length);
    }
    
    public Seq(final boolean ordered, final T[] array, final int start, final int count) {
        this(ordered, count, array.getClass().getComponentType());
        this.size = count;
        System.arraycopy(array, start, this.items, 0, this.size);
    }
    
    public static <T> Seq<T> of(final Class<T> arrayType) {
        return new Seq<T>(arrayType);
    }
    
    public static <T> Seq<T> of(final boolean ordered, final int capacity, final Class<T> arrayType) {
        return new Seq<T>(ordered, capacity, arrayType);
    }
    
    public static <T> Seq<T> withArrays(final Object... arrays) {
        final Seq<T> result = new Seq<T>();
        for (final Object a : arrays) {
            if (a instanceof Seq) {
                result.addAll((Seq<? extends T>)a);
            }
            else {
                result.add((T)a);
            }
        }
        return result;
    }
    
    public static <T> Seq<T> with(final T... array) {
        return new Seq<T>(array);
    }
    
    public static <T> Seq<T> with(final Iterable<T> array) {
        final Seq<T> out = new Seq<T>();
        for (final T thing : array) {
            out.add(thing);
        }
        return out;
    }
    
    public static <T> Seq<T> select(final T[] array, final Boolf<T> test) {
        final Seq<T> out = new Seq<T>(array.length);
        for (int i = 0; i < array.length; ++i) {
            if (test.get(array[i])) {
                out.add(array[i]);
            }
        }
        return out;
    }
    
    public <K, V> ObjectMap<K, V> asMap(final Func<T, K> keygen, final Func<T, V> valgen) {
        final ObjectMap<K, V> map = new ObjectMap<K, V>();
        for (int i = 0; i < this.size; ++i) {
            map.put(keygen.get(this.items[i]), valgen.get(this.items[i]));
        }
        return map;
    }
    
    public <K> ObjectMap<K, T> asMap(final Func<T, K> keygen) {
        return (ObjectMap<K, T>)this.asMap((Func<Object, K>)keygen, t -> t);
    }
    
    public ObjectSet<T> asSet() {
        return ObjectSet.with(this);
    }
    
    public Seq<T> copy() {
        return new Seq<T>((Seq<? extends T>)this);
    }
    
    public ArrayList<T> list() {
        final ArrayList<T> list = new ArrayList<T>(this.size);
        this.each(list::add);
        return list;
    }
    
    public float sumf(final Floatf<T> summer) {
        float sum = 0.0f;
        for (int i = 0; i < this.size; ++i) {
            sum += summer.get(this.items[i]);
        }
        return sum;
    }
    
    public int sum(final Intf<T> summer) {
        int sum = 0;
        for (int i = 0; i < this.size; ++i) {
            sum += summer.get(this.items[i]);
        }
        return sum;
    }
    
    public <E extends T> void each(final Boolf<? super T> pred, final Cons<E> consumer) {
        for (int i = 0; i < this.size; ++i) {
            if (pred.get((Object)this.items[i])) {
                consumer.get((E)this.items[i]);
            }
        }
    }
    
    @Override
    public void each(final Cons<? super T> consumer) {
        for (int i = 0; i < this.size; ++i) {
            consumer.get((Object)this.items[i]);
        }
    }
    
    public void replace(final Func<T, T> mapper) {
        for (int i = 0; i < this.size; ++i) {
            this.items[i] = mapper.get(this.items[i]);
        }
    }
    
    public <R> Seq<R> flatten() {
        final Seq<R> arr = new Seq<R>();
        for (int i = 0; i < this.size; ++i) {
            arr.addAll((Seq<? extends R>)this.items[i]);
        }
        return arr;
    }
    
    public <R> Seq<R> flatMap(final Func<T, Iterable<R>> mapper) {
        final Seq<R> arr = new Seq<R>(this.size);
        for (int i = 0; i < this.size; ++i) {
            arr.addAll((Iterable<? extends R>)mapper.get(this.items[i]));
        }
        return arr;
    }
    
    public <R> Seq<R> map(final Func<T, R> mapper) {
        final Seq<R> arr = new Seq<R>(this.size);
        for (int i = 0; i < this.size; ++i) {
            arr.add(mapper.get(this.items[i]));
        }
        return arr;
    }
    
    public IntSeq mapInt(final Intf<T> mapper) {
        final IntSeq arr = new IntSeq(this.size);
        for (int i = 0; i < this.size; ++i) {
            arr.add(mapper.get(this.items[i]));
        }
        return arr;
    }
    
    public FloatSeq mapFloat(final Floatf<T> mapper) {
        final FloatSeq arr = new FloatSeq(this.size);
        for (int i = 0; i < this.size; ++i) {
            arr.add(mapper.get(this.items[i]));
        }
        return arr;
    }
    
    public <R> R reduce(final R initial, final Func2<T, R, R> reducer) {
        R result = initial;
        for (int i = 0; i < this.size; ++i) {
            result = reducer.get(this.items[i], result);
        }
        return result;
    }
    
    public boolean contains(final Boolf<T> predicate) {
        return this.find(predicate) != null;
    }
    
    public T min(final Comparator<T> func) {
        T result = null;
        for (int i = 0; i < this.size; ++i) {
            final T t = this.items[i];
            if (result == null || func.compare(result, t) > 0) {
                result = t;
            }
        }
        return result;
    }
    
    public T max(final Comparator<T> func) {
        T result = null;
        for (int i = 0; i < this.size; ++i) {
            final T t = this.items[i];
            if (result == null || func.compare(result, t) < 0) {
                result = t;
            }
        }
        return result;
    }
    
    public T min(final Boolf<T> filter, final Floatf<T> func) {
        T result = null;
        float min = Float.MAX_VALUE;
        for (int i = 0; i < this.size; ++i) {
            final T t = this.items[i];
            if (filter.get(t)) {
                final float val = func.get(t);
                if (val <= min) {
                    result = t;
                    min = val;
                }
            }
        }
        return result;
    }
    
    public T min(final Floatf<T> func) {
        T result = null;
        float min = Float.MAX_VALUE;
        for (int i = 0; i < this.size; ++i) {
            final T t = this.items[i];
            final float val = func.get(t);
            if (val <= min) {
                result = t;
                min = val;
            }
        }
        return result;
    }
    
    public T max(final Floatf<T> func) {
        T result = null;
        float max = Float.NEGATIVE_INFINITY;
        for (int i = 0; i < this.size; ++i) {
            final T t = this.items[i];
            final float val = func.get(t);
            if (val >= max) {
                result = t;
                max = val;
            }
        }
        return result;
    }
    
    public T find(final Boolf<T> predicate) {
        for (int i = 0; i < this.size; ++i) {
            if (predicate.get(this.items[i])) {
                return this.items[i];
            }
        }
        return null;
    }
    
    public Seq<T> with(final Cons<Seq<T>> cons) {
        cons.get(this);
        return this;
    }
    
    public Seq<T> and(final T value) {
        this.add(value);
        return this;
    }
    
    public Seq<T> and(final Seq<T> value) {
        this.addAll((Seq<? extends T>)value);
        return this;
    }
    
    public Seq<T> and(final T[] value) {
        this.addAll(value);
        return this;
    }
    
    public void add(final T value) {
        T[] items = this.items;
        if (this.size == items.length) {
            items = this.resize(Math.max(8, (int)(this.size * 1.75f)));
        }
        items[this.size++] = value;
    }
    
    public void add(final T value1, final T value2) {
        T[] items = this.items;
        if (this.size + 1 >= items.length) {
            items = this.resize(Math.max(8, (int)(this.size * 1.75f)));
        }
        items[this.size] = value1;
        items[this.size + 1] = value2;
        this.size += 2;
    }
    
    public void add(final T value1, final T value2, final T value3) {
        T[] items = this.items;
        if (this.size + 2 >= items.length) {
            items = this.resize(Math.max(8, (int)(this.size * 1.75f)));
        }
        items[this.size] = value1;
        items[this.size + 1] = value2;
        items[this.size + 2] = value3;
        this.size += 3;
    }
    
    public void add(final T value1, final T value2, final T value3, final T value4) {
        T[] items = this.items;
        if (this.size + 3 >= items.length) {
            items = this.resize(Math.max(8, (int)(this.size * 1.8f)));
        }
        items[this.size] = value1;
        items[this.size + 1] = value2;
        items[this.size + 2] = value3;
        items[this.size + 3] = value4;
        this.size += 4;
    }
    
    public Seq<T> addAll(final Seq<? extends T> array) {
        this.addAll(array.items, 0, array.size);
        return this;
    }
    
    public Seq<T> addAll(final Seq<? extends T> array, final int start, final int count) {
        if (start + count > array.size) {
            throw new IllegalArgumentException("start + count must be <= size: " + start + " + " + count + " <= " + array.size);
        }
        this.addAll(array.items, start, count);
        return this;
    }
    
    public Seq<T> addAll(final T... array) {
        this.addAll(array, 0, array.length);
        return this;
    }
    
    public Seq<T> addAll(final T[] array, final int start, final int count) {
        T[] items = this.items;
        final int sizeNeeded = this.size + count;
        if (sizeNeeded > items.length) {
            items = this.resize(Math.max(8, (int)(sizeNeeded * 1.75f)));
        }
        System.arraycopy(array, start, items, this.size, count);
        this.size += count;
        return this;
    }
    
    public Seq<T> addAll(final Iterable<? extends T> items) {
        if (items instanceof Seq) {
            this.addAll((Seq)items);
        }
        else {
            for (final T t : items) {
                this.add(t);
            }
        }
        return this;
    }
    
    public void set(final Seq<? extends T> array) {
        this.clear();
        this.addAll(array);
    }
    
    @Nullable
    public T getFrac(final float index) {
        if (this.isEmpty()) {
            return null;
        }
        return this.get(Mathf.clamp((int)(index * this.size), 0, this.size - 1));
    }
    
    public T get(final int index) {
        if (index >= this.size) {
            throw new IndexOutOfBoundsException("index can't be >= size: " + index + " >= " + this.size);
        }
        return this.items[index];
    }
    
    public void set(final int index, final T value) {
        if (index >= this.size) {
            throw new IndexOutOfBoundsException("index can't be >= size: " + index + " >= " + this.size);
        }
        this.items[index] = value;
    }
    
    public void insert(final int index, final T value) {
        if (index > this.size) {
            throw new IndexOutOfBoundsException("index can't be > size: " + index + " > " + this.size);
        }
        T[] items = this.items;
        if (this.size == items.length) {
            items = this.resize(Math.max(8, (int)(this.size * 1.75f)));
        }
        if (this.ordered) {
            System.arraycopy(items, index, items, index + 1, this.size - index);
        }
        else {
            items[this.size] = items[index];
        }
        ++this.size;
        items[index] = value;
    }
    
    public void swap(final int first, final int second) {
        if (first >= this.size) {
            throw new IndexOutOfBoundsException("first can't be >= size: " + first + " >= " + this.size);
        }
        if (second >= this.size) {
            throw new IndexOutOfBoundsException("second can't be >= size: " + second + " >= " + this.size);
        }
        final T[] items = this.items;
        final T firstValue = items[first];
        items[first] = items[second];
        items[second] = firstValue;
    }
    
    public boolean contains(final T value) {
        return this.contains(value, false);
    }
    
    public boolean contains(final T value, final boolean identity) {
        final T[] items = this.items;
        int i = this.size - 1;
        if (identity || value == null) {
            while (i >= 0) {
                if (items[i--] == value) {
                    return true;
                }
            }
        }
        else {
            while (i >= 0) {
                if (value.equals(items[i--])) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public int indexOf(final T value) {
        return this.indexOf(value, false);
    }
    
    public int indexOf(final T value, final boolean identity) {
        final T[] items = this.items;
        if (identity || value == null) {
            for (int i = 0, n = this.size; i < n; ++i) {
                if (items[i] == value) {
                    return i;
                }
            }
        }
        else {
            for (int i = 0, n = this.size; i < n; ++i) {
                if (value.equals(items[i])) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    public int indexOf(final Boolf<T> value) {
        final T[] items = this.items;
        for (int i = 0, n = this.size; i < n; ++i) {
            if (value.get(items[i])) {
                return i;
            }
        }
        return -1;
    }
    
    public int lastIndexOf(final T value, final boolean identity) {
        final T[] items = this.items;
        if (identity || value == null) {
            for (int i = this.size - 1; i >= 0; --i) {
                if (items[i] == value) {
                    return i;
                }
            }
        }
        else {
            for (int i = this.size - 1; i >= 0; --i) {
                if (value.equals(items[i])) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    public boolean remove(final T value) {
        return this.remove(value, false);
    }
    
    public boolean remove(final Boolf<T> value) {
        for (int i = 0; i < this.size; ++i) {
            if (value.get(this.items[i])) {
                this.remove(i);
                return true;
            }
        }
        return false;
    }
    
    public boolean remove(final T value, final boolean identity) {
        final T[] items = this.items;
        if (identity || value == null) {
            for (int i = 0, n = this.size; i < n; ++i) {
                if (items[i] == value) {
                    this.remove(i);
                    return true;
                }
            }
        }
        else {
            for (int i = 0, n = this.size; i < n; ++i) {
                if (value.equals(items[i])) {
                    this.remove(i);
                    return true;
                }
            }
        }
        return false;
    }
    
    public T remove(final int index) {
        if (index >= this.size) {
            throw new IndexOutOfBoundsException("index can't be >= size: " + index + " >= " + this.size);
        }
        final T[] items = this.items;
        final T value = items[index];
        --this.size;
        if (this.ordered) {
            System.arraycopy(items, index + 1, items, index, this.size - index);
        }
        else {
            items[index] = items[this.size];
        }
        items[this.size] = null;
        return value;
    }
    
    public void removeRange(final int start, final int end) {
        if (end >= this.size) {
            throw new IndexOutOfBoundsException("end can't be >= size: " + end + " >= " + this.size);
        }
        if (start > end) {
            throw new IndexOutOfBoundsException("start can't be > end: " + start + " > " + end);
        }
        final T[] items = this.items;
        final int count = end - start + 1;
        if (this.ordered) {
            System.arraycopy(items, start + count, items, start, this.size - (start + count));
        }
        else {
            final int lastIndex = this.size - 1;
            for (int i = 0; i < count; ++i) {
                items[start + i] = items[lastIndex - i];
            }
        }
        this.size -= count;
    }
    
    public Seq<T> removeAll(final Boolf<T> pred) {
        final Iterator<T> iter = this.iterator();
        while (iter.hasNext()) {
            if (pred.get(iter.next())) {
                iter.remove();
            }
        }
        return this;
    }
    
    public boolean removeAll(final Seq<? extends T> array) {
        return this.removeAll(array, false);
    }
    
    public boolean removeAll(final Seq<? extends T> array, final boolean identity) {
        final int startSize;
        int size = startSize = this.size;
        final T[] items = this.items;
        if (identity) {
            for (int i = 0, n = array.size; i < n; ++i) {
                final T item = (T)array.get(i);
                for (int ii = 0; ii < size; ++ii) {
                    if (item == items[ii]) {
                        this.remove(ii);
                        --size;
                        break;
                    }
                }
            }
        }
        else {
            for (int i = 0, n = array.size; i < n; ++i) {
                final T item = (T)array.get(i);
                for (int ii = 0; ii < size; ++ii) {
                    if (item.equals(items[ii])) {
                        this.remove(ii);
                        --size;
                        break;
                    }
                }
            }
        }
        return size != startSize;
    }
    
    public T pop(final Prov<T> constructor) {
        if (this.size == 0) {
            return constructor.get();
        }
        return this.pop();
    }
    
    public T pop() {
        if (this.size == 0) {
            throw new IllegalStateException("Array is empty.");
        }
        --this.size;
        final T item = this.items[this.size];
        this.items[this.size] = null;
        return item;
    }
    
    public T peek() {
        if (this.size == 0) {
            throw new IllegalStateException("Array is empty.");
        }
        return this.items[this.size - 1];
    }
    
    public T first() {
        if (this.size == 0) {
            throw new IllegalStateException("Array is empty.");
        }
        return this.items[0];
    }
    
    @Nullable
    public T firstOpt() {
        if (this.size == 0) {
            return null;
        }
        return this.items[0];
    }
    
    public boolean isEmpty() {
        return this.size == 0;
    }
    
    public boolean any() {
        return this.size > 0;
    }
    
    public Seq<T> clear() {
        final T[] items = this.items;
        for (int i = 0, n = this.size; i < n; ++i) {
            items[i] = null;
        }
        this.size = 0;
        return this;
    }
    
    public T[] shrink() {
        if (this.items.length != this.size) {
            this.resize(this.size);
        }
        return this.items;
    }
    
    public T[] ensureCapacity(final int additionalCapacity) {
        if (additionalCapacity < 0) {
            throw new IllegalArgumentException("additionalCapacity must be >= 0: " + additionalCapacity);
        }
        final int sizeNeeded = this.size + additionalCapacity;
        if (sizeNeeded > this.items.length) {
            this.resize(Math.max(8, sizeNeeded));
        }
        return this.items;
    }
    
    public T[] setSize(final int newSize) {
        this.truncate(newSize);
        if (newSize > this.items.length) {
            this.resize(Math.max(8, newSize));
        }
        this.size = newSize;
        return this.items;
    }
    
    protected T[] resize(final int newSize) {
        final T[] items = this.items;
        final T[] newItems = (T[])((items.getClass() == Object[].class) ? new Object[newSize] : Array.newInstance(items.getClass().getComponentType(), newSize));
        System.arraycopy(items, 0, newItems, 0, Math.min(this.size, newItems.length));
        return this.items = newItems;
    }
    
    public Seq<T> sort() {
        Sort.instance().sort(this.items, 0, this.size);
        return this;
    }
    
    public Seq<T> sort(final Comparator<? super T> comparator) {
        Sort.instance().sort(this.items, comparator, 0, this.size);
        return this;
    }
    
    public Seq<T> sort(final Floatf<? super T> comparator) {
        Sort.instance().sort(this.items, Structs.comparingFloat(comparator), 0, this.size);
        return this;
    }
    
    public <U extends Comparable<? super U>> Seq<T> sortComparing(final Func<? super T, ? extends U> keyExtractor) {
        this.sort(Structs.comparing((Func<? super T, ? extends Comparable>)keyExtractor));
        return this;
    }
    
    public Seq<T> selectFrom(final Seq<T> base, final Boolf<T> predicate) {
        this.clear();
        base.each(t -> {
            if (predicate.get(t)) {
                this.add(t);
            }
            return;
        });
        return this;
    }
    
    public Seq<T> distinct() {
        final ObjectSet<T> set = this.asSet();
        this.clear();
        this.addAll((Iterable<? extends T>)set);
        return this;
    }
    
    public <R> Seq<R> as() {
        return (Seq<R>)this;
    }
    
    public Seq<T> select(final Boolf<T> predicate) {
        final Seq<T> arr = new Seq<T>();
        for (int i = 0; i < this.size; ++i) {
            if (predicate.get(this.items[i])) {
                arr.add(this.items[i]);
            }
        }
        return arr;
    }
    
    public Seq<T> filter(final Boolf<T> predicate) {
        return this.removeAll(e -> !predicate.get(e));
    }
    
    public int count(final Boolf<T> predicate) {
        int count = 0;
        for (int i = 0; i < this.size; ++i) {
            if (predicate.get(this.items[i])) {
                ++count;
            }
        }
        return count;
    }
    
    public T selectRanked(final Comparator<T> comparator, final int kthLowest) {
        if (kthLowest < 1) {
            throw new ArcRuntimeException("nth_lowest must be greater than 0, 1 = first, 2 = second...");
        }
        return Select.instance().select(this.items, comparator, kthLowest, this.size);
    }
    
    public int selectRankedIndex(final Comparator<T> comparator, final int kthLowest) {
        if (kthLowest < 1) {
            throw new ArcRuntimeException("nth_lowest must be greater than 0, 1 = first, 2 = second...");
        }
        return Select.instance().selectIndex(this.items, comparator, kthLowest, this.size);
    }
    
    public void reverse() {
        final T[] items = this.items;
        int i = 0;
        final int lastIndex = this.size - 1;
        for (int n = this.size / 2; i < n; ++i) {
            final int ii = lastIndex - i;
            final T temp = items[i];
            items[i] = items[ii];
            items[ii] = temp;
        }
    }
    
    public void shuffle() {
        final T[] items = this.items;
        for (int i = this.size - 1; i >= 0; --i) {
            final int ii = Mathf.random(i);
            final T temp = items[i];
            items[i] = items[ii];
            items[ii] = temp;
        }
    }
    
    public void truncate(final int newSize) {
        if (newSize < 0) {
            throw new IllegalArgumentException("newSize must be >= 0: " + newSize);
        }
        if (this.size <= newSize) {
            return;
        }
        for (int i = newSize; i < this.size; ++i) {
            this.items[i] = null;
        }
        this.size = newSize;
    }
    
    public T random(final Rand rand) {
        if (this.size == 0) {
            return null;
        }
        return this.items[rand.random(0, this.size - 1)];
    }
    
    public T random() {
        return this.random(Mathf.rand);
    }
    
    public T random(final T exclude) {
        if (exclude == null) {
            return this.random();
        }
        if (this.size == 0) {
            return null;
        }
        if (this.size == 1) {
            return this.first();
        }
        final int eidx = this.indexOf(exclude);
        if (eidx == -1) {
            return this.random();
        }
        int index = Mathf.random(0, this.size - 2);
        if (index >= eidx) {
            ++index;
        }
        return this.items[index];
    }
    
    public T[] toArray() {
        return this.toArray(this.items.getClass().getComponentType());
    }
    
    public <V> V[] toArray(final Class type) {
        final V[] result = (V[])Array.newInstance(type, this.size);
        System.arraycopy(this.items, 0, result, 0, this.size);
        return result;
    }
    
    @Override
    public int hashCode() {
        if (!this.ordered) {
            return super.hashCode();
        }
        final Object[] items = this.items;
        int h = 1;
        for (int i = 0, n = this.size; i < n; ++i) {
            h *= 31;
            final Object item = items[i];
            if (item != null) {
                h += item.hashCode();
            }
        }
        return h;
    }
    
    @Override
    public boolean equals(final Object object) {
        if (object == this) {
            return true;
        }
        if (!this.ordered) {
            return false;
        }
        if (!(object instanceof Seq)) {
            return false;
        }
        final Seq array = (Seq)object;
        if (!array.ordered) {
            return false;
        }
        final int n = this.size;
        if (n != array.size) {
            return false;
        }
        final Object[] items1 = this.items;
        final Object[] items2 = array.items;
        for (int i = 0; i < n; ++i) {
            final Object o1 = items1[i];
            final Object o2 = items2[i];
            if (o1 == null) {
                if (o2 != null) {
                    return false;
                }
            }
            else if (!o1.equals(o2)) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public String toString() {
        if (this.size == 0) {
            return "[]";
        }
        final T[] items = this.items;
        final StringBuilder buffer = new StringBuilder(32);
        buffer.append('[');
        buffer.append(items[0]);
        for (int i = 1; i < this.size; ++i) {
            buffer.append(", ");
            buffer.append(items[i]);
        }
        buffer.append(']');
        return buffer.toString();
    }
    
    public String toString(final String separator, final Func<T, String> stringifier) {
        if (this.size == 0) {
            return "";
        }
        final T[] items = this.items;
        final StringBuilder buffer = new StringBuilder(32);
        buffer.append(stringifier.get(items[0]));
        for (int i = 1; i < this.size; ++i) {
            buffer.append(separator);
            buffer.append(stringifier.get(items[i]));
        }
        return buffer.toString();
    }
    
    public String toString(final String separator) {
        return this.toString(separator, String::valueOf);
    }
    
    @Override
    public Iterator<T> iterator() {
        if (this.iterable == null) {
            this.iterable = new SeqIterable<T>(this);
        }
        return this.iterable.iterator();
    }
    
    static {
        Seq.iteratorsAllocated = 0;
    }
    
    public static class SeqIterable<T> implements Iterable<T>
    {
        final Seq<T> array;
        final boolean allowRemove;
        private SeqIterator iterator1;
        private SeqIterator iterator2;
        
        public SeqIterable(final Seq<T> array) {
            this(array, true);
        }
        
        public SeqIterable(final Seq<T> array, final boolean allowRemove) {
            this.iterator1 = new SeqIterator();
            this.iterator2 = new SeqIterator();
            this.array = array;
            this.allowRemove = allowRemove;
        }
        
        @Override
        public Iterator<T> iterator() {
            if (this.iterator1.done) {
                this.iterator1.index = 0;
                this.iterator1.done = false;
                return this.iterator1;
            }
            if (this.iterator2.done) {
                this.iterator2.index = 0;
                this.iterator2.done = false;
                return this.iterator2;
            }
            return new SeqIterator();
        }
        
        private class SeqIterator implements Iterator<T>
        {
            int index;
            boolean done;
            
            SeqIterator() {
                this.done = true;
                ++Seq.iteratorsAllocated;
            }
            
            @Override
            public boolean hasNext() {
                if (this.index >= SeqIterable.this.array.size) {
                    this.done = true;
                }
                return this.index < SeqIterable.this.array.size;
            }
            
            @Override
            public T next() {
                if (this.index >= SeqIterable.this.array.size) {
                    throw new NoSuchElementException(String.valueOf(this.index));
                }
                return SeqIterable.this.array.items[this.index++];
            }
            
            @Override
            public void remove() {
                if (!SeqIterable.this.allowRemove) {
                    throw new ArcRuntimeException("Remove not allowed.");
                }
                --this.index;
                SeqIterable.this.array.remove(this.index);
            }
        }
    }
}
