// 
// Decompiled by Procyon v0.5.36
// 

package arc.struct;

import java.util.Comparator;

public class DelayedRemovalSeq<T> extends Seq<T>
{
    private int iterating;
    private IntSeq remove;
    private int clear;
    
    public DelayedRemovalSeq() {
        this.remove = new IntSeq(0);
    }
    
    public DelayedRemovalSeq(final Seq array) {
        super(array);
        this.remove = new IntSeq(0);
    }
    
    public DelayedRemovalSeq(final boolean ordered, final int capacity, final Class arrayType) {
        super(ordered, capacity, arrayType);
        this.remove = new IntSeq(0);
    }
    
    public DelayedRemovalSeq(final boolean ordered, final int capacity) {
        super(ordered, capacity);
        this.remove = new IntSeq(0);
    }
    
    public DelayedRemovalSeq(final boolean ordered, final T[] array, final int startIndex, final int count) {
        super(ordered, array, startIndex, count);
        this.remove = new IntSeq(0);
    }
    
    public DelayedRemovalSeq(final Class arrayType) {
        super(arrayType);
        this.remove = new IntSeq(0);
    }
    
    public DelayedRemovalSeq(final int capacity) {
        super(capacity);
        this.remove = new IntSeq(0);
    }
    
    public DelayedRemovalSeq(final T[] array) {
        super(array);
        this.remove = new IntSeq(0);
    }
    
    public static <T> DelayedRemovalSeq<T> with(final T... array) {
        return new DelayedRemovalSeq<T>(array);
    }
    
    public void begin() {
        ++this.iterating;
    }
    
    public void end() {
        if (this.iterating == 0) {
            throw new IllegalStateException("begin must be called before end.");
        }
        --this.iterating;
        if (this.iterating == 0) {
            if (this.clear > 0 && this.clear == this.size) {
                this.remove.clear();
                this.clear();
            }
            else {
                for (int i = 0, n = this.remove.size; i < n; ++i) {
                    final int index = this.remove.pop();
                    if (index >= this.clear) {
                        this.remove(index);
                    }
                }
                for (int i = this.clear - 1; i >= 0; --i) {
                    this.remove(i);
                }
            }
            this.clear = 0;
        }
    }
    
    private void removeIntern(final int index) {
        if (index < this.clear) {
            return;
        }
        for (int i = 0, n = this.remove.size; i < n; ++i) {
            final int removeIndex = this.remove.get(i);
            if (index == removeIndex) {
                return;
            }
            if (index < removeIndex) {
                this.remove.insert(i, index);
                return;
            }
        }
        this.remove.add(index);
    }
    
    @Override
    public boolean remove(final T value, final boolean identity) {
        if (this.iterating <= 0) {
            return super.remove(value, identity);
        }
        final int index = this.indexOf(value, identity);
        if (index == -1) {
            return false;
        }
        this.removeIntern(index);
        return true;
    }
    
    @Override
    public T remove(final int index) {
        if (this.iterating > 0) {
            this.removeIntern(index);
            return this.get(index);
        }
        return super.remove(index);
    }
    
    @Override
    public void removeRange(final int start, final int end) {
        if (this.iterating > 0) {
            for (int i = end; i >= start; --i) {
                this.removeIntern(i);
            }
        }
        else {
            super.removeRange(start, end);
        }
    }
    
    @Override
    public Seq<T> clear() {
        if (this.iterating > 0) {
            this.clear = this.size;
            return this;
        }
        return super.clear();
    }
    
    @Override
    public void set(final int index, final T value) {
        if (this.iterating > 0) {
            throw new IllegalStateException("Invalid between begin/end.");
        }
        super.set(index, value);
    }
    
    @Override
    public void insert(final int index, final T value) {
        if (this.iterating > 0) {
            throw new IllegalStateException("Invalid between begin/end.");
        }
        super.insert(index, value);
    }
    
    @Override
    public void swap(final int first, final int second) {
        if (this.iterating > 0) {
            throw new IllegalStateException("Invalid between begin/end.");
        }
        super.swap(first, second);
    }
    
    @Override
    public T pop() {
        if (this.iterating > 0) {
            throw new IllegalStateException("Invalid between begin/end.");
        }
        return super.pop();
    }
    
    @Override
    public Seq<T> sort() {
        if (this.iterating > 0) {
            throw new IllegalStateException("Invalid between begin/end.");
        }
        return super.sort();
    }
    
    @Override
    public Seq<T> sort(final Comparator<? super T> comparator) {
        if (this.iterating > 0) {
            throw new IllegalStateException("Invalid between begin/end.");
        }
        return super.sort(comparator);
    }
    
    @Override
    public void reverse() {
        if (this.iterating > 0) {
            throw new IllegalStateException("Invalid between begin/end.");
        }
        super.reverse();
    }
    
    @Override
    public void shuffle() {
        if (this.iterating > 0) {
            throw new IllegalStateException("Invalid between begin/end.");
        }
        super.shuffle();
    }
    
    @Override
    public void truncate(final int newSize) {
        if (this.iterating > 0) {
            throw new IllegalStateException("Invalid between begin/end.");
        }
        super.truncate(newSize);
    }
    
    @Override
    public T[] setSize(final int newSize) {
        if (this.iterating > 0) {
            throw new IllegalStateException("Invalid between begin/end.");
        }
        return super.setSize(newSize);
    }
}
