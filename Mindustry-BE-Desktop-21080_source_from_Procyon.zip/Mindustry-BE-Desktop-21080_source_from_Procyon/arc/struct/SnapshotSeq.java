// 
// Decompiled by Procyon v0.5.36
// 

package arc.struct;

import java.util.Comparator;

public class SnapshotSeq<T> extends Seq<T>
{
    private T[] snapshot;
    private T[] recycled;
    private int snapshots;
    
    public SnapshotSeq() {
    }
    
    public SnapshotSeq(final Seq<T> array) {
        super(array);
    }
    
    public SnapshotSeq(final boolean ordered, final int capacity, final Class arrayType) {
        super(ordered, capacity, arrayType);
    }
    
    public SnapshotSeq(final boolean ordered, final int capacity) {
        super(ordered, capacity);
    }
    
    public SnapshotSeq(final boolean ordered, final T[] array, final int startIndex, final int count) {
        super(ordered, array, startIndex, count);
    }
    
    public SnapshotSeq(final Class arrayType) {
        super(arrayType);
    }
    
    public SnapshotSeq(final int capacity) {
        super(capacity);
    }
    
    public SnapshotSeq(final T[] array) {
        super(array);
    }
    
    public static <T> SnapshotSeq<T> with(final T... array) {
        return new SnapshotSeq<T>(array);
    }
    
    public T[] begin() {
        this.modified();
        this.snapshot = this.items;
        ++this.snapshots;
        return this.items;
    }
    
    public void end() {
        this.snapshots = Math.max(0, this.snapshots - 1);
        if (this.snapshot == null) {
            return;
        }
        if (this.snapshot != this.items && this.snapshots == 0) {
            this.recycled = this.snapshot;
            for (int i = 0, n = this.recycled.length; i < n; ++i) {
                this.recycled[i] = null;
            }
        }
        this.snapshot = null;
    }
    
    private void modified() {
        if (this.snapshot == null || this.snapshot != this.items) {
            return;
        }
        if (this.recycled != null && this.recycled.length >= this.size) {
            System.arraycopy(this.items, 0, this.recycled, 0, this.size);
            this.items = this.recycled;
            this.recycled = null;
        }
        else {
            this.resize(this.items.length);
        }
    }
    
    @Override
    public void set(final int index, final T value) {
        this.modified();
        super.set(index, value);
    }
    
    @Override
    public void insert(final int index, final T value) {
        this.modified();
        super.insert(index, value);
    }
    
    @Override
    public void swap(final int first, final int second) {
        this.modified();
        super.swap(first, second);
    }
    
    @Override
    public boolean remove(final T value, final boolean identity) {
        this.modified();
        return super.remove(value, identity);
    }
    
    @Override
    public T remove(final int index) {
        this.modified();
        return super.remove(index);
    }
    
    @Override
    public void removeRange(final int start, final int end) {
        this.modified();
        super.removeRange(start, end);
    }
    
    @Override
    public boolean removeAll(final Seq<? extends T> array, final boolean identity) {
        this.modified();
        return super.removeAll(array, identity);
    }
    
    @Override
    public T pop() {
        this.modified();
        return super.pop();
    }
    
    @Override
    public Seq<T> clear() {
        this.modified();
        super.clear();
        return this;
    }
    
    @Override
    public Seq<T> sort() {
        this.modified();
        return super.sort();
    }
    
    @Override
    public Seq<T> sort(final Comparator<? super T> comparator) {
        this.modified();
        return super.sort(comparator);
    }
    
    @Override
    public void reverse() {
        this.modified();
        super.reverse();
    }
    
    @Override
    public void shuffle() {
        this.modified();
        super.shuffle();
    }
    
    @Override
    public void truncate(final int newSize) {
        this.modified();
        super.truncate(newSize);
    }
    
    @Override
    public T[] setSize(final int newSize) {
        this.modified();
        return super.setSize(newSize);
    }
}
