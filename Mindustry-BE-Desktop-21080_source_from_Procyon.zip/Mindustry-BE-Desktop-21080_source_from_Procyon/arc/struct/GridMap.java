// 
// Decompiled by Procyon v0.5.36
// 

package arc.struct;

public class GridMap<T>
{
    protected LongMap<T> map;
    
    public GridMap() {
        this.map = new LongMap<T>();
    }
    
    private static long getHash(final int x, final int y) {
        return (long)x << 32 | ((long)y & 0xFFFFFFFFL);
    }
    
    public T get(final int x, final int y) {
        return this.map.get(getHash(x, y));
    }
    
    public T get(final int x, final int y, final T defaultValue) {
        final long hash = getHash(x, y);
        if (!this.map.containsKey(hash)) {
            return defaultValue;
        }
        return this.map.get(hash);
    }
    
    public boolean containsKey(final int x, final int y) {
        return this.map.containsKey(getHash(x, y));
    }
    
    public void put(final int x, final int y, final T t) {
        this.map.put(getHash(x, y), t);
    }
    
    public void remove(final int x, final int y) {
        this.map.remove(getHash(x, y));
    }
    
    public LongMap.Values<T> values() {
        return this.map.values();
    }
    
    public LongMap.Keys keys() {
        return this.map.keys();
    }
    
    public void clear() {
        this.map.clear();
    }
    
    public int size() {
        return this.map.size;
    }
}
