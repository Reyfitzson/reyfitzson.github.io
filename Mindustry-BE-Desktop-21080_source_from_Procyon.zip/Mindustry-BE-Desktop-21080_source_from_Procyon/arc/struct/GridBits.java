// 
// Decompiled by Procyon v0.5.36
// 

package arc.struct;

public class GridBits
{
    private final Bits bits;
    private final int width;
    private final int height;
    
    public GridBits(final int width, final int height) {
        this.width = width;
        this.height = height;
        this.bits = new Bits(width * height);
    }
    
    public void set(final GridBits other) {
        this.bits.set(other.bits);
    }
    
    public boolean get(final int x, final int y) {
        return x < this.width && y < this.height && x >= 0 && y >= 0 && this.bits.get(x + y * this.width);
    }
    
    public void set(final int x, final int y) {
        this.bits.set(x + y * this.width);
    }
    
    public void set(final int x, final int y, final boolean b) {
        if (b) {
            this.bits.set(x + y * this.width);
        }
        else {
            this.bits.clear(x + y * this.width);
        }
    }
    
    public void clear() {
        this.bits.clear();
    }
    
    public int width() {
        return this.width;
    }
    
    public int height() {
        return this.height;
    }
}
