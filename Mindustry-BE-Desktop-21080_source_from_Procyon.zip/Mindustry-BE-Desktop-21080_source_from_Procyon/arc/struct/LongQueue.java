// 
// Decompiled by Procyon v0.5.36
// 

package arc.struct;

import java.util.NoSuchElementException;

public class LongQueue
{
    public int size;
    protected long[] values;
    protected int head;
    protected int tail;
    
    public LongQueue() {
        this(16);
    }
    
    public LongQueue(final int initialSize) {
        this.size = 0;
        this.head = 0;
        this.tail = 0;
        this.values = new long[initialSize];
    }
    
    public LongQueue(final long[] array) {
        this(Math.max(array.length, 16));
        for (int i = 0; i < array.length; ++i) {
            this.addLast(array[i]);
        }
    }
    
    public void addLast(final long object) {
        long[] values = this.values;
        if (this.size == values.length) {
            this.resize(values.length << 1);
            values = this.values;
        }
        values[this.tail++] = object;
        if (this.tail == values.length) {
            this.tail = 0;
        }
        ++this.size;
    }
    
    public void addFirst(final long object) {
        long[] values = this.values;
        if (this.size == values.length) {
            this.resize(values.length << 1);
            values = this.values;
        }
        int head = this.head;
        if (--head == -1) {
            head = values.length - 1;
        }
        values[head] = object;
        this.head = head;
        ++this.size;
    }
    
    public void ensureCapacity(final int additional) {
        final int needed = this.size + additional;
        if (this.values.length < needed) {
            this.resize(needed);
        }
    }
    
    protected void resize(final int newSize) {
        final long[] values = this.values;
        final int head = this.head;
        final int tail = this.tail;
        final long[] newArray = new long[newSize];
        if (head < tail) {
            System.arraycopy(values, head, newArray, 0, tail - head);
        }
        else if (this.size > 0) {
            final int rest = values.length - head;
            System.arraycopy(values, head, newArray, 0, rest);
            System.arraycopy(values, 0, newArray, rest, tail);
        }
        this.values = newArray;
        this.head = 0;
        this.tail = this.size;
    }
    
    public long removeFirst() {
        if (this.size == 0) {
            throw new NoSuchElementException("Queue is empty.");
        }
        final long[] values = this.values;
        final long result = values[this.head];
        values[this.head] = 0L;
        ++this.head;
        if (this.head == values.length) {
            this.head = 0;
        }
        --this.size;
        return result;
    }
    
    public long removeLast() {
        if (this.size == 0) {
            throw new NoSuchElementException("Queue is empty.");
        }
        final long[] values = this.values;
        int tail = this.tail;
        if (--tail == -1) {
            tail = values.length - 1;
        }
        final long result = values[tail];
        values[tail] = 0L;
        this.tail = tail;
        --this.size;
        return result;
    }
    
    public int indexOf(final long value, final boolean identity) {
        if (this.size == 0) {
            return -1;
        }
        final long[] values = this.values;
        final int head = this.head;
        final int tail = this.tail;
        if (head < tail) {
            for (int i = head; i < tail; ++i) {
                if (values[i] == value) {
                    return i - head;
                }
            }
        }
        else {
            for (int i = head, n = values.length; i < n; ++i) {
                if (values[i] == value) {
                    return i - head;
                }
            }
            for (int i = 0; i < tail; ++i) {
                if (values[i] == value) {
                    return i + values.length - head;
                }
            }
        }
        return -1;
    }
    
    public boolean removeValue(final long value, final boolean identity) {
        final int index = this.indexOf(value, identity);
        if (index == -1) {
            return false;
        }
        this.removeIndex(index);
        return true;
    }
    
    public long removeIndex(int index) {
        if (index < 0) {
            throw new IndexOutOfBoundsException("index can't be < 0: " + index);
        }
        if (index >= this.size) {
            throw new IndexOutOfBoundsException("index can't be >= size: " + index + " >= " + this.size);
        }
        final long[] values = this.values;
        final int head = this.head;
        final int tail = this.tail;
        index += head;
        long value;
        if (head < tail) {
            value = values[index];
            System.arraycopy(values, index + 1, values, index, tail - index);
            --this.tail;
        }
        else if (index >= values.length) {
            index -= values.length;
            value = values[index];
            System.arraycopy(values, index + 1, values, index, tail - index);
            --this.tail;
        }
        else {
            value = values[index];
            System.arraycopy(values, head, values, head + 1, index - head);
            ++this.head;
            if (this.head == values.length) {
                this.head = 0;
            }
        }
        --this.size;
        return value;
    }
    
    public boolean isEmpty() {
        return this.size == 0;
    }
    
    public long first() {
        if (this.size == 0) {
            throw new NoSuchElementException("Queue is empty.");
        }
        return this.values[this.head];
    }
    
    public long last() {
        if (this.size == 0) {
            throw new NoSuchElementException("Queue is empty.");
        }
        final long[] values = this.values;
        int tail = this.tail;
        if (--tail == -1) {
            tail = values.length - 1;
        }
        return values[tail];
    }
    
    public long get(final int index) {
        if (index < 0) {
            throw new IndexOutOfBoundsException("index can't be < 0: " + index);
        }
        if (index >= this.size) {
            throw new IndexOutOfBoundsException("index can't be >= size: " + index + " >= " + this.size);
        }
        final long[] values = this.values;
        int i = this.head + index;
        if (i >= values.length) {
            i -= values.length;
        }
        return values[i];
    }
    
    public void set(final int index, final long value) {
        if (index < 0) {
            throw new IndexOutOfBoundsException("index can't be < 0: " + index);
        }
        if (index >= this.size) {
            throw new IndexOutOfBoundsException("index can't be >= size: " + index + " >= " + this.size);
        }
        final long[] values = this.values;
        int i = this.head + index;
        if (i >= values.length) {
            i -= values.length;
        }
        values[i] = value;
    }
    
    public void clear() {
        if (this.size == 0) {
            return;
        }
        this.head = 0;
        this.tail = 0;
        this.size = 0;
    }
    
    public long[] toArray() {
        final long[] out = new long[this.size];
        for (int i = 0; i < this.size; ++i) {
            out[i] = this.get(i);
        }
        return out;
    }
    
    @Override
    public String toString() {
        if (this.size == 0) {
            return "[]";
        }
        final long[] values = this.values;
        final int head = this.head;
        final int tail = this.tail;
        final StringBuilder sb = new StringBuilder(64);
        sb.append('[');
        sb.append(values[head]);
        for (int i = (head + 1) % values.length; i != tail; i = (i + 1) % values.length) {
            sb.append(", ").append(values[i]);
        }
        sb.append(']');
        return sb.toString();
    }
}
