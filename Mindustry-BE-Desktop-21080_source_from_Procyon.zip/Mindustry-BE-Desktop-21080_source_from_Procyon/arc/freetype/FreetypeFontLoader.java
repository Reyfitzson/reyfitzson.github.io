// 
// Decompiled by Procyon v0.5.36
// 

package arc.freetype;

import arc.assets.AssetLoaderParameters;
import arc.assets.AssetDescriptor;
import arc.struct.Seq;
import arc.files.Fi;
import arc.assets.AssetManager;
import arc.assets.loaders.FileHandleResolver;
import arc.graphics.g2d.Font;
import arc.assets.loaders.AsynchronousAssetLoader;

public class FreetypeFontLoader extends AsynchronousAssetLoader<Font, FreeTypeFontLoaderParameter>
{
    public FreetypeFontLoader(final FileHandleResolver resolver) {
        super(resolver);
    }
    
    @Override
    public void loadAsync(final AssetManager manager, final String fileName, final Fi file, final FreeTypeFontLoaderParameter parameter) {
        if (parameter == null) {
            throw new RuntimeException("FreetypeFontParameter must be set in AssetManager#load to point at a TTF file!");
        }
    }
    
    @Override
    public Font loadSync(final AssetManager manager, final String fileName, final Fi file, final FreeTypeFontLoaderParameter parameter) {
        if (parameter == null) {
            throw new RuntimeException("FreetypeFontParameter must be set in AssetManager#load to point at a TTF file!");
        }
        final FreeTypeFontGenerator generator = manager.get(parameter.fontFileName + ".gen", FreeTypeFontGenerator.class);
        return generator.generateFont(parameter.fontParameters);
    }
    
    @Override
    public Seq<AssetDescriptor> getDependencies(final String fileName, final Fi file, final FreeTypeFontLoaderParameter parameter) {
        final Seq<AssetDescriptor> deps = new Seq<AssetDescriptor>();
        deps.add(new AssetDescriptor(parameter.fontFileName + ".gen", FreeTypeFontGenerator.class));
        return deps;
    }
    
    public static class FreeTypeFontLoaderParameter extends AssetLoaderParameters<Font>
    {
        public String fontFileName;
        public FreeTypeFontGenerator.FreeTypeFontParameter fontParameters;
        
        public FreeTypeFontLoaderParameter() {
            this.fontParameters = new FreeTypeFontGenerator.FreeTypeFontParameter();
        }
        
        public FreeTypeFontLoaderParameter(final String fontFileName, final FreeTypeFontGenerator.FreeTypeFontParameter fontParameters) {
            this.fontParameters = new FreeTypeFontGenerator.FreeTypeFontParameter();
            this.fontFileName = fontFileName;
            this.fontParameters = fontParameters;
        }
    }
}
