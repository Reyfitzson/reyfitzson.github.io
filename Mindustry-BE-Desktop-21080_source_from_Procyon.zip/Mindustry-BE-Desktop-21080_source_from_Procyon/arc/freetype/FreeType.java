// 
// Decompiled by Procyon v0.5.36
// 

package arc.freetype;

import java.nio.IntBuffer;
import arc.graphics.Color;
import arc.graphics.Pixmap;
import java.nio.Buffer;
import arc.files.Fi;
import java.util.Iterator;
import arc.util.Buffers;
import java.nio.ByteBuffer;
import arc.struct.LongMap;
import arc.util.Disposable;
import arc.util.ArcRuntimeException;
import arc.util.SharedLibraryLoader;

public class FreeType
{
    public static int FT_PIXEL_MODE_NONE;
    public static int FT_PIXEL_MODE_MONO;
    public static int FT_PIXEL_MODE_GRAY;
    public static int FT_PIXEL_MODE_GRAY2;
    public static int FT_PIXEL_MODE_GRAY4;
    public static int FT_PIXEL_MODE_LCD;
    public static int FT_PIXEL_MODE_LCD_V;
    public static int FT_ENCODING_NONE;
    public static int FT_ENCODING_MS_SYMBOL;
    public static int FT_ENCODING_UNICODE;
    public static int FT_ENCODING_SJIS;
    public static int FT_ENCODING_GB2312;
    public static int FT_ENCODING_BIG5;
    public static int FT_ENCODING_WANSUNG;
    public static int FT_ENCODING_JOHAB;
    public static int FT_ENCODING_ADOBE_STANDARD;
    public static int FT_ENCODING_ADOBE_EXPERT;
    public static int FT_ENCODING_ADOBE_CUSTOM;
    public static int FT_ENCODING_ADOBE_LATIN_1;
    public static int FT_ENCODING_OLD_LATIN_2;
    public static int FT_ENCODING_APPLE_ROMAN;
    public static int FT_FACE_FLAG_SCALABLE;
    public static int FT_FACE_FLAG_FIXED_SIZES;
    public static int FT_FACE_FLAG_FIXED_WIDTH;
    public static int FT_FACE_FLAG_SFNT;
    public static int FT_FACE_FLAG_HORIZONTAL;
    public static int FT_FACE_FLAG_VERTICAL;
    public static int FT_FACE_FLAG_KERNING;
    public static int FT_FACE_FLAG_FAST_GLYPHS;
    public static int FT_FACE_FLAG_MULTIPLE_MASTERS;
    public static int FT_FACE_FLAG_GLYPH_NAMES;
    public static int FT_FACE_FLAG_EXTERNAL_STREAM;
    public static int FT_FACE_FLAG_HINTER;
    public static int FT_FACE_FLAG_CID_KEYED;
    public static int FT_FACE_FLAG_TRICKY;
    public static int FT_STYLE_FLAG_ITALIC;
    public static int FT_STYLE_FLAG_BOLD;
    public static int FT_LOAD_DEFAULT;
    public static int FT_LOAD_NO_SCALE;
    public static int FT_LOAD_NO_HINTING;
    public static int FT_LOAD_RENDER;
    public static int FT_LOAD_NO_BITMAP;
    public static int FT_LOAD_VERTICAL_LAYOUT;
    public static int FT_LOAD_FORCE_AUTOHINT;
    public static int FT_LOAD_CROP_BITMAP;
    public static int FT_LOAD_PEDANTIC;
    public static int FT_LOAD_IGNORE_GLOBAL_ADVANCE_WIDTH;
    public static int FT_LOAD_NO_RECURSE;
    public static int FT_LOAD_IGNORE_TRANSFORM;
    public static int FT_LOAD_MONOCHROME;
    public static int FT_LOAD_LINEAR_DESIGN;
    public static int FT_LOAD_NO_AUTOHINT;
    public static int FT_LOAD_TARGET_NORMAL;
    public static int FT_LOAD_TARGET_LIGHT;
    public static int FT_LOAD_TARGET_MONO;
    public static int FT_LOAD_TARGET_LCD;
    public static int FT_LOAD_TARGET_LCD_V;
    public static int FT_RENDER_MODE_NORMAL;
    public static int FT_RENDER_MODE_LIGHT;
    public static int FT_RENDER_MODE_MONO;
    public static int FT_RENDER_MODE_LCD;
    public static int FT_RENDER_MODE_LCD_V;
    public static int FT_RENDER_MODE_MAX;
    public static int FT_KERNING_DEFAULT;
    public static int FT_KERNING_UNFITTED;
    public static int FT_KERNING_UNSCALED;
    public static int FT_STROKER_LINECAP_BUTT;
    public static int FT_STROKER_LINECAP_ROUND;
    public static int FT_STROKER_LINECAP_SQUARE;
    public static int FT_STROKER_LINEJOIN_ROUND;
    public static int FT_STROKER_LINEJOIN_BEVEL;
    public static int FT_STROKER_LINEJOIN_MITER_VARIABLE;
    public static int FT_STROKER_LINEJOIN_MITER;
    public static int FT_STROKER_LINEJOIN_MITER_FIXED;
    
    static native int getLastErrorCode();
    
    private static int encode(final char a, final char b, final char c, final char d) {
        return a << 24 | b << 16 | c << 8 | d;
    }
    
    public static Library initFreeType() {
        new SharedLibraryLoader().load("arc-freetype");
        final long address = initFreeTypeJni();
        if (address == 0L) {
            throw new ArcRuntimeException("Couldn't initialize FreeType library, FreeType error code: " + getLastErrorCode());
        }
        return new Library(address);
    }
    
    private static native long initFreeTypeJni();
    
    public static int toInt(final int value) {
        return (value + 63 & 0xFFFFFFC0) >> 6;
    }
    
    static {
        FreeType.FT_PIXEL_MODE_NONE = 0;
        FreeType.FT_PIXEL_MODE_MONO = 1;
        FreeType.FT_PIXEL_MODE_GRAY = 2;
        FreeType.FT_PIXEL_MODE_GRAY2 = 3;
        FreeType.FT_PIXEL_MODE_GRAY4 = 4;
        FreeType.FT_PIXEL_MODE_LCD = 5;
        FreeType.FT_PIXEL_MODE_LCD_V = 6;
        FreeType.FT_ENCODING_NONE = 0;
        FreeType.FT_ENCODING_MS_SYMBOL = encode('s', 'y', 'm', 'b');
        FreeType.FT_ENCODING_UNICODE = encode('u', 'n', 'i', 'c');
        FreeType.FT_ENCODING_SJIS = encode('s', 'j', 'i', 's');
        FreeType.FT_ENCODING_GB2312 = encode('g', 'b', ' ', ' ');
        FreeType.FT_ENCODING_BIG5 = encode('b', 'i', 'g', '5');
        FreeType.FT_ENCODING_WANSUNG = encode('w', 'a', 'n', 's');
        FreeType.FT_ENCODING_JOHAB = encode('j', 'o', 'h', 'a');
        FreeType.FT_ENCODING_ADOBE_STANDARD = encode('A', 'D', 'O', 'B');
        FreeType.FT_ENCODING_ADOBE_EXPERT = encode('A', 'D', 'B', 'E');
        FreeType.FT_ENCODING_ADOBE_CUSTOM = encode('A', 'D', 'B', 'C');
        FreeType.FT_ENCODING_ADOBE_LATIN_1 = encode('l', 'a', 't', '1');
        FreeType.FT_ENCODING_OLD_LATIN_2 = encode('l', 'a', 't', '2');
        FreeType.FT_ENCODING_APPLE_ROMAN = encode('a', 'r', 'm', 'n');
        FreeType.FT_FACE_FLAG_SCALABLE = 1;
        FreeType.FT_FACE_FLAG_FIXED_SIZES = 2;
        FreeType.FT_FACE_FLAG_FIXED_WIDTH = 4;
        FreeType.FT_FACE_FLAG_SFNT = 8;
        FreeType.FT_FACE_FLAG_HORIZONTAL = 16;
        FreeType.FT_FACE_FLAG_VERTICAL = 32;
        FreeType.FT_FACE_FLAG_KERNING = 64;
        FreeType.FT_FACE_FLAG_FAST_GLYPHS = 128;
        FreeType.FT_FACE_FLAG_MULTIPLE_MASTERS = 256;
        FreeType.FT_FACE_FLAG_GLYPH_NAMES = 512;
        FreeType.FT_FACE_FLAG_EXTERNAL_STREAM = 1024;
        FreeType.FT_FACE_FLAG_HINTER = 2048;
        FreeType.FT_FACE_FLAG_CID_KEYED = 4096;
        FreeType.FT_FACE_FLAG_TRICKY = 8192;
        FreeType.FT_STYLE_FLAG_ITALIC = 1;
        FreeType.FT_STYLE_FLAG_BOLD = 2;
        FreeType.FT_LOAD_DEFAULT = 0;
        FreeType.FT_LOAD_NO_SCALE = 1;
        FreeType.FT_LOAD_NO_HINTING = 2;
        FreeType.FT_LOAD_RENDER = 4;
        FreeType.FT_LOAD_NO_BITMAP = 8;
        FreeType.FT_LOAD_VERTICAL_LAYOUT = 16;
        FreeType.FT_LOAD_FORCE_AUTOHINT = 32;
        FreeType.FT_LOAD_CROP_BITMAP = 64;
        FreeType.FT_LOAD_PEDANTIC = 128;
        FreeType.FT_LOAD_IGNORE_GLOBAL_ADVANCE_WIDTH = 512;
        FreeType.FT_LOAD_NO_RECURSE = 1024;
        FreeType.FT_LOAD_IGNORE_TRANSFORM = 2048;
        FreeType.FT_LOAD_MONOCHROME = 4096;
        FreeType.FT_LOAD_LINEAR_DESIGN = 8192;
        FreeType.FT_LOAD_NO_AUTOHINT = 32768;
        FreeType.FT_LOAD_TARGET_NORMAL = 0;
        FreeType.FT_LOAD_TARGET_LIGHT = 65536;
        FreeType.FT_LOAD_TARGET_MONO = 131072;
        FreeType.FT_LOAD_TARGET_LCD = 196608;
        FreeType.FT_LOAD_TARGET_LCD_V = 262144;
        FreeType.FT_RENDER_MODE_NORMAL = 0;
        FreeType.FT_RENDER_MODE_LIGHT = 1;
        FreeType.FT_RENDER_MODE_MONO = 2;
        FreeType.FT_RENDER_MODE_LCD = 3;
        FreeType.FT_RENDER_MODE_LCD_V = 4;
        FreeType.FT_RENDER_MODE_MAX = 5;
        FreeType.FT_KERNING_DEFAULT = 0;
        FreeType.FT_KERNING_UNFITTED = 1;
        FreeType.FT_KERNING_UNSCALED = 2;
        FreeType.FT_STROKER_LINECAP_BUTT = 0;
        FreeType.FT_STROKER_LINECAP_ROUND = 1;
        FreeType.FT_STROKER_LINECAP_SQUARE = 2;
        FreeType.FT_STROKER_LINEJOIN_ROUND = 0;
        FreeType.FT_STROKER_LINEJOIN_BEVEL = 1;
        FreeType.FT_STROKER_LINEJOIN_MITER_VARIABLE = 2;
        FreeType.FT_STROKER_LINEJOIN_MITER = FreeType.FT_STROKER_LINEJOIN_MITER_VARIABLE;
        FreeType.FT_STROKER_LINEJOIN_MITER_FIXED = 3;
    }
    
    private static class Pointer
    {
        long address;
        
        Pointer(final long address) {
            this.address = address;
        }
    }
    
    public static class Library extends Pointer implements Disposable
    {
        LongMap<ByteBuffer> fontData;
        
        Library(final long address) {
            super(address);
            this.fontData = new LongMap<ByteBuffer>();
        }
        
        @Override
        public void dispose() {
            doneFreeType(this.address);
            for (final ByteBuffer buffer : this.fontData.values()) {
                if (Buffers.isUnsafeByteBuffer(buffer)) {
                    Buffers.disposeUnsafeByteBuffer(buffer);
                }
            }
        }
        
        private static native void doneFreeType(final long p0);
        
        public Face newFace(final Fi font, final int faceIndex) {
            final byte[] data = font.readBytes();
            return this.newMemoryFace(data, data.length, faceIndex);
        }
        
        public Face newMemoryFace(final byte[] data, final int dataSize, final int faceIndex) {
            final ByteBuffer buffer = Buffers.newUnsafeByteBuffer(data.length);
            Buffers.copy(data, 0, buffer, data.length);
            return this.newMemoryFace(buffer, faceIndex);
        }
        
        public Face newMemoryFace(final ByteBuffer buffer, final int faceIndex) {
            final long face = newMemoryFace(this.address, buffer, buffer.remaining(), faceIndex);
            if (face == 0L) {
                if (Buffers.isUnsafeByteBuffer(buffer)) {
                    Buffers.disposeUnsafeByteBuffer(buffer);
                }
                throw new ArcRuntimeException("Couldn't load font, FreeType error code: " + FreeType.getLastErrorCode());
            }
            this.fontData.put(face, buffer);
            return new Face(face, this);
        }
        
        private static native long newMemoryFace(final long p0, final ByteBuffer p1, final int p2, final int p3);
        
        public Stroker createStroker() {
            final long stroker = strokerNew(this.address);
            if (stroker == 0L) {
                throw new ArcRuntimeException("Couldn't create FreeType stroker, FreeType error code: " + FreeType.getLastErrorCode());
            }
            return new Stroker(stroker);
        }
        
        private static native long strokerNew(final long p0);
    }
    
    public static class Face extends Pointer implements Disposable
    {
        Library library;
        
        public Face(final long address, final Library library) {
            super(address);
            this.library = library;
        }
        
        @Override
        public void dispose() {
            doneFace(this.address);
            final ByteBuffer buffer = this.library.fontData.get(this.address);
            if (buffer != null) {
                this.library.fontData.remove(this.address);
                if (Buffers.isUnsafeByteBuffer(buffer)) {
                    Buffers.disposeUnsafeByteBuffer(buffer);
                }
            }
        }
        
        private static native void doneFace(final long p0);
        
        public int getFaceFlags() {
            return getFaceFlags(this.address);
        }
        
        private static native int getFaceFlags(final long p0);
        
        public int getStyleFlags() {
            return getStyleFlags(this.address);
        }
        
        private static native int getStyleFlags(final long p0);
        
        public int getNumGlyphs() {
            return getNumGlyphs(this.address);
        }
        
        private static native int getNumGlyphs(final long p0);
        
        public int getAscender() {
            return getAscender(this.address);
        }
        
        private static native int getAscender(final long p0);
        
        public int getDescender() {
            return getDescender(this.address);
        }
        
        private static native int getDescender(final long p0);
        
        public int getHeight() {
            return getHeight(this.address);
        }
        
        private static native int getHeight(final long p0);
        
        public int getMaxAdvanceWidth() {
            return getMaxAdvanceWidth(this.address);
        }
        
        private static native int getMaxAdvanceWidth(final long p0);
        
        public int getMaxAdvanceHeight() {
            return getMaxAdvanceHeight(this.address);
        }
        
        private static native int getMaxAdvanceHeight(final long p0);
        
        public int getUnderlinePosition() {
            return getUnderlinePosition(this.address);
        }
        
        private static native int getUnderlinePosition(final long p0);
        
        public int getUnderlineThickness() {
            return getUnderlineThickness(this.address);
        }
        
        private static native int getUnderlineThickness(final long p0);
        
        public boolean selectSize(final int strikeIndex) {
            return selectSize(this.address, strikeIndex);
        }
        
        private static native boolean selectSize(final long p0, final int p1);
        
        public boolean setCharSize(final int charWidth, final int charHeight, final int horzResolution, final int vertResolution) {
            return setCharSize(this.address, charWidth, charHeight, horzResolution, vertResolution);
        }
        
        private static native boolean setCharSize(final long p0, final int p1, final int p2, final int p3, final int p4);
        
        public boolean setPixelSizes(final int pixelWidth, final int pixelHeight) {
            return setPixelSizes(this.address, pixelWidth, pixelHeight);
        }
        
        private static native boolean setPixelSizes(final long p0, final int p1, final int p2);
        
        public boolean loadGlyph(final int glyphIndex, final int loadFlags) {
            return loadGlyph(this.address, glyphIndex, loadFlags);
        }
        
        private static native boolean loadGlyph(final long p0, final int p1, final int p2);
        
        public boolean loadChar(final int charCode, final int loadFlags) {
            return loadChar(this.address, charCode, loadFlags);
        }
        
        private static native boolean loadChar(final long p0, final int p1, final int p2);
        
        public GlyphSlot getGlyph() {
            return new GlyphSlot(getGlyph(this.address));
        }
        
        private static native long getGlyph(final long p0);
        
        public Size getSize() {
            return new Size(getSize(this.address));
        }
        
        private static native long getSize(final long p0);
        
        public boolean hasKerning() {
            return hasKerning(this.address);
        }
        
        private static native boolean hasKerning(final long p0);
        
        public int getKerning(final int leftGlyph, final int rightGlyph, final int kernMode) {
            return getKerning(this.address, leftGlyph, rightGlyph, kernMode);
        }
        
        private static native int getKerning(final long p0, final int p1, final int p2, final int p3);
        
        public int getCharIndex(final int charCode) {
            return getCharIndex(this.address, charCode);
        }
        
        private static native int getCharIndex(final long p0, final int p1);
    }
    
    public static class Size extends Pointer
    {
        Size(final long address) {
            super(address);
        }
        
        public SizeMetrics getMetrics() {
            return new SizeMetrics(getMetrics(this.address));
        }
        
        private static native long getMetrics(final long p0);
    }
    
    public static class SizeMetrics extends Pointer
    {
        SizeMetrics(final long address) {
            super(address);
        }
        
        public int getXppem() {
            return getXppem(this.address);
        }
        
        private static native int getXppem(final long p0);
        
        public int getYppem() {
            return getYppem(this.address);
        }
        
        private static native int getYppem(final long p0);
        
        public int getXScale() {
            return getXscale(this.address);
        }
        
        private static native int getXscale(final long p0);
        
        public int getYscale() {
            return getYscale(this.address);
        }
        
        private static native int getYscale(final long p0);
        
        public int getAscender() {
            return getAscender(this.address);
        }
        
        private static native int getAscender(final long p0);
        
        public int getDescender() {
            return getDescender(this.address);
        }
        
        private static native int getDescender(final long p0);
        
        public int getHeight() {
            return getHeight(this.address);
        }
        
        private static native int getHeight(final long p0);
        
        public int getMaxAdvance() {
            return getMaxAdvance(this.address);
        }
        
        private static native int getMaxAdvance(final long p0);
    }
    
    public static class GlyphSlot extends Pointer
    {
        GlyphSlot(final long address) {
            super(address);
        }
        
        public GlyphMetrics getMetrics() {
            return new GlyphMetrics(getMetrics(this.address));
        }
        
        private static native long getMetrics(final long p0);
        
        public int getLinearHoriAdvance() {
            return getLinearHoriAdvance(this.address);
        }
        
        private static native int getLinearHoriAdvance(final long p0);
        
        public int getLinearVertAdvance() {
            return getLinearVertAdvance(this.address);
        }
        
        private static native int getLinearVertAdvance(final long p0);
        
        public int getAdvanceX() {
            return getAdvanceX(this.address);
        }
        
        private static native int getAdvanceX(final long p0);
        
        public int getAdvanceY() {
            return getAdvanceY(this.address);
        }
        
        private static native int getAdvanceY(final long p0);
        
        public int getFormat() {
            return getFormat(this.address);
        }
        
        private static native int getFormat(final long p0);
        
        public Bitmap getBitmap() {
            return new Bitmap(getBitmap(this.address));
        }
        
        private static native long getBitmap(final long p0);
        
        public int getBitmapLeft() {
            return getBitmapLeft(this.address);
        }
        
        private static native int getBitmapLeft(final long p0);
        
        public int getBitmapTop() {
            return getBitmapTop(this.address);
        }
        
        private static native int getBitmapTop(final long p0);
        
        public boolean renderGlyph(final int renderMode) {
            return renderGlyph(this.address, renderMode);
        }
        
        private static native boolean renderGlyph(final long p0, final int p1);
        
        public Glyph getGlyph() {
            final long glyph = getGlyph(this.address);
            if (glyph == 0L) {
                throw new ArcRuntimeException("Couldn't get glyph, FreeType error code: " + FreeType.getLastErrorCode());
            }
            return new Glyph(glyph);
        }
        
        private static native long getGlyph(final long p0);
    }
    
    public static class Glyph extends Pointer implements Disposable
    {
        private boolean rendered;
        
        Glyph(final long address) {
            super(address);
        }
        
        @Override
        public void dispose() {
            done(this.address);
        }
        
        private static native void done(final long p0);
        
        public void strokeBorder(final Stroker stroker, final boolean inside) {
            this.address = strokeBorder(this.address, stroker.address, inside);
        }
        
        private static native long strokeBorder(final long p0, final long p1, final boolean p2);
        
        public void toBitmap(final int renderMode) {
            final long bitmap = toBitmap(this.address, renderMode);
            if (bitmap == 0L) {
                throw new ArcRuntimeException("Couldn't render glyph, FreeType error code: " + FreeType.getLastErrorCode());
            }
            this.address = bitmap;
            this.rendered = true;
        }
        
        private static native long toBitmap(final long p0, final int p1);
        
        public Bitmap getBitmap() {
            if (!this.rendered) {
                throw new ArcRuntimeException("Glyph is not yet rendered");
            }
            return new Bitmap(getBitmap(this.address));
        }
        
        private static native long getBitmap(final long p0);
        
        public int getLeft() {
            if (!this.rendered) {
                throw new ArcRuntimeException("Glyph is not yet rendered");
            }
            return getLeft(this.address);
        }
        
        private static native int getLeft(final long p0);
        
        public int getTop() {
            if (!this.rendered) {
                throw new ArcRuntimeException("Glyph is not yet rendered");
            }
            return getTop(this.address);
        }
        
        private static native int getTop(final long p0);
    }
    
    public static class Bitmap extends Pointer
    {
        Bitmap(final long address) {
            super(address);
        }
        
        public int getRows() {
            return getRows(this.address);
        }
        
        private static native int getRows(final long p0);
        
        public int getWidth() {
            return getWidth(this.address);
        }
        
        private static native int getWidth(final long p0);
        
        public int getPitch() {
            return getPitch(this.address);
        }
        
        private static native int getPitch(final long p0);
        
        public ByteBuffer getBuffer() {
            if (this.getRows() == 0) {
                return Buffers.newByteBuffer(1);
            }
            return getBuffer(this.address);
        }
        
        private static native ByteBuffer getBuffer(final long p0);
        
        public Pixmap getPixmap(final Pixmap.Format format, final Color color, final float gamma) {
            final int width = this.getWidth();
            final int rows = this.getRows();
            final ByteBuffer src = this.getBuffer();
            final int pixelMode = this.getPixelMode();
            final int rowBytes = Math.abs(this.getPitch());
            Pixmap pixmap;
            if (color == Color.white && pixelMode == FreeType.FT_PIXEL_MODE_GRAY && rowBytes == width && gamma == 1.0f) {
                pixmap = new Pixmap(width, rows, Pixmap.Format.alpha);
                Buffers.copy(src, pixmap.getPixels(), pixmap.getPixels().capacity());
            }
            else {
                pixmap = new Pixmap(width, rows, Pixmap.Format.rgba8888);
                final int rgba = color.rgba8888();
                final byte[] srcRow = new byte[rowBytes];
                final int[] dstRow = new int[width];
                final IntBuffer dst = pixmap.getPixels().asIntBuffer();
                if (pixelMode == FreeType.FT_PIXEL_MODE_MONO) {
                    for (int y = 0; y < rows; ++y) {
                        src.get(srcRow);
                        int i = 0;
                        for (int x = 0; x < width; x += 8) {
                            final byte b = srcRow[i];
                            for (int ii = 0, n = Math.min(8, width - x); ii < n; ++ii) {
                                if ((b & 1 << 7 - ii) != 0x0) {
                                    dstRow[x + ii] = rgba;
                                }
                                else {
                                    dstRow[x + ii] = 0;
                                }
                            }
                            ++i;
                        }
                        dst.put(dstRow);
                    }
                }
                else {
                    final int rgb = rgba & 0xFFFFFF00;
                    final int a = rgba & 0xFF;
                    for (int y2 = 0; y2 < rows; ++y2) {
                        src.get(srcRow);
                        for (int x2 = 0; x2 < width; ++x2) {
                            final int alpha = srcRow[x2] & 0xFF;
                            if (alpha == 0) {
                                dstRow[x2] = rgb;
                            }
                            else if (alpha == 255) {
                                dstRow[x2] = (rgb | a);
                            }
                            else {
                                dstRow[x2] = (rgb | (int)(a * (float)Math.pow(alpha / 255.0f, gamma)));
                            }
                        }
                        dst.put(dstRow);
                    }
                }
            }
            Pixmap converted = pixmap;
            if (format != pixmap.getFormat()) {
                converted = new Pixmap(pixmap.getWidth(), pixmap.getHeight(), format);
                converted.setBlending(Pixmap.Blending.none);
                converted.drawPixmap(pixmap, 0, 0);
                pixmap.dispose();
            }
            return converted;
        }
        
        public int getNumGray() {
            return getNumGray(this.address);
        }
        
        private static native int getNumGray(final long p0);
        
        public int getPixelMode() {
            return getPixelMode(this.address);
        }
        
        private static native int getPixelMode(final long p0);
    }
    
    public static class GlyphMetrics extends Pointer
    {
        GlyphMetrics(final long address) {
            super(address);
        }
        
        public int getWidth() {
            return getWidth(this.address);
        }
        
        private static native int getWidth(final long p0);
        
        public int getHeight() {
            return getHeight(this.address);
        }
        
        private static native int getHeight(final long p0);
        
        public int getHoriBearingX() {
            return getHoriBearingX(this.address);
        }
        
        private static native int getHoriBearingX(final long p0);
        
        public int getHoriBearingY() {
            return getHoriBearingY(this.address);
        }
        
        private static native int getHoriBearingY(final long p0);
        
        public int getHoriAdvance() {
            return getHoriAdvance(this.address);
        }
        
        private static native int getHoriAdvance(final long p0);
        
        public int getVertBearingX() {
            return getVertBearingX(this.address);
        }
        
        private static native int getVertBearingX(final long p0);
        
        public int getVertBearingY() {
            return getVertBearingY(this.address);
        }
        
        private static native int getVertBearingY(final long p0);
        
        public int getVertAdvance() {
            return getVertAdvance(this.address);
        }
        
        private static native int getVertAdvance(final long p0);
    }
    
    public static class Stroker extends Pointer implements Disposable
    {
        Stroker(final long address) {
            super(address);
        }
        
        public void set(final int radius, final int lineCap, final int lineJoin, final int miterLimit) {
            set(this.address, radius, lineCap, lineJoin, miterLimit);
        }
        
        private static native void set(final long p0, final int p1, final int p2, final int p3, final int p4);
        
        @Override
        public void dispose() {
            done(this.address);
        }
        
        private static native void done(final long p0);
    }
}
