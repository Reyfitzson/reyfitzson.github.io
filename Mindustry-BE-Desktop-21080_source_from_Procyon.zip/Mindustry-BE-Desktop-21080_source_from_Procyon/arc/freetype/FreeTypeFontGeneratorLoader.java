// 
// Decompiled by Procyon v0.5.36
// 

package arc.freetype;

import arc.assets.AssetLoaderParameters;
import arc.assets.AssetDescriptor;
import arc.struct.Seq;
import arc.files.Fi;
import arc.assets.AssetManager;
import arc.assets.loaders.FileHandleResolver;
import arc.assets.loaders.SynchronousAssetLoader;

public class FreeTypeFontGeneratorLoader extends SynchronousAssetLoader<FreeTypeFontGenerator, FreeTypeFontGeneratorParameters>
{
    public FreeTypeFontGeneratorLoader(final FileHandleResolver resolver) {
        super(resolver);
    }
    
    @Override
    public FreeTypeFontGenerator load(final AssetManager assetManager, final String fileName, final Fi file, final FreeTypeFontGeneratorParameters parameter) {
        FreeTypeFontGenerator generator = null;
        if (file.extension().equals("gen")) {
            generator = new FreeTypeFontGenerator(file.sibling(file.nameWithoutExtension()));
        }
        else {
            generator = new FreeTypeFontGenerator(file);
        }
        return generator;
    }
    
    @Override
    public Seq<AssetDescriptor> getDependencies(final String fileName, final Fi file, final FreeTypeFontGeneratorParameters parameter) {
        return null;
    }
    
    public static class FreeTypeFontGeneratorParameters extends AssetLoaderParameters<FreeTypeFontGenerator>
    {
    }
}
