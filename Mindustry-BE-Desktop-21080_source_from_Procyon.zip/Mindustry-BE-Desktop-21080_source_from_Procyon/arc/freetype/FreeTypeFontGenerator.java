// 
// Decompiled by Procyon v0.5.36
// 

package arc.freetype;

import arc.graphics.Texture;
import arc.graphics.g2d.GlyphLayout;
import arc.math.geom.Rect;
import arc.graphics.Color;
import arc.util.Log;
import arc.graphics.Pixmap;
import arc.math.Mathf;
import arc.graphics.g2d.PixmapPacker;
import arc.graphics.g2d.TextureRegion;
import arc.struct.Seq;
import arc.graphics.g2d.Font;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.io.Closeable;
import java.io.IOException;
import java.nio.Buffer;
import arc.util.Buffers;
import arc.util.io.Streams;
import arc.util.ArcRuntimeException;
import arc.files.Fi;
import arc.util.Disposable;

public class FreeTypeFontGenerator implements Disposable
{
    public static final String DEFAULT_CHARS = "\u0000ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890\"!`?'.,;:()[]{}<>|/@\\^$\u20ac-%+=#_&~*\u007f\u0080\u0081\u0082\u0083\u0084\u0085\u0086\u0087\u0088\u0089\u008a\u008b\u008c\u008d\u008e\u008f\u0090\u0091\u0092\u0093\u0094\u0095\u0096\u0097\u0098\u0099\u009a\u009b\u009c\u009d\u009e\u009f ¡¢£¤¥¦§¨©ª«¬\u00ad®¯°±²³´µ¶·¸¹º»¼½¾¿\u00c0\u00c1\u00c2\u00c3\u00c4\u00c5\u00c6\u00c7\u00c8\u00c9\u00ca\u00cb\u00cc\u00cd\u00ce\u00cf\u00d0\u00d1\u00d2\u00d3\u00d4\u00d5\u00d6\u00d7\u00d8\u00d9\u00da\u00db\u00dc\u00dd\u00de\u00df\u00e0\u00e1\u00e2\u00e3\u00e4\u00e5\u00e6\u00e7\u00e8\u00e9\u00ea\u00eb\u00ec\u00ed\u00ee\u00ef\u00f0\u00f1\u00f2\u00f3\u00f4\u00f5\u00f6\u00f7\u00f8\u00f9\u00fa\u00fb\u00fc\u00fd\u00fe\u00ff";
    public static final int NO_MAXIMUM = -1;
    private static int maxTextureSize;
    final FreeType.Library library;
    final FreeType.Face face;
    final String name;
    boolean bitmapped;
    
    public FreeTypeFontGenerator(final Fi fontFile) {
        this(fontFile, 0);
    }
    
    public FreeTypeFontGenerator(final Fi fontFile, final int faceIndex) {
        this.bitmapped = false;
        this.name = fontFile.pathWithoutExtension();
        final int fileSize = (int)fontFile.length();
        this.library = FreeType.initFreeType();
        ByteBuffer buffer = null;
        try {
            buffer = fontFile.map();
        }
        catch (ArcRuntimeException ex2) {}
        if (buffer == null) {
            final InputStream input = fontFile.read();
            try {
                if (fileSize == 0) {
                    final byte[] data = Streams.copyBytes(input, 16384);
                    buffer = Buffers.newUnsafeByteBuffer(data.length);
                    Buffers.copy(data, 0, buffer, data.length);
                }
                else {
                    buffer = Buffers.newUnsafeByteBuffer(fileSize);
                    Streams.copy(input, buffer);
                }
            }
            catch (IOException ex) {
                throw new ArcRuntimeException(ex);
            }
            finally {
                Streams.close(input);
            }
        }
        this.face = this.library.newMemoryFace(buffer, faceIndex);
        if (this.face == null) {
            throw new ArcRuntimeException("Couldn't create face for font: " + fontFile);
        }
        if (this.checkForBitmapFont()) {
            return;
        }
        this.setPixelSizes(0, 15);
    }
    
    public static int getMaxTextureSize() {
        return FreeTypeFontGenerator.maxTextureSize;
    }
    
    public static void setMaxTextureSize(final int texSize) {
        FreeTypeFontGenerator.maxTextureSize = texSize;
    }
    
    private int getLoadingFlags(final FreeTypeFontParameter parameter) {
        int loadingFlags = FreeType.FT_LOAD_DEFAULT;
        switch (parameter.hinting) {
            case none: {
                loadingFlags |= FreeType.FT_LOAD_NO_HINTING;
                break;
            }
            case slight: {
                loadingFlags |= FreeType.FT_LOAD_TARGET_LIGHT;
                break;
            }
            case medium: {
                loadingFlags |= FreeType.FT_LOAD_TARGET_NORMAL;
                break;
            }
            case full: {
                loadingFlags |= FreeType.FT_LOAD_TARGET_MONO;
                break;
            }
            case autoSlight: {
                loadingFlags |= (FreeType.FT_LOAD_FORCE_AUTOHINT | FreeType.FT_LOAD_TARGET_LIGHT);
                break;
            }
            case autoMedium: {
                loadingFlags |= (FreeType.FT_LOAD_FORCE_AUTOHINT | FreeType.FT_LOAD_TARGET_NORMAL);
                break;
            }
            case autoFull: {
                loadingFlags |= (FreeType.FT_LOAD_FORCE_AUTOHINT | FreeType.FT_LOAD_TARGET_MONO);
                break;
            }
        }
        return loadingFlags;
    }
    
    private boolean loadChar(final int c) {
        return this.loadChar(c, FreeType.FT_LOAD_DEFAULT | FreeType.FT_LOAD_FORCE_AUTOHINT);
    }
    
    private boolean loadChar(final int c, final int flags) {
        return this.face.loadChar(c, flags);
    }
    
    private boolean checkForBitmapFont() {
        final int faceFlags = this.face.getFaceFlags();
        if ((faceFlags & FreeType.FT_FACE_FLAG_FIXED_SIZES) == FreeType.FT_FACE_FLAG_FIXED_SIZES && (faceFlags & FreeType.FT_FACE_FLAG_HORIZONTAL) == FreeType.FT_FACE_FLAG_HORIZONTAL && this.loadChar(32)) {
            final FreeType.GlyphSlot slot = this.face.getGlyph();
            if (slot.getFormat() == 1651078259) {
                this.bitmapped = true;
            }
        }
        return this.bitmapped;
    }
    
    public Font generateFont(final FreeTypeFontParameter parameter) {
        return this.generateFont(parameter, new FreeTypeFontData());
    }
    
    public Font generateFont(final FreeTypeFontParameter parameter, final FreeTypeFontData data) {
        final boolean updateTextureRegions = data.regions == null && parameter.packer != null;
        if (updateTextureRegions) {
            data.regions = new Seq<TextureRegion>();
        }
        this.generateData(parameter, data);
        if (updateTextureRegions) {
            parameter.packer.updateTextureRegions(data.regions, parameter.minFilter, parameter.magFilter, parameter.genMipMaps);
        }
        if (data.regions.isEmpty()) {
            throw new ArcRuntimeException("Unable to create a font with no texture regions.");
        }
        final Font font = new Font(data, data.regions, true);
        font.setOwnsTexture(parameter.packer == null);
        return font;
    }
    
    public int scaleForPixelHeight(final int height) {
        this.setPixelSizes(0, height);
        final FreeType.SizeMetrics fontMetrics = this.face.getSize().getMetrics();
        final int ascent = FreeType.toInt(fontMetrics.getAscender());
        final int descent = FreeType.toInt(fontMetrics.getDescender());
        return height * height / (ascent - descent);
    }
    
    public int scaleForPixelWidth(final int width, final int numChars) {
        final FreeType.SizeMetrics fontMetrics = this.face.getSize().getMetrics();
        final int advance = FreeType.toInt(fontMetrics.getMaxAdvance());
        final int ascent = FreeType.toInt(fontMetrics.getAscender());
        final int descent = FreeType.toInt(fontMetrics.getDescender());
        final int unscaledHeight = ascent - descent;
        final int height = unscaledHeight * width / (advance * numChars);
        this.setPixelSizes(0, height);
        return height;
    }
    
    public int scaleToFitSquare(final int width, final int height, final int numChars) {
        return Math.min(this.scaleForPixelHeight(height), this.scaleForPixelWidth(width, numChars));
    }
    
    public GlyphAndBitmap generateGlyphAndBitmap(final int c, final int size, final boolean flip) {
        this.setPixelSizes(0, size);
        final FreeType.SizeMetrics fontMetrics = this.face.getSize().getMetrics();
        final int baseline = FreeType.toInt(fontMetrics.getAscender());
        if (this.face.getCharIndex(c) == 0) {
            return null;
        }
        if (!this.loadChar(c)) {
            throw new ArcRuntimeException("Unable to load character!");
        }
        final FreeType.GlyphSlot slot = this.face.getGlyph();
        FreeType.Bitmap bitmap;
        if (this.bitmapped) {
            bitmap = slot.getBitmap();
        }
        else if (!slot.renderGlyph(FreeType.FT_RENDER_MODE_NORMAL)) {
            bitmap = null;
        }
        else {
            bitmap = slot.getBitmap();
        }
        final FreeType.GlyphMetrics metrics = slot.getMetrics();
        final Font.Glyph glyph = new Font.Glyph();
        if (bitmap != null) {
            glyph.width = bitmap.getWidth();
            glyph.height = bitmap.getRows();
        }
        else {
            glyph.width = 0;
            glyph.height = 0;
        }
        glyph.xoffset = slot.getBitmapLeft();
        glyph.yoffset = (flip ? (-slot.getBitmapTop() + baseline) : (-(glyph.height - slot.getBitmapTop()) - baseline));
        glyph.xadvance = FreeType.toInt(metrics.getHoriAdvance());
        glyph.srcX = 0;
        glyph.srcY = 0;
        glyph.id = c;
        final GlyphAndBitmap result = new GlyphAndBitmap();
        result.glyph = glyph;
        result.bitmap = bitmap;
        return result;
    }
    
    public FreeTypeFontData generateData(final int size) {
        final FreeTypeFontParameter parameter = new FreeTypeFontParameter();
        parameter.size = size;
        return this.generateData(parameter);
    }
    
    public FreeTypeFontData generateData(final FreeTypeFontParameter parameter) {
        return this.generateData(parameter, new FreeTypeFontData());
    }
    
    void setPixelSizes(final int pixelWidth, final int pixelHeight) {
        if (!this.bitmapped && !this.face.setPixelSizes(pixelWidth, pixelHeight)) {
            throw new ArcRuntimeException("Couldn't set size for font");
        }
    }
    
    public FreeTypeFontData generateData(FreeTypeFontParameter parameter, final FreeTypeFontData data) {
        parameter = ((parameter == null) ? new FreeTypeFontParameter() : parameter);
        final char[] characters = parameter.characters.toCharArray();
        final int charactersLength = characters.length;
        final boolean incremental = parameter.incremental;
        final int flags = this.getLoadingFlags(parameter);
        this.setPixelSizes(0, parameter.size);
        final FreeType.SizeMetrics fontMetrics = this.face.getSize().getMetrics();
        data.flipped = parameter.flip;
        data.ascent = (float)FreeType.toInt(fontMetrics.getAscender());
        data.descent = (float)FreeType.toInt(fontMetrics.getDescender());
        data.lineHeight = (float)FreeType.toInt(fontMetrics.getHeight());
        final float baseLine = data.ascent;
        if (this.bitmapped && data.lineHeight == 0.0f) {
            for (int c = 32; c < 32 + this.face.getNumGlyphs(); ++c) {
                if (this.loadChar(c, flags)) {
                    final int lh = FreeType.toInt(this.face.getGlyph().getMetrics().getHeight());
                    data.lineHeight = ((lh > data.lineHeight) ? ((float)lh) : data.lineHeight);
                }
            }
        }
        data.lineHeight += parameter.spaceY;
        if (this.loadChar(32, flags) || this.loadChar(108, flags)) {
            data.spaceXadvance = (float)FreeType.toInt(this.face.getGlyph().getMetrics().getHoriAdvance());
        }
        else {
            data.spaceXadvance = (float)this.face.getMaxAdvanceWidth();
        }
        for (final char xChar : data.xChars) {
            if (this.loadChar(xChar, flags)) {
                data.xHeight = (float)FreeType.toInt(this.face.getGlyph().getMetrics().getHeight());
                if (data.xHeight > 0.0f) {
                    break;
                }
            }
        }
        if (data.xHeight == 0.0f) {
            throw new ArcRuntimeException("No x-height character found in font");
        }
        for (final char capChar : data.capChars) {
            if (this.loadChar(capChar, flags)) {
                data.capHeight = (float)(FreeType.toInt(this.face.getGlyph().getMetrics().getHeight()) + Math.abs(parameter.shadowOffsetY));
                break;
            }
        }
        if (!this.bitmapped && data.capHeight == 1.0f) {
            throw new ArcRuntimeException("No cap character found in font");
        }
        data.ascent -= data.capHeight;
        data.down = -data.lineHeight;
        if (parameter.flip) {
            data.ascent = -data.ascent;
            data.down = -data.down;
        }
        boolean ownsAtlas = false;
        PixmapPacker packer = parameter.packer;
        if (packer == null) {
            int size;
            PixmapPacker.PackStrategy packStrategy;
            if (incremental) {
                size = FreeTypeFontGenerator.maxTextureSize;
                packStrategy = new PixmapPacker.GuillotineStrategy();
            }
            else {
                final int maxGlyphHeight = (int)Math.ceil(data.lineHeight);
                size = Mathf.nextPowerOfTwo((int)Math.sqrt(maxGlyphHeight * maxGlyphHeight * charactersLength));
                if (FreeTypeFontGenerator.maxTextureSize > 0) {
                    size = Math.min(size, FreeTypeFontGenerator.maxTextureSize);
                }
                packStrategy = new PixmapPacker.SkylineStrategy();
            }
            ownsAtlas = true;
            packer = new PixmapPacker(size, size, Pixmap.Format.rgba8888, 1, false, packStrategy);
            packer.setTransparentColor(parameter.color);
            packer.getTransparentColor().a = 0.0f;
            if (parameter.borderWidth > 0.0f) {
                packer.setTransparentColor(parameter.borderColor);
                packer.getTransparentColor().a = 0.0f;
            }
        }
        if (incremental) {
            data.glyphs = new Seq<Font.Glyph>(charactersLength + 32);
        }
        FreeType.Stroker stroker = null;
        if (parameter.borderWidth > 0.0f) {
            stroker = this.library.createStroker();
            stroker.set((int)(parameter.borderWidth * 64.0f), parameter.borderStraight ? FreeType.FT_STROKER_LINECAP_BUTT : FreeType.FT_STROKER_LINECAP_ROUND, parameter.borderStraight ? FreeType.FT_STROKER_LINEJOIN_MITER_FIXED : FreeType.FT_STROKER_LINEJOIN_ROUND, 0);
        }
        final int[] heights = new int[charactersLength];
        for (int i = 0; i < charactersLength; ++i) {
            final char c2 = characters[i];
            final int height = this.loadChar(c2, flags) ? FreeType.toInt(this.face.getGlyph().getMetrics().getHeight()) : 0;
            heights[i] = height;
            if (c2 == '\0') {
                final Font.Glyph missingGlyph = this.createGlyph('\0', data, parameter, stroker, baseLine, packer);
                if (missingGlyph != null && missingGlyph.width != 0 && missingGlyph.height != 0) {
                    data.setGlyph(0, missingGlyph);
                    data.missingGlyph = missingGlyph;
                    if (incremental) {
                        data.glyphs.add(missingGlyph);
                    }
                }
            }
        }
        int best;
        char tmpChar;
        for (int heightsCount = heights.length; heightsCount > 0; --heightsCount, heights[best] = heights[heightsCount], tmpChar = characters[best], characters[best] = characters[heightsCount], characters[heightsCount] = tmpChar) {
            best = 0;
            int maxHeight = heights[0];
            for (int j = 1; j < heightsCount; ++j) {
                final int height2 = heights[j];
                if (height2 > maxHeight) {
                    maxHeight = height2;
                    best = j;
                }
            }
            final char c3 = characters[best];
            if (data.getGlyph(c3) == null) {
                final Font.Glyph glyph = this.createGlyph(c3, data, parameter, stroker, baseLine, packer);
                if (glyph != null) {
                    data.setGlyph(c3, glyph);
                    if (incremental) {
                        data.glyphs.add(glyph);
                    }
                }
            }
        }
        if (stroker != null && !incremental) {
            stroker.dispose();
        }
        if (incremental) {
            data.generator = this;
            data.parameter = parameter;
            data.stroker = stroker;
            data.packer = packer;
        }
        final FreeTypeFontParameter freeTypeFontParameter = parameter;
        freeTypeFontParameter.kerning &= this.face.hasKerning();
        if (parameter.kerning) {
            for (int k = 0; k < charactersLength; ++k) {
                final char firstChar = characters[k];
                final Font.Glyph first = data.getGlyph(firstChar);
                if (first != null) {
                    final int firstIndex = this.face.getCharIndex(firstChar);
                    for (int ii = k; ii < charactersLength; ++ii) {
                        final char secondChar = characters[ii];
                        final Font.Glyph second = data.getGlyph(secondChar);
                        if (second != null) {
                            final int secondIndex = this.face.getCharIndex(secondChar);
                            int kerning = this.face.getKerning(firstIndex, secondIndex, 0);
                            if (kerning != 0) {
                                first.setKerning(secondChar, FreeType.toInt(kerning));
                            }
                            kerning = this.face.getKerning(secondIndex, firstIndex, 0);
                            if (kerning != 0) {
                                second.setKerning(firstChar, FreeType.toInt(kerning));
                            }
                        }
                    }
                }
            }
        }
        if (ownsAtlas) {
            packer.updateTextureRegions(data.regions = new Seq<TextureRegion>(), parameter.minFilter, parameter.magFilter, parameter.genMipMaps);
        }
        Font.Glyph spaceGlyph = data.getGlyph(' ');
        if (spaceGlyph == null) {
            spaceGlyph = new Font.Glyph();
            spaceGlyph.xadvance = (int)data.spaceXadvance + parameter.spaceX;
            data.setGlyph(spaceGlyph.id = 32, spaceGlyph);
        }
        if (spaceGlyph.width == 0) {
            spaceGlyph.width = (int)(spaceGlyph.xadvance + data.padRight);
        }
        return data;
    }
    
    Font.Glyph createGlyph(final char c, final FreeTypeFontData data, final FreeTypeFontParameter parameter, final FreeType.Stroker stroker, final float baseLine, final PixmapPacker packer) {
        final boolean missing = this.face.getCharIndex(c) == 0 && c != '\0';
        if (missing) {
            return null;
        }
        if (!this.loadChar(c, this.getLoadingFlags(parameter))) {
            return null;
        }
        final FreeType.GlyphSlot slot = this.face.getGlyph();
        FreeType.Glyph mainGlyph = slot.getGlyph();
        try {
            mainGlyph.toBitmap(parameter.mono ? FreeType.FT_RENDER_MODE_MONO : FreeType.FT_RENDER_MODE_NORMAL);
        }
        catch (ArcRuntimeException e) {
            mainGlyph.dispose();
            Log.infoTag("FreeTypeFontGenerator", "Couldn't render char: " + c);
            return null;
        }
        final FreeType.Bitmap mainBitmap = mainGlyph.getBitmap();
        Pixmap mainPixmap = mainBitmap.getPixmap(Pixmap.Format.rgba8888, parameter.color, parameter.gamma);
        if (mainBitmap.getWidth() != 0 && mainBitmap.getRows() != 0) {
            int offsetX = 0;
            int offsetY = 0;
            if (parameter.borderWidth > 0.0f) {
                final int top = mainGlyph.getTop();
                final int left = mainGlyph.getLeft();
                final FreeType.Glyph borderGlyph = slot.getGlyph();
                borderGlyph.strokeBorder(stroker, false);
                borderGlyph.toBitmap(parameter.mono ? FreeType.FT_RENDER_MODE_MONO : FreeType.FT_RENDER_MODE_NORMAL);
                offsetX = left - borderGlyph.getLeft();
                offsetY = -(top - borderGlyph.getTop());
                final FreeType.Bitmap borderBitmap = borderGlyph.getBitmap();
                final Pixmap borderPixmap = borderBitmap.getPixmap(Pixmap.Format.rgba8888, parameter.borderColor, parameter.borderGamma);
                for (int i = 0, n = parameter.renderCount; i < n; ++i) {
                    borderPixmap.drawPixmap(mainPixmap, offsetX, offsetY);
                }
                mainPixmap.dispose();
                mainGlyph.dispose();
                mainPixmap = borderPixmap;
                mainGlyph = borderGlyph;
            }
            if (parameter.shadowOffsetX != 0 || parameter.shadowOffsetY != 0) {
                final int mainW = mainPixmap.getWidth();
                final int mainH = mainPixmap.getHeight();
                final int shadowOffsetX = Math.max(parameter.shadowOffsetX, 0);
                final int shadowOffsetY = Math.max(parameter.shadowOffsetY, 0);
                final int shadowW = mainW + Math.abs(parameter.shadowOffsetX);
                final int shadowH = mainH + Math.abs(parameter.shadowOffsetY);
                final Pixmap shadowPixmap = new Pixmap(shadowW, shadowH, mainPixmap.getFormat());
                final Color shadowColor = parameter.shadowColor;
                final float a = shadowColor.a;
                if (a != 0.0f) {
                    final byte r = (byte)(shadowColor.r * 255.0f);
                    final byte g = (byte)(shadowColor.g * 255.0f);
                    final byte b = (byte)(shadowColor.b * 255.0f);
                    final ByteBuffer mainPixels = mainPixmap.getPixels();
                    final ByteBuffer shadowPixels = shadowPixmap.getPixels();
                    for (int y = 0; y < mainH; ++y) {
                        final int shadowRow = shadowW * (y + shadowOffsetY) + shadowOffsetX;
                        for (int x = 0; x < mainW; ++x) {
                            final int mainPixel = (mainW * y + x) * 4;
                            final byte mainA = mainPixels.get(mainPixel + 3);
                            if (mainA != 0) {
                                final int shadowPixel = (shadowRow + x) * 4;
                                shadowPixels.put(shadowPixel, r);
                                shadowPixels.put(shadowPixel + 1, g);
                                shadowPixels.put(shadowPixel + 2, b);
                                shadowPixels.put(shadowPixel + 3, (byte)((mainA & 0xFF) * a));
                            }
                        }
                    }
                }
                for (int j = 0, n2 = parameter.renderCount; j < n2; ++j) {
                    shadowPixmap.drawPixmap(mainPixmap, Math.max(-parameter.shadowOffsetX, 0), Math.max(-parameter.shadowOffsetY, 0));
                }
                mainPixmap.dispose();
                mainPixmap = shadowPixmap;
            }
            else if (parameter.borderWidth == 0.0f) {
                for (int k = 0, n3 = parameter.renderCount - 1; k < n3; ++k) {
                    mainPixmap.drawPixmap(mainPixmap, 0, 0);
                }
            }
            if (parameter.padTop > 0 || parameter.padLeft > 0 || parameter.padBottom > 0 || parameter.padRight > 0) {
                final Pixmap padPixmap = new Pixmap(mainPixmap.getWidth() + parameter.padLeft + parameter.padRight, mainPixmap.getHeight() + parameter.padTop + parameter.padBottom, mainPixmap.getFormat());
                padPixmap.drawPixmap(mainPixmap, parameter.padLeft, parameter.padTop);
                mainPixmap.dispose();
                mainPixmap = padPixmap;
            }
        }
        final FreeType.GlyphMetrics metrics = slot.getMetrics();
        final Font.Glyph glyph = new Font.Glyph();
        glyph.id = c;
        glyph.width = mainPixmap.getWidth();
        glyph.height = mainPixmap.getHeight();
        glyph.xoffset = mainGlyph.getLeft();
        if (parameter.flip) {
            glyph.yoffset = -mainGlyph.getTop() + (int)baseLine;
        }
        else {
            glyph.yoffset = -(glyph.height - mainGlyph.getTop()) - (int)baseLine;
        }
        glyph.xadvance = FreeType.toInt(metrics.getHoriAdvance()) + (int)parameter.borderWidth + parameter.spaceX;
        if (this.bitmapped) {
            mainPixmap.setColor(Color.clear);
            mainPixmap.fill();
            final ByteBuffer buf = mainBitmap.getBuffer();
            final int whiteIntBits = Color.white.toIntBits();
            final int clearIntBits = Color.clear.toIntBits();
            for (int h = 0; h < glyph.height; ++h) {
                final int idx = h * mainBitmap.getPitch();
                for (int w = 0; w < glyph.width + glyph.xoffset; ++w) {
                    final int bit = buf.get(idx + w / 8) >>> 7 - w % 8 & 0x1;
                    mainPixmap.draw(w, h, (bit == 1) ? whiteIntBits : clearIntBits);
                }
            }
        }
        final Rect rect = packer.pack(mainPixmap);
        glyph.page = packer.getPages().size - 1;
        glyph.srcX = (int)rect.x;
        glyph.srcY = (int)rect.y;
        if (parameter.incremental && data.regions != null && data.regions.size <= glyph.page) {
            packer.updateTextureRegions(data.regions, parameter.minFilter, parameter.magFilter, parameter.genMipMaps);
        }
        mainPixmap.dispose();
        mainGlyph.dispose();
        return glyph;
    }
    
    @Override
    public void dispose() {
        this.face.dispose();
        this.library.dispose();
    }
    
    static {
        FreeTypeFontGenerator.maxTextureSize = 1024;
    }
    
    public enum Hinting
    {
        none, 
        slight, 
        medium, 
        full, 
        autoSlight, 
        autoMedium, 
        autoFull;
    }
    
    public static class FreeTypeFontData extends Font.FontData implements Disposable
    {
        Seq<TextureRegion> regions;
        FreeTypeFontGenerator generator;
        FreeTypeFontParameter parameter;
        FreeType.Stroker stroker;
        PixmapPacker packer;
        Seq<Font.Glyph> glyphs;
        private boolean dirty;
        
        @Override
        public Font.Glyph getGlyph(final char ch) {
            Font.Glyph glyph = super.getGlyph(ch);
            if (glyph == null && this.generator != null) {
                this.generator.setPixelSizes(0, this.parameter.size);
                final float baseline = ((this.flipped ? (-this.ascent) : this.ascent) + this.capHeight) / this.scaleY;
                glyph = this.generator.createGlyph(ch, this, this.parameter, this.stroker, baseline, this.packer);
                if (glyph == null) {
                    return this.missingGlyph;
                }
                this.setGlyphRegion(glyph, this.regions.get(glyph.page));
                this.setGlyph(ch, glyph);
                this.glyphs.add(glyph);
                this.dirty = true;
                final FreeType.Face face = this.generator.face;
                if (this.parameter.kerning) {
                    final int glyphIndex = face.getCharIndex(ch);
                    for (int i = 0, n = this.glyphs.size; i < n; ++i) {
                        final Font.Glyph other = this.glyphs.get(i);
                        final int otherIndex = face.getCharIndex(other.id);
                        int kerning = face.getKerning(glyphIndex, otherIndex, 0);
                        if (kerning != 0) {
                            glyph.setKerning(other.id, FreeType.toInt(kerning));
                        }
                        kerning = face.getKerning(otherIndex, glyphIndex, 0);
                        if (kerning != 0) {
                            other.setKerning(ch, FreeType.toInt(kerning));
                        }
                    }
                }
            }
            return glyph;
        }
        
        @Override
        public void getGlyphs(final GlyphLayout.GlyphRun run, final CharSequence str, final int start, final int end, final Font.Glyph lastGlyph) {
            if (this.packer != null) {
                this.packer.setPackToTexture(true);
            }
            super.getGlyphs(run, str, start, end, lastGlyph);
            if (this.dirty) {
                this.dirty = false;
                this.packer.updateTextureRegions(this.regions, this.parameter.minFilter, this.parameter.magFilter, this.parameter.genMipMaps);
            }
        }
        
        @Override
        public void dispose() {
            if (this.stroker != null) {
                this.stroker.dispose();
            }
            if (this.packer != null) {
                this.packer.dispose();
            }
        }
    }
    
    public static class FreeTypeFontParameter
    {
        public int size;
        public boolean mono;
        public Hinting hinting;
        public Color color;
        public float gamma;
        public int renderCount;
        public float borderWidth;
        public Color borderColor;
        public boolean borderStraight;
        public float borderGamma;
        public int shadowOffsetX;
        public int shadowOffsetY;
        public Color shadowColor;
        public int spaceX;
        public int spaceY;
        public int padTop;
        public int padLeft;
        public int padBottom;
        public int padRight;
        public String characters;
        public boolean kerning;
        public PixmapPacker packer;
        public boolean flip;
        public boolean genMipMaps;
        public Texture.TextureFilter minFilter;
        public Texture.TextureFilter magFilter;
        public boolean incremental;
        
        public FreeTypeFontParameter() {
            this.size = 16;
            this.hinting = Hinting.autoMedium;
            this.color = Color.white;
            this.gamma = 1.8f;
            this.renderCount = 2;
            this.borderWidth = 0.0f;
            this.borderColor = Color.black;
            this.borderStraight = false;
            this.borderGamma = 1.8f;
            this.shadowOffsetX = 0;
            this.shadowOffsetY = 0;
            this.shadowColor = new Color(0.0f, 0.0f, 0.0f, 0.75f);
            this.characters = "\u0000ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890\"!`?'.,;:()[]{}<>|/@\\^$\u20ac-%+=#_&~*\u007f\u0080\u0081\u0082\u0083\u0084\u0085\u0086\u0087\u0088\u0089\u008a\u008b\u008c\u008d\u008e\u008f\u0090\u0091\u0092\u0093\u0094\u0095\u0096\u0097\u0098\u0099\u009a\u009b\u009c\u009d\u009e\u009f ¡¢£¤¥¦§¨©ª«¬\u00ad®¯°±²³´µ¶·¸¹º»¼½¾¿\u00c0\u00c1\u00c2\u00c3\u00c4\u00c5\u00c6\u00c7\u00c8\u00c9\u00ca\u00cb\u00cc\u00cd\u00ce\u00cf\u00d0\u00d1\u00d2\u00d3\u00d4\u00d5\u00d6\u00d7\u00d8\u00d9\u00da\u00db\u00dc\u00dd\u00de\u00df\u00e0\u00e1\u00e2\u00e3\u00e4\u00e5\u00e6\u00e7\u00e8\u00e9\u00ea\u00eb\u00ec\u00ed\u00ee\u00ef\u00f0\u00f1\u00f2\u00f3\u00f4\u00f5\u00f6\u00f7\u00f8\u00f9\u00fa\u00fb\u00fc\u00fd\u00fe\u00ff";
            this.kerning = true;
            this.packer = null;
            this.flip = false;
            this.genMipMaps = false;
            this.minFilter = Texture.TextureFilter.nearest;
            this.magFilter = Texture.TextureFilter.nearest;
        }
    }
    
    public class GlyphAndBitmap
    {
        public Font.Glyph glyph;
        public FreeType.Bitmap bitmap;
    }
}
