// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx;

import arc.util.Time;
import arc.graphics.g2d.Draw;
import arc.files.Fi;
import arc.Core;
import arc.graphics.gl.FrameBuffer;
import arc.graphics.Texture;
import arc.graphics.gl.Shader;
import arc.util.Disposable;

public abstract class FxFilter implements Disposable
{
    protected static final int u_texture0 = 0;
    protected static final int u_texture1 = 1;
    protected static final int u_texture2 = 2;
    protected static final int u_texture3 = 3;
    protected final Shader shader;
    protected Texture inputTexture;
    protected FrameBuffer outputBuffer;
    protected boolean disabled;
    protected boolean autobind;
    public float time;
    
    public FxFilter() {
        this(null);
    }
    
    public FxFilter(final String vert, final String frag) {
        this(compileShader(Core.files.classpath("shaders/" + vert + ".vert"), Core.files.classpath("shaders/" + frag + ".frag")));
    }
    
    public FxFilter(final Shader shader) {
        this.inputTexture = null;
        this.outputBuffer = null;
        this.disabled = false;
        this.autobind = false;
        this.time = 0.0f;
        this.shader = shader;
    }
    
    public static Shader compileShader(final Fi vertexFile, final Fi fragmentFile) {
        return compileShader(vertexFile, fragmentFile, "");
    }
    
    public static Shader compileShader(final Fi vertexFile, final Fi fragmentFile, final String defines) {
        return new Shader(defines + "\n" + vertexFile.readString(), defines + "\n" + fragmentFile.readString());
    }
    
    public FxFilter setInput(final Texture input) {
        this.inputTexture = input;
        return this;
    }
    
    public FxFilter setInput(final FrameBuffer input) {
        return this.setInput(input.getTexture());
    }
    
    public FxFilter setOutput(final FrameBuffer output) {
        this.outputBuffer = output;
        return this;
    }
    
    @Override
    public void dispose() {
        this.shader.dispose();
    }
    
    public void resize(final int width, final int height) {
    }
    
    public void rebind() {
        if (this.shader == null) {
            return;
        }
        this.shader.bind();
        this.setParams();
    }
    
    protected void setParams() {
        if (this.shader != null) {
            this.shader.setUniformi("u_texture0", 0);
        }
    }
    
    public void render() {
        final boolean manualBufferBind = this.outputBuffer != null && !this.outputBuffer.isBound();
        if (manualBufferBind) {
            this.outputBuffer.begin();
        }
        this.onBeforeRender();
        this.shader.bind();
        if (this.autobind) {
            this.setParams();
        }
        Draw.blit(this.shader);
        if (manualBufferBind) {
            this.outputBuffer.end();
        }
    }
    
    protected void onBeforeRender() {
        this.inputTexture.bind(0);
    }
    
    public void render(final FrameBuffer src, final FrameBuffer dst) {
        this.setInput(src).setOutput(dst).render();
    }
    
    public boolean isDisabled() {
        return this.disabled;
    }
    
    public void setDisabled(final boolean enabled) {
        this.disabled = enabled;
    }
    
    public void update() {
        this.time = Time.time;
    }
}
