// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx;

import arc.graphics.Gl;
import arc.graphics.g2d.Draw;
import arc.graphics.Color;
import arc.graphics.gl.FrameBuffer;
import arc.graphics.Texture;
import java.util.Iterator;
import arc.Core;
import arc.fx.util.PingPongBuffer;
import arc.graphics.Pixmap;
import arc.fx.util.FxBufferRenderer;
import arc.struct.Seq;
import arc.struct.ObjectIntMap;
import arc.util.Disposable;

public final class FxProcessor implements Disposable
{
    private final ObjectIntMap<FxFilter> priorities;
    private final Seq<FxFilter> effectsAll;
    private final Seq<FxFilter> effectsEnabled;
    private final FxBufferRenderer bufferRenderer;
    private final Pixmap.Format fboFormat;
    private final PingPongBuffer pingPongBuffer;
    private boolean disabled;
    private boolean capturing;
    private boolean hasCaptured;
    private boolean applyingEffects;
    private boolean blendingEnabled;
    private int width;
    private int height;
    
    public FxProcessor() {
        this(Pixmap.Format.rgba8888, Core.graphics.getBackBufferWidth(), Core.graphics.getBackBufferHeight());
    }
    
    public FxProcessor(final int w, final int h) {
        this(Pixmap.Format.rgba8888, w, h);
    }
    
    public FxProcessor(final Pixmap.Format fboFormat, final int bufferWidth, final int bufferHeight) {
        this(fboFormat, bufferWidth, bufferHeight, false, false);
    }
    
    public FxProcessor(final Pixmap.Format fboFormat, final int bufferWidth, final int bufferHeight, final boolean depth, final boolean stencil) {
        this.priorities = new ObjectIntMap<FxFilter>();
        this.effectsAll = new Seq<FxFilter>();
        this.effectsEnabled = new Seq<FxFilter>();
        this.bufferRenderer = new FxBufferRenderer();
        this.disabled = false;
        this.capturing = false;
        this.hasCaptured = false;
        this.applyingEffects = false;
        this.blendingEnabled = false;
        this.fboFormat = fboFormat;
        this.pingPongBuffer = new PingPongBuffer(fboFormat, bufferWidth, bufferHeight, depth, stencil);
        this.width = bufferWidth;
        this.height = bufferHeight;
    }
    
    @Override
    public void dispose() {
        this.pingPongBuffer.dispose();
    }
    
    public void resize(final int width, final int height) {
        if (this.width != width || this.height != height) {
            this.width = width;
            this.height = height;
            this.pingPongBuffer.resize(width, height);
            for (final FxFilter filter : this.effectsAll) {
                filter.resize(width, height);
                filter.rebind();
            }
        }
    }
    
    public void rebind() {
        this.bufferRenderer.rebind();
        for (final FxFilter filter : this.effectsAll) {
            filter.rebind();
        }
    }
    
    public int getWidth() {
        return this.width;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public boolean isDisabled() {
        return this.disabled;
    }
    
    public void setDisabled(final boolean disabled) {
        this.disabled = disabled;
    }
    
    public boolean isBlendingEnabled() {
        return this.blendingEnabled;
    }
    
    public void setBlendingEnabled(final boolean blendingEnabled) {
        this.blendingEnabled = blendingEnabled;
    }
    
    public Pixmap.Format getFramebufferFormat() {
        return this.fboFormat;
    }
    
    public void setBufferTextureParams(final Texture.TextureWrap u, final Texture.TextureWrap v, final Texture.TextureFilter min, final Texture.TextureFilter mag) {
        this.pingPongBuffer.setTextureParams(u, v, min, mag);
    }
    
    public void setTextureFilter(final Texture.TextureFilter filter) {
        this.setBufferTextureParams(Texture.TextureWrap.clampToEdge, Texture.TextureWrap.clampToEdge, filter, filter);
    }
    
    public boolean isCapturing() {
        return this.capturing;
    }
    
    public boolean isApplyingEffects() {
        return this.applyingEffects;
    }
    
    public boolean hasResult() {
        return this.hasCaptured;
    }
    
    public FrameBuffer getResultBuffer() {
        return this.pingPongBuffer.getDstBuffer();
    }
    
    public PingPongBuffer getPingPongBuffer() {
        return this.pingPongBuffer;
    }
    
    public boolean hasEnabledEffects() {
        return this.effectsAll.contains(fx -> !fx.isDisabled());
    }
    
    public void addEffect(final FxFilter effect) {
        this.addEffect(effect, 0);
    }
    
    public void addEffect(final FxFilter effect, final int priority) {
        this.effectsAll.add(effect);
        this.priorities.put(effect, priority);
        this.effectsAll.sort(e -> (float)this.priorities.get(effect, 0));
        effect.resize(this.width, this.height);
        effect.rebind();
    }
    
    public void removeEffect(final FxFilter effect) {
        this.effectsAll.remove(effect);
    }
    
    public void removeAllEffects() {
        this.effectsAll.clear();
    }
    
    public void setEffectPriority(final FxFilter effect, final int priority) {
        this.priorities.put(effect, priority);
        this.effectsAll.sort(e -> (float)this.priorities.get(effect, 0));
    }
    
    public void clear() {
        this.clear(Color.clear);
    }
    
    public void clear(final Color color) {
        if (this.capturing) {
            throw new IllegalStateException("Cannot clean up buffers when capturing.");
        }
        if (this.applyingEffects) {
            throw new IllegalStateException("Cannot clean up buffers when applying effects.");
        }
        this.pingPongBuffer.clear(color);
        this.hasCaptured = false;
    }
    
    public boolean begin() {
        if (this.applyingEffects) {
            throw new IllegalStateException("You cannot capture when you're applying the effects.");
        }
        if (this.disabled) {
            return false;
        }
        if (this.capturing) {
            return false;
        }
        Draw.flush();
        this.capturing = true;
        this.pingPongBuffer.begin();
        return true;
    }
    
    public boolean end() {
        if (!this.capturing) {
            return false;
        }
        Draw.flush();
        this.hasCaptured = true;
        this.capturing = false;
        this.pingPongBuffer.end();
        return true;
    }
    
    public void applyEffects() {
        if (this.capturing) {
            throw new IllegalStateException("You should call VfxManager.endCapture() before applying the effects.");
        }
        if (this.disabled) {
            return;
        }
        if (!this.hasCaptured) {
            return;
        }
        this.effectsAll.each(FxFilter::update);
        final Seq<FxFilter> effectChain = this.effectsEnabled.selectFrom(this.effectsAll, e -> !e.isDisabled());
        this.applyingEffects = true;
        final int count = effectChain.size;
        if (count > 0) {
            if (this.blendingEnabled) {
                Gl.enable(3042);
            }
            else {
                Gl.disable(3042);
            }
            Gl.disable(2884);
            Gl.disable(2929);
            this.pingPongBuffer.swap();
            this.pingPongBuffer.begin();
            for (int i = 0; i < count; ++i) {
                final FxFilter effect = effectChain.get(i);
                effect.render(this.pingPongBuffer.getSrcBuffer(), this.pingPongBuffer.getDstBuffer());
                if (i < count - 1) {
                    this.pingPongBuffer.swap();
                }
            }
            this.pingPongBuffer.end();
            Gl.activeTexture(33984);
            if (this.blendingEnabled) {
                Gl.disable(3042);
            }
        }
        this.applyingEffects = false;
    }
    
    public void render() {
        if (this.capturing) {
            throw new IllegalStateException("You should call VfxManager.endCapture() before rendering the result.");
        }
        if (this.disabled) {
            return;
        }
        if (!this.hasCaptured) {
            return;
        }
        if (this.blendingEnabled) {
            Gl.enable(3042);
        }
        else {
            Gl.disable(3042);
        }
        this.bufferRenderer.renderToScreen(this.pingPongBuffer.getDstBuffer());
        if (this.blendingEnabled) {
            Gl.disable(3042);
        }
    }
    
    public void render(final int x, final int y, final int width, final int height) {
        if (this.capturing) {
            throw new IllegalStateException("You should call VfxManager.endCapture() before rendering the result.");
        }
        if (this.disabled) {
            return;
        }
        if (!this.hasCaptured) {
            return;
        }
        if (this.blendingEnabled) {
            Gl.enable(3042);
        }
        this.bufferRenderer.renderToScreen(this.pingPongBuffer.getDstBuffer(), x, y, width, height);
        if (this.blendingEnabled) {
            Gl.disable(3042);
        }
    }
    
    public void render(final FrameBuffer output) {
        if (this.capturing) {
            throw new IllegalStateException("You should call VfxManager.endCapture() before rendering the result.");
        }
        if (this.disabled) {
            return;
        }
        if (!this.hasCaptured) {
            return;
        }
        if (this.blendingEnabled) {
            Gl.enable(3042);
        }
        this.bufferRenderer.renderToFbo(this.pingPongBuffer.getDstBuffer(), output);
        if (this.blendingEnabled) {
            Gl.disable(3042);
        }
    }
}
