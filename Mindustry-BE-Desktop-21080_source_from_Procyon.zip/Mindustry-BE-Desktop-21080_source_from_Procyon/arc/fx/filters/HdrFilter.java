// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.fx.FxFilter;

public final class HdrFilter extends FxFilter
{
    public float exposure;
    public float gamma;
    
    public HdrFilter() {
        this(3.0f, 2.2f);
    }
    
    public HdrFilter(final float exposure, final float gamma) {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/hdr.frag")));
        this.exposure = exposure;
        this.gamma = gamma;
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("u_exposure", this.exposure);
        this.shader.setUniformf("u_gamma", this.gamma);
    }
}
