// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.fx.FxFilter;

public final class RadialDistortionFilter extends FxFilter
{
    public float zoom;
    public float distortion;
    
    public RadialDistortionFilter() {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/radial-distortion.frag")));
        this.zoom = 1.0f;
        this.distortion = 0.3f;
        this.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("distortion", this.distortion);
        this.shader.setUniformf("zoom", this.zoom);
    }
}
