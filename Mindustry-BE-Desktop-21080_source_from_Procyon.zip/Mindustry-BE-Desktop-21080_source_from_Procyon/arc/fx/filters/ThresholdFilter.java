// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.fx.FxFilter;

public class ThresholdFilter extends FxFilter
{
    public float gamma;
    
    public ThresholdFilter() {
        super("screenspace", "threshold");
        this.gamma = 0.0f;
        this.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("treshold", this.gamma);
        this.shader.setUniformf("tresholdInvTx", 1.0f / (1.0f - this.gamma));
    }
}
