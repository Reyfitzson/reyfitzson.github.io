// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.fx.FxFilter;

public class NoiseFilter extends FxFilter
{
    public float amount;
    public float speed;
    
    public NoiseFilter(final float amount, final float speed) {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/noise.frag")));
        this.amount = amount;
        this.speed = speed;
        this.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("u_amount", this.amount);
        this.shader.setUniformf("u_speed", this.speed);
        this.shader.setUniformf("u_time", this.time);
    }
}
