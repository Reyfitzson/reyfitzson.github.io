// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.fx.FxFilter;

public class FisheyeDistortionFilter extends FxFilter
{
    public FisheyeDistortionFilter() {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/fisheye.frag")));
    }
}
