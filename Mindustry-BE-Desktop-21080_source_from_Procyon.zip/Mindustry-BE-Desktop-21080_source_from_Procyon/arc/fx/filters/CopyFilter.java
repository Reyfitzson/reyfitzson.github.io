// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.fx.FxFilter;

public class CopyFilter extends FxFilter
{
    public CopyFilter() {
        super("screenspace", "copy");
    }
}
