// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.math.geom.Vec2;
import arc.fx.FxFilter;

public final class NfaaFilter extends FxFilter
{
    private final Vec2 viewportInverse;
    
    public NfaaFilter() {
        this(false);
    }
    
    public NfaaFilter(final boolean supportAlpha) {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/nfaa.frag"), supportAlpha ? "#define SUPPORT_ALPHA" : ""));
        this.viewportInverse = new Vec2();
    }
    
    @Override
    public void resize(final int width, final int height) {
        this.viewportInverse.set(1.0f / width, 1.0f / height);
        this.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("u_viewportInverse", this.viewportInverse);
    }
}
