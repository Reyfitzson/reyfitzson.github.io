// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.graphics.gl.FrameBuffer;
import arc.Application;
import arc.graphics.Pixmap;
import arc.Core;
import arc.graphics.Texture;
import arc.fx.util.FxBufferQueue;
import arc.fx.FxFilter;

public class MotionBlurFilter extends FxFilter
{
    private final CopyFilter copyFilter;
    private final FxBufferQueue localBuffer;
    public float blurOpacity;
    public Texture lastFrameTex;
    
    public MotionBlurFilter(final BlurFunction blurFunction) {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/" + blurFunction.fragmentShaderName + ".frag")));
        this.blurOpacity = 0.9f;
        this.copyFilter = new CopyFilter();
        this.localBuffer = new FxBufferQueue(Pixmap.Format.rgba8888, (Core.app.getType() == Application.ApplicationType.web) ? 2 : 1);
        this.rebind();
    }
    
    @Override
    public void resize(final int width, final int height) {
        this.copyFilter.resize(width, height);
        this.localBuffer.resize(width, height);
    }
    
    @Override
    public void dispose() {
        super.dispose();
        this.copyFilter.dispose();
        this.localBuffer.dispose();
    }
    
    @Override
    public void rebind() {
        super.rebind();
        this.copyFilter.rebind();
        this.localBuffer.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        if (this.lastFrameTex != null) {
            this.shader.setUniformi("u_texture1", 1);
        }
        this.shader.setUniformf("u_blurOpacity", this.blurOpacity);
    }
    
    @Override
    protected void onBeforeRender() {
        this.inputTexture.bind(0);
        if (this.lastFrameTex != null) {
            this.lastFrameTex.bind(1);
        }
    }
    
    @Override
    public void render(final FrameBuffer src, final FrameBuffer dst) {
        final FrameBuffer prevFrame = this.localBuffer.changeToNext();
        this.setInput(src).setOutput(prevFrame).render();
        this.lastFrameTex = prevFrame.getTexture();
        this.copyFilter.setInput(prevFrame).setOutput(dst).render();
    }
    
    public enum BlurFunction
    {
        MAX("motionblur-max"), 
        MIX("motionblur-mix");
        
        final String fragmentShaderName;
        
        private BlurFunction(final String fragmentShaderName) {
            this.fragmentShaderName = fragmentShaderName;
        }
    }
}
