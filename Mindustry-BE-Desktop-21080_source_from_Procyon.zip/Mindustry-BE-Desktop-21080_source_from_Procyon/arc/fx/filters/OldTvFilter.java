// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.math.geom.Vec2;
import arc.fx.FxFilter;

public class OldTvFilter extends FxFilter
{
    private final Vec2 resolution;
    
    public OldTvFilter() {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/old-tv.frag")));
        this.resolution = new Vec2();
        this.rebind();
    }
    
    @Override
    public void resize(final int width, final int height) {
        this.resolution.set((float)width, (float)height);
        this.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("u_resolution", this.resolution);
        this.shader.setUniformf("u_time", this.time);
    }
}
