// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.util.Tmp;
import arc.Core;
import arc.math.geom.Vec2;
import arc.fx.FxFilter;

public class CrtFilter extends FxFilter
{
    public final Vec2 viewportSize;
    public SizeSource sizeSource;
    
    public CrtFilter() {
        this(LineStyle.HORIZONTAL_HARD, 1.3f, 0.5f);
    }
    
    public CrtFilter(final LineStyle lineStyle, final float brightnessMin, final float brightnessMax) {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/crt.frag"), "#define SL_BRIGHTNESS_MIN " + brightnessMin + "\n#define SL_BRIGHTNESS_MAX " + brightnessMax + "\n#define LINE_TYPE " + lineStyle.ordinal()));
        this.viewportSize = new Vec2();
        this.sizeSource = SizeSource.VIEWPORT;
        this.rebind();
    }
    
    @Override
    public void resize(final int width, final int height) {
        this.viewportSize.set((float)width, (float)height);
        this.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("u_resolution", (this.sizeSource == SizeSource.SCREEN) ? Tmp.v1.set((float)Core.graphics.getWidth(), (float)Core.graphics.getHeight()) : this.viewportSize);
    }
    
    public enum SizeSource
    {
        VIEWPORT, 
        SCREEN;
    }
    
    public enum LineStyle
    {
        CROSSLINE_HARD, 
        VERTICAL_HARD, 
        HORIZONTAL_HARD, 
        VERTICAL_SMOOTH, 
        HORIZONTAL_SMOOTH;
    }
}
