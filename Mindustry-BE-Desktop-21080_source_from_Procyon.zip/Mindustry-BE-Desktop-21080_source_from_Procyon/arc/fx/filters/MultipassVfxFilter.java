// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.fx.util.PingPongBuffer;
import arc.util.Disposable;

public abstract class MultipassVfxFilter implements Disposable
{
    public void resize(final int width, final int height) {
    }
    
    public abstract void setParams();
    
    public abstract void render(final PingPongBuffer p0);
}
