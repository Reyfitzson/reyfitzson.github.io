// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.graphics.gl.FrameBuffer;
import arc.Core;
import arc.graphics.Texture;
import arc.fx.FxFilter;

public final class MixFilter extends FxFilter
{
    private Texture inputTexture2;
    public float mix;
    
    public MixFilter() {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/mix.frag")));
        this.inputTexture2 = null;
        this.mix = 0.5f;
        this.rebind();
    }
    
    public MixFilter setInput(final FrameBuffer buffer1, final FrameBuffer buffer2) {
        this.inputTexture = buffer1.getTexture();
        this.inputTexture2 = buffer2.getTexture();
        return this;
    }
    
    public MixFilter setInput(final Texture texture1, final Texture texture2) {
        this.inputTexture = texture1;
        this.inputTexture2 = texture2;
        return this;
    }
    
    @Override
    public MixFilter setInput(final FrameBuffer input) {
        throw new UnsupportedOperationException("Use #setInput(FboWrapper, FboWrapper)} instead.");
    }
    
    @Override
    public MixFilter setInput(final Texture input) {
        throw new UnsupportedOperationException("Use #setInput(Texture, Texture)} instead.");
    }
    
    @Override
    public void resize(final int width, final int height) {
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformi("u_texture1", 1);
        this.shader.setUniformf("u_mix", this.mix);
    }
    
    @Override
    protected void onBeforeRender() {
        this.inputTexture.bind(0);
        this.inputTexture2.bind(1);
    }
}
