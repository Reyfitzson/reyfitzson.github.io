// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.util.Time;
import arc.Core;
import arc.fx.FxFilter;

public class FilmGrainFilter extends FxFilter
{
    public float seed;
    
    public FilmGrainFilter() {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/film-grain.frag")));
        this.seed = 0.0f;
        this.rebind();
    }
    
    public void setSeed(final float seed) {
        this.seed = seed;
        this.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("u_seed", this.seed);
    }
    
    @Override
    public void update() {
        this.time = (this.time + Time.delta / 60.0f) % 1.0f;
        this.seed = this.time;
    }
}
