// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.graphics.Texture;
import arc.fx.FxFilter;

public final class VignettingFilter extends FxFilter
{
    private Texture lutTexture;
    public float vignetteX;
    public float vignetteY;
    public float centerX;
    public float centerY;
    public float intensity;
    public float saturation;
    public float saturationMul;
    public boolean saturationEnabled;
    public boolean lutEnabled;
    public float lutIntensity;
    public int lutIndex1;
    public int lutIndex2;
    public float lutStep;
    public float lutStepOffset;
    public float lutIndexOffset;
    
    public VignettingFilter(final boolean controlSaturation) {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/vignetting.frag"), controlSaturation ? "#define CONTROL_SATURATION\n#define ENABLE_GRADIENT_MAPPING" : "#define ENABLE_GRADIENT_MAPPING"));
        this.lutTexture = null;
        this.vignetteX = 0.8f;
        this.vignetteY = 0.25f;
        this.centerX = 0.5f;
        this.centerY = 0.5f;
        this.intensity = 1.0f;
        this.saturation = 0.0f;
        this.saturationMul = 0.0f;
        this.lutEnabled = false;
        this.lutIntensity = 1.0f;
        this.lutIndex1 = -1;
        this.lutIndex2 = -1;
        this.lutIndexOffset = 0.0f;
        this.saturationEnabled = controlSaturation;
        this.rebind();
    }
    
    public void setLut(final Texture texture) {
        this.lutTexture = texture;
        this.lutEnabled = (this.lutTexture != null);
        if (this.lutEnabled) {
            this.lutStep = 1.0f / texture.height;
            this.lutStepOffset = this.lutStep / 2.0f;
        }
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformi("u_lutIndex1", this.lutIndex1);
        this.shader.setUniformi("u_lutIndex2", this.lutIndex2);
        this.shader.setUniformf("u_lutIndexOffset", this.lutIndexOffset);
        this.shader.setUniformi("u_texture1", 1);
        this.shader.setUniformf("u_lutIntensity", this.lutIntensity);
        this.shader.setUniformf("u_lutStep", this.lutStep);
        this.shader.setUniformf("u_lutStepOffset", this.lutStepOffset);
        if (this.saturationEnabled) {
            this.shader.setUniformf("u_saturation", this.saturation);
            this.shader.setUniformf("u_saturationMul", this.saturationMul);
        }
        this.shader.setUniformf("u_vignetteIntensity", this.intensity);
        this.shader.setUniformf("u_vignetteX", this.vignetteX);
        this.shader.setUniformf("u_vignetteY", this.vignetteY);
        this.shader.setUniformf("u_centerX", this.centerX);
        this.shader.setUniformf("u_centerY", this.centerY);
    }
    
    @Override
    protected void onBeforeRender() {
        this.inputTexture.bind(0);
        if (this.lutEnabled) {
            this.lutTexture.bind(1);
        }
    }
}
