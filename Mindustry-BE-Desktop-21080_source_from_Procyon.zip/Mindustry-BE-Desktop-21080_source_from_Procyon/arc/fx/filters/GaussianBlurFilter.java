// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.fx.util.PingPongBuffer;

public class GaussianBlurFilter extends MultipassVfxFilter
{
    private BlurType type;
    private float amount;
    private int passes;
    private float invWidth;
    private float invHeight;
    private Convolve2dFilter convolve;
    
    public GaussianBlurFilter() {
        this(BlurType.gaussian5x5);
    }
    
    public GaussianBlurFilter(final BlurType blurType) {
        this.amount = 1.0f;
        this.passes = 1;
        this.setType(blurType);
    }
    
    @Override
    public void dispose() {
        this.convolve.dispose();
    }
    
    @Override
    public void resize(final int width, final int height) {
        this.invWidth = 1.0f / width;
        this.invHeight = 1.0f / height;
        this.convolve.resize(width, height);
        this.computeBlurWeightings();
    }
    
    @Override
    public void setParams() {
        this.convolve.setParams();
        this.computeBlurWeightings();
    }
    
    @Override
    public void render(final PingPongBuffer buffer) {
        for (int i = 0; i < this.passes; ++i) {
            this.convolve.render(buffer);
            if (i < this.passes - 1) {
                buffer.swap();
            }
        }
    }
    
    public BlurType getType() {
        return this.type;
    }
    
    public void setType(final BlurType type) {
        if (type == null) {
            throw new IllegalArgumentException("Blur type cannot be null.");
        }
        if (this.type != type) {
            this.type = type;
            if (this.convolve != null) {
                this.convolve.dispose();
            }
            this.convolve = new Convolve2dFilter(this.type.tap.radius);
            this.computeBlurWeightings();
        }
    }
    
    public float getAmount() {
        return this.amount;
    }
    
    public void setAmount(final float amount) {
        this.amount = amount;
        this.computeBlurWeightings();
    }
    
    public int getPasses() {
        return this.passes;
    }
    
    public void setPasses(final int passes) {
        this.passes = passes;
    }
    
    private void computeBlurWeightings() {
        boolean hasData = true;
        final float[] outWeights = this.convolve.weights;
        final float[] outOffsetsH = this.convolve.offsetsHor;
        final float[] outOffsetsV = this.convolve.offsetsVert;
        final float dx = this.invWidth;
        final float dy = this.invHeight;
        switch (this.type) {
            case gaussian3x3:
            case gaussian5x5: {
                this.computeKernel(this.type.tap.radius, this.amount, outWeights);
                this.computeOffsets(this.type.tap.radius, this.invWidth, this.invHeight, outOffsetsH, outOffsetsV);
                break;
            }
            case gaussian3x3b: {
                outWeights[0] = 0.352941f;
                outWeights[1] = 0.294118f;
                outWeights[2] = 0.352941f;
                outOffsetsH[0] = -1.33333f;
                outOffsetsH[1] = 0.0f;
                outOffsetsH[3] = (outOffsetsH[2] = 0.0f);
                outOffsetsH[4] = 1.33333f;
                outOffsetsV[0] = (outOffsetsH[5] = 0.0f);
                outOffsetsV[1] = -1.33333f;
                outOffsetsV[2] = 0.0f;
                outOffsetsV[4] = (outOffsetsV[3] = 0.0f);
                outOffsetsV[5] = 1.33333f;
                for (int i = 0; i < this.convolve.length * 2; ++i) {
                    final float[] array = outOffsetsH;
                    final int n = i;
                    array[n] *= dx;
                    final float[] array2 = outOffsetsV;
                    final int n2 = i;
                    array2[n2] *= dy;
                }
                break;
            }
            case gaussian5x5b: {
                outWeights[0] = 0.0702703f;
                outWeights[1] = 0.316216f;
                outWeights[2] = 0.227027f;
                outWeights[3] = 0.316216f;
                outWeights[4] = 0.0702703f;
                outOffsetsH[0] = -3.23077f;
                outOffsetsH[1] = 0.0f;
                outOffsetsH[2] = -1.38462f;
                outOffsetsH[3] = 0.0f;
                outOffsetsH[5] = (outOffsetsH[4] = 0.0f);
                outOffsetsH[6] = 1.38462f;
                outOffsetsH[7] = 0.0f;
                outOffsetsH[8] = 3.23077f;
                outOffsetsV[0] = (outOffsetsH[9] = 0.0f);
                outOffsetsV[1] = -3.23077f;
                outOffsetsV[2] = 0.0f;
                outOffsetsV[3] = -1.38462f;
                outOffsetsV[4] = 0.0f;
                outOffsetsV[6] = (outOffsetsV[5] = 0.0f);
                outOffsetsV[7] = 1.38462f;
                outOffsetsV[8] = 0.0f;
                outOffsetsV[9] = 3.23077f;
                for (int i = 0; i < this.convolve.length * 2; ++i) {
                    final float[] array3 = outOffsetsH;
                    final int n3 = i;
                    array3[n3] *= dx;
                    final float[] array4 = outOffsetsV;
                    final int n4 = i;
                    array4[n4] *= dy;
                }
                break;
            }
            default: {
                hasData = false;
                break;
            }
        }
        if (hasData) {
            this.convolve.setParams();
        }
    }
    
    private void computeKernel(final int blurRadius, final float blurAmount, final float[] outKernel) {
        final int radius = blurRadius;
        final float sigma = blurAmount;
        final float twoSigmaSquare = 2.0f * sigma * sigma;
        final float sigmaRoot = (float)Math.sqrt(twoSigmaSquare * 3.141592653589793);
        float total = 0.0f;
        float distance = 0.0f;
        int index = 0;
        for (int i = -radius; i <= radius; ++i) {
            distance = (float)(i * i);
            index = i + radius;
            outKernel[index] = (float)Math.exp(-distance / twoSigmaSquare) / sigmaRoot;
            total += outKernel[index];
        }
        for (int size = radius * 2 + 1, j = 0; j < size; ++j) {
            final int n = j;
            outKernel[n] /= total;
        }
    }
    
    private void computeOffsets(final int blurRadius, final float dx, final float dy, final float[] outOffsetH, final float[] outOffsetV) {
        final int radius = blurRadius;
        final int X = 0;
        final int Y = 1;
        for (int i = -radius, j = 0; i <= radius; ++i, j += 2) {
            outOffsetH[j + 0] = i * dx;
            outOffsetV[j + 0] = (outOffsetH[j + 1] = 0.0f);
            outOffsetV[j + 1] = i * dy;
        }
    }
    
    private enum Tap
    {
        tap3x3(1), 
        tap5x5(2);
        
        public final int radius;
        
        private Tap(final int radius) {
            this.radius = radius;
        }
    }
    
    public enum BlurType
    {
        gaussian3x3(Tap.tap3x3), 
        gaussian3x3b(Tap.tap3x3), 
        gaussian5x5(Tap.tap5x5), 
        gaussian5x5b(Tap.tap5x5);
        
        public final Tap tap;
        
        private BlurType(final Tap tap) {
            this.tap = tap;
        }
    }
}
