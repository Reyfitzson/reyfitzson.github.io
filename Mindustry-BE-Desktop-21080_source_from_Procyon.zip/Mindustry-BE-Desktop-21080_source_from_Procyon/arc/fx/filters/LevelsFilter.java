// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.fx.FxFilter;

public class LevelsFilter extends FxFilter
{
    public float brightness;
    public float contrast;
    public float saturation;
    public float hue;
    public float gamma;
    
    public LevelsFilter() {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/levels.frag")));
        this.brightness = 0.0f;
        this.contrast = 1.0f;
        this.saturation = 1.0f;
        this.hue = 1.0f;
        this.gamma = 1.0f;
        this.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("u_brightness", this.brightness);
        this.shader.setUniformf("u_contrast", this.contrast);
        this.shader.setUniformf("u_saturation", this.saturation);
        this.shader.setUniformf("u_hue", this.hue);
        this.shader.setUniformf("u_gamma", this.gamma);
    }
}
