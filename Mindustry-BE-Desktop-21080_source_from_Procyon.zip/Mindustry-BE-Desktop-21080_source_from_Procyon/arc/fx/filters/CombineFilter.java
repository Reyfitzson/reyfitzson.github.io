// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.graphics.gl.FrameBuffer;
import arc.graphics.Texture;
import arc.fx.FxFilter;

public final class CombineFilter extends FxFilter
{
    public float src1int;
    public float src1sat;
    public float src2int;
    public float src2sat;
    public Texture inputTexture2;
    
    public CombineFilter() {
        super("screenspace", "combine");
        this.src1int = 1.0f;
        this.src1sat = 1.0f;
        this.src2int = 1.0f;
        this.src2sat = 1.0f;
        this.inputTexture2 = null;
        this.rebind();
    }
    
    public CombineFilter setInput(final FrameBuffer buffer1, final FrameBuffer buffer2) {
        this.inputTexture = buffer1.getTexture();
        this.inputTexture2 = buffer2.getTexture();
        return this;
    }
    
    public CombineFilter setInput(final Texture texture1, final Texture texture2) {
        this.inputTexture = texture1;
        this.inputTexture2 = texture2;
        return this;
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformi("u_texture1", 1);
        this.shader.setUniformf("u_src1Intensity", this.src1int);
        this.shader.setUniformf("u_src2Intensity", this.src2int);
        this.shader.setUniformf("u_src1Saturation", this.src1sat);
        this.shader.setUniformf("u_src2Saturation", this.src2sat);
    }
    
    @Override
    protected void onBeforeRender() {
        this.inputTexture.bind(0);
        this.inputTexture2.bind(1);
    }
}
