// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.fx.FxFilter;

public final class RadialBlurFilter extends FxFilter
{
    public final int passes;
    public float strength;
    public float originX;
    public float originY;
    public float zoom;
    
    public RadialBlurFilter(final int passes) {
        super(FxFilter.compileShader(Core.files.classpath("shaders/radial-blur.vert"), Core.files.classpath("shaders/radial-blur.frag"), "#define PASSES " + passes));
        this.strength = 0.2f;
        this.originX = 0.5f;
        this.originY = 0.5f;
        this.zoom = 1.0f;
        this.passes = passes;
        this.rebind();
    }
    
    public float getOriginX() {
        return this.originX;
    }
    
    public float getOriginY() {
        return this.originY;
    }
    
    public void setOrigin(final int align) {
        float originX;
        if ((align & 0x8) != 0x0) {
            originX = 0.0f;
        }
        else if ((align & 0x10) != 0x0) {
            originX = 1.0f;
        }
        else {
            originX = 0.5f;
        }
        float originY;
        if ((align & 0x4) != 0x0) {
            originY = 0.0f;
        }
        else if ((align & 0x2) != 0x0) {
            originY = 1.0f;
        }
        else {
            originY = 0.5f;
        }
        this.setOrigin(originX, originY);
    }
    
    public void setOrigin(final float originX, final float originY) {
        this.originX = originX;
        this.originY = originY;
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("u_blurDiv", this.strength / this.passes);
        this.shader.setUniformf("u_offsetX", this.originX);
        this.shader.setUniformf("u_offsetY", this.originY);
        this.shader.setUniformf("u_zoom", this.zoom);
    }
}
