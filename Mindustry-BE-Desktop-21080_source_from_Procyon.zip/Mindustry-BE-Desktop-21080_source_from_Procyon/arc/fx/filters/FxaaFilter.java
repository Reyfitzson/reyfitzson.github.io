// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.math.geom.Vec2;
import arc.fx.FxFilter;

public final class FxaaFilter extends FxFilter
{
    public final Vec2 viewportInverse;
    public float fxaaReduceMin;
    public float fxaaReduceMul;
    public float fxaaSpanMax;
    
    public FxaaFilter() {
        this(0.0078125f, 0.125f, 8.0f, true);
    }
    
    public FxaaFilter(final float fxaaReduceMin, final float fxaaReduceMul, final float fxaaSpanMax, final boolean supportAlpha) {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/fxaa.frag"), supportAlpha ? "#define SUPPORT_ALPHA" : ""));
        this.viewportInverse = new Vec2();
        this.fxaaReduceMin = fxaaReduceMin;
        this.fxaaReduceMul = fxaaReduceMul;
        this.fxaaSpanMax = fxaaSpanMax;
        this.rebind();
    }
    
    @Override
    public void resize(final int width, final int height) {
        this.viewportInverse.set(1.0f / width, 1.0f / height);
        this.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("u_viewportInverse", this.viewportInverse);
        this.shader.setUniformf("u_fxaaReduceMin", this.fxaaReduceMin);
        this.shader.setUniformf("u_fxaaReduceMul", this.fxaaReduceMul);
        this.shader.setUniformf("u_fxaaSpanMax", this.fxaaSpanMax);
    }
}
