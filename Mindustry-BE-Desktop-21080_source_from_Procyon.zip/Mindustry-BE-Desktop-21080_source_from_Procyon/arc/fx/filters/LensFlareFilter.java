// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.graphics.Color;
import arc.math.geom.Vec2;
import arc.fx.FxFilter;

public final class LensFlareFilter extends FxFilter
{
    private final Vec2 viewport;
    public final Vec2 lightPosition;
    public final Color color;
    public float intensity;
    
    public LensFlareFilter() {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/lensflare.frag")));
        this.viewport = new Vec2();
        this.lightPosition = new Vec2(0.5f, 0.5f);
        this.color = new Color(1.0f, 0.8f, 0.2f, 1.0f);
        this.intensity = 5.0f;
        this.rebind();
    }
    
    @Override
    public void resize(final int width, final int height) {
        this.viewport.set((float)width, (float)height);
        this.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("u_lightPosition", this.lightPosition);
        this.shader.setUniformf("u_intensity", this.intensity);
        this.shader.setUniformf("u_color", this.color.r, this.color.g, this.color.b);
        this.shader.setUniformf("u_viewport", this.viewport);
    }
}
