// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.filters;

import arc.Core;
import arc.fx.FxFilter;

public class ChromaticAberrationFilter extends FxFilter
{
    public float maxDistortion;
    
    public ChromaticAberrationFilter(final int passes) {
        super(FxFilter.compileShader(Core.files.classpath("shaders/screenspace.vert"), Core.files.classpath("shaders/chromatic-aberration.frag"), "#define PASSES " + passes));
        this.maxDistortion = 1.2f;
        this.rebind();
    }
    
    public void setParams() {
        this.shader.setUniformi("u_texture0", 0);
        this.shader.setUniformf("u_maxDistortion", this.maxDistortion);
    }
}
