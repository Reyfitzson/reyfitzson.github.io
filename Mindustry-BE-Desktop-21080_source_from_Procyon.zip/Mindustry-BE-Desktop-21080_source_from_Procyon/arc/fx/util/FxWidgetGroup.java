// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.util;

import arc.util.viewport.Viewport;
import arc.math.Mathf;
import arc.math.geom.Rect;
import arc.graphics.Color;
import arc.graphics.Texture;
import arc.graphics.g2d.Draw;
import arc.scene.Scene;
import arc.fx.FxProcessor;
import arc.scene.ui.layout.WidgetGroup;

public class FxWidgetGroup extends WidgetGroup
{
    private final FxProcessor fxProcessor;
    private boolean initialized;
    private boolean resizePending;
    private boolean matchWidgetSize;
    
    public FxWidgetGroup() {
        this.initialized = false;
        this.resizePending = false;
        this.matchWidgetSize = false;
        this.fxProcessor = new FxProcessor();
        super.setTransform(false);
    }
    
    public FxProcessor getFxProcessor() {
        return this.fxProcessor;
    }
    
    public boolean isMatchWidgetSize() {
        return this.matchWidgetSize;
    }
    
    public void setMatchWidgetSize(final boolean matchWidgetSize) {
        if (this.matchWidgetSize == matchWidgetSize) {
            return;
        }
        this.matchWidgetSize = matchWidgetSize;
        this.resizePending = true;
    }
    
    @Override
    protected void setScene(final Scene stage) {
        super.setScene(stage);
        if (stage != null) {
            this.initialize();
        }
        else {
            this.reset();
        }
    }
    
    @Override
    protected void sizeChanged() {
        super.sizeChanged();
        this.resizePending = true;
    }
    
    @Override
    public void draw() {
        Draw.flush();
        this.performPendingResize();
        this.fxProcessor.clear();
        this.fxProcessor.begin();
        this.validate();
        this.drawChildren();
        Draw.flush();
        this.fxProcessor.end();
        this.fxProcessor.applyEffects();
        if (this.fxProcessor.hasResult()) {
            final Color color = this.color;
            Draw.color(color.r, color.g, color.b, color.a * this.parentAlpha);
            Draw.rect(Draw.wrap(this.fxProcessor.getResultBuffer().getTexture()), this.x + this.width / 2.0f, this.y + this.height / 2.0f, this.width, this.height);
        }
    }
    
    @Override
    protected void drawChildren() {
        final boolean capturing = this.fxProcessor.isCapturing();
        if (capturing) {
            super.setTransform(true);
        }
        if (!capturing) {
            this.clipBegin();
        }
        super.drawChildren();
        Draw.flush();
        if (capturing) {
            super.setTransform(false);
        }
        if (!capturing) {
            this.clipEnd();
        }
    }
    
    @Deprecated
    @Override
    public void setCullingArea(final Rect cullingArea) {
        throw new UnsupportedOperationException("VfxWidgetGroup doesn't support culling area.");
    }
    
    @Deprecated
    @Override
    public void setTransform(final boolean transform) {
        throw new UnsupportedOperationException("VfxWidgetGroup doesn't support transform.");
    }
    
    private void initialize() {
        if (this.initialized) {
            return;
        }
        this.performPendingResize();
        this.resizePending = false;
        this.initialized = true;
    }
    
    private void reset() {
        if (!this.initialized) {
            return;
        }
        this.fxProcessor.dispose();
        this.resizePending = false;
        this.initialized = false;
    }
    
    private void performPendingResize() {
        if (!this.resizePending) {
            return;
        }
        int width;
        int height;
        if ((int)this.getWidth() == 0 || (int)this.getHeight() == 0) {
            width = 16;
            height = 16;
        }
        else if (this.matchWidgetSize) {
            width = Mathf.floor(this.getWidth());
            height = Mathf.floor(this.getHeight());
        }
        else {
            final Viewport viewport = this.getScene().getViewport();
            final float ppu = viewport.getScreenWidth() / viewport.getWorldWidth();
            width = Mathf.floor(this.getWidth() * ppu);
            height = Mathf.floor(this.getHeight() * ppu);
        }
        this.fxProcessor.resize(width, height);
        this.resizePending = false;
    }
}
