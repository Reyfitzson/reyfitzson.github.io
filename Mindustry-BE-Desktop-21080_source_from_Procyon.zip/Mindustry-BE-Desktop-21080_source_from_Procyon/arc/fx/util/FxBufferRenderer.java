// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.util;

import arc.graphics.Gl;
import arc.Core;
import arc.graphics.gl.FrameBuffer;
import arc.graphics.gl.Shader;
import arc.util.Disposable;

public class FxBufferRenderer implements Disposable
{
    private final Shader shader;
    
    public FxBufferRenderer() {
        this.shader = new Shader("attribute vec4 a_position;\nattribute vec2 a_texCoord0;\nvarying vec2 v_texCoords;\nvoid main(){\n    v_texCoords = a_texCoord0;\n    gl_Position = a_position;\n}", "varying vec2 v_texCoords;\nuniform sampler2D u_texture0;\nvoid main(){\n    gl_FragColor = texture2D(u_texture0, v_texCoords);\n}");
        this.rebind();
    }
    
    @Override
    public void dispose() {
        this.shader.dispose();
    }
    
    public void rebind() {
        this.shader.bind();
        this.shader.setUniformi("u_texture0", 0);
    }
    
    public void renderToScreen(final FrameBuffer input) {
        this.renderToScreen(input, 0, 0, Core.graphics.getBackBufferWidth(), Core.graphics.getBackBufferHeight());
    }
    
    public void renderToScreen(final FrameBuffer input, final int x, final int y, final int width, final int height) {
        Gl.viewport(x, y, width, height);
        input.blit(this.shader);
    }
    
    public void renderToFbo(final FrameBuffer input, final FrameBuffer output) {
        output.begin();
        input.blit(this.shader);
        output.end();
    }
}
