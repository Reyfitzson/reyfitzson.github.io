// 
// Decompiled by Procyon v0.5.36
// 

package arc.fx.util;

import arc.graphics.Pixmap;
import arc.graphics.Texture;
import arc.graphics.gl.FrameBuffer;
import arc.struct.Seq;
import arc.util.Disposable;

public class FxBufferQueue implements Disposable
{
    private final Seq<FrameBuffer> buffers;
    private int currentIdx;
    private Texture.TextureWrap wrapU;
    private Texture.TextureWrap wrapV;
    private Texture.TextureFilter filterMin;
    private Texture.TextureFilter filterMag;
    
    public FxBufferQueue(final Pixmap.Format pixelFormat, final int fboAmount) {
        this.currentIdx = 0;
        this.wrapU = Texture.TextureWrap.clampToEdge;
        this.wrapV = Texture.TextureWrap.clampToEdge;
        this.filterMin = Texture.TextureFilter.nearest;
        this.filterMag = Texture.TextureFilter.nearest;
        if (fboAmount < 1) {
            throw new IllegalArgumentException("FBO amount should be a positive number.");
        }
        this.buffers = new Seq<FrameBuffer>(true, fboAmount);
        for (int i = 0; i < fboAmount; ++i) {
            this.buffers.add(new FrameBuffer(pixelFormat, 4, 4));
        }
    }
    
    @Override
    public void dispose() {
        for (int i = 0; i < this.buffers.size; ++i) {
            this.buffers.get(i).dispose();
        }
    }
    
    public void resize(final int width, final int height) {
        for (int i = 0; i < this.buffers.size; ++i) {
            this.buffers.get(i).resize(width, height);
        }
    }
    
    public void rebind() {
        for (int i = 0; i < this.buffers.size; ++i) {
            final FrameBuffer wrapper = this.buffers.get(i);
            if (wrapper != null) {
                final Texture texture = wrapper.getTexture();
                texture.setWrap(this.wrapU, this.wrapV);
                texture.setFilter(this.filterMin, this.filterMag);
            }
        }
    }
    
    public FrameBuffer getCurrent() {
        return this.buffers.get(this.currentIdx);
    }
    
    public FrameBuffer changeToNext() {
        this.currentIdx = (this.currentIdx + 1) % this.buffers.size;
        return this.getCurrent();
    }
    
    public void setTextureParams(final Texture.TextureWrap u, final Texture.TextureWrap v, final Texture.TextureFilter min, final Texture.TextureFilter mag) {
        this.wrapU = u;
        this.wrapV = v;
        this.filterMin = min;
        this.filterMag = mag;
        this.rebind();
    }
}
