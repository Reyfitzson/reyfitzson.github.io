// 
// Decompiled by Procyon v0.5.36
// 

package arc.audio;

public abstract class AudioFilter
{
    protected long handle;
    
    protected AudioFilter(final long handle) {
        this.handle = handle;
    }
}
