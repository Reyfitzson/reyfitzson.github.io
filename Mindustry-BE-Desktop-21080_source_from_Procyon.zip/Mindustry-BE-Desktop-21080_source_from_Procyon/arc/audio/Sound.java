// 
// Decompiled by Procyon v0.5.36
// 

package arc.audio;

import arc.math.geom.Position;
import arc.math.Mathf;
import arc.Core;
import arc.files.Fi;

public class Sound extends AudioSource
{
    public AudioBus bus;
    long framePlayed;
    Fi file;
    
    public Sound() {
        this.bus = ((Core.audio == null) ? null : Core.audio.soundBus);
    }
    
    public Sound(final Fi file) {
        this.bus = ((Core.audio == null) ? null : Core.audio.soundBus);
        this.load(file);
    }
    
    public void load(final Fi file) {
        final byte[] data = file.readBytes();
        this.file = file;
        this.handle = Soloud.wavLoad(data, data.length);
    }
    
    public int play(final float volume, final float pitch, final float pan, final boolean loop) {
        if (this.handle == 0L || this.framePlayed == Core.graphics.getFrameId() || this.bus == null || !Core.audio.initialized) {
            return -1;
        }
        this.framePlayed = Core.graphics.getFrameId();
        return Soloud.sourcePlayBus(this.handle, this.bus.handle, volume, pitch, pan, loop);
    }
    
    public void setBus(final AudioBus bus) {
        this.bus = bus;
    }
    
    public void stop() {
        if (this.handle == 0L) {
            return;
        }
        Soloud.sourceStop(this.handle);
    }
    
    public float calcPan(final float x, final float y) {
        if (Core.app.isHeadless()) {
            return 0.0f;
        }
        return Mathf.clamp((x - Core.camera.position.x) / (Core.camera.width / 2.0f), -0.9f, 0.9f);
    }
    
    public float calcVolume(final float x, final float y) {
        return this.calcFalloff(x, y) * Core.settings.getInt("sfxvol") / 100.0f;
    }
    
    public float calcFalloff(final float x, final float y) {
        if (Core.app.isHeadless()) {
            return 1.0f;
        }
        final float dst = Mathf.dst(x, y, Core.camera.position.x, Core.camera.position.y);
        return Mathf.clamp(1.0f / (dst * dst / Core.audio.falloff));
    }
    
    public int at(final float x, final float y, final float pitch) {
        return this.at(x, y, pitch, 1.0f);
    }
    
    public int at(final float x, final float y, final float pitch, final float volume) {
        final float vol = this.calcVolume(x, y) * volume;
        if (vol < 0.01f) {
            return -1;
        }
        return this.play(vol, pitch, this.calcPan(x, y));
    }
    
    public int at(final float x, final float y) {
        return this.at(x, y, 1.0f);
    }
    
    public int at(final Position pos) {
        return this.at(pos.getX(), pos.getY());
    }
    
    public int at(final Position pos, final float pitch) {
        return this.at(pos.getX(), pos.getY(), pitch);
    }
    
    public int play() {
        return this.play(1.0f * Core.settings.getInt("sfxvol") / 100.0f);
    }
    
    public int play(final float volume) {
        return this.play(volume, 1.0f, 0.0f);
    }
    
    public int play(final float volume, final float pitch, final float pan) {
        return this.play(volume, pitch, pan, false);
    }
    
    public int loop() {
        return this.loop(1.0f);
    }
    
    public int loop(final float volume) {
        return this.loop(volume, 1.0f, 0.0f);
    }
    
    public int loop(final float volume, final float pitch, final float pan) {
        return this.play(volume, pitch, pan, true);
    }
    
    @Override
    public String toString() {
        return "SoloudSound: " + this.file;
    }
}
