// 
// Decompiled by Procyon v0.5.36
// 

package arc.audio;

import arc.util.Nullable;
import arc.files.Fi;
import arc.ApplicationListener;
import arc.Core;
import arc.util.Log;
import arc.util.Disposable;

public class Audio implements Disposable
{
    public float falloff;
    boolean initialized;
    public AudioBus soundBus;
    public AudioBus musicBus;
    
    public Audio() {
        this.falloff = 16000.0f;
        this.soundBus = new AudioBus();
        this.musicBus = new AudioBus();
        this.initialize();
    }
    
    public boolean initialized() {
        return this.initialized;
    }
    
    protected void initialize() {
        try {
            Soloud.init();
            Log.info("[Audio] Initialized SoLoud @ using @ at @hz / @ samples / @ channels", Soloud.version(), Soloud.backendString(), Soloud.backendSamplerate(), Soloud.backendBufferSize(), Soloud.backendChannels());
            this.initialized = true;
            this.soundBus = new AudioBus().init();
            this.musicBus = new AudioBus().init();
            Core.app.addListener(new ApplicationListener() {
                @Override
                public void pause() {
                    if (Core.app.isMobile()) {
                        Soloud.pauseAll(true);
                    }
                }
                
                @Override
                public void resume() {
                    if (Core.app.isMobile()) {
                        Soloud.pauseAll(false);
                    }
                }
            });
        }
        catch (Throwable error) {
            Log.err("Failed to initialize audio, disabling sound", error);
        }
    }
    
    public Sound newSound(final Fi file) {
        try {
            return new Sound(file);
        }
        catch (Throwable t) {
            Log.err("Error loading sound: " + file, t);
            return new Sound();
        }
    }
    
    public Music newMusic(final Fi file) {
        try {
            return new Music(file);
        }
        catch (Throwable t) {
            Log.err("Error loading music: " + file, t);
            return new Music();
        }
    }
    
    public boolean isPlaying(final int soundId) {
        return this.initialized && Soloud.idValid(soundId);
    }
    
    public void protect(final int voice, final boolean protect) {
        if (!this.initialized) {
            return;
        }
        Soloud.idProtected(voice, protect);
    }
    
    public int play(final AudioSource source, final float volume, final float pitch, final float pan, final boolean loop) {
        if (!this.initialized || source.handle == 0L) {
            return -1;
        }
        return Soloud.sourcePlay(source.handle, volume, pitch, pan, loop);
    }
    
    public void stop(final AudioSource source) {
        if (!this.initialized || source.handle == 0L) {
            return;
        }
        Soloud.sourceStop(source.handle);
    }
    
    public void stop(final int soundId) {
        if (!this.initialized) {
            return;
        }
        Soloud.idStop(soundId);
    }
    
    public void setPaused(final int soundId, final boolean paused) {
        if (!this.initialized) {
            return;
        }
        Soloud.idPause(soundId, paused);
    }
    
    public void setLooping(final int soundId, final boolean looping) {
        if (!this.initialized) {
            return;
        }
        Soloud.idLooping(soundId, looping);
    }
    
    public void setPitch(final int soundId, final float pitch) {
        if (!this.initialized) {
            return;
        }
        Soloud.idPitch(soundId, pitch);
    }
    
    public void setVolume(final int soundId, final float volume) {
        if (!this.initialized) {
            return;
        }
        Soloud.idVolume(soundId, volume);
    }
    
    public void set(final int soundId, final float pan, final float volume) {
        if (!this.initialized) {
            return;
        }
        Soloud.idVolume(soundId, volume);
        Soloud.idPan(soundId, pan);
    }
    
    public void fadeFilterParam(final int voice, final int filter, final int attribute, final float value, final float timeSec) {
        if (!this.initialized) {
            return;
        }
        Soloud.filterFade(voice, filter, attribute, value, timeSec);
    }
    
    public void setFilterParam(final int voice, final int filter, final int attribute, final float value) {
        if (!this.initialized) {
            return;
        }
        Soloud.filterSet(voice, filter, attribute, value);
    }
    
    public void setFilter(final int index, @Nullable final AudioFilter filter) {
        if (!this.initialized) {
            return;
        }
        Soloud.setGlobalFilter(index, (filter == null) ? 0L : filter.handle);
    }
    
    @Override
    public void dispose() {
        if (!this.initialized) {
            return;
        }
        Soloud.stopAll();
        Soloud.deinit();
        this.initialized = false;
    }
}
