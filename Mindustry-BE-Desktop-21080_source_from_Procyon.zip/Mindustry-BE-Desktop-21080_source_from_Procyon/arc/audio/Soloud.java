// 
// Decompiled by Procyon v0.5.36
// 

package arc.audio;

public class Soloud
{
    static native void init();
    
    static native void deinit();
    
    static native String backendString();
    
    static native int backendId();
    
    static native int backendChannels();
    
    static native int backendSamplerate();
    
    static native int backendBufferSize();
    
    static native int version();
    
    static native void stopAll();
    
    static native void pauseAll(final boolean p0);
    
    static native void biquadSet(final long p0, final int p1, final float p2, final float p3);
    
    static native void echoSet(final long p0, final float p1, final float p2, final float p3);
    
    static native void lofiSet(final long p0, final float p1, final float p2);
    
    static native void flangerSet(final long p0, final float p1, final float p2);
    
    static native void waveShaperSet(final long p0, final float p1);
    
    static native void bassBoostSet(final long p0, final float p1);
    
    static native void robotizeSet(final long p0, final float p1, final int p2);
    
    static native void freeverbSet(final long p0, final float p1, final float p2, final float p3, final float p4);
    
    static native long filterBiquad();
    
    static native long filterEcho();
    
    static native long filterLofi();
    
    static native long filterFlanger();
    
    static native long filterBassBoost();
    
    static native long filterWaveShaper();
    
    static native long filterRobotize();
    
    static native long filterFreeverb();
    
    static native void setGlobalFilter(final int p0, final long p1);
    
    static native void filterFade(final int p0, final int p1, final int p2, final float p3, final float p4);
    
    static native void filterSet(final int p0, final int p1, final int p2, final float p3);
    
    static native long speechNew();
    
    static native void speechText(final long p0, final String p1);
    
    static native void speechParams(final long p0, final int p1, final float p2, final float p3, final int p4);
    
    static native long busNew();
    
    static native long wavLoad(final byte[] p0, final int p1);
    
    static native void idSeek(final int p0, final float p1);
    
    static native void idVolume(final int p0, final float p1);
    
    static native float idGetVolume(final int p0);
    
    static native void idPan(final int p0, final float p1);
    
    static native void idPitch(final int p0, final float p1);
    
    static native void idPause(final int p0, final boolean p1);
    
    static native boolean idGetPause(final int p0);
    
    static native void idProtected(final int p0, final boolean p1);
    
    static native void idStop(final int p0);
    
    static native void idLooping(final int p0, final boolean p1);
    
    static native boolean idGetLooping(final int p0);
    
    static native float idPosition(final int p0);
    
    static native boolean idValid(final int p0);
    
    static native long streamLoad(final String p0);
    
    static native double streamLength(final long p0);
    
    static native void sourceDestroy(final long p0);
    
    static native void sourceInaudible(final long p0, final boolean p1, final boolean p2);
    
    static native int sourcePlay(final long p0);
    
    static native int sourceCount(final long p0);
    
    static native int sourcePlay(final long p0, final float p1, final float p2, final float p3, final boolean p4);
    
    static native int sourcePlayBus(final long p0, final long p1, final float p2, final float p3, final float p4, final boolean p5);
    
    static native void sourceLoop(final long p0, final boolean p1);
    
    static native void sourceStop(final long p0);
    
    static native void sourceFilter(final long p0, final int p1, final long p2);
}
