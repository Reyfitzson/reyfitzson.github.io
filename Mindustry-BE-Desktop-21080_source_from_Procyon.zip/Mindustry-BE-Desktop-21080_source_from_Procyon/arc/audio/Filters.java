// 
// Decompiled by Procyon v0.5.36
// 

package arc.audio;

public class Filters
{
    public static final int paramWet = 0;
    
    public static class BiquadFilter extends AudioFilter
    {
        public BiquadFilter() {
            super(Soloud.filterBiquad());
        }
        
        public void set(final int type, final float frequency, final float resonance) {
            Soloud.biquadSet(this.handle, type, frequency, resonance);
        }
    }
    
    public static class EchoFilter extends AudioFilter
    {
        public EchoFilter() {
            super(Soloud.filterEcho());
        }
        
        public void set(final float delay, final float decay, final float filter) {
            Soloud.echoSet(this.handle, delay, decay, filter);
        }
    }
    
    public static class LofiFilter extends AudioFilter
    {
        public LofiFilter() {
            super(Soloud.filterLofi());
        }
        
        public void set(final float sampleRate, final float depth) {
            Soloud.lofiSet(this.handle, sampleRate, depth);
        }
    }
    
    public static class FlangerFilter extends AudioFilter
    {
        public FlangerFilter() {
            super(Soloud.filterFlanger());
        }
        
        public void set(final float delay, final float frequency) {
            Soloud.flangerSet(this.handle, delay, frequency);
        }
    }
    
    public static class WaveShaperFilter extends AudioFilter
    {
        public WaveShaperFilter() {
            super(Soloud.filterWaveShaper());
        }
        
        public void set(final float amount) {
            Soloud.waveShaperSet(this.handle, amount);
        }
    }
    
    public static class BassBoostFilter extends AudioFilter
    {
        public BassBoostFilter() {
            super(Soloud.filterBassBoost());
        }
        
        public void set(final float amount) {
            Soloud.bassBoostSet(this.handle, amount);
        }
    }
    
    public static class RobotizeFilter extends AudioFilter
    {
        public RobotizeFilter() {
            super(Soloud.filterRobotize());
        }
        
        public void set(final float freq, final int waveform) {
            Soloud.robotizeSet(this.handle, freq, waveform);
        }
    }
    
    public static class FreeverbFilter extends AudioFilter
    {
        public FreeverbFilter() {
            super(Soloud.filterFreeverb());
        }
        
        public void set(final float mode, final float roomSize, final float damp, final float width) {
            Soloud.freeverbSet(this.handle, mode, roomSize, damp, width);
        }
    }
}
