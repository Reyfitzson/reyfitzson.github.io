// 
// Decompiled by Procyon v0.5.36
// 

package arc.audio;

import arc.util.Nullable;
import arc.util.Disposable;

public abstract class AudioSource implements Disposable
{
    protected long handle;
    
    public void setFilter(final int index, @Nullable final AudioFilter filter) {
        if (this.handle == 0L) {
            return;
        }
        Soloud.sourceFilter(this.handle, index, (filter == null) ? 0L : filter.handle);
    }
    
    public void setFilter(@Nullable final AudioFilter filter) {
        this.setFilter(0, filter);
    }
    
    @Override
    public void dispose() {
    }
}
