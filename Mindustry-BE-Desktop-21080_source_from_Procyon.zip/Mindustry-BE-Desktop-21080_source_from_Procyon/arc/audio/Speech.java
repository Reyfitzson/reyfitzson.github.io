// 
// Decompiled by Procyon v0.5.36
// 

package arc.audio;

import arc.Core;

public class Speech extends Sound
{
    public Speech() {
        if (Core.audio != null && Core.audio.initialized()) {
            this.handle = Soloud.speechNew();
        }
    }
    
    public void setText(final String text) {
        if (this.handle != 0L) {
            Soloud.speechText(this.handle, text);
        }
    }
    
    public void setParams(final int freq, final float speed, final float declination, final int waveform) {
        if (this.handle != 0L) {
            Soloud.speechParams(this.handle, freq, speed, declination, waveform);
        }
    }
}
