// 
// Decompiled by Procyon v0.5.36
// 

package arc.audio;

import java.io.IOException;
import java.io.File;
import arc.Core;
import arc.util.ArcRuntimeException;
import arc.util.Nullable;
import arc.files.Fi;

public class Music extends AudioSource
{
    @Nullable
    Fi file;
    int voice;
    boolean looping;
    float volume;
    float pitch;
    float pan;
    
    public Music(final Fi file) throws Exception {
        this.voice = -1;
        this.volume = 1.0f;
        this.pitch = 1.0f;
        this.pan = 0.0f;
        this.load(file);
    }
    
    public Music() {
        this.voice = -1;
        this.volume = 1.0f;
        this.pitch = 1.0f;
        this.pan = 0.0f;
    }
    
    public void load(final Fi file) throws Exception {
        this.file = file;
        Exception last = null;
        final Fi[] caches = caches(file.nameWithoutExtension() + "__" + file.length() + "." + file.extension());
        final int length = caches.length;
        int i = 0;
        while (i < length) {
            final Fi result = caches[i];
            if (!result.exists() || result.isDirectory() || result.length() != file.length()) {
                file.copyTo(result);
            }
            try {
                this.handle = Soloud.streamLoad(result.file().getCanonicalPath());
                return;
            }
            catch (Exception e) {
                try {
                    this.handle = Soloud.streamLoad(result.file().getAbsolutePath());
                    return;
                }
                catch (Exception ex) {
                    last = new ArcRuntimeException("Error loading music: " + result.file().getCanonicalPath(), e);
                    ++i;
                }
            }
            break;
        }
        if (last != null) {
            throw last;
        }
    }
    
    public void play() {
        if (this.handle == 0L || !Core.audio.initialized) {
            return;
        }
        if (Soloud.idValid(this.voice) && Soloud.idGetPause(this.voice)) {
            this.pause(false);
        }
        else {
            Soloud.idProtected(this.voice = Soloud.sourcePlayBus(this.handle, Core.audio.musicBus.handle, this.volume, this.pitch, this.pan, this.looping), true);
        }
    }
    
    public void pause(final boolean pause) {
        if (this.handle == 0L || this.voice <= 0) {
            return;
        }
        Soloud.idPause(this.voice, pause);
    }
    
    public void stop() {
        if (this.handle == 0L || this.voice <= 0) {
            return;
        }
        Soloud.sourceStop(this.handle);
        this.voice = 0;
    }
    
    public boolean isPlaying() {
        return this.handle != 0L && this.voice > 0 && Soloud.idValid(this.voice) && !Soloud.idGetPause(this.voice);
    }
    
    public boolean isLooping() {
        return this.looping;
    }
    
    public void setLooping(final boolean isLooping) {
        this.looping = isLooping;
        if (this.handle == 0L || this.voice <= 0) {
            return;
        }
        Soloud.idLooping(this.voice, isLooping);
    }
    
    public float getVolume() {
        return this.volume;
    }
    
    public void setVolume(final float volume) {
        this.volume = volume;
        if (this.handle == 0L || this.voice <= 0) {
            return;
        }
        Soloud.idVolume(this.voice, volume);
    }
    
    public void set(final float pan, final float volume) {
        this.volume = volume;
        this.pan = pan;
        if (this.handle == 0L || this.voice <= 0) {
            return;
        }
        Soloud.idVolume(this.voice, volume);
        Soloud.idPan(this.voice, pan);
    }
    
    public float getPosition() {
        if (this.handle == 0L) {
            return 0.0f;
        }
        return Soloud.idPosition(this.voice);
    }
    
    public void setPosition(final float position) {
        if (this.handle == 0L || this.voice <= 0) {
            return;
        }
        Soloud.idSeek(this.voice, position);
    }
    
    @Override
    public String toString() {
        return "SoloudMusic: " + this.file;
    }
    
    protected static Fi[] caches(final String name) throws IOException {
        final String dir = System.getProperty("java.io.tmpdir");
        return new Fi[] { Core.settings.getDataDirectory().child("cache").child(name), Core.files.cache(name), (dir == null) ? Core.files.absolute(File.createTempFile(name, "mind").getAbsolutePath()) : Core.files.absolute(dir).child(name) };
    }
}
