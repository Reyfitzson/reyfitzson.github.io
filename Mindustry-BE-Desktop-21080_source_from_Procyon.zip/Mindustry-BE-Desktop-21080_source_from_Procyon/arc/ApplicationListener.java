// 
// Decompiled by Procyon v0.5.36
// 

package arc;

import arc.files.Fi;

public interface ApplicationListener
{
    default void init() {
    }
    
    default void resize(final int width, final int height) {
    }
    
    default void update() {
    }
    
    default void pause() {
    }
    
    default void resume() {
    }
    
    default void dispose() {
    }
    
    default void exit() {
    }
    
    default void fileDropped(final Fi file) {
    }
}
