// 
// Decompiled by Procyon v0.5.36
// 

package arc;

import arc.util.OS;
import arc.math.Mathf;
import arc.graphics.Pixmaps;
import arc.graphics.Pixmap;
import arc.graphics.gl.GLVersion;
import arc.graphics.Color;
import arc.graphics.Gl;
import arc.graphics.GL30;
import arc.graphics.GL20;
import arc.util.Disposable;

public abstract class Graphics implements Disposable
{
    private Object lastCursor;
    
    public boolean isGL30Available() {
        return Core.gl30 != null;
    }
    
    public abstract GL20 getGL20();
    
    public abstract void setGL20(final GL20 p0);
    
    public abstract GL30 getGL30();
    
    public abstract void setGL30(final GL30 p0);
    
    public void clear(final float r, final float g, final float b, final float a) {
        Gl.clearColor(r, g, b, a);
        Gl.clear(16384);
    }
    
    public void clear(final Color color) {
        this.clear(color.r, color.g, color.b, color.a);
    }
    
    public boolean isPortrait() {
        return this.getWidth() < this.getHeight();
    }
    
    public abstract int getWidth();
    
    public abstract int getHeight();
    
    public float getAspect() {
        return this.getWidth() / (float)this.getHeight();
    }
    
    public boolean isHidden() {
        return this.getWidth() < 2 || this.getHeight() < 2;
    }
    
    public abstract int getBackBufferWidth();
    
    public abstract int getBackBufferHeight();
    
    public int[] getSafeInsets() {
        return new int[4];
    }
    
    public abstract long getFrameId();
    
    public abstract float getDeltaTime();
    
    public abstract int getFramesPerSecond();
    
    public abstract GLVersion getGLVersion();
    
    public abstract float getPpiX();
    
    public abstract float getPpiY();
    
    public abstract float getPpcX();
    
    public abstract float getPpcY();
    
    public abstract float getDensity();
    
    public abstract boolean supportsDisplayModeChange();
    
    public abstract Monitor getPrimaryMonitor();
    
    public abstract Monitor getMonitor();
    
    public abstract Monitor[] getMonitors();
    
    public abstract DisplayMode[] getDisplayModes();
    
    public abstract DisplayMode[] getDisplayModes(final Monitor p0);
    
    public abstract DisplayMode getDisplayMode();
    
    public abstract DisplayMode getDisplayMode(final Monitor p0);
    
    public abstract boolean setFullscreenMode(final DisplayMode p0);
    
    public abstract boolean setWindowedMode(final int p0, final int p1);
    
    public abstract void setTitle(final String p0);
    
    public abstract void setUndecorated(final boolean p0);
    
    public abstract void setResizable(final boolean p0);
    
    public abstract void setVSync(final boolean p0);
    
    public abstract BufferFormat getBufferFormat();
    
    public abstract boolean supportsExtension(final String p0);
    
    public abstract boolean isContinuousRendering();
    
    public abstract void setContinuousRendering(final boolean p0);
    
    public abstract void requestRendering();
    
    public abstract boolean isFullscreen();
    
    public abstract Cursor newCursor(final Pixmap p0, final int p1, final int p2);
    
    public Cursor newCursor(final Pixmap pixmap, final int scaling, final Color outlineColor) {
        final Pixmap out = Pixmaps.outline(pixmap, outlineColor);
        out.setColor(Color.white);
        Pixmap out2 = Pixmaps.scale(out, (float)scaling);
        if (!Mathf.isPowerOfTwo(out2.getWidth())) {
            final Pixmap old = out2;
            out2 = Pixmaps.resize(out2, Mathf.nextPowerOfTwo(out2.getWidth()), Mathf.nextPowerOfTwo(out2.getWidth()));
            old.dispose();
        }
        out.dispose();
        pixmap.dispose();
        return this.newCursor(out2, out2.getWidth() / 2, out2.getHeight() / 2);
    }
    
    public Cursor newCursor(final Pixmap pixmap, final int scaling, final Color outlineColor, final int outlineThickness) {
        final Pixmap out = Pixmaps.outline(pixmap, outlineColor, outlineThickness);
        out.setColor(Color.white);
        Pixmap out2 = Pixmaps.scale(out, (float)scaling);
        if (!Mathf.isPowerOfTwo(out2.getWidth())) {
            final Pixmap old = out2;
            out2 = Pixmaps.resize(out2, Mathf.nextPowerOfTwo(out2.getWidth()), Mathf.nextPowerOfTwo(out2.getWidth()));
            old.dispose();
        }
        out.dispose();
        pixmap.dispose();
        return this.newCursor(out2, out2.getWidth() / 2, out2.getHeight() / 2);
    }
    
    public Cursor newCursor(final String filename, final int scale) {
        if (scale == 1 || OS.isAndroid || OS.isIos) {
            return this.newCursor(filename);
        }
        final Pixmap base = new Pixmap(Core.files.internal("cursors/" + filename + ".png"));
        final Pixmap result = Pixmaps.scale(base, base.getWidth() * scale, base.getHeight() * scale, Pixmap.PixmapFilter.nearestNeighbour);
        base.dispose();
        return this.newCursor(result, result.getWidth() / 2, result.getHeight() / 2);
    }
    
    public Cursor newCursor(final String filename) {
        final Pixmap p = new Pixmap(Core.files.internal("cursors/" + filename + ".png"));
        return this.newCursor(p, p.getWidth() / 2, p.getHeight() / 2);
    }
    
    public Cursor newCursor(final String filename, final int scaling, final Color outlineColor) {
        return this.newCursor(new Pixmap(Core.files.internal("cursors/" + filename + ".png")), scaling, outlineColor);
    }
    
    public Cursor newCursor(final String filename, final int scaling, final Color outlineColor, final int outlineScaling) {
        return this.newCursor(new Pixmap(Core.files.internal("cursors/" + filename + ".png")), scaling, outlineColor, outlineScaling);
    }
    
    public void restoreCursor() {
        this.cursor(Cursor.SystemCursor.arrow);
    }
    
    public void cursor(final Cursor cursor) {
        if (this.lastCursor == cursor) {
            return;
        }
        if (cursor instanceof Cursor.SystemCursor) {
            if (((Cursor.SystemCursor)cursor).cursor != null) {
                this.setCursor(((Cursor.SystemCursor)cursor).cursor);
            }
            else {
                this.setSystemCursor((Cursor.SystemCursor)cursor);
            }
        }
        else {
            this.setCursor(cursor);
        }
        this.lastCursor = cursor;
    }
    
    protected abstract void setCursor(final Cursor p0);
    
    protected abstract void setSystemCursor(final Cursor.SystemCursor p0);
    
    @Override
    public void dispose() {
        for (final Cursor.SystemCursor cursor : Cursor.SystemCursor.values()) {
            cursor.dispose();
        }
    }
    
    public static class DisplayMode
    {
        public final int width;
        public final int height;
        public final int refreshRate;
        public final int bitsPerPixel;
        
        public DisplayMode(final int width, final int height, final int refreshRate, final int bitsPerPixel) {
            this.width = width;
            this.height = height;
            this.refreshRate = refreshRate;
            this.bitsPerPixel = bitsPerPixel;
        }
        
        @Override
        public String toString() {
            return this.width + "x" + this.height + ", bpp: " + this.bitsPerPixel + ", hz: " + this.refreshRate;
        }
    }
    
    public static class Monitor
    {
        public final int virtualX;
        public final int virtualY;
        public final String name;
        
        public Monitor(final int virtualX, final int virtualY, final String name) {
            this.virtualX = virtualX;
            this.virtualY = virtualY;
            this.name = name;
        }
    }
    
    public static class BufferFormat
    {
        public final int r;
        public final int g;
        public final int b;
        public final int a;
        public final int depth;
        public final int stencil;
        public final int samples;
        public final boolean coverageSampling;
        
        public BufferFormat(final int r, final int g, final int b, final int a, final int depth, final int stencil, final int samples, final boolean coverageSampling) {
            this.r = r;
            this.g = g;
            this.b = b;
            this.a = a;
            this.depth = depth;
            this.stencil = stencil;
            this.samples = samples;
            this.coverageSampling = coverageSampling;
        }
        
        @Override
        public String toString() {
            return "r: " + this.r + ", g: " + this.g + ", b: " + this.b + ", a: " + this.a + ", depth: " + this.depth + ", stencil: " + this.stencil + ", num samples: " + this.samples + ", coverage sampling: " + this.coverageSampling;
        }
    }
    
    public interface Cursor extends Disposable
    {
        public enum SystemCursor implements Cursor
        {
            arrow, 
            ibeam, 
            crosshair, 
            hand, 
            horizontalResize, 
            verticalResize;
            
            protected Cursor cursor;
            
            public void set(final Cursor cursor) {
                this.cursor = cursor;
            }
            
            @Override
            public void dispose() {
                if (this.cursor != null && !(this.cursor instanceof SystemCursor)) {
                    this.cursor.dispose();
                    this.cursor = null;
                }
            }
        }
    }
}
