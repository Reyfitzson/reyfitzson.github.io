// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g3d;

import arc.graphics.Texture;
import arc.math.Mathf;
import arc.graphics.g2d.TextureRegion;
import arc.graphics.Gl;
import arc.math.geom.Mat3D;
import arc.math.geom.Vec3;
import arc.graphics.g2d.Batch;

public class PlaneBatch3D extends Batch
{
    protected final Vec3 up;
    protected final Vec3 right;
    protected final Vec3 origin;
    protected final Vec3 vec;
    protected final VertexBatch3D batch;
    protected final float[] vertex;
    protected float scaling;
    
    public PlaneBatch3D() {
        this(5000);
    }
    
    public PlaneBatch3D(final int vertices) {
        this.up = new Vec3();
        this.right = new Vec3();
        this.origin = new Vec3();
        this.vec = new Vec3();
        this.vertex = new float[6];
        this.scaling = 1.0f;
        this.batch = new VertexBatch3D(vertices, false, true, 1);
    }
    
    public void setScaling(final float scaling) {
        this.scaling = scaling;
    }
    
    public void setPlane(final Vec3 origin, final Vec3 up, final Vec3 right) {
        this.origin.set(origin);
        this.up.set(up).nor();
        this.right.set(right).nor();
    }
    
    public void proj(final Mat3D mat) {
        this.batch.proj(mat);
    }
    
    @Override
    protected void flush() {
        if (this.lastTexture == null || this.idx == 0) {
            return;
        }
        Gl.depthMask(false);
        this.lastTexture.bind();
        this.batch.flush(4);
        this.idx = 0;
        Gl.depthMask(true);
    }
    
    @Override
    protected void draw(final TextureRegion region, final float x, final float y, final float originX, final float originY, final float width, final float height, final float rotation) {
        final Texture texture = region.texture;
        if (texture != this.lastTexture) {
            this.switchTexture(texture);
        }
        this.checkFlush();
        final float worldOriginX = x + originX;
        final float worldOriginY = y + originY;
        final float fx = -originX;
        final float fy = -originY;
        final float fx2 = width - originX;
        final float fy2 = height - originY;
        final float cos = Mathf.cosDeg(rotation);
        final float sin = Mathf.sinDeg(rotation);
        float x2 = cos * fx - sin * fy;
        float y2 = sin * fx + cos * fy;
        float x3 = cos * fx - sin * fy2;
        float y3 = sin * fx + cos * fy2;
        float x4 = cos * fx2 - sin * fy2;
        float y4 = sin * fx2 + cos * fy2;
        float x5 = x2 + (x4 - x3);
        float y5 = y4 - (y3 - y2);
        x2 += worldOriginX;
        y2 += worldOriginY;
        x3 += worldOriginX;
        y3 += worldOriginY;
        x4 += worldOriginX;
        y4 += worldOriginY;
        x5 += worldOriginX;
        y5 += worldOriginY;
        final float u = region.u;
        final float v = region.v2;
        final float u2 = region.u2;
        final float v2 = region.v;
        final float color = this.colorPacked;
        this.vertex(x3, y3, color, u, v2);
        this.vertex(x2, y2, color, u, v);
        this.vertex(x4, y4, color, u2, v2);
        this.vertex(x5, y5, color, u2, v);
        this.vertex(x4, y4, color, u2, v2);
        this.vertex(x2, y2, color, u, v);
        ++this.idx;
    }
    
    @Override
    protected void draw(final Texture texture, final float[] v, final int offset, final int count) {
        if (texture != this.lastTexture) {
            this.switchTexture(texture);
        }
        for (int i = offset; i < count; i += 24) {
            this.checkFlush();
            this.vertex(v[i], v[i + 1], v[i + 2], v[i + 3], v[i + 4]);
            this.vertex(v[i + 12], v[i + 13], v[i + 14], v[i + 15], v[i + 16]);
            this.vertex(v[i + 6], v[i + 7], v[i + 8], v[i + 9], v[i + 10]);
            this.vertex(v[i + 12], v[i + 13], v[i + 14], v[i + 15], v[i + 16]);
            this.vertex(v[i], v[i + 1], v[i + 2], v[i + 3], v[i + 4]);
            this.vertex(v[i + 18], v[i + 19], v[i + 20], v[i + 21], v[i + 22]);
            ++this.idx;
        }
    }
    
    private void checkFlush() {
        if (this.idx >= this.batch.getMaxVertices() / 6 / 6) {
            this.flush();
        }
    }
    
    private void vertex(final float x1, final float y1, final float c1, final float u1, final float v1) {
        this.vec.set(this.origin).add(this.right, x1 * this.scaling).add(this.up, y1 * this.scaling);
        this.vertex[0] = this.vec.x;
        this.vertex[1] = this.vec.y;
        this.vertex[2] = this.vec.z;
        this.vertex[3] = c1;
        this.vertex[4] = u1;
        this.vertex[5] = v1;
        this.batch.vertex(this.vertex);
    }
}
