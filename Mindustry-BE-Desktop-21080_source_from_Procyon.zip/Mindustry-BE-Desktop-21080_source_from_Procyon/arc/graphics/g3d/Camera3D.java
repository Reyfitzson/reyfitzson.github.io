// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g3d;

import arc.Core;
import arc.math.geom.Ray;
import arc.math.geom.Mat3D;
import arc.math.geom.Vec3;

public class Camera3D
{
    public float fov;
    public float near;
    public float far;
    public boolean perspective;
    public float width;
    public float height;
    public final Vec3 position;
    public final Vec3 direction;
    public final Vec3 up;
    public final Mat3D combined;
    public final Mat3D projection;
    public final Mat3D view;
    public final Mat3D invProjectionView;
    private final Vec3 tmpVec;
    private final Ray ray;
    
    public Camera3D() {
        this.fov = 67.0f;
        this.near = 1.0f;
        this.far = 100.0f;
        this.perspective = true;
        this.position = new Vec3();
        this.direction = new Vec3(0.0f, 0.0f, -1.0f);
        this.up = new Vec3(0.0f, 1.0f, 0.0f);
        this.combined = new Mat3D();
        this.projection = new Mat3D();
        this.view = new Mat3D();
        this.invProjectionView = new Mat3D();
        this.tmpVec = new Vec3();
        this.ray = new Ray(new Vec3(), new Vec3());
    }
    
    public void update() {
        if (this.perspective) {
            this.projection.setToProjection(Math.abs(this.near), Math.abs(this.far), this.fov, this.width / this.height);
        }
        else {
            this.projection.setToOrtho(-this.width / 2.0f, this.width / 2.0f, -this.height / 2.0f, this.height / 2.0f, this.near, this.far);
        }
        this.view.setToLookAt(this.position, this.tmpVec.set(this.position).add(this.direction), this.up);
        this.combined.set(this.projection).mul(this.view);
        this.invProjectionView.set(this.combined).inv();
    }
    
    public void resize(final float width, final float height) {
        this.width = width;
        this.height = height;
    }
    
    public void lookAt(final float x, final float y, final float z) {
        this.tmpVec.set(x, y, z).sub(this.position).nor();
        if (!this.tmpVec.isZero()) {
            final float dot = this.tmpVec.dot(this.up);
            if (Math.abs(dot - 1.0f) < 1.0E-9f) {
                this.up.set(this.direction).scl(-1.0f);
            }
            else if (Math.abs(dot + 1.0f) < 1.0E-9f) {
                this.up.set(this.direction);
            }
            this.direction.set(this.tmpVec);
            this.normalizeUp();
        }
    }
    
    public void lookAt(final Vec3 target) {
        this.lookAt(target.x, target.y, target.z);
    }
    
    public void normalizeUp() {
        this.tmpVec.set(this.direction).crs(this.up);
        this.up.set(this.tmpVec).crs(this.direction).nor();
    }
    
    public Vec3 unproject(final Vec3 screenCoords, final float viewportX, final float viewportY, final float viewportWidth, final float viewportHeight) {
        float x = screenCoords.x;
        float y = screenCoords.y;
        x -= viewportX;
        y -= viewportY;
        screenCoords.x = 2.0f * x / viewportWidth - 1.0f;
        screenCoords.y = 2.0f * y / viewportHeight - 1.0f;
        screenCoords.z = 2.0f * screenCoords.z - 1.0f;
        Mat3D.prj(screenCoords, this.invProjectionView);
        return screenCoords;
    }
    
    public Vec3 unproject(final Vec3 screenCoords) {
        this.unproject(screenCoords, 0.0f, 0.0f, (float)Core.graphics.getWidth(), (float)Core.graphics.getHeight());
        return screenCoords;
    }
    
    public Vec3 project(final Vec3 worldCoords) {
        this.project(worldCoords, 0.0f, 0.0f, (float)Core.graphics.getWidth(), (float)Core.graphics.getHeight());
        return worldCoords;
    }
    
    public Vec3 project(final Vec3 worldCoords, final float viewportX, final float viewportY, final float viewportWidth, final float viewportHeight) {
        Mat3D.prj(worldCoords, this.combined);
        worldCoords.x = viewportWidth * (worldCoords.x + 1.0f) / 2.0f + viewportX;
        worldCoords.y = viewportHeight * (worldCoords.y + 1.0f) / 2.0f + viewportY;
        worldCoords.z = (worldCoords.z + 1.0f) / 2.0f;
        return worldCoords;
    }
    
    public Ray getMouseRay() {
        return this.getPickRay((float)Core.input.mouseX(), (float)Core.input.mouseY());
    }
    
    public Ray getPickRay(final float screenX, final float screenY, final float viewportX, final float viewportY, final float viewportWidth, final float viewportHeight) {
        this.unproject(this.ray.origin.set(screenX, screenY, 0.0f), viewportX, viewportY, viewportWidth, viewportHeight);
        this.unproject(this.ray.direction.set(screenX, screenY, 1.0f), viewportX, viewportY, viewportWidth, viewportHeight);
        this.ray.direction.sub(this.ray.origin).nor();
        return this.ray;
    }
    
    public Ray getPickRay(final float screenX, final float screenY) {
        return this.getPickRay(screenX, screenY, 0.0f, 0.0f, (float)Core.graphics.getWidth(), (float)Core.graphics.getHeight());
    }
}
