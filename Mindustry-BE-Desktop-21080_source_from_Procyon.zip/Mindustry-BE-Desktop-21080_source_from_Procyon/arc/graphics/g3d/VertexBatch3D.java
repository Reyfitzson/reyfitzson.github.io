// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g3d;

import arc.math.geom.Vec3;
import arc.graphics.Color;
import arc.struct.Seq;
import arc.graphics.VertexAttribute;
import arc.graphics.gl.Shader;
import arc.math.geom.Mat3D;
import arc.graphics.Mesh;

public class VertexBatch3D
{
    private final int maxVertices;
    private final Mesh mesh;
    private final int numTexCoords;
    private final int vertexSize;
    private final int normalOffset;
    private final int colorOffset;
    private final int texCoordOffset;
    private final Mat3D proj;
    private final float[] vertices;
    private final String[] shaderUniformNames;
    private int vertexIdx;
    private int numSetTexCoords;
    private int numVertices;
    private Shader shader;
    private boolean ownsShader;
    
    public VertexBatch3D(final boolean hasNormals, final boolean hasColors, final int numTexCoords) {
        this(5000, hasNormals, hasColors, numTexCoords, createDefaultShader(hasNormals, hasColors, numTexCoords));
        this.ownsShader = true;
    }
    
    public VertexBatch3D(final int maxVertices, final boolean hasNormals, final boolean hasColors, final int numTexCoords) {
        this(maxVertices, hasNormals, hasColors, numTexCoords, createDefaultShader(hasNormals, hasColors, numTexCoords));
        this.ownsShader = true;
    }
    
    public VertexBatch3D(final int maxVertices, final boolean hasNormals, final boolean hasColors, final int numTexCoords, final Shader shader) {
        this.proj = new Mat3D();
        this.maxVertices = maxVertices;
        this.numTexCoords = numTexCoords;
        this.shader = shader;
        final VertexAttribute[] attribs = this.buildVertexAttributes(hasNormals, hasColors, numTexCoords);
        this.mesh = new Mesh(false, maxVertices, 0, attribs);
        this.vertices = new float[maxVertices * (this.mesh.vertexSize / 4)];
        this.vertexSize = this.mesh.vertexSize / 4;
        int offset = 3;
        if (hasNormals) {
            this.normalOffset = offset;
            offset += 2;
        }
        else {
            this.normalOffset = 0;
        }
        if (hasColors) {
            this.colorOffset = offset;
            ++offset;
        }
        else {
            this.colorOffset = 0;
        }
        this.texCoordOffset = offset;
        this.shaderUniformNames = new String[numTexCoords];
        for (int i = 0; i < numTexCoords; ++i) {
            this.shaderUniformNames[i] = "u_sampler" + i;
        }
    }
    
    private static String createVertexShader(final boolean hasNormals, final boolean hasColors, final int numTexCoords) {
        final StringBuilder shader = new StringBuilder("attribute vec4 a_position;\n" + (hasNormals ? "attribute vec3 a_normal;\n" : "") + (hasColors ? "attribute vec4 a_color;\n" : ""));
        for (int i = 0; i < numTexCoords; ++i) {
            shader.append("attribute vec2 a_texCoord").append(i).append(";\n");
        }
        shader.append("uniform mat4 u_proj;\n");
        shader.append(hasColors ? "varying vec4 v_col;\n" : "");
        for (int i = 0; i < numTexCoords; ++i) {
            shader.append("varying vec2 v_tex").append(i).append(";\n");
        }
        shader.append("void main() {\n   gl_Position = u_proj * a_position;\n").append(hasColors ? "   v_col = a_color;\n" : "");
        for (int i = 0; i < numTexCoords; ++i) {
            shader.append("   v_tex").append(i).append(" = ").append("a_texCoord").append(i).append(";\n");
        }
        shader.append("   gl_PointSize = 1.0;\n");
        shader.append("}\n");
        return shader.toString();
    }
    
    private static String createFragmentShader(final boolean hasNormals, final boolean hasColors, final int numTexCoords) {
        final StringBuilder shader = new StringBuilder();
        if (hasColors) {
            shader.append("varying vec4 v_col;\n");
        }
        for (int i = 0; i < numTexCoords; ++i) {
            shader.append("varying vec2 v_tex").append(i).append(";\n");
            shader.append("uniform sampler2D u_sampler").append(i).append(";\n");
        }
        shader.append("void main(){\n   gl_FragColor = ").append(hasColors ? "v_col" : "vec4(1, 1, 1, 1)");
        if (numTexCoords > 0) {
            shader.append(" * ");
        }
        for (int i = 0; i < numTexCoords; ++i) {
            if (i == numTexCoords - 1) {
                shader.append(" texture2D(u_sampler").append(i).append(",  v_tex").append(i).append(")");
            }
            else {
                shader.append(" texture2D(u_sampler").append(i).append(",  v_tex").append(i).append(") *");
            }
        }
        shader.append(";\n}");
        return shader.toString();
    }
    
    public static Shader createDefaultShader(final boolean hasNormals, final boolean hasColors, final int numTexCoords) {
        final String vertexShader = createVertexShader(hasNormals, hasColors, numTexCoords);
        final String fragmentShader = createFragmentShader(hasNormals, hasColors, numTexCoords);
        return new Shader(vertexShader, fragmentShader);
    }
    
    private VertexAttribute[] buildVertexAttributes(final boolean hasNormals, final boolean hasColor, final int numTexCoords) {
        final Seq<VertexAttribute> attribs = new Seq<VertexAttribute>();
        attribs.add(VertexAttribute.position3);
        if (hasNormals) {
            attribs.add(VertexAttribute.normal);
        }
        if (hasColor) {
            attribs.add(VertexAttribute.color);
        }
        for (int i = 0; i < numTexCoords; ++i) {
            attribs.add(new VertexAttribute(2, "a_texCoord" + i));
        }
        return attribs.toArray(VertexAttribute.class);
    }
    
    public void setShader(final Shader shader) {
        if (this.ownsShader) {
            this.shader.dispose();
        }
        this.shader = shader;
        this.ownsShader = false;
    }
    
    public void color(final Color color) {
        this.vertices[this.vertexIdx + this.colorOffset] = color.toFloatBits();
    }
    
    public void color(final float r, final float g, final float b, final float a) {
        this.vertices[this.vertexIdx + this.colorOffset] = Color.toFloatBits(r, g, b, a);
    }
    
    public void color(final float colorBits) {
        this.vertices[this.vertexIdx + this.colorOffset] = colorBits;
    }
    
    public void texCoord(final float u, final float v) {
        final int idx = this.vertexIdx + this.texCoordOffset;
        this.vertices[idx + this.numSetTexCoords] = u;
        this.vertices[idx + this.numSetTexCoords + 1] = v;
        this.numSetTexCoords += 2;
    }
    
    public void normal(final Vec3 v) {
        this.normal(v.x, v.y, v.z);
    }
    
    public void normal(final float x, final float y, final float z) {
        final int idx = this.vertexIdx + this.normalOffset;
        this.vertices[idx] = x;
        this.vertices[idx + 1] = y;
        this.vertices[idx + 2] = z;
    }
    
    public void tri2(final Vec3 v1, final Vec3 v2, final Vec3 v3, final Color color) {
        this.tri(v1, v2, v3, color);
        this.tri(v1, v3, v2, color);
    }
    
    public void tri(final Vec3 v1, final Vec3 v2, final Vec3 v3, final Color color) {
        this.tri(v1.x, v1.y, v1.z, v2.x, v2.y, v2.z, v3.x, v3.y, v3.z, color);
    }
    
    public void tri(final float x1, final float y1, final float z1, final float x2, final float y2, final float z2, final float x3, final float y3, final float z3, final Color color) {
        this.color(color);
        this.vertex(x1, y1, z1);
        this.color(color);
        this.vertex(x2, y2, z2);
        this.color(color);
        this.vertex(x3, y3, z3);
    }
    
    public void vertex(final Vec3 v, final Color color) {
        this.color(color);
        this.vertex(v.x, v.y, v.z);
    }
    
    public void vertex(final Vec3 v) {
        this.vertex(v.x, v.y, v.z);
    }
    
    public void vertex(final float x, final float y, final float z) {
        final int idx = this.vertexIdx;
        this.vertices[idx] = x;
        this.vertices[idx + 1] = y;
        this.vertices[idx + 2] = z;
        this.numSetTexCoords = 0;
        this.vertexIdx += this.vertexSize;
        ++this.numVertices;
    }
    
    public void vertex(final float[] floats) {
        System.arraycopy(floats, 0, this.vertices, this.vertexIdx, this.vertexSize);
        this.vertexIdx += this.vertexSize;
        ++this.numVertices;
    }
    
    public Mat3D proj() {
        return this.proj;
    }
    
    public void proj(final Mat3D projModelView) {
        this.proj.set(projModelView);
    }
    
    public void flush(final int primitiveType) {
        this.flush(primitiveType, this.shader);
    }
    
    public void flush(final int primitiveType, final Shader shader) {
        if (this.numVertices == 0) {
            return;
        }
        shader.bind();
        shader.apply();
        shader.setUniformMatrix4("u_proj", this.proj.val);
        for (int i = 0; i < this.numTexCoords; ++i) {
            shader.setUniformi(this.shaderUniformNames[i], i);
        }
        this.mesh.setVertices(this.vertices, 0, this.vertexIdx);
        this.mesh.render(shader, primitiveType);
        this.numSetTexCoords = 0;
        this.vertexIdx = 0;
        this.numVertices = 0;
    }
    
    public int getNumVertices() {
        return this.numVertices;
    }
    
    public int getMaxVertices() {
        return this.maxVertices;
    }
    
    public void dispose() {
        if (this.ownsShader && this.shader != null) {
            this.shader.dispose();
        }
        this.mesh.dispose();
    }
}
