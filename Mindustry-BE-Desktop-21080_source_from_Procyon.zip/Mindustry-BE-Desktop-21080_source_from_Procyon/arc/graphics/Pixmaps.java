// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import arc.graphics.g2d.TextureRegion;
import arc.func.Intc2;
import arc.math.geom.Vec2;
import arc.math.Mathf;
import arc.math.geom.Geometry;
import java.nio.ByteBuffer;
import arc.util.Tmp;
import arc.struct.IntSeq;

public class Pixmaps
{
    private static Pixmap drawPixmap;
    private static IntSeq tmpArray;
    
    public static Pixmap noise(final int w, final int h) {
        final Pixmap out = new Pixmap(w, h);
        for (int x = 0; x < w; ++x) {
            for (int y = 0; y < h; ++y) {
                out.draw(x, y, Tmp.c1.rand());
            }
        }
        return out;
    }
    
    public static Texture noiseTex(final int w, final int h) {
        final Pixmap p = noise(w, h);
        final Texture tex = new Texture(p);
        tex.setWrap(Texture.TextureWrap.repeat);
        p.dispose();
        return tex;
    }
    
    public static void flip(final Pixmap pixmap) {
        final ByteBuffer pixels = pixmap.getPixels();
        final int numBytes = pixmap.getWidth() * pixmap.getHeight() * 4;
        final byte[] lines = new byte[numBytes];
        final int numBytesPerLine = pixmap.getWidth() * 4;
        for (int i = 0; i < pixmap.getHeight(); ++i) {
            pixels.position((pixmap.getHeight() - i - 1) * numBytesPerLine);
            pixels.get(lines, i * numBytesPerLine, numBytesPerLine);
        }
        pixels.clear();
        pixels.put(lines);
    }
    
    public static Pixmap median(final Pixmap input, final int radius, final double percentile) {
        return median(input, radius, percentile, Pixmaps.tmpArray);
    }
    
    public static Pixmap median(final Pixmap input, final int radius, final double percentile, final IntSeq tmp) {
        final Pixmap pixmap = new Pixmap(input.getWidth(), input.getHeight());
        final Pixmap pixmap2;
        input.each((x, y) -> {
            tmp.clear();
            Geometry.circle(x, y, pixmap2.getWidth(), pixmap2.getHeight(), radius, (cx, cy) -> tmp.add(input.getPixel(cx, cy)));
            tmp.sort();
            pixmap2.draw(x, y, tmp.get(Mathf.clamp((int)(tmp.size * percentile), 0, tmp.size - 1)));
            return;
        });
        return pixmap;
    }
    
    public static Pixmap copy(final Pixmap input) {
        final Pixmap pixmap = new Pixmap(input.getWidth(), input.getHeight(), Pixmap.Format.rgba8888);
        pixmap.drawPixmap(input, 0, 0);
        return pixmap;
    }
    
    public static Pixmap scale(final Pixmap pixmap, final int width, final int height, final Pixmap.PixmapFilter filter) {
        final Pixmap dest = new Pixmap(width, height);
        dest.setFilter(filter);
        dest.drawPixmap(pixmap, 0, 0, pixmap.getWidth(), pixmap.getHeight(), 0, 0, width, height);
        return dest;
    }
    
    public static Pixmap scale(final Pixmap input, final float scale) {
        return scale(input, scale, scale);
    }
    
    public static Pixmap scale(final Pixmap input, final float scalex, final float scaley) {
        final Pixmap pixmap = new Pixmap((int)(input.getWidth() * scalex), (int)(input.getHeight() * scaley), Pixmap.Format.rgba8888);
        for (int x = 0; x < pixmap.getWidth(); ++x) {
            for (int y = 0; y < pixmap.getHeight(); ++y) {
                pixmap.draw(x, y, input.getPixel((int)(x / scalex), (int)(y / scaley)));
            }
        }
        return pixmap;
    }
    
    public static Pixmap outline(final Pixmap input, final Color color, final int thickness) {
        if (thickness == 1) {
            return outline(input, color);
        }
        final Pixmap pixmap = copy(input);
        pixmap.setColor(color);
        for (int x = 0; x < pixmap.getWidth(); ++x) {
            for (int y = 0; y < pixmap.getHeight(); ++y) {
                if (empty(input.getPixel(x, y))) {
                    boolean found = false;
                Label_0137:
                    for (int dx = -thickness; dx <= thickness; ++dx) {
                        for (int dy = -thickness; dy <= thickness; ++dy) {
                            if (Mathf.dst2((float)dx, (float)dy) <= thickness * thickness && !empty(input.getPixel(x + dx, y + dy))) {
                                found = true;
                                break Label_0137;
                            }
                        }
                    }
                    if (found) {
                        pixmap.draw(x, y);
                    }
                }
            }
        }
        return pixmap;
    }
    
    public static Pixmap outline(final Pixmap input, final Color color) {
        final Pixmap pixmap = copy(input);
        pixmap.setColor(color);
        for (int x = 0; x < pixmap.getWidth(); ++x) {
            for (int y = 0; y < pixmap.getHeight(); ++y) {
                if (empty(input.getPixel(x, y)) && (!empty(input.getPixel(x, y + 1)) || !empty(input.getPixel(x, y - 1)) || !empty(input.getPixel(x - 1, y)) || !empty(input.getPixel(x + 1, y)))) {
                    pixmap.draw(x, y);
                }
            }
        }
        return pixmap;
    }
    
    public static Pixmap zoom(final Pixmap input, final int scale) {
        final Pixmap pixmap = new Pixmap(input.getWidth(), input.getHeight(), Pixmap.Format.rgba8888);
        for (int x = 0; x < pixmap.getWidth(); ++x) {
            for (int y = 0; y < pixmap.getHeight(); ++y) {
                pixmap.draw(x, y, input.getPixel(x / scale + pixmap.getWidth() / 2 / scale, y / scale + pixmap.getHeight() / 2 / scale));
            }
        }
        return pixmap;
    }
    
    public static Pixmap resize(final Pixmap input, final int width, final int height) {
        final Pixmap pixmap = new Pixmap(width, height, Pixmap.Format.rgba8888);
        pixmap.drawPixmap(input, width / 2 - input.getWidth() / 2, height / 2 - input.getHeight() / 2);
        return pixmap;
    }
    
    public static Pixmap resize(final Pixmap input, final int width, final int height, final int backgroundColor) {
        final Pixmap pixmap = new Pixmap(width, height, Pixmap.Format.rgba8888);
        pixmap.setColor(backgroundColor);
        pixmap.fill();
        pixmap.drawPixmap(input, width / 2 - input.getWidth() / 2, height / 2 - input.getHeight() / 2);
        return pixmap;
    }
    
    public static Pixmap crop(final Pixmap input, final int x, final int y, final int width, final int height) {
        final Pixmap pixmap = new Pixmap(width, height, Pixmap.Format.rgba8888);
        pixmap.drawPixmap(input, 0, 0, x, y, width, height);
        return pixmap;
    }
    
    public static Pixmap rotate(final Pixmap input, final float angle) {
        final Vec2 vector = new Vec2();
        final Pixmap pixmap = new Pixmap(input.getHeight(), input.getWidth(), Pixmap.Format.rgba8888);
        for (int x = 0; x < input.getWidth(); ++x) {
            for (int y = 0; y < input.getHeight(); ++y) {
                vector.set(x - input.getWidth() / 2.0f + 0.5f, y - input.getHeight() / 2.0f);
                vector.rotate(-angle);
                final int px = (int)(vector.x + input.getWidth() / 2.0f + 0.01f);
                final int py = (int)(vector.y + input.getHeight() / 2.0f + 0.01f);
                pixmap.draw(px - input.getWidth() / 2 + pixmap.getWidth() / 2, py - input.getHeight() / 2 + pixmap.getHeight() / 2, input.getPixel(x, y));
            }
        }
        return pixmap;
    }
    
    public static boolean empty(final int i) {
        return (i & 0xFF) == 0x0;
    }
    
    public static void traverse(final Pixmap input, final Intc2 t) {
        for (int x = 0; x < input.getWidth(); ++x) {
            for (int y = 0; y < input.getHeight(); ++y) {
                t.get(x, y);
            }
        }
    }
    
    public static Pixmap huePixmap(final int width, final int height) {
        final Pixmap pixmap = new Pixmap(width, height, Pixmap.Format.rgba8888);
        final Color color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        for (int x = 0; x < width; ++x) {
            color.fromHsv(x / (float)width, 1.0f, 1.0f);
            pixmap.setColor(color);
            for (int y = 0; y < height; ++y) {
                pixmap.draw(x, y);
            }
        }
        return pixmap;
    }
    
    public static Texture hueTexture(final int width, final int height) {
        return new Texture(huePixmap(width, height));
    }
    
    public static Pixmap blankPixmap() {
        final Pixmap pixmap = new Pixmap(1, 1, Pixmap.Format.rgba8888);
        pixmap.setColor(Color.white);
        pixmap.fill();
        return pixmap;
    }
    
    public static Texture blankTexture() {
        final Texture texture = new Texture(blankPixmap());
        texture.setWrap(Texture.TextureWrap.repeat, Texture.TextureWrap.repeat);
        return texture;
    }
    
    public static TextureRegion blankTextureRegion() {
        return new TextureRegion(blankTexture());
    }
    
    public static void drawPixel(final Texture texture, final int x, final int y, final int color) {
        if (Pixmaps.drawPixmap == null) {
            Pixmaps.drawPixmap = new Pixmap(1, 1, Pixmap.Format.rgba8888);
        }
        Pixmaps.drawPixmap.setColor(color);
        Pixmaps.drawPixmap.fill();
        texture.draw(Pixmaps.drawPixmap, x, y);
    }
    
    static {
        Pixmaps.tmpArray = new IntSeq();
    }
}
