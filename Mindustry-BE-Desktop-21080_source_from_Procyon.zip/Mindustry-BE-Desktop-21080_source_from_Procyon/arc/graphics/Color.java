// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import arc.math.geom.Vec3;
import arc.math.Mathf;

public class Color
{
    public static final Color white;
    public static final Color lightGray;
    public static final Color gray;
    public static final Color darkGray;
    public static final Color black;
    public static final Color clear;
    public static final float whiteFloatBits;
    public static final float clearFloatBits;
    public static final float blackFloatBits;
    public static final Color blue;
    public static final Color navy;
    public static final Color royal;
    public static final Color slate;
    public static final Color sky;
    public static final Color cyan;
    public static final Color teal;
    public static final Color green;
    public static final Color acid;
    public static final Color lime;
    public static final Color forest;
    public static final Color olive;
    public static final Color yellow;
    public static final Color gold;
    public static final Color goldenrod;
    public static final Color orange;
    public static final Color brown;
    public static final Color tan;
    public static final Color brick;
    public static final Color red;
    public static final Color scarlet;
    public static final Color crimson;
    public static final Color coral;
    public static final Color salmon;
    public static final Color pink;
    public static final Color magenta;
    public static final Color purple;
    public static final Color violet;
    public static final Color maroon;
    private static final float[] tmpHSV;
    public float r;
    public float g;
    public float b;
    public float a;
    
    public Color() {
    }
    
    public Color(final int rgba8888) {
        this.rgba8888(rgba8888);
    }
    
    public Color(final float r, final float g, final float b, final float a) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;
        this.clamp();
    }
    
    public Color(final float r, final float g, final float b) {
        this(r, g, b, 1.0f);
    }
    
    public Color(final Color color) {
        this.set(color);
    }
    
    public static Color valueOf(final String hex) {
        return valueOf(new Color(), hex);
    }
    
    public static Color valueOf(final Color color, final String hex) {
        final int offset = (hex.charAt(0) == '#') ? 1 : 0;
        final int r = parseHex(hex, offset, offset + 2);
        final int g = parseHex(hex, offset + 2, offset + 4);
        final int b = parseHex(hex, offset + 4, offset + 6);
        final int a = (hex.length() - offset != 8) ? 255 : parseHex(hex, offset + 6, offset + 8);
        return color.set(r / 255.0f, g / 255.0f, b / 255.0f, a / 255.0f);
    }
    
    private static int parseHex(final String string, final int from, final int to) {
        int total = 0;
        for (int i = from; i < to; ++i) {
            final char c = string.charAt(i);
            total += Character.digit(c, 16) * ((i == from) ? 16 : 1);
        }
        return total;
    }
    
    public static float toFloatBits(final int r, final int g, final int b, final int a) {
        final int color = a << 24 | b << 16 | g << 8 | r;
        return intToFloatColor(color);
    }
    
    public static float toFloatBits(final float r, final float g, final float b, final float a) {
        final int color = (int)(255.0f * a) << 24 | (int)(255.0f * b) << 16 | (int)(255.0f * g) << 8 | (int)(255.0f * r);
        return intToFloatColor(color);
    }
    
    public static int toIntBits(final int r, final int g, final int b, final int a) {
        return a << 24 | b << 16 | g << 8 | r;
    }
    
    public static int alpha(final float alpha) {
        return (int)(alpha * 255.0f);
    }
    
    public static int luminanceAlpha(final float luminance, final float alpha) {
        return (int)(luminance * 255.0f) << 8 | (int)(alpha * 255.0f);
    }
    
    public static int rgb565(final float r, final float g, final float b) {
        return (int)(r * 31.0f) << 11 | (int)(g * 63.0f) << 5 | (int)(b * 31.0f);
    }
    
    public static int rgba4444(final float r, final float g, final float b, final float a) {
        return (int)(r * 15.0f) << 12 | (int)(g * 15.0f) << 8 | (int)(b * 15.0f) << 4 | (int)(a * 15.0f);
    }
    
    public static int rgb888(final float r, final float g, final float b) {
        return (int)(r * 255.0f) << 16 | (int)(g * 255.0f) << 8 | (int)(b * 255.0f);
    }
    
    public static int rgba8888(final float r, final float g, final float b, final float a) {
        return (int)(r * 255.0f) << 24 | (int)(g * 255.0f) << 16 | (int)(b * 255.0f) << 8 | (int)(a * 255.0f);
    }
    
    public static int argb8888(final float a, final float r, final float g, final float b) {
        return (int)(a * 255.0f) << 24 | (int)(r * 255.0f) << 16 | (int)(g * 255.0f) << 8 | (int)(b * 255.0f);
    }
    
    public int rgb565() {
        return (int)(this.r * 31.0f) << 11 | (int)(this.g * 63.0f) << 5 | (int)(this.b * 31.0f);
    }
    
    public int rgba4444() {
        return (int)(this.r * 15.0f) << 12 | (int)(this.g * 15.0f) << 8 | (int)(this.b * 15.0f) << 4 | (int)(this.a * 15.0f);
    }
    
    public int rgb888() {
        return (int)(this.r * 255.0f) << 16 | (int)(this.g * 255.0f) << 8 | (int)(this.b * 255.0f);
    }
    
    public int rgba8888() {
        return (int)(this.r * 255.0f) << 24 | (int)(this.g * 255.0f) << 16 | (int)(this.b * 255.0f) << 8 | (int)(this.a * 255.0f);
    }
    
    public int argb8888() {
        return (int)(this.a * 255.0f) << 24 | (int)(this.r * 255.0f) << 16 | (int)(this.g * 255.0f) << 8 | (int)(this.b * 255.0f);
    }
    
    public Color rgb565(final int value) {
        this.r = ((value & 0xF800) >>> 11) / 31.0f;
        this.g = ((value & 0x7E0) >>> 5) / 63.0f;
        this.b = (value & 0x1F) / 31.0f;
        return this;
    }
    
    public Color rgba4444(final int value) {
        this.r = ((value & 0xF000) >>> 12) / 15.0f;
        this.g = ((value & 0xF00) >>> 8) / 15.0f;
        this.b = ((value & 0xF0) >>> 4) / 15.0f;
        this.a = (value & 0xF) / 15.0f;
        return this;
    }
    
    public Color rgb888(final int value) {
        this.r = ((value & 0xFF0000) >>> 16) / 255.0f;
        this.g = ((value & 0xFF00) >>> 8) / 255.0f;
        this.b = (value & 0xFF) / 255.0f;
        return this;
    }
    
    public Color rgba8888(final int value) {
        this.r = ((value & 0xFF000000) >>> 24) / 255.0f;
        this.g = ((value & 0xFF0000) >>> 16) / 255.0f;
        this.b = ((value & 0xFF00) >>> 8) / 255.0f;
        this.a = (value & 0xFF) / 255.0f;
        return this;
    }
    
    public Color argb8888(final int value) {
        this.a = ((value & 0xFF000000) >>> 24) / 255.0f;
        this.r = ((value & 0xFF0000) >>> 16) / 255.0f;
        this.g = ((value & 0xFF00) >>> 8) / 255.0f;
        this.b = (value & 0xFF) / 255.0f;
        return this;
    }
    
    public Color abgr8888(final float value) {
        final int c = floatToIntColor(value);
        this.a = ((c & 0xFF000000) >>> 24) / 255.0f;
        this.b = ((c & 0xFF0000) >>> 16) / 255.0f;
        this.g = ((c & 0xFF00) >>> 8) / 255.0f;
        this.r = (c & 0xFF) / 255.0f;
        return this;
    }
    
    public static Color grays(final float value) {
        return new Color(value, value, value);
    }
    
    public static Color rgb(final int r, final int g, final int b) {
        return new Color(r / 255.0f, g / 255.0f, b / 255.0f);
    }
    
    public static int floatToIntColor(final float value) {
        int intBits = Float.floatToRawIntBits(value);
        intBits |= (int)((intBits >>> 24) * 1.003937f) << 24;
        return intBits;
    }
    
    public static float intToFloatColor(final int value) {
        return Float.intBitsToFloat(value & 0xFEFFFFFF);
    }
    
    public Color rand() {
        return this.set(Mathf.random(), Mathf.random(), Mathf.random(), 1.0f);
    }
    
    public Color randHue() {
        this.fromHsv(Mathf.random(360.0f), 1.0f, 1.0f);
        this.a = 1.0f;
        return this;
    }
    
    public float diff(final Color other) {
        return Math.abs(this.hue() - other.hue()) / 360.0f + Math.abs(this.value() - other.value()) + Math.abs(this.saturation() - other.saturation());
    }
    
    public int rgba() {
        return this.rgba8888();
    }
    
    public Color set(final Color color) {
        this.r = color.r;
        this.g = color.g;
        this.b = color.b;
        this.a = color.a;
        return this;
    }
    
    public Color set(final Vec3 vec) {
        return this.set(vec.x, vec.y, vec.z);
    }
    
    public Color mul(final Color color) {
        this.r *= color.r;
        this.g *= color.g;
        this.b *= color.b;
        this.a *= color.a;
        return this.clamp();
    }
    
    public Color mul(final float value) {
        this.r *= value;
        this.g *= value;
        this.b *= value;
        return this.clamp();
    }
    
    public Color mula(final float value) {
        this.r *= value;
        this.g *= value;
        this.b *= value;
        this.a *= value;
        return this.clamp();
    }
    
    public Color add(final Color color) {
        this.r += color.r;
        this.g += color.g;
        this.b += color.b;
        return this.clamp();
    }
    
    public Color sub(final Color color) {
        this.r -= color.r;
        this.g -= color.g;
        this.b -= color.b;
        return this.clamp();
    }
    
    public Color clamp() {
        if (this.r < 0.0f) {
            this.r = 0.0f;
        }
        else if (this.r > 1.0f) {
            this.r = 1.0f;
        }
        if (this.g < 0.0f) {
            this.g = 0.0f;
        }
        else if (this.g > 1.0f) {
            this.g = 1.0f;
        }
        if (this.b < 0.0f) {
            this.b = 0.0f;
        }
        else if (this.b > 1.0f) {
            this.b = 1.0f;
        }
        if (this.a < 0.0f) {
            this.a = 0.0f;
        }
        else if (this.a > 1.0f) {
            this.a = 1.0f;
        }
        return this;
    }
    
    public Color set(final float r, final float g, final float b, final float a) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;
        return this.clamp();
    }
    
    public Color set(final float r, final float g, final float b) {
        this.r = r;
        this.g = g;
        this.b = b;
        return this.clamp();
    }
    
    public Color set(final int rgba) {
        return this.rgba8888(rgba);
    }
    
    public float sum() {
        return this.r + this.g + this.b;
    }
    
    public Color add(final float r, final float g, final float b, final float a) {
        this.r += r;
        this.g += g;
        this.b += b;
        this.a += a;
        return this.clamp();
    }
    
    public Color add(final float r, final float g, final float b) {
        this.r += r;
        this.g += g;
        this.b += b;
        return this.clamp();
    }
    
    public Color sub(final float r, final float g, final float b, final float a) {
        this.r -= r;
        this.g -= g;
        this.b -= b;
        this.a -= a;
        return this.clamp();
    }
    
    public Color sub(final float r, final float g, final float b) {
        this.r -= r;
        this.g -= g;
        this.b -= b;
        return this.clamp();
    }
    
    public Color inv() {
        this.r = 1.0f - this.r;
        this.g = 1.0f - this.g;
        this.b = 1.0f - this.b;
        return this;
    }
    
    public Color r(final float r) {
        this.r = r;
        return this;
    }
    
    public Color g(final float g) {
        this.g = g;
        return this;
    }
    
    public Color b(final float b) {
        this.b = b;
        return this;
    }
    
    public Color a(final float a) {
        this.a = a;
        return this;
    }
    
    public Color mul(final float r, final float g, final float b, final float a) {
        this.r *= r;
        this.g *= g;
        this.b *= b;
        this.a *= a;
        return this.clamp();
    }
    
    public Color lerp(final Color target, final float t) {
        this.r += t * (target.r - this.r);
        this.g += t * (target.g - this.g);
        this.b += t * (target.b - this.b);
        this.a += t * (target.a - this.a);
        return this.clamp();
    }
    
    public Color lerp(final float r, final float g, final float b, final float a, final float t) {
        this.r += t * (r - this.r);
        this.g += t * (g - this.g);
        this.b += t * (b - this.b);
        this.a += t * (a - this.a);
        return this.clamp();
    }
    
    public Color premultiplyAlpha() {
        this.r *= this.a;
        this.g *= this.a;
        this.b *= this.a;
        return this;
    }
    
    public Color write(final Color to) {
        return to.set(this);
    }
    
    public float hue() {
        this.toHsv(Color.tmpHSV);
        return Color.tmpHSV[0];
    }
    
    public float saturation() {
        this.toHsv(Color.tmpHSV);
        return Color.tmpHSV[1];
    }
    
    public float value() {
        this.toHsv(Color.tmpHSV);
        return Color.tmpHSV[2];
    }
    
    public Color shiftHue(final float amount) {
        this.toHsv(Color.tmpHSV);
        final float[] tmpHSV = Color.tmpHSV;
        final int n = 0;
        tmpHSV[n] += amount;
        this.fromHsv(Color.tmpHSV);
        return this;
    }
    
    public Color shiftSaturation(final float amount) {
        this.toHsv(Color.tmpHSV);
        final float[] tmpHSV = Color.tmpHSV;
        final int n = 1;
        tmpHSV[n] += amount;
        this.fromHsv(Color.tmpHSV);
        return this;
    }
    
    public Color shiftValue(final float amount) {
        this.toHsv(Color.tmpHSV);
        final float[] tmpHSV = Color.tmpHSV;
        final int n = 2;
        tmpHSV[n] += amount;
        this.fromHsv(Color.tmpHSV);
        return this;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final Color color = (Color)o;
        return this.toIntBits() == color.toIntBits();
    }
    
    @Override
    public int hashCode() {
        int result = (this.r != 0.0f) ? Float.floatToIntBits(this.r) : 0;
        result = 31 * result + ((this.g != 0.0f) ? Float.floatToIntBits(this.g) : 0);
        result = 31 * result + ((this.b != 0.0f) ? Float.floatToIntBits(this.b) : 0);
        result = 31 * result + ((this.a != 0.0f) ? Float.floatToIntBits(this.a) : 0);
        return result;
    }
    
    public float toFloatBits() {
        final int color = (int)(255.0f * this.a) << 24 | (int)(255.0f * this.b) << 16 | (int)(255.0f * this.g) << 8 | (int)(255.0f * this.r);
        return intToFloatColor(color);
    }
    
    public int toIntBits() {
        return (int)(255.0f * this.a) << 24 | (int)(255.0f * this.b) << 16 | (int)(255.0f * this.g) << 8 | (int)(255.0f * this.r);
    }
    
    @Override
    public String toString() {
        final StringBuilder value = new StringBuilder();
        this.toString(value);
        return value.toString();
    }
    
    public void toString(final StringBuilder builder) {
        builder.append(Integer.toHexString((int)(255.0f * this.r) << 24 | (int)(255.0f * this.g) << 16 | (int)(255.0f * this.b) << 8 | (int)(255.0f * this.a)));
        while (builder.length() < 8) {
            builder.insert(0, "0");
        }
    }
    
    public Color fromHsv(final float h, final float s, final float v) {
        final float x = (h / 60.0f + 6.0f) % 6.0f;
        final int i = (int)x;
        final float f = x - i;
        final float p = v * (1.0f - s);
        final float q = v * (1.0f - s * f);
        final float t = v * (1.0f - s * (1.0f - f));
        switch (i) {
            case 0: {
                this.r = v;
                this.g = t;
                this.b = p;
                break;
            }
            case 1: {
                this.r = q;
                this.g = v;
                this.b = p;
                break;
            }
            case 2: {
                this.r = p;
                this.g = v;
                this.b = t;
                break;
            }
            case 3: {
                this.r = p;
                this.g = q;
                this.b = v;
                break;
            }
            case 4: {
                this.r = t;
                this.g = p;
                this.b = v;
                break;
            }
            default: {
                this.r = v;
                this.g = p;
                this.b = q;
                break;
            }
        }
        return this.clamp();
    }
    
    public Color fromHsv(final float[] hsv) {
        return this.fromHsv(hsv[0], hsv[1], hsv[2]);
    }
    
    public float[] toHsv(final float[] hsv) {
        final float max = Math.max(Math.max(this.r, this.g), this.b);
        final float min = Math.min(Math.min(this.r, this.g), this.b);
        final float range = max - min;
        if (range == 0.0f) {
            hsv[0] = 0.0f;
        }
        else if (max == this.r) {
            hsv[0] = (60.0f * (this.g - this.b) / range + 360.0f) % 360.0f;
        }
        else if (max == this.g) {
            hsv[0] = 60.0f * (this.b - this.r) / range + 120.0f;
        }
        else {
            hsv[0] = 60.0f * (this.r - this.g) / range + 240.0f;
        }
        if (max > 0.0f) {
            hsv[1] = 1.0f - min / max;
        }
        else {
            hsv[1] = 0.0f;
        }
        hsv[2] = max;
        return hsv;
    }
    
    public static Color HSVtoRGB(final float h, final float s, final float v, final float alpha) {
        final Color c = HSVtoRGB(h, s, v);
        c.a = alpha;
        return c;
    }
    
    public static Color HSVtoRGB(final float h, final float s, final float v) {
        final Color c = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        HSVtoRGB(h, s, v, c);
        return c;
    }
    
    public static Color HSVtoRGB(float h, float s, float v, final Color targetColor) {
        if (h == 360.0f) {
            h = 359.0f;
        }
        h = (float)Math.max(0.0, Math.min(360.0, h));
        s = (float)Math.max(0.0, Math.min(100.0, s));
        v = (float)Math.max(0.0, Math.min(100.0, v));
        s /= 100.0f;
        v /= 100.0f;
        h /= 60.0f;
        final int i = Mathf.floor(h);
        final float f = h - i;
        final float p = v * (1.0f - s);
        final float q = v * (1.0f - s * f);
        final float t = v * (1.0f - s * (1.0f - f));
        float r = 0.0f;
        float g = 0.0f;
        float b = 0.0f;
        switch (i) {
            case 0: {
                r = v;
                g = t;
                b = p;
                break;
            }
            case 1: {
                r = q;
                g = v;
                b = p;
                break;
            }
            case 2: {
                r = p;
                g = v;
                b = t;
                break;
            }
            case 3: {
                r = p;
                g = q;
                b = v;
                break;
            }
            case 4: {
                r = t;
                g = p;
                b = v;
                break;
            }
            default: {
                r = v;
                g = p;
                b = q;
                break;
            }
        }
        targetColor.set(r, g, b, targetColor.a);
        return targetColor;
    }
    
    public static int[] RGBtoHSV(final Color c) {
        return RGBtoHSV(c.r, c.g, c.b);
    }
    
    public static int[] RGBtoHSV(final float r, final float g, final float b) {
        final float min = Math.min(Math.min(r, g), b);
        float v;
        final float max = v = Math.max(Math.max(r, g), b);
        final float delta = max - min;
        if (max != 0.0f) {
            float s = delta / max;
            float h;
            if (delta == 0.0f) {
                h = 0.0f;
            }
            else if (r == max) {
                h = (g - b) / delta;
            }
            else if (g == max) {
                h = 2.0f + (b - r) / delta;
            }
            else {
                h = 4.0f + (r - g) / delta;
            }
            h *= 60.0f;
            if (h < 0.0f) {
                h += 360.0f;
            }
            s *= 100.0f;
            v *= 100.0f;
            return new int[] { Mathf.round(h), Mathf.round(s), Mathf.round(v) };
        }
        float s = 0.0f;
        float h = 0.0f;
        return new int[] { Mathf.round(h), Mathf.round(s), Mathf.round(v) };
    }
    
    public Color cpy() {
        return new Color(this);
    }
    
    public Color lerp(final Color[] colors, final float s) {
        final int l = colors.length;
        final Color a = colors[(int)(s * (l - 1))];
        final Color b = colors[Mathf.clamp((int)(s * (l - 1) + 1.0f), 0, l - 1)];
        final float n = s * (l - 1) - (int)(s * (l - 1));
        final float i = 1.0f - n;
        return this.set(a.r * i + b.r * n, a.g * i + b.g * n, a.b * i + b.b * n, 1.0f);
    }
    
    static {
        white = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        lightGray = new Color(-1077952513);
        gray = new Color(2139062271);
        darkGray = new Color(1061109759);
        black = new Color(0.0f, 0.0f, 0.0f, 1.0f);
        clear = new Color(0.0f, 0.0f, 0.0f, 0.0f);
        whiteFloatBits = Color.white.toFloatBits();
        clearFloatBits = Color.clear.toFloatBits();
        blackFloatBits = Color.black.toFloatBits();
        blue = new Color(0.0f, 0.0f, 1.0f, 1.0f);
        navy = new Color(0.0f, 0.0f, 0.5f, 1.0f);
        royal = new Color(1097458175);
        slate = new Color(1887473919);
        sky = new Color(-2016482305);
        cyan = new Color(0.0f, 1.0f, 1.0f, 1.0f);
        teal = new Color(0.0f, 0.5f, 0.5f, 1.0f);
        green = new Color(16711935);
        acid = new Color(2147418367);
        lime = new Color(852308735);
        forest = new Color(579543807);
        olive = new Color(1804477439);
        yellow = new Color(-65281);
        gold = new Color(-2686721);
        goldenrod = new Color(-626712321);
        orange = new Color(-5963521);
        brown = new Color(-1958407169);
        tan = new Color(-759919361);
        brick = new Color(-1306385665);
        red = new Color(-16776961);
        scarlet = new Color(-13361921);
        crimson = new Color(-602653441);
        coral = new Color(-8433409);
        salmon = new Color(-92245249);
        pink = new Color(-9849601);
        magenta = new Color(1.0f, 0.0f, 1.0f, 1.0f);
        purple = new Color(-1608453889);
        violet = new Color(-293409025);
        maroon = new Color(-1339006721);
        tmpHSV = new float[3];
    }
}
