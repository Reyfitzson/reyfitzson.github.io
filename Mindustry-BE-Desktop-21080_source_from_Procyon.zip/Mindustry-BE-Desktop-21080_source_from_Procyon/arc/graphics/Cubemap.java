// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import arc.math.geom.Vec3;
import arc.graphics.gl.FacedCubemapData;
import arc.graphics.gl.PixmapTextureData;
import arc.files.Fi;
import arc.Core;

public class Cubemap extends GLTexture
{
    protected CubemapData data;
    
    public Cubemap(final CubemapData data) {
        super(34067);
        this.load(this.data = data);
    }
    
    public Cubemap(final String base) {
        this(Core.files.internal(base + "right.png"), Core.files.internal(base + "left.png"), Core.files.internal(base + "top.png"), Core.files.internal(base + "bottom.png"), Core.files.internal(base + "front.png"), Core.files.internal(base + "back.png"));
    }
    
    public Cubemap(final Fi positiveX, final Fi negativeX, final Fi positiveY, final Fi negativeY, final Fi positiveZ, final Fi negativeZ) {
        this(positiveX, negativeX, positiveY, negativeY, positiveZ, negativeZ, false);
    }
    
    public Cubemap(final Fi positiveX, final Fi negativeX, final Fi positiveY, final Fi negativeY, final Fi positiveZ, final Fi negativeZ, final boolean useMipMaps) {
        this(TextureData.load(positiveX, useMipMaps), TextureData.load(negativeX, useMipMaps), TextureData.load(positiveY, useMipMaps), TextureData.load(negativeY, useMipMaps), TextureData.load(positiveZ, useMipMaps), TextureData.load(negativeZ, useMipMaps));
    }
    
    public Cubemap(final Pixmap positiveX, final Pixmap negativeX, final Pixmap positiveY, final Pixmap negativeY, final Pixmap positiveZ, final Pixmap negativeZ) {
        this(positiveX, negativeX, positiveY, negativeY, positiveZ, negativeZ, false);
    }
    
    public Cubemap(final Pixmap positiveX, final Pixmap negativeX, final Pixmap positiveY, final Pixmap negativeY, final Pixmap positiveZ, final Pixmap negativeZ, final boolean useMipMaps) {
        this((positiveX == null) ? null : new PixmapTextureData(positiveX, null, useMipMaps, false), (negativeX == null) ? null : new PixmapTextureData(negativeX, null, useMipMaps, false), (positiveY == null) ? null : new PixmapTextureData(positiveY, null, useMipMaps, false), (negativeY == null) ? null : new PixmapTextureData(negativeY, null, useMipMaps, false), (positiveZ == null) ? null : new PixmapTextureData(positiveZ, null, useMipMaps, false), (negativeZ == null) ? null : new PixmapTextureData(negativeZ, null, useMipMaps, false));
    }
    
    public Cubemap(final int width, final int height, final int depth, final Pixmap.Format format) {
        this(new PixmapTextureData(new Pixmap(depth, height, format), null, false, true), new PixmapTextureData(new Pixmap(depth, height, format), null, false, true), new PixmapTextureData(new Pixmap(width, depth, format), null, false, true), new PixmapTextureData(new Pixmap(width, depth, format), null, false, true), new PixmapTextureData(new Pixmap(width, height, format), null, false, true), new PixmapTextureData(new Pixmap(width, height, format), null, false, true));
    }
    
    public Cubemap(final TextureData positiveX, final TextureData negativeX, final TextureData positiveY, final TextureData negativeY, final TextureData positiveZ, final TextureData negativeZ) {
        super(34067);
        this.minFilter = Texture.TextureFilter.nearest;
        this.magFilter = Texture.TextureFilter.nearest;
        this.uWrap = Texture.TextureWrap.clampToEdge;
        this.vWrap = Texture.TextureWrap.clampToEdge;
        this.load(this.data = new FacedCubemapData(positiveX, negativeX, positiveY, negativeY, positiveZ, negativeZ));
    }
    
    public void load(final CubemapData data) {
        if (!data.isPrepared()) {
            data.prepare();
        }
        this.width = data.getWidth();
        this.height = data.getHeight();
        this.bind();
        this.unsafeSetFilter(this.minFilter, this.magFilter, true);
        this.unsafeSetWrap(this.uWrap, this.vWrap, true);
        data.consumeCubemapData();
        Gl.bindTexture(this.glTarget, 0);
    }
    
    public CubemapData getCubemapData() {
        return this.data;
    }
    
    @Override
    public int getDepth() {
        return 0;
    }
    
    @Override
    public void dispose() {
        if (this.glHandle == 0) {
            return;
        }
        this.delete();
    }
    
    public enum CubemapSide
    {
        positiveX(0, 34069, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, 0.0f), 
        negativeX(1, 34070, 0.0f, -1.0f, 0.0f, -1.0f, 0.0f, 0.0f), 
        positiveY(2, 34071, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f), 
        negativeY(3, 34072, 0.0f, 0.0f, -1.0f, 0.0f, -1.0f, 0.0f), 
        positiveZ(4, 34073, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f), 
        negativeZ(5, 34074, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, -1.0f);
        
        public final int index;
        public final int glEnum;
        public final Vec3 up;
        public final Vec3 direction;
        
        private CubemapSide(final int index, final int glEnum, final float upX, final float upY, final float upZ, final float directionX, final float directionY, final float directionZ) {
            this.index = index;
            this.glEnum = glEnum;
            this.up = new Vec3(upX, upY, upZ);
            this.direction = new Vec3(directionX, directionY, directionZ);
        }
        
        public int getGLEnum() {
            return this.glEnum;
        }
        
        public Vec3 getUp(final Vec3 out) {
            return out.set(this.up);
        }
        
        public Vec3 getDirection(final Vec3 out) {
            return out.set(this.direction);
        }
    }
}
