// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import java.nio.Buffer;
import arc.util.ArcRuntimeException;
import arc.Core;
import arc.graphics.gl.FileTextureArrayData;
import arc.files.Fi;

public class TextureArray extends GLTexture
{
    private TextureArrayData data;
    
    public TextureArray(final String... internalPaths) {
        this(getInternalHandles(internalPaths));
    }
    
    public TextureArray(final Fi... files) {
        this(false, files);
    }
    
    public TextureArray(final boolean useMipMaps, final Fi... files) {
        this(useMipMaps, Pixmap.Format.rgba8888, files);
    }
    
    public TextureArray(final boolean useMipMaps, final Pixmap.Format format, final Fi... files) {
        this(new FileTextureArrayData(format, useMipMaps, files));
    }
    
    public TextureArray(final TextureArrayData data) {
        super(35866, Gl.genTexture());
        if (Core.gl30 == null) {
            throw new ArcRuntimeException("TextureArray requires a device running with GLES 3.0 compatibilty");
        }
        this.load(data);
    }
    
    private static Fi[] getInternalHandles(final String... internalPaths) {
        final Fi[] handles = new Fi[internalPaths.length];
        for (int i = 0; i < internalPaths.length; ++i) {
            handles[i] = Core.files.internal(internalPaths[i]);
        }
        return handles;
    }
    
    private void load(final TextureArrayData data) {
        this.data = data;
        this.width = data.getWidth();
        this.height = data.getHeight();
        this.bind();
        Core.gl30.glTexImage3D(35866, 0, data.getInternalFormat(), data.getWidth(), data.getHeight(), data.getDepth(), 0, data.getInternalFormat(), data.getGLType(), null);
        if (!data.isPrepared()) {
            data.prepare();
        }
        data.consumeTextureArrayData();
        this.setFilter(this.minFilter, this.magFilter);
        this.setWrap(this.uWrap, this.vWrap);
        Gl.bindTexture(this.glTarget, 0);
    }
    
    @Override
    public int getDepth() {
        return this.data.getDepth();
    }
}
