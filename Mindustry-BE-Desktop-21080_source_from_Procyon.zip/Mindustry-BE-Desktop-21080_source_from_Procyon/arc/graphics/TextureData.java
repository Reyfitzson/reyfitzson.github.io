// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import arc.graphics.gl.FileTextureData;
import arc.files.Fi;

public interface TextureData
{
    boolean isCustom();
    
    boolean isPrepared();
    
    void prepare();
    
    Pixmap consumePixmap();
    
    default Pixmap getPixmap() {
        if (!this.isPrepared()) {
            this.prepare();
        }
        return this.consumePixmap();
    }
    
    boolean disposePixmap();
    
    void consumeCustomData(final int p0);
    
    int getWidth();
    
    int getHeight();
    
    Pixmap.Format getFormat();
    
    boolean useMipMaps();
    
    default TextureData load(final Fi file, final boolean useMipMaps) {
        return load(file, null, useMipMaps);
    }
    
    default TextureData load(final Fi file, final Pixmap.Format format, final boolean useMipMaps) {
        if (file == null) {
            return null;
        }
        return new FileTextureData(file, new Pixmap(file), format, useMipMaps);
    }
}
