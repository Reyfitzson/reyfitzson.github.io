// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

public interface TextureArrayData
{
    boolean isPrepared();
    
    void prepare();
    
    void consumeTextureArrayData();
    
    int getWidth();
    
    int getHeight();
    
    int getDepth();
    
    int getInternalFormat();
    
    int getGLType();
}
