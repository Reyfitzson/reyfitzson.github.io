// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import java.util.Locale;
import arc.struct.OrderedMap;

public final class Colors
{
    private static final OrderedMap<String, Color> map;
    
    private Colors() {
    }
    
    public static OrderedMap<String, Color> getColors() {
        return Colors.map;
    }
    
    public static Color get(final String name) {
        return Colors.map.get(name);
    }
    
    public static Color put(final String name, final Color color) {
        return Colors.map.put(name, color);
    }
    
    public static void reset() {
        Colors.map.clear();
        Colors.map.put("CLEAR", Color.clear);
        Colors.map.put("BLACK", Color.black);
        Colors.map.put("WHITE", Color.white);
        Colors.map.put("LIGHT_GRAY", Color.lightGray);
        Colors.map.put("GRAY", Color.gray);
        Colors.map.put("DARK_GRAY", Color.darkGray);
        Colors.map.put("LIGHT_GREY", Color.lightGray);
        Colors.map.put("GREY", Color.gray);
        Colors.map.put("DARK_GREY", Color.darkGray);
        Colors.map.put("BLUE", Color.royal);
        Colors.map.put("NAVY", Color.navy);
        Colors.map.put("ROYAL", Color.royal);
        Colors.map.put("SLATE", Color.slate);
        Colors.map.put("SKY", Color.sky);
        Colors.map.put("CYAN", Color.cyan);
        Colors.map.put("TEAL", Color.teal);
        Colors.map.put("GREEN", Color.valueOf("38d667"));
        Colors.map.put("ACID", Color.acid);
        Colors.map.put("LIME", Color.lime);
        Colors.map.put("FOREST", Color.forest);
        Colors.map.put("OLIVE", Color.olive);
        Colors.map.put("YELLOW", Color.yellow);
        Colors.map.put("GOLD", Color.gold);
        Colors.map.put("GOLDENROD", Color.goldenrod);
        Colors.map.put("ORANGE", Color.orange);
        Colors.map.put("BROWN", Color.brown);
        Colors.map.put("TAN", Color.tan);
        Colors.map.put("BRICK", Color.brick);
        Colors.map.put("RED", Color.valueOf("e55454"));
        Colors.map.put("SCARLET", Color.scarlet);
        Colors.map.put("CRIMSON", Color.crimson);
        Colors.map.put("CORAL", Color.coral);
        Colors.map.put("SALMON", Color.salmon);
        Colors.map.put("PINK", Color.pink);
        Colors.map.put("MAGENTA", Color.magenta);
        Colors.map.put("PURPLE", Color.purple);
        Colors.map.put("VIOLET", Color.violet);
        Colors.map.put("MAROON", Color.maroon);
        final Color color;
        Colors.map.copy().each((key, val) -> color = Colors.map.put(key.toLowerCase(Locale.ROOT).replace("_", ""), val));
    }
    
    static {
        map = new OrderedMap<String, Color>();
        reset();
    }
}
