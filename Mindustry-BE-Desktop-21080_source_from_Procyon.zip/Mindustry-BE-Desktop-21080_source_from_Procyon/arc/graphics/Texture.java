// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import arc.graphics.gl.FileTextureData;
import java.nio.Buffer;
import arc.graphics.gl.PixmapTextureData;
import arc.files.Fi;
import arc.Core;

public class Texture extends GLTexture
{
    TextureData data;
    
    public Texture(final String internalPath) {
        this(Core.files.internal(internalPath));
    }
    
    public Texture(final Fi file) {
        this(file, null, false);
    }
    
    public Texture(final Fi file, final boolean useMipMaps) {
        this(file, null, useMipMaps);
    }
    
    public Texture(final Fi file, final Pixmap.Format format, final boolean useMipMaps) {
        this(TextureData.load(file, format, useMipMaps));
    }
    
    public Texture(final Pixmap pixmap) {
        this(new PixmapTextureData(pixmap, null, false, false));
    }
    
    public Texture(final Pixmap pixmap, final boolean useMipMaps) {
        this(new PixmapTextureData(pixmap, null, useMipMaps, false));
    }
    
    public Texture(final Pixmap pixmap, final Pixmap.Format format, final boolean useMipMaps) {
        this(new PixmapTextureData(pixmap, format, useMipMaps, false));
    }
    
    public Texture(final int width, final int height, final Pixmap.Format format) {
        this(new PixmapTextureData(new Pixmap(width, height, format), null, false, true));
    }
    
    public Texture(final TextureData data) {
        this(3553, Gl.genTexture(), data);
    }
    
    private Texture() {
        super(0, 0);
    }
    
    protected Texture(final int glTarget, final int glHandle, final TextureData data) {
        super(glTarget, glHandle);
        this.load(data);
    }
    
    public static Texture createEmpty(final TextureData data) {
        final Texture tex = new Texture();
        tex.data = data;
        return tex;
    }
    
    public void load(final TextureData data) {
        this.data = data;
        this.width = data.getWidth();
        this.height = data.getHeight();
        if (!data.isPrepared()) {
            data.prepare();
        }
        this.bind();
        GLTexture.uploadImageData(3553, data);
        this.unsafeSetFilter(this.minFilter, this.magFilter, true);
        this.unsafeSetWrap(this.uWrap, this.vWrap, true);
        Gl.bindTexture(this.glTarget, 0);
    }
    
    public void draw(final Pixmap pixmap) {
        this.draw(pixmap, 0, 0);
    }
    
    public void draw(final Pixmap pixmap, final int x, final int y) {
        this.bind();
        Gl.texSubImage2D(this.glTarget, 0, x, y, pixmap.getWidth(), pixmap.getHeight(), pixmap.getGLFormat(), pixmap.getGLType(), pixmap.getPixels());
    }
    
    @Override
    public int getDepth() {
        return 0;
    }
    
    public TextureData getTextureData() {
        return this.data;
    }
    
    @Override
    public void dispose() {
        if (this.glHandle == 0) {
            return;
        }
        this.delete();
    }
    
    @Override
    public boolean isDisposed() {
        return this.glHandle == 0;
    }
    
    @Override
    public String toString() {
        if (this.data instanceof FileTextureData) {
            return this.data.toString();
        }
        return super.toString();
    }
    
    public enum TextureFilter
    {
        nearest(9728), 
        linear(9729), 
        mipMap(9987), 
        mipMapNearestNearest(9984), 
        mipMapLinearNearest(9985), 
        mipMapNearestLinear(9986), 
        mipMapLinearLinear(9987);
        
        public final int glEnum;
        
        private TextureFilter(final int glEnum) {
            this.glEnum = glEnum;
        }
        
        public boolean isMipMap() {
            return this.glEnum != 9728 && this.glEnum != 9729;
        }
    }
    
    public enum TextureWrap
    {
        mirroredRepeat(33648), 
        clampToEdge(33071), 
        repeat(10497);
        
        final int glEnum;
        
        private TextureWrap(final int glEnum) {
            this.glEnum = glEnum;
        }
        
        public int getGLEnum() {
            return this.glEnum;
        }
    }
}
