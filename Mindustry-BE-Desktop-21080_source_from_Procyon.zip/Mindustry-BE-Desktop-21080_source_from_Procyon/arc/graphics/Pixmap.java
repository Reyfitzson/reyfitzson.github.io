// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import java.nio.ByteBuffer;
import arc.graphics.g2d.PixmapRegion;
import arc.func.Intc2;
import arc.files.Fi;
import arc.Core;
import java.io.IOException;
import arc.util.ArcRuntimeException;
import arc.util.Disposable;

public class Pixmap implements Disposable
{
    static final int pixmapFormatAlpha = 1;
    static final int pixmapFormatLuminanceAlpha = 2;
    static final int pixmapFormatRGB888 = 3;
    static final int pixmapFormatRGBA8888 = 4;
    static final int pixmapFormatRGB565 = 5;
    static final int pixmapFormatRGBA4444 = 6;
    static final int pixmapScaleNearest = 0;
    static final int pixmapScaleLinear = 1;
    final NativePixmap pixmap;
    int color;
    private Blending blending;
    private PixmapFilter filter;
    private boolean disposed;
    
    public Pixmap(final int width, final int height) {
        this(width, height, Format.rgba8888);
    }
    
    public Pixmap(final int width, final int height, final Format format) {
        this.color = 0;
        this.blending = Blending.sourceOver;
        this.filter = PixmapFilter.bilinear;
        this.pixmap = new NativePixmap(width, height, format.toPixmapFormat());
        this.setColor(0.0f, 0.0f, 0.0f, 0.0f);
        this.fill();
    }
    
    public Pixmap(final byte[] encodedData) {
        this(encodedData, 0, encodedData.length);
    }
    
    public Pixmap(final byte[] encodedData, final int offset, final int len) {
        this.color = 0;
        this.blending = Blending.sourceOver;
        this.filter = PixmapFilter.bilinear;
        try {
            this.pixmap = new NativePixmap(encodedData, offset, len, 0);
        }
        catch (IOException e) {
            throw new ArcRuntimeException("Couldn't load pixmap from image data", e);
        }
    }
    
    public Pixmap(final String file) {
        this(Core.files.internal(file));
    }
    
    public Pixmap(final Fi file) {
        this.color = 0;
        this.blending = Blending.sourceOver;
        this.filter = PixmapFilter.bilinear;
        try {
            final byte[] bytes = file.readBytes();
            this.pixmap = new NativePixmap(bytes, 0, bytes.length, 0);
        }
        catch (Exception e) {
            throw new ArcRuntimeException("Couldn't load file: " + file, e);
        }
    }
    
    public Pixmap(final NativePixmap pixmap) {
        this.color = 0;
        this.blending = Blending.sourceOver;
        this.filter = PixmapFilter.bilinear;
        this.pixmap = pixmap;
    }
    
    public void each(final Intc2 cons) {
        for (int x = 0; x < this.getWidth(); ++x) {
            for (int y = 0; y < this.getHeight(); ++y) {
                cons.get(x, y);
            }
        }
    }
    
    public void setColor(final int color) {
        this.color = color;
    }
    
    public void setColor(final float r, final float g, final float b, final float a) {
        this.color = Color.rgba8888(r, g, b, a);
    }
    
    public void setColor(final Color color) {
        this.color = Color.rgba8888(color.r, color.g, color.b, color.a);
    }
    
    public void fill() {
        clear(this.pixmap.basePtr, this.color);
    }
    
    public void drawLine(final int x, final int y, final int x2, final int y2) {
        drawLine(this.pixmap.basePtr, x, y, x2, y2, this.color);
    }
    
    public void drawRectangle(final int x, final int y, final int width, final int height) {
        drawRect(this.pixmap.basePtr, x, y, width, height, this.color);
    }
    
    public void draw(final PixmapRegion region) {
        this.drawPixmap(region.pixmap, region.x, region.y, region.width, region.height, 0, 0, region.width, region.height);
    }
    
    public void draw(final PixmapRegion region, final int x, final int y) {
        this.drawPixmap(region.pixmap, region.x, region.y, region.width, region.height, x, y, region.width, region.height);
    }
    
    public void draw(final PixmapRegion region, final int x, final int y, final int width, final int height) {
        this.drawPixmap(region.pixmap, region.x, region.y, region.width, region.height, x, y, width, height);
    }
    
    public void draw(final PixmapRegion region, final int x, final int y, final int srcx, final int srcy, final int srcWidth, final int srcHeight) {
        this.drawPixmap(region.pixmap, x, y, region.x + srcx, region.y + srcy, srcWidth, srcHeight);
    }
    
    public void draw(final PixmapRegion region, final int srcx, final int srcy, final int srcWidth, final int srcHeight, final int dstx, final int dsty, final int dstWidth, final int dstHeight) {
        this.drawPixmap(region.pixmap, region.x + srcx, region.y + srcy, srcWidth, srcHeight, dstx, dsty, dstWidth, dstHeight);
    }
    
    public void drawPixmap(final Pixmap pixmap) {
        this.drawPixmap(pixmap, 0, 0);
    }
    
    public void drawPixmap(final Pixmap pixmap, final int x, final int y) {
        this.drawPixmap(pixmap, x, y, 0, 0, pixmap.getWidth(), pixmap.getHeight());
    }
    
    public void drawPixmap(final Pixmap pixmap, final int x, final int y, final int srcx, final int srcy, final int srcWidth, final int srcHeight) {
        drawPixmap(pixmap.pixmap.basePtr, this.pixmap.basePtr, srcx, srcy, srcWidth, srcHeight, x, y, srcWidth, srcHeight);
    }
    
    public void drawPixmap(final Pixmap pixmap, final int srcx, final int srcy, final int srcWidth, final int srcHeight, final int dstx, final int dsty, final int dstWidth, final int dstHeight) {
        drawPixmap(pixmap.pixmap.basePtr, this.pixmap.basePtr, srcx, srcy, srcWidth, srcHeight, dstx, dsty, dstWidth, dstHeight);
    }
    
    public void fillRectangle(final int x, final int y, final int width, final int height) {
        fillRect(this.pixmap.basePtr, x, y, width, height, this.color);
    }
    
    public void drawCircle(final int x, final int y, final int radius) {
        drawCircle(this.pixmap.basePtr, x, y, radius, this.color);
    }
    
    public void fillCircle(final int x, final int y, final int radius) {
        fillCircle(this.pixmap.basePtr, x, y, radius, this.color);
    }
    
    public void fillTriangle(final int x1, final int y1, final int x2, final int y2, final int x3, final int y3) {
        fillTriangle(this.pixmap.basePtr, x1, y1, x2, y2, x3, y3, this.color);
    }
    
    public int getPixel(final int x, final int y) {
        return getPixel(this.pixmap.basePtr, x, y);
    }
    
    public int getWidth() {
        return this.pixmap.width;
    }
    
    public int getHeight() {
        return this.pixmap.height;
    }
    
    @Override
    public void dispose() {
        if (this.disposed) {
            throw new ArcRuntimeException("Pixmap already disposed!");
        }
        free(this.pixmap.basePtr);
        this.disposed = true;
    }
    
    @Override
    public boolean isDisposed() {
        return this.disposed;
    }
    
    public void draw(final int x, final int y, final Color color) {
        this.draw(x, y, color.rgba());
    }
    
    public void draw(final int x, final int y) {
        setPixel(this.pixmap.basePtr, x, y, this.color);
    }
    
    public void draw(final int x, final int y, final int color) {
        setPixel(this.pixmap.basePtr, x, y, color);
    }
    
    public int getGLFormat() {
        return toGlFormat(this.pixmap.format);
    }
    
    public int getGLInternalFormat() {
        return toGlFormat(this.pixmap.format);
    }
    
    public int getGLType() {
        return toGlType(this.pixmap.format);
    }
    
    public ByteBuffer getPixels() {
        if (this.disposed) {
            throw new ArcRuntimeException("Pixmap already disposed");
        }
        return this.pixmap.pixelPtr;
    }
    
    public Format getFormat() {
        return Format.fromPixmapFormat(this.pixmap.format);
    }
    
    public Blending getBlending() {
        return this.blending;
    }
    
    public void setBlending(final Blending blending) {
        this.blending = blending;
        final int blend = (blending != Blending.none) ? 1 : 0;
        setBlend(this.pixmap.basePtr, blend);
    }
    
    public PixmapFilter getFilter() {
        return this.filter;
    }
    
    public void setFilter(final PixmapFilter filter) {
        this.filter = filter;
        final int scale = (filter != PixmapFilter.nearestNeighbour) ? 1 : 0;
        setScale(this.pixmap.basePtr, scale);
    }
    
    public static int toGlFormat(final int format) {
        switch (format) {
            case 1: {
                return 6406;
            }
            case 2: {
                return 6410;
            }
            case 3:
            case 5: {
                return 6407;
            }
            case 4:
            case 6: {
                return 6408;
            }
            default: {
                throw new ArcRuntimeException("unknown format: " + format);
            }
        }
    }
    
    public static int toGlType(final int format) {
        switch (format) {
            case 1:
            case 2:
            case 3:
            case 4: {
                return 5121;
            }
            case 5: {
                return 33635;
            }
            case 6: {
                return 32819;
            }
            default: {
                throw new ArcRuntimeException("unknown format: " + format);
            }
        }
    }
    
    static native ByteBuffer load(final long[] p0, final byte[] p1, final int p2, final int p3);
    
    static native ByteBuffer newPixmap(final long[] p0, final int p1, final int p2, final int p3);
    
    static native void free(final long p0);
    
    private static native void clear(final long p0, final int p1);
    
    private static native void setPixel(final long p0, final int p1, final int p2, final int p3);
    
    private static native int getPixel(final long p0, final int p1, final int p2);
    
    private static native void drawLine(final long p0, final int p1, final int p2, final int p3, final int p4, final int p5);
    
    private static native void drawRect(final long p0, final int p1, final int p2, final int p3, final int p4, final int p5);
    
    private static native void drawCircle(final long p0, final int p1, final int p2, final int p3, final int p4);
    
    private static native void fillRect(final long p0, final int p1, final int p2, final int p3, final int p4, final int p5);
    
    private static native void fillCircle(final long p0, final int p1, final int p2, final int p3, final int p4);
    
    private static native void fillTriangle(final long p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7);
    
    static native void drawPixmap(final long p0, final long p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final int p8, final int p9);
    
    private static native void setBlend(final long p0, final int p1);
    
    private static native void setScale(final long p0, final int p1);
    
    public static native String getFailureReason();
    
    public enum Format
    {
        alpha, 
        intensity, 
        luminanceAlpha, 
        rgb565, 
        rgba4444, 
        rgb888, 
        rgba8888;
        
        public int toPixmapFormat() {
            switch (this) {
                case alpha:
                case intensity: {
                    return 1;
                }
                case luminanceAlpha: {
                    return 2;
                }
                case rgb565: {
                    return 5;
                }
                case rgba4444: {
                    return 6;
                }
                case rgb888: {
                    return 3;
                }
                case rgba8888: {
                    return 4;
                }
                default: {
                    throw new ArcRuntimeException("Unknown Format: " + this);
                }
            }
        }
        
        public static Format fromPixmapFormat(final int format) {
            switch (format) {
                case 1: {
                    return Format.alpha;
                }
                case 2: {
                    return Format.luminanceAlpha;
                }
                case 5: {
                    return Format.rgb565;
                }
                case 6: {
                    return Format.rgba4444;
                }
                case 3: {
                    return Format.rgb888;
                }
                case 4: {
                    return Format.rgba8888;
                }
                default: {
                    throw new ArcRuntimeException("Unknown Pixmap Format: " + format);
                }
            }
        }
        
        public int toGlFormat() {
            return Pixmap.toGlFormat(this.toPixmapFormat());
        }
        
        public int toGlType() {
            return Pixmap.toGlType(this.toPixmapFormat());
        }
    }
    
    public enum Blending
    {
        none, 
        sourceOver;
    }
    
    public enum PixmapFilter
    {
        nearestNeighbour, 
        bilinear;
    }
    
    private static class NativePixmap
    {
        long basePtr;
        int width;
        int height;
        int format;
        ByteBuffer pixelPtr;
        long[] nativeData;
        
        public NativePixmap(final byte[] encodedData, final int offset, final int len, final int requestedFormat) throws IOException {
            this.nativeData = new long[4];
            this.pixelPtr = Pixmap.load(this.nativeData, encodedData, offset, len);
            if (this.pixelPtr == null) {
                throw new IOException("Error loading pixmap: " + Pixmap.getFailureReason());
            }
            this.basePtr = this.nativeData[0];
            this.width = (int)this.nativeData[1];
            this.height = (int)this.nativeData[2];
            this.format = (int)this.nativeData[3];
            if (requestedFormat != 0 && requestedFormat != this.format) {
                this.convert(requestedFormat);
            }
        }
        
        public NativePixmap(final int width, final int height, final int format) throws ArcRuntimeException {
            this.nativeData = new long[4];
            this.pixelPtr = Pixmap.newPixmap(this.nativeData, width, height, format);
            if (this.pixelPtr == null) {
                throw new ArcRuntimeException("Error loading pixmap.");
            }
            this.basePtr = this.nativeData[0];
            this.width = (int)this.nativeData[1];
            this.height = (int)this.nativeData[2];
            this.format = (int)this.nativeData[3];
        }
        
        private void convert(final int requestedFormat) {
            final NativePixmap pixmap = new NativePixmap(this.width, this.height, requestedFormat);
            Pixmap.drawPixmap(this.basePtr, pixmap.basePtr, 0, 0, this.width, this.height, 0, 0, this.width, this.height);
            Pixmap.free(this.basePtr);
            this.basePtr = pixmap.basePtr;
            this.format = pixmap.format;
            this.height = pixmap.height;
            this.nativeData = pixmap.nativeData;
            this.pixelPtr = pixmap.pixelPtr;
            this.width = pixmap.width;
        }
    }
}
