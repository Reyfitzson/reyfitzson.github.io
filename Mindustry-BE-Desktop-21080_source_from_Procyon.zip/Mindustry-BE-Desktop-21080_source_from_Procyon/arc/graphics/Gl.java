// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import arc.util.Buffers;
import java.nio.FloatBuffer;
import java.nio.Buffer;
import arc.Core;
import java.util.Arrays;
import arc.struct.Bits;
import java.nio.IntBuffer;

public class Gl
{
    private static final boolean optimize = true;
    public static final int esVersion20 = 1;
    public static final int depthBufferBit = 256;
    public static final int stencilBufferBit = 1024;
    public static final int colorBufferBit = 16384;
    public static final int falseV = 0;
    public static final int trueV = 1;
    public static final int points = 0;
    public static final int lines = 1;
    public static final int lineLoop = 2;
    public static final int lineStrip = 3;
    public static final int triangles = 4;
    public static final int triangleStrip = 5;
    public static final int triangleFan = 6;
    public static final int zero = 0;
    public static final int one = 1;
    public static final int srcColor = 768;
    public static final int oneMinusSrcColor = 769;
    public static final int srcAlpha = 770;
    public static final int oneMinusSrcAlpha = 771;
    public static final int dstAlpha = 772;
    public static final int oneMinusDstAlpha = 773;
    public static final int dstColor = 774;
    public static final int oneMinusDstColor = 775;
    public static final int srcAlphaSaturate = 776;
    public static final int funcAdd = 32774;
    public static final int blendEquation = 32777;
    public static final int blendEquationRgb = 32777;
    public static final int blendEquationAlpha = 34877;
    public static final int funcSubtract = 32778;
    public static final int funcReverseSubtract = 32779;
    public static final int min = 32775;
    public static final int max = 32776;
    public static final int blendDstRgb = 32968;
    public static final int blendSrcRgb = 32969;
    public static final int blendDstAlpha = 32970;
    public static final int blendSrcAlpha = 32971;
    public static final int constantColor = 32769;
    public static final int oneMinusConstantColor = 32770;
    public static final int constantAlpha = 32771;
    public static final int oneMinusConstantAlpha = 32772;
    public static final int blendColor = 32773;
    public static final int arrayBuffer = 34962;
    public static final int elementArrayBuffer = 34963;
    public static final int arrayBufferBinding = 34964;
    public static final int elementArrayBufferBinding = 34965;
    public static final int streamDraw = 35040;
    public static final int staticDraw = 35044;
    public static final int dynamicDraw = 35048;
    public static final int bufferSize = 34660;
    public static final int bufferUsage = 34661;
    public static final int currentVertexAttrib = 34342;
    public static final int front = 1028;
    public static final int back = 1029;
    public static final int frontAndBack = 1032;
    public static final int texture2d = 3553;
    public static final int cullFace = 2884;
    public static final int blend = 3042;
    public static final int dither = 3024;
    public static final int stencilTest = 2960;
    public static final int depthTest = 2929;
    public static final int scissorTest = 3089;
    public static final int polygonOffsetFill = 32823;
    public static final int sampleAlphaToCoverage = 32926;
    public static final int sampleCoverage = 32928;
    public static final int noError = 0;
    public static final int invalidEnum = 1280;
    public static final int invalidValue = 1281;
    public static final int invalidOperation = 1282;
    public static final int outOfMemory = 1285;
    public static final int cw = 2304;
    public static final int ccw = 2305;
    public static final int lineWidth = 2849;
    public static final int aliasedPointSizeRange = 33901;
    public static final int aliasedLineWidthRange = 33902;
    public static final int cullFaceMode = 2885;
    public static final int frontFace = 2886;
    public static final int depthRange = 2928;
    public static final int depthWritemask = 2930;
    public static final int depthClearValue = 2931;
    public static final int depthFunc = 2932;
    public static final int stencilClearValue = 2961;
    public static final int stencilFunc = 2962;
    public static final int stencilFail = 2964;
    public static final int stencilPassDepthFail = 2965;
    public static final int stencilPassDepthPass = 2966;
    public static final int stencilRef = 2967;
    public static final int stencilValueMask = 2963;
    public static final int stencilWritemask = 2968;
    public static final int stencilBackFunc = 34816;
    public static final int stencilBackFail = 34817;
    public static final int stencilBackPassDepthFail = 34818;
    public static final int stencilBackPassDepthPass = 34819;
    public static final int stencilBackRef = 36003;
    public static final int stencilBackValueMask = 36004;
    public static final int stencilBackWritemask = 36005;
    public static final int viewport = 2978;
    public static final int scissorBox = 3088;
    public static final int colorClearValue = 3106;
    public static final int colorWritemask = 3107;
    public static final int unpackAlignment = 3317;
    public static final int packAlignment = 3333;
    public static final int maxTextureSize = 3379;
    public static final int maxTextureUnits = 34018;
    public static final int maxViewportDims = 3386;
    public static final int subpixelBits = 3408;
    public static final int redBits = 3410;
    public static final int greenBits = 3411;
    public static final int blueBits = 3412;
    public static final int alphaBits = 3413;
    public static final int depthBits = 3414;
    public static final int stencilBits = 3415;
    public static final int polygonOffsetUnits = 10752;
    public static final int polygonOffsetFactor = 32824;
    public static final int textureBinding2d = 32873;
    public static final int sampleBuffers = 32936;
    public static final int samples = 32937;
    public static final int sampleCoverageValue = 32938;
    public static final int sampleCoverageInvert = 32939;
    public static final int numCompressedTextureFormats = 34466;
    public static final int compressedTextureFormats = 34467;
    public static final int dontCare = 4352;
    public static final int fastest = 4353;
    public static final int nicest = 4354;
    public static final int generateMipmap = 33169;
    public static final int generateMipmapHint = 33170;
    public static final int byteV = 5120;
    public static final int unsignedByte = 5121;
    public static final int shortV = 5122;
    public static final int unsignedShort = 5123;
    public static final int intV = 5124;
    public static final int unsignedInt = 5125;
    public static final int floatV = 5126;
    public static final int fixed = 5132;
    public static final int depthComponent = 6402;
    public static final int alpha = 6406;
    public static final int rgb = 6407;
    public static final int rgba = 6408;
    public static final int luminance = 6409;
    public static final int luminanceAlpha = 6410;
    public static final int unsignedShort4444 = 32819;
    public static final int unsignedShort5551 = 32820;
    public static final int unsignedShort565 = 33635;
    public static final int fragmentShader = 35632;
    public static final int vertexShader = 35633;
    public static final int maxVertexAttribs = 34921;
    public static final int maxVertexUniformVectors = 36347;
    public static final int maxVaryingVectors = 36348;
    public static final int maxCombinedTextureImageUnits = 35661;
    public static final int maxVertexTextureImageUnits = 35660;
    public static final int maxTextureImageUnits = 34930;
    public static final int maxFragmentUniformVectors = 36349;
    public static final int shaderType = 35663;
    public static final int deleteStatus = 35712;
    public static final int linkStatus = 35714;
    public static final int validateStatus = 35715;
    public static final int attachedShaders = 35717;
    public static final int activeUniforms = 35718;
    public static final int activeUniformMaxLength = 35719;
    public static final int activeAttributes = 35721;
    public static final int activeAttributeMaxLength = 35722;
    public static final int shadingLanguageVersion = 35724;
    public static final int currentProgram = 35725;
    public static final int never = 512;
    public static final int less = 513;
    public static final int equal = 514;
    public static final int lequal = 515;
    public static final int greater = 516;
    public static final int notequal = 517;
    public static final int gequal = 518;
    public static final int always = 519;
    public static final int keep = 7680;
    public static final int replace = 7681;
    public static final int incr = 7682;
    public static final int decr = 7683;
    public static final int invert = 5386;
    public static final int incrWrap = 34055;
    public static final int decrWrap = 34056;
    public static final int vendor = 7936;
    public static final int renderer = 7937;
    public static final int version = 7938;
    public static final int extensions = 7939;
    public static final int nearest = 9728;
    public static final int linear = 9729;
    public static final int nearestMipmapNearest = 9984;
    public static final int linearMipmapNearest = 9985;
    public static final int nearestMipmapLinear = 9986;
    public static final int linearMipmapLinear = 9987;
    public static final int textureMagFilter = 10240;
    public static final int textureMinFilter = 10241;
    public static final int textureWrapS = 10242;
    public static final int textureWrapT = 10243;
    public static final int texture = 5890;
    public static final int textureCubeMap = 34067;
    public static final int textureBindingCubeMap = 34068;
    public static final int textureCubeMapPositiveX = 34069;
    public static final int textureCubeMapNegativeX = 34070;
    public static final int textureCubeMapPositiveY = 34071;
    public static final int textureCubeMapNegativeY = 34072;
    public static final int textureCubeMapPositiveZ = 34073;
    public static final int textureCubeMapNegativeZ = 34074;
    public static final int maxCubeMapTextureSize = 34076;
    public static final int texture0 = 33984;
    public static final int texture1 = 33985;
    public static final int texture2 = 33986;
    public static final int texture3 = 33987;
    public static final int texture4 = 33988;
    public static final int texture5 = 33989;
    public static final int texture6 = 33990;
    public static final int texture7 = 33991;
    public static final int texture8 = 33992;
    public static final int texture9 = 33993;
    public static final int texture10 = 33994;
    public static final int texture11 = 33995;
    public static final int texture12 = 33996;
    public static final int texture13 = 33997;
    public static final int texture14 = 33998;
    public static final int texture15 = 33999;
    public static final int texture16 = 34000;
    public static final int texture17 = 34001;
    public static final int texture18 = 34002;
    public static final int texture19 = 34003;
    public static final int texture20 = 34004;
    public static final int texture21 = 34005;
    public static final int texture22 = 34006;
    public static final int texture23 = 34007;
    public static final int texture24 = 34008;
    public static final int texture25 = 34009;
    public static final int texture26 = 34010;
    public static final int texture27 = 34011;
    public static final int texture28 = 34012;
    public static final int texture29 = 34013;
    public static final int texture30 = 34014;
    public static final int texture31 = 34015;
    public static final int activeTexture = 34016;
    public static final int repeat = 10497;
    public static final int clampToEdge = 33071;
    public static final int mirroredRepeat = 33648;
    public static final int floatVec2 = 35664;
    public static final int floatVec3 = 35665;
    public static final int floatVec4 = 35666;
    public static final int intVec2 = 35667;
    public static final int intVec3 = 35668;
    public static final int intVec4 = 35669;
    public static final int bool = 35670;
    public static final int boolVec2 = 35671;
    public static final int boolVec3 = 35672;
    public static final int boolVec4 = 35673;
    public static final int floatMat2 = 35674;
    public static final int floatMat3 = 35675;
    public static final int floatMat4 = 35676;
    public static final int sampler2d = 35678;
    public static final int samplerCube = 35680;
    public static final int vertexAttribArrayEnabled = 34338;
    public static final int vertexAttribArraySize = 34339;
    public static final int vertexAttribArrayStride = 34340;
    public static final int vertexAttribArrayType = 34341;
    public static final int vertexAttribArrayNormalized = 34922;
    public static final int vertexAttribArrayPointer = 34373;
    public static final int vertexAttribArrayBufferBinding = 34975;
    public static final int implementationColorReadType = 35738;
    public static final int implementationColorReadFormat = 35739;
    public static final int compileStatus = 35713;
    public static final int infoLogLength = 35716;
    public static final int shaderSourceLength = 35720;
    public static final int shaderCompiler = 36346;
    public static final int shaderBinaryFormats = 36344;
    public static final int numShaderBinaryFormats = 36345;
    public static final int lowFloat = 36336;
    public static final int mediumFloat = 36337;
    public static final int highFloat = 36338;
    public static final int lowInt = 36339;
    public static final int mediumInt = 36340;
    public static final int highInt = 36341;
    public static final int framebuffer = 36160;
    public static final int renderbuffer = 36161;
    public static final int rgba4 = 32854;
    public static final int rgb5A1 = 32855;
    public static final int rgb565 = 36194;
    public static final int depthComponent16 = 33189;
    public static final int stencilIndex = 6401;
    public static final int stencilIndex8 = 36168;
    public static final int renderbufferWidth = 36162;
    public static final int renderbufferHeight = 36163;
    public static final int renderbufferInternalFormat = 36164;
    public static final int renderbufferRedSize = 36176;
    public static final int renderbufferGreenSize = 36177;
    public static final int renderbufferBlueSize = 36178;
    public static final int renderbufferAlphaSize = 36179;
    public static final int renderbufferDepthSize = 36180;
    public static final int renderbufferStencilSize = 36181;
    public static final int framebufferAttachmentObjectType = 36048;
    public static final int framebufferAttachmentObjectName = 36049;
    public static final int framebufferAttachmentTextureLevel = 36050;
    public static final int framebufferAttachmentTextureCubeMapFace = 36051;
    public static final int colorAttachment0 = 36064;
    public static final int depthAttachment = 36096;
    public static final int stencilAttachment = 36128;
    public static final int none = 0;
    public static final int framebufferComplete = 36053;
    public static final int framebufferIncompleteAttachment = 36054;
    public static final int framebufferIncompleteMissingAttachment = 36055;
    public static final int framebufferIncompleteDimensions = 36057;
    public static final int framebufferUnsupported = 36061;
    public static final int framebufferBinding = 36006;
    public static final int renderbufferBinding = 36007;
    public static final int maxRenderbufferSize = 34024;
    public static final int invalidFramebufferOperation = 1286;
    public static final int vertexProgramPointSize = 34370;
    private static IntBuffer ibuf;
    private static IntBuffer ibuf2;
    private static int lastActiveTexture;
    private static int[] lastBoundTextures;
    private static int lastUsedProgram;
    private static Bits enabled;
    private static boolean wasDepthMask;
    private static int lastSfactor;
    private static int lastDfactor;
    
    public static void reset() {
        Gl.lastActiveTexture = -1;
        Arrays.fill(Gl.lastBoundTextures, -1);
        Gl.lastUsedProgram = 0;
        Gl.enabled.clear();
        Gl.wasDepthMask = true;
        Gl.lastSfactor = -1;
        Gl.lastDfactor = -1;
    }
    
    public static void activeTexture(final int texture) {
        if (Gl.lastActiveTexture == texture) {
            return;
        }
        Core.gl.glActiveTexture(texture);
        Gl.lastActiveTexture = texture;
    }
    
    public static void bindTexture(final int target, final int texture) {
        if (target == 3553) {
            final int index = Gl.lastActiveTexture - 33984;
            if (index >= 0 && index < Gl.lastBoundTextures.length) {
                if (Gl.lastBoundTextures[index] == texture) {
                    return;
                }
                Gl.lastBoundTextures[index] = texture;
            }
        }
        Core.gl.glBindTexture(target, texture);
    }
    
    public static void blendFunc(final int sfactor, final int dfactor) {
        if (Gl.lastSfactor == sfactor && Gl.lastDfactor == dfactor) {
            return;
        }
        Core.gl.glBlendFunc(Gl.lastSfactor = sfactor, Gl.lastDfactor = dfactor);
        Gl.lastSfactor = sfactor;
        Gl.lastDfactor = dfactor;
    }
    
    public static void clear(final int mask) {
        Core.gl.glClear(mask);
    }
    
    public static void clearColor(final float red, final float green, final float blue, final float alpha) {
        Core.gl.glClearColor(red, green, blue, alpha);
    }
    
    public static void clearDepthf(final float depth) {
        Core.gl.glClearDepthf(depth);
    }
    
    public static void clearStencil(final int s) {
        Core.gl.glClearStencil(s);
    }
    
    public static void colorMask(final boolean red, final boolean green, final boolean blue, final boolean alpha) {
        Core.gl.glColorMask(red, green, blue, alpha);
    }
    
    public static void compressedTexImage2D(final int target, final int level, final int internalformat, final int width, final int height, final int border, final int imageSize, final Buffer data) {
        Core.gl.glCompressedTexImage2D(target, level, internalformat, width, height, border, imageSize, data);
    }
    
    public static void compressedTexSubImage2D(final int target, final int level, final int xoffset, final int yoffset, final int width, final int height, final int format, final int imageSize, final Buffer data) {
        Core.gl.glCompressedTexSubImage2D(target, level, xoffset, yoffset, width, height, format, imageSize, data);
    }
    
    public static void copyTexImage2D(final int target, final int level, final int internalformat, final int x, final int y, final int width, final int height, final int border) {
        Core.gl.glCopyTexImage2D(target, level, internalformat, x, y, width, height, border);
    }
    
    public static void copyTexSubImage2D(final int target, final int level, final int xoffset, final int yoffset, final int x, final int y, final int width, final int height) {
        Core.gl.glCopyTexSubImage2D(target, level, xoffset, yoffset, x, y, width, height);
    }
    
    public static void cullFace(final int mode) {
        Core.gl.glCullFace(mode);
    }
    
    public static void deleteTexture(final int texture) {
        for (int i = 0; i < Gl.lastBoundTextures.length; ++i) {
            if (Gl.lastBoundTextures[i] == texture) {
                Gl.lastBoundTextures[i] = -1;
            }
        }
        Core.gl.glDeleteTexture(texture);
    }
    
    public static void depthFunc(final int func) {
        Core.gl.glDepthFunc(func);
    }
    
    public static void depthMask(final boolean flag) {
        Core.gl.glDepthMask(flag);
    }
    
    public static void depthRangef(final float zNear, final float zFar) {
        Core.gl.glDepthRangef(zNear, zFar);
    }
    
    public static void disable(final int cap) {
        if (!Gl.enabled.get(cap)) {
            return;
        }
        Core.gl.glDisable(cap);
        Gl.enabled.clear(cap);
    }
    
    public static void drawArrays(final int mode, final int first, final int count) {
        Core.gl.glDrawArrays(mode, first, count);
    }
    
    public static void drawElements(final int mode, final int count, final int type, final Buffer indices) {
        Core.gl.glDrawElements(mode, count, type, indices);
    }
    
    public static void enable(final int cap) {
        if (Gl.enabled.get(cap)) {
            return;
        }
        Core.gl.glEnable(cap);
        Gl.enabled.set(cap);
    }
    
    public static void finish() {
        Core.gl.glFinish();
    }
    
    public static void flush() {
        Core.gl.glFlush();
    }
    
    public static void frontFace(final int mode) {
        Core.gl.glFrontFace(mode);
    }
    
    public static int genTexture() {
        return Core.gl.glGenTexture();
    }
    
    public static int getError() {
        return Core.gl.glGetError();
    }
    
    public static void getIntegerv(final int pname, final IntBuffer params) {
        Core.gl.glGetIntegerv(pname, params);
    }
    
    public static int getInt(final int name) {
        Gl.ibuf.position(0);
        getIntegerv(name, Gl.ibuf);
        return Gl.ibuf.get(0);
    }
    
    public static String getString(final int name) {
        return Core.gl.glGetString(name);
    }
    
    public static void hint(final int target, final int mode) {
        Core.gl.glHint(target, mode);
    }
    
    public static void pixelStorei(final int pname, final int param) {
        Core.gl.glPixelStorei(pname, param);
    }
    
    public static void polygonOffset(final float factor, final float units) {
        Core.gl.glPolygonOffset(factor, units);
    }
    
    public static void readPixels(final int x, final int y, final int width, final int height, final int format, final int type, final Buffer pixels) {
        Core.gl.glReadPixels(x, y, width, height, format, type, pixels);
    }
    
    public static void scissor(final int x, final int y, final int width, final int height) {
        Core.gl.glScissor(x, y, width, height);
    }
    
    public static void stencilFunc(final int func, final int ref, final int mask) {
        Core.gl.glStencilFunc(func, ref, mask);
    }
    
    public static void stencilMask(final int mask) {
        Core.gl.glStencilMask(mask);
    }
    
    public static void stencilOp(final int fail, final int zfail, final int zpass) {
        Core.gl.glStencilOp(fail, zfail, zpass);
    }
    
    public static void texImage2D(final int target, final int level, final int internalformat, final int width, final int height, final int border, final int format, final int type, final Buffer pixels) {
        Core.gl.glTexImage2D(target, level, internalformat, width, height, border, format, type, pixels);
    }
    
    public static void texParameterf(final int target, final int pname, final float param) {
        Core.gl.glTexParameterf(target, pname, param);
    }
    
    public static void texSubImage2D(final int target, final int level, final int xoffset, final int yoffset, final int width, final int height, final int format, final int type, final Buffer pixels) {
        Core.gl.glTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type, pixels);
    }
    
    public static void viewport(final int x, final int y, final int width, final int height) {
        Core.gl.glViewport(x, y, width, height);
    }
    
    public static void attachShader(final int program, final int shader) {
        Core.gl.glAttachShader(program, shader);
    }
    
    public static void bindAttribLocation(final int program, final int index, final String name) {
        Core.gl.glBindAttribLocation(program, index, name);
    }
    
    public static void bindBuffer(final int target, final int buffer) {
        Core.gl.glBindBuffer(target, buffer);
    }
    
    public static void bindFramebuffer(final int target, final int framebuffer) {
        Core.gl.glBindFramebuffer(target, framebuffer);
    }
    
    public static void bindRenderbuffer(final int target, final int renderbuffer) {
        Core.gl.glBindRenderbuffer(target, renderbuffer);
    }
    
    public static void blendColor(final float red, final float green, final float blue, final float alpha) {
        Core.gl.glBlendColor(red, green, blue, alpha);
    }
    
    public static void blendEquation(final int mode) {
        Core.gl.glBlendEquation(mode);
    }
    
    public static void blendEquationSeparate(final int modeRGB, final int modeAlpha) {
        Core.gl.glBlendEquationSeparate(modeRGB, modeAlpha);
    }
    
    public static void blendFuncSeparate(final int srcRGB, final int dstRGB, final int srcAlpha, final int dstAlpha) {
        Core.gl.glBlendFuncSeparate(srcRGB, dstRGB, srcAlpha, dstAlpha);
    }
    
    public static void bufferData(final int target, final int size, final Buffer data, final int usage) {
        Core.gl.glBufferData(target, size, data, usage);
    }
    
    public static void bufferSubData(final int target, final int offset, final int size, final Buffer data) {
        Core.gl.glBufferSubData(target, offset, size, data);
    }
    
    public static int checkFramebufferStatus(final int target) {
        return Core.gl.glCheckFramebufferStatus(target);
    }
    
    public static void compileShader(final int shader) {
        Core.gl.glCompileShader(shader);
    }
    
    public static int createProgram() {
        return Core.gl.glCreateProgram();
    }
    
    public static int createShader(final int type) {
        return Core.gl.glCreateShader(type);
    }
    
    public static void deleteBuffer(final int buffer) {
        Core.gl.glDeleteBuffer(buffer);
    }
    
    public static void deleteFramebuffer(final int framebuffer) {
        Core.gl.glDeleteFramebuffer(framebuffer);
    }
    
    public static void deleteProgram(final int program) {
        Core.gl.glDeleteProgram(program);
    }
    
    public static void deleteRenderbuffer(final int renderbuffer) {
        Core.gl.glDeleteRenderbuffer(renderbuffer);
    }
    
    public static void deleteShader(final int shader) {
        Core.gl.glDeleteShader(shader);
    }
    
    public static void detachShader(final int program, final int shader) {
        Core.gl.glDetachShader(program, shader);
    }
    
    public static void disableVertexAttribArray(final int index) {
        Core.gl.glDisableVertexAttribArray(index);
    }
    
    public static void drawElements(final int mode, final int count, final int type, final int indices) {
        Core.gl.glDrawElements(mode, count, type, indices);
    }
    
    public static void enableVertexAttribArray(final int index) {
        Core.gl.glEnableVertexAttribArray(index);
    }
    
    public static void framebufferRenderbuffer(final int target, final int attachment, final int renderbuffertarget, final int renderbuffer) {
        Core.gl.glFramebufferRenderbuffer(target, attachment, renderbuffertarget, renderbuffer);
    }
    
    public static void framebufferTexture2D(final int target, final int attachment, final int textarget, final int texture, final int level) {
        Core.gl.glFramebufferTexture2D(target, attachment, textarget, texture, level);
    }
    
    public static int genBuffer() {
        return Core.gl.glGenBuffer();
    }
    
    public static void generateMipmap(final int target) {
        Core.gl.glGenerateMipmap(target);
    }
    
    public static int genFramebuffer() {
        return Core.gl.glGenFramebuffer();
    }
    
    public static int genRenderbuffer() {
        return Core.gl.glGenRenderbuffer();
    }
    
    public static String getActiveAttrib(final int program, final int index, final IntBuffer size, final IntBuffer type) {
        return Core.gl.glGetActiveAttrib(program, index, size, type);
    }
    
    public static String getActiveUniform(final int program, final int index, final IntBuffer size, final IntBuffer type) {
        return Core.gl.glGetActiveUniform(program, index, size, type);
    }
    
    public static int getAttribLocation(final int program, final String name) {
        return Core.gl.glGetAttribLocation(program, name);
    }
    
    public static void getBooleanv(final int pname, final Buffer params) {
        Core.gl.glGetBooleanv(pname, params);
    }
    
    public static void getBufferParameteriv(final int target, final int pname, final IntBuffer params) {
        Core.gl.glGetBufferParameteriv(target, pname, params);
    }
    
    public static void getFloatv(final int pname, final FloatBuffer params) {
        Core.gl.glGetFloatv(pname, params);
    }
    
    public static void getFramebufferAttachmentParameteriv(final int target, final int attachment, final int pname, final IntBuffer params) {
        Core.gl.glGetFramebufferAttachmentParameteriv(target, attachment, pname, params);
    }
    
    public static void getProgramiv(final int program, final int pname, final IntBuffer params) {
        Core.gl.glGetProgramiv(program, pname, params);
    }
    
    public static String getProgramInfoLog(final int program) {
        return Core.gl.glGetProgramInfoLog(program);
    }
    
    public static void getRenderbufferParameteriv(final int target, final int pname, final IntBuffer params) {
        Core.gl.glGetRenderbufferParameteriv(target, pname, params);
    }
    
    public static void getShaderiv(final int shader, final int pname, final IntBuffer params) {
        Core.gl.glGetShaderiv(shader, pname, params);
    }
    
    public static String getShaderInfoLog(final int shader) {
        return Core.gl.glGetShaderInfoLog(shader);
    }
    
    public static void getShaderPrecisionFormat(final int shadertype, final int precisiontype, final IntBuffer range, final IntBuffer precision) {
        Core.gl.glGetShaderPrecisionFormat(shadertype, precisiontype, range, precision);
    }
    
    public static void getTexParameterfv(final int target, final int pname, final FloatBuffer params) {
        Core.gl.glGetTexParameterfv(target, pname, params);
    }
    
    public static void getTexParameteriv(final int target, final int pname, final IntBuffer params) {
        Core.gl.glGetTexParameteriv(target, pname, params);
    }
    
    public static void getUniformfv(final int program, final int location, final FloatBuffer params) {
        Core.gl.glGetUniformfv(program, location, params);
    }
    
    public static void getUniformiv(final int program, final int location, final IntBuffer params) {
        Core.gl.glGetUniformiv(program, location, params);
    }
    
    public static int getUniformLocation(final int program, final String name) {
        return Core.gl.glGetUniformLocation(program, name);
    }
    
    public static void getVertexAttribfv(final int index, final int pname, final FloatBuffer params) {
        Core.gl.glGetVertexAttribfv(index, pname, params);
    }
    
    public static void getVertexAttribiv(final int index, final int pname, final IntBuffer params) {
        Core.gl.glGetVertexAttribiv(index, pname, params);
    }
    
    public static boolean isBuffer(final int buffer) {
        return Core.gl.glIsBuffer(buffer);
    }
    
    public static boolean isEnabled(final int cap) {
        return Core.gl.glIsEnabled(cap);
    }
    
    public static boolean isFramebuffer(final int framebuffer) {
        return Core.gl.glIsFramebuffer(framebuffer);
    }
    
    public static boolean isProgram(final int program) {
        return Core.gl.glIsProgram(program);
    }
    
    public static boolean isRenderbuffer(final int renderbuffer) {
        return Core.gl.glIsRenderbuffer(renderbuffer);
    }
    
    public static boolean isShader(final int shader) {
        return Core.gl.glIsShader(shader);
    }
    
    public static boolean isTexture(final int texture) {
        return Core.gl.glIsTexture(texture);
    }
    
    public static void linkProgram(final int program) {
        Core.gl.glLinkProgram(program);
    }
    
    public static void releaseShaderCompiler() {
        Core.gl.glReleaseShaderCompiler();
    }
    
    public static void renderbufferStorage(final int target, final int internalformat, final int width, final int height) {
        Core.gl.glRenderbufferStorage(target, internalformat, width, height);
    }
    
    public static void sampleCoverage(final float value, final boolean invert) {
        Core.gl.glSampleCoverage(value, invert);
    }
    
    public static void shaderSource(final int shader, final String string) {
        Core.gl.glShaderSource(shader, string);
    }
    
    public static void stencilFuncSeparate(final int face, final int func, final int ref, final int mask) {
        Core.gl.glStencilFuncSeparate(face, func, ref, mask);
    }
    
    public static void stencilMaskSeparate(final int face, final int mask) {
        Core.gl.glStencilMaskSeparate(face, mask);
    }
    
    public static void stencilOpSeparate(final int face, final int fail, final int zfail, final int zpass) {
        Core.gl.glStencilOpSeparate(face, fail, zfail, zpass);
    }
    
    public static void texParameterfv(final int target, final int pname, final FloatBuffer params) {
        Core.gl.glTexParameterfv(target, pname, params);
    }
    
    public static void texParameteri(final int target, final int pname, final int param) {
        Core.gl.glTexParameteri(target, pname, param);
    }
    
    public static void texParameteriv(final int target, final int pname, final IntBuffer params) {
        Core.gl.glTexParameteriv(target, pname, params);
    }
    
    public static void uniform1f(final int location, final float x) {
        Core.gl.glUniform1f(location, x);
    }
    
    public static void uniform1fv(final int location, final int count, final FloatBuffer v) {
        Core.gl.glUniform1fv(location, count, v);
    }
    
    public static void uniform1fv(final int location, final int count, final float[] v, final int offset) {
        Core.gl.glUniform1fv(location, count, v, offset);
    }
    
    public static void uniform1i(final int location, final int x) {
        Core.gl.glUniform1i(location, x);
    }
    
    public static void uniform1iv(final int location, final int count, final IntBuffer v) {
        Core.gl.glUniform1iv(location, count, v);
    }
    
    public static void uniform1iv(final int location, final int count, final int[] v, final int offset) {
        Core.gl.glUniform1iv(location, count, v, offset);
    }
    
    public static void uniform2f(final int location, final float x, final float y) {
        Core.gl.glUniform2f(location, x, y);
    }
    
    public static void uniform2fv(final int location, final int count, final FloatBuffer v) {
        Core.gl.glUniform2fv(location, count, v);
    }
    
    public static void uniform2fv(final int location, final int count, final float[] v, final int offset) {
        Core.gl.glUniform2fv(location, count, v, offset);
    }
    
    public static void uniform2i(final int location, final int x, final int y) {
        Core.gl.glUniform2i(location, x, y);
    }
    
    public static void uniform2iv(final int location, final int count, final IntBuffer v) {
        Core.gl.glUniform2iv(location, count, v);
    }
    
    public static void uniform2iv(final int location, final int count, final int[] v, final int offset) {
        Core.gl.glUniform2iv(location, count, v, offset);
    }
    
    public static void uniform3f(final int location, final float x, final float y, final float z) {
        Core.gl.glUniform3f(location, x, y, z);
    }
    
    public static void uniform3fv(final int location, final int count, final FloatBuffer v) {
        Core.gl.glUniform3fv(location, count, v);
    }
    
    public static void uniform3fv(final int location, final int count, final float[] v, final int offset) {
        Core.gl.glUniform3fv(location, count, v, offset);
    }
    
    public static void uniform3i(final int location, final int x, final int y, final int z) {
        Core.gl.glUniform3i(location, x, y, z);
    }
    
    public static void uniform3iv(final int location, final int count, final IntBuffer v) {
        Core.gl.glUniform3iv(location, count, v);
    }
    
    public static void uniform3iv(final int location, final int count, final int[] v, final int offset) {
        Core.gl.glUniform3iv(location, count, v, offset);
    }
    
    public static void uniform4f(final int location, final float x, final float y, final float z, final float w) {
        Core.gl.glUniform4f(location, x, y, z, w);
    }
    
    public static void uniform4fv(final int location, final int count, final FloatBuffer v) {
        Core.gl.glUniform4fv(location, count, v);
    }
    
    public static void uniform4fv(final int location, final int count, final float[] v, final int offset) {
        Core.gl.glUniform4fv(location, count, v, offset);
    }
    
    public static void uniform4i(final int location, final int x, final int y, final int z, final int w) {
        Core.gl.glUniform4i(location, x, y, z, w);
    }
    
    public static void uniform4iv(final int location, final int count, final IntBuffer v) {
        Core.gl.glUniform4iv(location, count, v);
    }
    
    public static void uniform4iv(final int location, final int count, final int[] v, final int offset) {
        Core.gl.glUniform4iv(location, count, v, offset);
    }
    
    public static void uniformMatrix2fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        Core.gl.glUniformMatrix2fv(location, count, transpose, value);
    }
    
    public static void uniformMatrix2fv(final int location, final int count, final boolean transpose, final float[] value, final int offset) {
        Core.gl.glUniformMatrix2fv(location, count, transpose, value, offset);
    }
    
    public static void uniformMatrix3fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        Core.gl.glUniformMatrix3fv(location, count, transpose, value);
    }
    
    public static void uniformMatrix3fv(final int location, final int count, final boolean transpose, final float[] value, final int offset) {
        Core.gl.glUniformMatrix3fv(location, count, transpose, value, offset);
    }
    
    public static void uniformMatrix4fv(final int location, final int count, final boolean transpose, final FloatBuffer value) {
        Core.gl.glUniformMatrix4fv(location, count, transpose, value);
    }
    
    public static void uniformMatrix4fv(final int location, final int count, final boolean transpose, final float[] value, final int offset) {
        Core.gl.glUniformMatrix4fv(location, count, transpose, value, offset);
    }
    
    public static void useProgram(final int program) {
        if (Gl.lastUsedProgram == program) {
            return;
        }
        Core.gl.glUseProgram(program);
        Gl.lastUsedProgram = program;
    }
    
    public static void validateProgram(final int program) {
        Core.gl.glValidateProgram(program);
    }
    
    public static void vertexAttrib1f(final int indx, final float x) {
        Core.gl.glVertexAttrib1f(indx, x);
    }
    
    public static void vertexAttrib1fv(final int indx, final FloatBuffer values) {
        Core.gl.glVertexAttrib1fv(indx, values);
    }
    
    public static void vertexAttrib2f(final int indx, final float x, final float y) {
        Core.gl.glVertexAttrib2f(indx, x, y);
    }
    
    public static void vertexAttrib2fv(final int indx, final FloatBuffer values) {
        Core.gl.glVertexAttrib2fv(indx, values);
    }
    
    public static void vertexAttrib3f(final int indx, final float x, final float y, final float z) {
        Core.gl.glVertexAttrib3f(indx, x, y, z);
    }
    
    public static void vertexAttrib3fv(final int indx, final FloatBuffer values) {
        Core.gl.glVertexAttrib3fv(indx, values);
    }
    
    public static void vertexAttrib4f(final int indx, final float x, final float y, final float z, final float w) {
        Core.gl.glVertexAttrib4f(indx, x, y, z, w);
    }
    
    public static void vertexAttrib4fv(final int indx, final FloatBuffer values) {
        Core.gl.glVertexAttrib4fv(indx, values);
    }
    
    public static void vertexAttribPointer(final int indx, final int size, final int type, final boolean normalized, final int stride, final Buffer ptr) {
        Core.gl.glVertexAttribPointer(indx, size, type, normalized, stride, ptr);
    }
    
    public static void vertexAttribPointer(final int indx, final int size, final int type, final boolean normalized, final int stride, final int ptr) {
        Core.gl.glVertexAttribPointer(indx, size, type, normalized, stride, ptr);
    }
    
    static {
        Gl.ibuf = Buffers.newIntBuffer(1);
        Gl.ibuf2 = Buffers.newIntBuffer(2);
        Gl.lastActiveTexture = -1;
        Gl.lastBoundTextures = new int[32];
        Gl.lastUsedProgram = 0;
        Gl.enabled = new Bits();
        Gl.wasDepthMask = true;
        Gl.lastSfactor = -1;
        Gl.lastDfactor = -1;
        reset();
    }
}
