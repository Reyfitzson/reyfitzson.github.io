// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

public enum Blending
{
    normal(770, 771), 
    additive(770, 1), 
    disabled(770, 771) {
        @Override
        public void apply() {
            Gl.disable(3042);
        }
    };
    
    public final int src;
    public final int dst;
    
    private Blending(final int src, final int dst) {
        this.src = src;
        this.dst = dst;
    }
    
    public void apply() {
        Gl.enable(3042);
        Gl.blendFunc(this.src, this.dst);
    }
}
