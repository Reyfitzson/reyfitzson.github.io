// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import java.nio.ShortBuffer;
import arc.util.Disposable;

public interface IndexData extends Disposable
{
    int size();
    
    int max();
    
    void set(final short[] p0, final int p1, final int p2);
    
    void set(final ShortBuffer p0);
    
    void update(final int p0, final short[] p1, final int p2, final int p3);
    
    ShortBuffer buffer();
    
    void bind();
    
    void unbind();
    
    void dispose();
}
