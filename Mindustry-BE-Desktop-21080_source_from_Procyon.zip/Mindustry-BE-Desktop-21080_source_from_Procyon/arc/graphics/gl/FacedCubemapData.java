// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import java.nio.Buffer;
import arc.graphics.Gl;
import arc.util.ArcRuntimeException;
import arc.graphics.Cubemap;
import arc.files.Fi;
import arc.graphics.Pixmap;
import arc.graphics.TextureData;
import arc.graphics.CubemapData;

public class FacedCubemapData implements CubemapData
{
    protected final TextureData[] data;
    
    public FacedCubemapData() {
        this(null, null, null, null, null, (Pixmap)null);
    }
    
    public FacedCubemapData(final Fi positiveX, final Fi negativeX, final Fi positiveY, final Fi negativeY, final Fi positiveZ, final Fi negativeZ) {
        this(TextureData.load(positiveX, false), TextureData.load(negativeX, false), TextureData.load(positiveY, false), TextureData.load(negativeY, false), TextureData.load(positiveZ, false), TextureData.load(negativeZ, false));
    }
    
    public FacedCubemapData(final Fi positiveX, final Fi negativeX, final Fi positiveY, final Fi negativeY, final Fi positiveZ, final Fi negativeZ, final boolean useMipMaps) {
        this(TextureData.load(positiveX, useMipMaps), TextureData.load(negativeX, useMipMaps), TextureData.load(positiveY, useMipMaps), TextureData.load(negativeY, useMipMaps), TextureData.load(positiveZ, useMipMaps), TextureData.load(negativeZ, useMipMaps));
    }
    
    public FacedCubemapData(final Pixmap positiveX, final Pixmap negativeX, final Pixmap positiveY, final Pixmap negativeY, final Pixmap positiveZ, final Pixmap negativeZ) {
        this(positiveX, negativeX, positiveY, negativeY, positiveZ, negativeZ, false);
    }
    
    public FacedCubemapData(final Pixmap positiveX, final Pixmap negativeX, final Pixmap positiveY, final Pixmap negativeY, final Pixmap positiveZ, final Pixmap negativeZ, final boolean useMipMaps) {
        this((positiveX == null) ? null : new PixmapTextureData(positiveX, null, useMipMaps, false), (negativeX == null) ? null : new PixmapTextureData(negativeX, null, useMipMaps, false), (positiveY == null) ? null : new PixmapTextureData(positiveY, null, useMipMaps, false), (negativeY == null) ? null : new PixmapTextureData(negativeY, null, useMipMaps, false), (positiveZ == null) ? null : new PixmapTextureData(positiveZ, null, useMipMaps, false), (negativeZ == null) ? null : new PixmapTextureData(negativeZ, null, useMipMaps, false));
    }
    
    public FacedCubemapData(final int width, final int height, final int depth, final Pixmap.Format format) {
        this(new PixmapTextureData(new Pixmap(depth, height, format), null, false, true), new PixmapTextureData(new Pixmap(depth, height, format), null, false, true), new PixmapTextureData(new Pixmap(width, depth, format), null, false, true), new PixmapTextureData(new Pixmap(width, depth, format), null, false, true), new PixmapTextureData(new Pixmap(width, height, format), null, false, true), new PixmapTextureData(new Pixmap(width, height, format), null, false, true));
    }
    
    public FacedCubemapData(final TextureData positiveX, final TextureData negativeX, final TextureData positiveY, final TextureData negativeY, final TextureData positiveZ, final TextureData negativeZ) {
        (this.data = new TextureData[6])[0] = positiveX;
        this.data[1] = negativeX;
        this.data[2] = positiveY;
        this.data[3] = negativeY;
        this.data[4] = positiveZ;
        this.data[5] = negativeZ;
    }
    
    public void load(final Cubemap.CubemapSide side, final Fi file) {
        this.data[side.index] = TextureData.load(file, false);
    }
    
    public void load(final Cubemap.CubemapSide side, final Pixmap pixmap) {
        this.data[side.index] = ((pixmap == null) ? null : new PixmapTextureData(pixmap, null, false, false));
    }
    
    public boolean isComplete() {
        for (int i = 0; i < this.data.length; ++i) {
            if (this.data[i] == null) {
                return false;
            }
        }
        return true;
    }
    
    public TextureData getTextureData(final Cubemap.CubemapSide side) {
        return this.data[side.index];
    }
    
    @Override
    public int getWidth() {
        int width = 0;
        int tmp;
        if (this.data[Cubemap.CubemapSide.positiveZ.index] != null && (tmp = this.data[Cubemap.CubemapSide.positiveZ.index].getWidth()) > width) {
            width = tmp;
        }
        if (this.data[Cubemap.CubemapSide.negativeZ.index] != null && (tmp = this.data[Cubemap.CubemapSide.negativeZ.index].getWidth()) > width) {
            width = tmp;
        }
        if (this.data[Cubemap.CubemapSide.positiveY.index] != null && (tmp = this.data[Cubemap.CubemapSide.positiveY.index].getWidth()) > width) {
            width = tmp;
        }
        if (this.data[Cubemap.CubemapSide.negativeY.index] != null && (tmp = this.data[Cubemap.CubemapSide.negativeY.index].getWidth()) > width) {
            width = tmp;
        }
        return width;
    }
    
    @Override
    public int getHeight() {
        int height = 0;
        int tmp;
        if (this.data[Cubemap.CubemapSide.positiveZ.index] != null && (tmp = this.data[Cubemap.CubemapSide.positiveZ.index].getHeight()) > height) {
            height = tmp;
        }
        if (this.data[Cubemap.CubemapSide.negativeZ.index] != null && (tmp = this.data[Cubemap.CubemapSide.negativeZ.index].getHeight()) > height) {
            height = tmp;
        }
        if (this.data[Cubemap.CubemapSide.positiveX.index] != null && (tmp = this.data[Cubemap.CubemapSide.positiveX.index].getHeight()) > height) {
            height = tmp;
        }
        if (this.data[Cubemap.CubemapSide.negativeX.index] != null && (tmp = this.data[Cubemap.CubemapSide.negativeX.index].getHeight()) > height) {
            height = tmp;
        }
        return height;
    }
    
    @Override
    public boolean isPrepared() {
        return false;
    }
    
    @Override
    public void prepare() {
        if (!this.isComplete()) {
            throw new ArcRuntimeException("You need to complete your cubemap data before using it");
        }
        for (final TextureData datum : this.data) {
            if (!datum.isPrepared()) {
                datum.prepare();
            }
        }
    }
    
    @Override
    public void consumeCubemapData() {
        for (int i = 0; i < this.data.length; ++i) {
            if (this.data[i].isCustom()) {
                this.data[i].consumeCustomData(34069 + i);
            }
            else {
                Pixmap pixmap = this.data[i].consumePixmap();
                boolean disposePixmap = this.data[i].disposePixmap();
                if (this.data[i].getFormat() != pixmap.getFormat()) {
                    final Pixmap tmp = new Pixmap(pixmap.getWidth(), pixmap.getHeight(), this.data[i].getFormat());
                    tmp.setBlending(Pixmap.Blending.none);
                    tmp.drawPixmap(pixmap, 0, 0, 0, 0, pixmap.getWidth(), pixmap.getHeight());
                    if (this.data[i].disposePixmap()) {
                        pixmap.dispose();
                    }
                    pixmap = tmp;
                    disposePixmap = true;
                }
                Gl.pixelStorei(3317, 1);
                Gl.texImage2D(34069 + i, 0, pixmap.getGLInternalFormat(), pixmap.getWidth(), pixmap.getHeight(), 0, pixmap.getGLFormat(), pixmap.getGLType(), pixmap.getPixels());
                if (disposePixmap) {
                    pixmap.dispose();
                }
            }
        }
    }
}
