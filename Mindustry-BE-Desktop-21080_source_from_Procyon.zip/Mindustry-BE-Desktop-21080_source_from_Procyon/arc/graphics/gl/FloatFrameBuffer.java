// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import arc.graphics.GLTexture;
import arc.Core;
import arc.graphics.TextureData;
import arc.graphics.Pixmap;
import arc.graphics.Texture;

public class FloatFrameBuffer extends FrameBuffer
{
    FloatFrameBuffer() {
    }
    
    protected FloatFrameBuffer(final GLFrameBufferBuilder<? extends GLFrameBuffer<Texture>> bufferBuilder) {
        super(bufferBuilder);
    }
    
    public FloatFrameBuffer(final int width, final int height, final boolean hasDepth) {
        final FloatFrameBufferBuilder bufferBuilder = new FloatFrameBufferBuilder(width, height);
        bufferBuilder.addFloatAttachment(34836, 6408, 5126, false);
        if (hasDepth) {
            bufferBuilder.addBasicDepthRenderBuffer();
        }
        this.bufferBuilder = (GLFrameBufferBuilder<? extends GLFrameBuffer<T>>)bufferBuilder;
        this.build();
    }
    
    @Override
    protected void create(final Pixmap.Format format, final int width, final int height, final boolean hasDepth, final boolean hasStencil) {
    }
    
    @Override
    public void resize(final int width, final int height) {
        throw new IllegalArgumentException("resize() is currently unsupported here.");
    }
    
    @Override
    protected Texture createTexture(final FrameBufferTextureAttachmentSpec attachmentSpec) {
        final FloatTextureData data = new FloatTextureData(this.bufferBuilder.width, this.bufferBuilder.height, attachmentSpec.internalFormat, attachmentSpec.format, attachmentSpec.type, attachmentSpec.isGpuOnly);
        final Texture result = new Texture(data);
        if (Core.app.isDesktop()) {
            result.setFilter(Texture.TextureFilter.linear, Texture.TextureFilter.linear);
        }
        else {
            result.setFilter(Texture.TextureFilter.nearest, Texture.TextureFilter.nearest);
        }
        result.setWrap(Texture.TextureWrap.clampToEdge, Texture.TextureWrap.clampToEdge);
        return result;
    }
}
