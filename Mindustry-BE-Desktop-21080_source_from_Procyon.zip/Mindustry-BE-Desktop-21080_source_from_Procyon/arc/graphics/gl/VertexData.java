// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import java.nio.FloatBuffer;
import arc.graphics.Gl;
import arc.util.ArcRuntimeException;
import arc.util.Disposable;

public interface VertexData extends Disposable
{
    default void render(final IndexData indices, final int primitiveType, final int offset, final int count) {
        if (indices.size() > 0) {
            if (count + offset > indices.max()) {
                throw new ArcRuntimeException("Mesh attempting to access memory outside of the index buffer (count: " + count + ", offset: " + offset + ", max: " + indices.max() + ")");
            }
            Gl.drawElements(primitiveType, count, 5123, offset * 2);
        }
        else {
            Gl.drawArrays(primitiveType, offset, count);
        }
    }
    
    int size();
    
    int max();
    
    void set(final float[] p0, final int p1, final int p2);
    
    void update(final int p0, final float[] p1, final int p2, final int p3);
    
    FloatBuffer buffer();
    
    void bind(final Shader p0);
    
    void unbind(final Shader p0);
}
