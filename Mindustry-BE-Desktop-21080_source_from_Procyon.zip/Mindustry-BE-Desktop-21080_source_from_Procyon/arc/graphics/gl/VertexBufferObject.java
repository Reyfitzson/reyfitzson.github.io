// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import arc.graphics.VertexAttribute;
import arc.util.ArcRuntimeException;
import java.nio.Buffer;
import arc.util.Buffers;
import arc.graphics.Gl;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import arc.graphics.Mesh;

public class VertexBufferObject implements VertexData
{
    boolean dirty;
    boolean bound;
    private Mesh mesh;
    private FloatBuffer buffer;
    private ByteBuffer byteBuffer;
    private boolean ownsBuffer;
    private int bufferHandle;
    private int usage;
    
    public VertexBufferObject(final boolean isStatic, final int numVertices, final Mesh mesh) {
        this.dirty = false;
        this.bound = false;
        this.mesh = mesh;
        this.bufferHandle = Gl.genBuffer();
        this.usage = (isStatic ? 35044 : 35040);
        final ByteBuffer data = Buffers.newUnsafeByteBuffer(mesh.vertexSize * numVertices);
        data.limit(0);
        this.setBuffer(data, true);
    }
    
    @Override
    public int size() {
        return this.buffer.limit() * 4 / this.mesh.vertexSize;
    }
    
    @Override
    public int max() {
        return this.byteBuffer.capacity() / this.mesh.vertexSize;
    }
    
    @Override
    public FloatBuffer buffer() {
        this.dirty = true;
        return this.buffer;
    }
    
    protected void setBuffer(final Buffer data, final boolean ownsBuffer) {
        if (this.bound) {
            throw new ArcRuntimeException("Cannot change attributes while VBO is bound");
        }
        if (this.ownsBuffer && this.byteBuffer != null) {
            Buffers.disposeUnsafeByteBuffer(this.byteBuffer);
        }
        if (data instanceof ByteBuffer) {
            this.byteBuffer = (ByteBuffer)data;
            this.ownsBuffer = ownsBuffer;
            final int l = this.byteBuffer.limit();
            this.byteBuffer.limit(this.byteBuffer.capacity());
            this.buffer = this.byteBuffer.asFloatBuffer();
            this.byteBuffer.limit(l);
            this.buffer.limit(l / 4);
            return;
        }
        throw new ArcRuntimeException("Only ByteBuffer is currently supported");
    }
    
    private void bufferChanged() {
        if (this.bound) {
            Gl.bufferData(34962, this.byteBuffer.limit(), this.byteBuffer, this.usage);
            this.dirty = false;
        }
    }
    
    @Override
    public void set(final float[] vertices, final int offset, final int count) {
        this.dirty = true;
        Buffers.copy(vertices, this.byteBuffer, count, offset);
        this.buffer.position(0);
        this.buffer.limit(count);
        this.bufferChanged();
    }
    
    @Override
    public void update(final int targetOffset, final float[] vertices, final int sourceOffset, final int count) {
        this.dirty = true;
        final int pos = this.byteBuffer.position();
        this.byteBuffer.position(targetOffset * 4);
        Buffers.copy(vertices, sourceOffset, count, this.byteBuffer);
        this.byteBuffer.position(pos);
        this.buffer.position(0);
        this.bufferChanged();
    }
    
    public void bind() {
        Gl.bindBuffer(34962, this.bufferHandle);
        if (this.dirty) {
            this.byteBuffer.limit(this.buffer.limit() * 4);
            Gl.bufferData(34962, this.byteBuffer.limit(), this.byteBuffer, this.usage);
            this.dirty = false;
        }
        this.bound = true;
    }
    
    @Override
    public void bind(final Shader shader) {
        this.bind();
        int offset = 0;
        for (final VertexAttribute attribute : this.mesh.attributes) {
            final int location = shader.getAttributeLocation(attribute.alias);
            final int aoffset = offset;
            offset += attribute.size;
            if (location >= 0) {
                shader.enableVertexAttribute(location);
                shader.setVertexAttribute(location, attribute.components, attribute.type, attribute.normalized, this.mesh.vertexSize, aoffset);
            }
        }
    }
    
    @Override
    public void unbind(final Shader shader) {
        for (final VertexAttribute attribute : this.mesh.attributes) {
            shader.disableVertexAttribute(attribute.alias);
        }
        Gl.bindBuffer(34962, 0);
        this.bound = false;
    }
    
    @Override
    public void dispose() {
        Gl.bindBuffer(34962, 0);
        Gl.deleteBuffer(this.bufferHandle);
        this.bufferHandle = 0;
        if (this.ownsBuffer) {
            Buffers.disposeUnsafeByteBuffer(this.byteBuffer);
        }
    }
}
