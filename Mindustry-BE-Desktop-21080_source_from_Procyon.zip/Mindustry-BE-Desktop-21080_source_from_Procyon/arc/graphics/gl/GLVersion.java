// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import java.util.regex.Matcher;
import arc.util.Log;
import java.util.regex.Pattern;
import arc.Application;

public class GLVersion
{
    public final String vendorString;
    public final String rendererString;
    public final GlType type;
    public int majorVersion;
    public int minorVersion;
    public int releaseVersion;
    
    public GLVersion(final Application.ApplicationType appType, final String versionString, String vendorString, String rendererString) {
        if (appType == Application.ApplicationType.android) {
            this.type = GlType.GLES;
        }
        else if (appType == Application.ApplicationType.iOS) {
            this.type = GlType.GLES;
        }
        else if (appType == Application.ApplicationType.desktop) {
            this.type = GlType.OpenGL;
        }
        else if (appType == Application.ApplicationType.web) {
            this.type = GlType.WebGL;
        }
        else {
            this.type = GlType.NONE;
        }
        if (this.type == GlType.GLES) {
            this.extractVersion("OpenGL ES (\\d(\\.\\d){0,2})", versionString);
        }
        else if (this.type == GlType.WebGL) {
            this.extractVersion("WebGL (\\d(\\.\\d){0,2})", versionString);
        }
        else if (this.type == GlType.OpenGL) {
            this.extractVersion("(\\d(\\.\\d){0,2})", versionString);
        }
        else {
            this.majorVersion = -1;
            this.minorVersion = -1;
            this.releaseVersion = -1;
            vendorString = "";
            rendererString = "";
        }
        this.vendorString = vendorString;
        this.rendererString = rendererString;
    }
    
    private void extractVersion(final String patternString, final String versionString) {
        final Pattern pattern = Pattern.compile(patternString);
        final Matcher matcher = pattern.matcher(versionString);
        final boolean found = matcher.find();
        if (found) {
            final String result = matcher.group(1);
            final String[] resultSplit = result.split("\\.");
            this.majorVersion = this.parseInt(resultSplit[0], 2);
            this.minorVersion = ((resultSplit.length < 2) ? 0 : this.parseInt(resultSplit[1], 0));
            this.releaseVersion = ((resultSplit.length < 3) ? 0 : this.parseInt(resultSplit[2], 0));
        }
        else {
            Log.err("[Arc GL] Invalid version string: " + versionString, new Object[0]);
            this.majorVersion = 2;
            this.minorVersion = 0;
            this.releaseVersion = 0;
        }
    }
    
    private int parseInt(final String v, final int defaultValue) {
        try {
            return Integer.parseInt(v);
        }
        catch (NumberFormatException nfe) {
            Log.err("[Arc GL] Error parsing number: " + v + ", assuming: " + defaultValue, new Object[0]);
            return defaultValue;
        }
    }
    
    public boolean atLeast(final int testMajorVersion, final int testMinorVersion) {
        return this.majorVersion > testMajorVersion || (this.majorVersion == testMajorVersion && this.minorVersion >= testMinorVersion);
    }
    
    public String getDebugVersionString() {
        return "Type: " + this.type + "\nVersion: " + this.majorVersion + ":" + this.minorVersion + ":" + this.releaseVersion + "\nVendor: " + this.vendorString + "\nRenderer: " + this.rendererString;
    }
    
    @Override
    public String toString() {
        return this.type + " " + this.majorVersion + "." + this.minorVersion + "." + this.releaseVersion + " / " + this.vendorString + " / " + this.rendererString;
    }
    
    public enum GlType
    {
        OpenGL, 
        GLES, 
        WebGL, 
        NONE;
    }
}
