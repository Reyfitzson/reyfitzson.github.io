// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import arc.graphics.Cubemap;
import arc.graphics.Texture;
import arc.graphics.Pixmap;
import arc.graphics.g2d.Draw;
import arc.graphics.Color;
import arc.util.ArcRuntimeException;
import java.util.Iterator;
import java.nio.IntBuffer;
import arc.util.Buffers;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import arc.Core;
import arc.graphics.Gl;
import arc.struct.Seq;
import arc.util.Disposable;
import arc.graphics.GLTexture;

public abstract class GLFrameBuffer<T extends GLTexture> implements Disposable
{
    protected static final int GL_DEPTH24_STENCIL8_OES = 35056;
    protected static GLFrameBuffer currentBoundFramebuffer;
    protected static int defaultFramebufferHandle;
    protected static int bufferNesting;
    protected static boolean defaultFramebufferHandleInitialized;
    protected Seq<T> textureAttachments;
    protected GLFrameBuffer lastBoundFramebuffer;
    protected int framebufferHandle;
    protected int depthbufferHandle;
    protected int stencilbufferHandle;
    protected int depthStencilPackedBufferHandle;
    protected boolean hasDepthStencilPackedBuffer;
    protected boolean isMRT;
    protected GLFrameBufferBuilder<? extends GLFrameBuffer<T>> bufferBuilder;
    
    GLFrameBuffer() {
        this.textureAttachments = new Seq<T>();
        this.lastBoundFramebuffer = null;
    }
    
    protected GLFrameBuffer(final GLFrameBufferBuilder<? extends GLFrameBuffer<T>> bufferBuilder) {
        this.textureAttachments = new Seq<T>();
        this.lastBoundFramebuffer = null;
        this.bufferBuilder = bufferBuilder;
        this.build();
    }
    
    public static int getBufferNesting() {
        return GLFrameBuffer.bufferNesting;
    }
    
    public static void unbind() {
        Gl.bindFramebuffer(36160, GLFrameBuffer.defaultFramebufferHandle);
    }
    
    public T getTexture() {
        return this.textureAttachments.first();
    }
    
    public Seq<T> getTextureAttachments() {
        return this.textureAttachments;
    }
    
    protected abstract T createTexture(final FrameBufferTextureAttachmentSpec p0);
    
    protected abstract void disposeColorTexture(final T p0);
    
    protected abstract void attachFrameBufferColorTexture(final T p0);
    
    protected void build() {
        this.checkValidBuilder();
        if (!GLFrameBuffer.defaultFramebufferHandleInitialized) {
            GLFrameBuffer.defaultFramebufferHandleInitialized = true;
            if (Core.app.isIOS()) {
                final IntBuffer intbuf = ByteBuffer.allocateDirect(64).order(ByteOrder.nativeOrder()).asIntBuffer();
                Gl.getIntegerv(36006, intbuf);
                GLFrameBuffer.defaultFramebufferHandle = intbuf.get(0);
            }
            else {
                GLFrameBuffer.defaultFramebufferHandle = 0;
            }
        }
        final int lastHandle = (GLFrameBuffer.currentBoundFramebuffer == null) ? GLFrameBuffer.defaultFramebufferHandle : GLFrameBuffer.currentBoundFramebuffer.framebufferHandle;
        Gl.bindFramebuffer(36160, this.framebufferHandle = Gl.genFramebuffer());
        final int width = this.bufferBuilder.width;
        final int height = this.bufferBuilder.height;
        if (this.bufferBuilder.hasDepthRenderBuffer) {
            Gl.bindRenderbuffer(36161, this.depthbufferHandle = Gl.genRenderbuffer());
            Gl.renderbufferStorage(36161, this.bufferBuilder.depthRenderBufferSpec.internalFormat, width, height);
        }
        if (this.bufferBuilder.hasStencilRenderBuffer) {
            Gl.bindRenderbuffer(36161, this.stencilbufferHandle = Gl.genRenderbuffer());
            Gl.renderbufferStorage(36161, this.bufferBuilder.stencilRenderBufferSpec.internalFormat, width, height);
        }
        if (this.bufferBuilder.hasPackedStencilDepthRenderBuffer) {
            Gl.bindRenderbuffer(36161, this.depthStencilPackedBufferHandle = Gl.genRenderbuffer());
            Gl.renderbufferStorage(36161, this.bufferBuilder.packedStencilDepthRenderBufferSpec.internalFormat, width, height);
        }
        this.isMRT = (this.bufferBuilder.textureAttachmentSpecs.size > 1);
        int colorTextureCounter = 0;
        if (this.isMRT) {
            for (final FrameBufferTextureAttachmentSpec attachmentSpec : this.bufferBuilder.textureAttachmentSpecs) {
                final T texture = this.createTexture(attachmentSpec);
                this.textureAttachments.add(texture);
                if (attachmentSpec.isColorTexture()) {
                    Gl.framebufferTexture2D(36160, 36064 + colorTextureCounter, 3553, texture.getTextureObjectHandle(), 0);
                    ++colorTextureCounter;
                }
                else if (attachmentSpec.isDepth) {
                    Gl.framebufferTexture2D(36160, 36096, 3553, texture.getTextureObjectHandle(), 0);
                }
                else {
                    if (!attachmentSpec.isStencil) {
                        continue;
                    }
                    Gl.framebufferTexture2D(36160, 36128, 3553, texture.getTextureObjectHandle(), 0);
                }
            }
        }
        else {
            final T texture2 = this.createTexture(this.bufferBuilder.textureAttachmentSpecs.first());
            this.textureAttachments.add(texture2);
            Gl.bindTexture(texture2.glTarget, texture2.getTextureObjectHandle());
        }
        if (this.isMRT) {
            final IntBuffer buffer = Buffers.newIntBuffer(colorTextureCounter);
            for (int i = 0; i < colorTextureCounter; ++i) {
                buffer.put(36064 + i);
            }
            buffer.position(0);
            Core.gl30.glDrawBuffers(colorTextureCounter, buffer);
        }
        else {
            this.attachFrameBufferColorTexture(this.textureAttachments.first());
        }
        if (this.bufferBuilder.hasDepthRenderBuffer) {
            Gl.framebufferRenderbuffer(36160, 36096, 36161, this.depthbufferHandle);
        }
        if (this.bufferBuilder.hasStencilRenderBuffer) {
            Gl.framebufferRenderbuffer(36160, 36128, 36161, this.stencilbufferHandle);
        }
        if (this.bufferBuilder.hasPackedStencilDepthRenderBuffer) {
            Gl.framebufferRenderbuffer(36160, 33306, 36161, this.depthStencilPackedBufferHandle);
        }
        Gl.bindRenderbuffer(36161, 0);
        for (final T texture3 : this.textureAttachments) {
            Gl.bindTexture(texture3.glTarget, 0);
        }
        int result = Gl.checkFramebufferStatus(36160);
        if (result == 36061 && this.bufferBuilder.hasDepthRenderBuffer && this.bufferBuilder.hasStencilRenderBuffer && (Core.graphics.supportsExtension("GL_OES_packed_depth_stencil") || Core.graphics.supportsExtension("GL_EXT_packed_depth_stencil"))) {
            if (this.bufferBuilder.hasDepthRenderBuffer) {
                Gl.deleteRenderbuffer(this.depthbufferHandle);
                this.depthbufferHandle = 0;
            }
            if (this.bufferBuilder.hasStencilRenderBuffer) {
                Gl.deleteRenderbuffer(this.stencilbufferHandle);
                this.stencilbufferHandle = 0;
            }
            if (this.bufferBuilder.hasPackedStencilDepthRenderBuffer) {
                Gl.deleteRenderbuffer(this.depthStencilPackedBufferHandle);
                this.depthStencilPackedBufferHandle = 0;
            }
            this.depthStencilPackedBufferHandle = Gl.genRenderbuffer();
            this.hasDepthStencilPackedBuffer = true;
            Gl.bindRenderbuffer(36161, this.depthStencilPackedBufferHandle);
            Gl.renderbufferStorage(36161, 35056, width, height);
            Gl.bindRenderbuffer(36161, 0);
            Gl.framebufferRenderbuffer(36160, 36096, 36161, this.depthStencilPackedBufferHandle);
            Gl.framebufferRenderbuffer(36160, 36128, 36161, this.depthStencilPackedBufferHandle);
            result = Gl.checkFramebufferStatus(36160);
        }
        Gl.bindFramebuffer(36160, lastHandle);
        if (result == 36053) {
            return;
        }
        final Iterator<T> iterator3 = this.textureAttachments.iterator();
        while (iterator3.hasNext()) {
            final T texture = iterator3.next();
            this.disposeColorTexture(texture);
        }
        if (this.hasDepthStencilPackedBuffer) {
            Gl.deleteBuffer(this.depthStencilPackedBufferHandle);
        }
        else {
            if (this.bufferBuilder.hasDepthRenderBuffer) {
                Gl.deleteRenderbuffer(this.depthbufferHandle);
            }
            if (this.bufferBuilder.hasStencilRenderBuffer) {
                Gl.deleteRenderbuffer(this.stencilbufferHandle);
            }
        }
        Gl.deleteFramebuffer(this.framebufferHandle);
        if (result == 36054) {
            throw new IllegalStateException("Frame buffer couldn't be constructed: incomplete attachment");
        }
        if (result == 36057) {
            throw new IllegalStateException("Frame buffer couldn't be constructed: incomplete dimensions");
        }
        if (result == 36055) {
            throw new IllegalStateException("Frame buffer couldn't be constructed: missing attachment");
        }
        if (result == 36061) {
            throw new IllegalStateException("Frame buffer couldn't be constructed: unsupported combination of formats");
        }
        throw new IllegalStateException("Frame buffer couldn't be constructed: unknown error " + result);
    }
    
    private void checkValidBuilder() {
        final boolean runningGL30 = Core.graphics.isGL30Available();
        if (!runningGL30) {
            if (this.bufferBuilder.hasPackedStencilDepthRenderBuffer) {
                throw new ArcRuntimeException("Packed Stencil/Render render buffers are not available on GLES 2.0");
            }
            if (this.bufferBuilder.textureAttachmentSpecs.size > 1) {
                throw new ArcRuntimeException("Multiple render targets not available on GLES 2.0");
            }
            for (final FrameBufferTextureAttachmentSpec spec : this.bufferBuilder.textureAttachmentSpecs) {
                if (spec.isDepth) {
                    throw new ArcRuntimeException("Depth texture FrameBuffer Attachment not available on GLES 2.0");
                }
                if (spec.isStencil) {
                    throw new ArcRuntimeException("Stencil texture FrameBuffer Attachment not available on GLES 2.0");
                }
                if (spec.isFloat && !Core.graphics.supportsExtension("OES_texture_float")) {
                    throw new ArcRuntimeException("Float texture FrameBuffer Attachment not available on GLES 2.0");
                }
            }
        }
    }
    
    @Override
    public void dispose() {
        for (final T texture : this.textureAttachments) {
            this.disposeColorTexture(texture);
        }
        if (this.hasDepthStencilPackedBuffer) {
            Gl.deleteRenderbuffer(this.depthStencilPackedBufferHandle);
        }
        else {
            if (this.bufferBuilder.hasDepthRenderBuffer) {
                Gl.deleteRenderbuffer(this.depthbufferHandle);
            }
            if (this.bufferBuilder.hasStencilRenderBuffer) {
                Gl.deleteRenderbuffer(this.stencilbufferHandle);
            }
        }
        Gl.deleteFramebuffer(this.framebufferHandle);
    }
    
    public void bind() {
        Gl.bindFramebuffer(36160, this.framebufferHandle);
    }
    
    public boolean isBound() {
        return GLFrameBuffer.currentBoundFramebuffer == this;
    }
    
    public void begin(final Color clearColor) {
        this.begin();
        Gl.clearColor(clearColor.r, clearColor.g, clearColor.b, clearColor.a);
        Gl.clear((this.depthbufferHandle != 0) ? 16640 : 16384);
    }
    
    public void begin() {
        Draw.flush();
        this.beginBind();
        this.setFrameBufferViewport();
    }
    
    public void beginBind() {
        if (GLFrameBuffer.currentBoundFramebuffer == this) {
            throw new IllegalArgumentException("Do not begin() twice.");
        }
        this.lastBoundFramebuffer = GLFrameBuffer.currentBoundFramebuffer;
        GLFrameBuffer.currentBoundFramebuffer = this;
        ++GLFrameBuffer.bufferNesting;
        this.bind();
    }
    
    protected void setFrameBufferViewport() {
        Gl.viewport(0, 0, this.bufferBuilder.width, this.bufferBuilder.height);
    }
    
    public void end() {
        Draw.flush();
        if (this.lastBoundFramebuffer != null) {
            this.lastBoundFramebuffer.bind();
            this.lastBoundFramebuffer.setFrameBufferViewport();
        }
        else {
            unbind();
            Gl.viewport(0, 0, Core.graphics.getBackBufferWidth(), Core.graphics.getBackBufferHeight());
        }
        --GLFrameBuffer.bufferNesting;
        GLFrameBuffer.currentBoundFramebuffer = this.lastBoundFramebuffer;
        this.lastBoundFramebuffer = null;
    }
    
    public void endBind() {
        if (this.lastBoundFramebuffer != null) {
            this.lastBoundFramebuffer.bind();
        }
        else {
            unbind();
        }
        --GLFrameBuffer.bufferNesting;
        GLFrameBuffer.currentBoundFramebuffer = this.lastBoundFramebuffer;
        this.lastBoundFramebuffer = null;
    }
    
    public int getFramebufferHandle() {
        return this.framebufferHandle;
    }
    
    public int getDepthBufferHandle() {
        return this.depthbufferHandle;
    }
    
    public int getStencilBufferHandle() {
        return this.stencilbufferHandle;
    }
    
    protected int getDepthStencilPackedBuffer() {
        return this.depthStencilPackedBufferHandle;
    }
    
    public int getHeight() {
        return this.bufferBuilder.height;
    }
    
    public int getWidth() {
        return this.bufferBuilder.width;
    }
    
    static {
        GLFrameBuffer.defaultFramebufferHandleInitialized = false;
    }
    
    protected static class FrameBufferTextureAttachmentSpec
    {
        int internalFormat;
        int format;
        int type;
        boolean isFloat;
        boolean isGpuOnly;
        boolean isDepth;
        boolean isStencil;
        
        public FrameBufferTextureAttachmentSpec(final int internalformat, final int format, final int type) {
            this.internalFormat = internalformat;
            this.format = format;
            this.type = type;
        }
        
        public boolean isColorTexture() {
            return !this.isDepth && !this.isStencil;
        }
    }
    
    protected static class FrameBufferRenderBufferAttachmentSpec
    {
        int internalFormat;
        
        public FrameBufferRenderBufferAttachmentSpec(final int internalFormat) {
            this.internalFormat = internalFormat;
        }
    }
    
    protected abstract static class GLFrameBufferBuilder<U extends GLFrameBuffer<? extends GLTexture>>
    {
        protected int width;
        protected int height;
        protected Seq<FrameBufferTextureAttachmentSpec> textureAttachmentSpecs;
        protected FrameBufferRenderBufferAttachmentSpec stencilRenderBufferSpec;
        protected FrameBufferRenderBufferAttachmentSpec depthRenderBufferSpec;
        protected FrameBufferRenderBufferAttachmentSpec packedStencilDepthRenderBufferSpec;
        protected boolean hasStencilRenderBuffer;
        protected boolean hasDepthRenderBuffer;
        protected boolean hasPackedStencilDepthRenderBuffer;
        
        public GLFrameBufferBuilder(final int width, final int height) {
            this.textureAttachmentSpecs = new Seq<FrameBufferTextureAttachmentSpec>();
            this.width = width;
            this.height = height;
        }
        
        public GLFrameBufferBuilder<U> addColorTextureAttachment(final int internalFormat, final int format, final int type) {
            this.textureAttachmentSpecs.add(new FrameBufferTextureAttachmentSpec(internalFormat, format, type));
            return this;
        }
        
        public GLFrameBufferBuilder<U> addBasicColorTextureAttachment(final Pixmap.Format format) {
            final int glFormat = format.toGlFormat();
            final int glType = format.toGlType();
            return this.addColorTextureAttachment(glFormat, glFormat, glType);
        }
        
        public GLFrameBufferBuilder<U> addFloatAttachment(final int internalFormat, final int format, final int type, final boolean gpuOnly) {
            final FrameBufferTextureAttachmentSpec spec = new FrameBufferTextureAttachmentSpec(internalFormat, format, type);
            spec.isFloat = true;
            spec.isGpuOnly = gpuOnly;
            this.textureAttachmentSpecs.add(spec);
            return this;
        }
        
        public GLFrameBufferBuilder<U> addDepthTextureAttachment(final int internalFormat, final int type) {
            final FrameBufferTextureAttachmentSpec spec = new FrameBufferTextureAttachmentSpec(internalFormat, 6402, type);
            spec.isDepth = true;
            this.textureAttachmentSpecs.add(spec);
            return this;
        }
        
        public GLFrameBufferBuilder<U> addStencilTextureAttachment(final int internalFormat, final int type) {
            final FrameBufferTextureAttachmentSpec spec = new FrameBufferTextureAttachmentSpec(internalFormat, 36128, type);
            spec.isStencil = true;
            this.textureAttachmentSpecs.add(spec);
            return this;
        }
        
        public GLFrameBufferBuilder<U> addDepthRenderBuffer(final int internalFormat) {
            this.depthRenderBufferSpec = new FrameBufferRenderBufferAttachmentSpec(internalFormat);
            this.hasDepthRenderBuffer = true;
            return this;
        }
        
        public GLFrameBufferBuilder<U> addStencilRenderBuffer(final int internalFormat) {
            this.stencilRenderBufferSpec = new FrameBufferRenderBufferAttachmentSpec(internalFormat);
            this.hasStencilRenderBuffer = true;
            return this;
        }
        
        public GLFrameBufferBuilder<U> addStencilDepthPackedRenderBuffer(final int internalFormat) {
            this.packedStencilDepthRenderBufferSpec = new FrameBufferRenderBufferAttachmentSpec(internalFormat);
            this.hasPackedStencilDepthRenderBuffer = true;
            return this;
        }
        
        public GLFrameBufferBuilder<U> addBasicDepthRenderBuffer() {
            return this.addDepthRenderBuffer(33189);
        }
        
        public GLFrameBufferBuilder<U> addBasicStencilRenderBuffer() {
            return this.addStencilRenderBuffer(36168);
        }
        
        public GLFrameBufferBuilder<U> addBasicStencilDepthPackedRenderBuffer() {
            return this.addStencilDepthPackedRenderBuffer(35056);
        }
        
        public abstract U build();
    }
    
    public static class FrameBufferBuilder extends GLFrameBufferBuilder<FrameBuffer>
    {
        public FrameBufferBuilder(final int width, final int height) {
            super(width, height);
        }
        
        @Override
        public FrameBuffer build() {
            return new FrameBuffer(this);
        }
    }
    
    public static class FloatFrameBufferBuilder extends GLFrameBufferBuilder<FloatFrameBuffer>
    {
        public FloatFrameBufferBuilder(final int width, final int height) {
            super(width, height);
        }
        
        @Override
        public FloatFrameBuffer build() {
            return new FloatFrameBuffer(this);
        }
    }
    
    public static class FrameBufferCubemapBuilder extends GLFrameBufferBuilder<FrameBufferCubemap>
    {
        public FrameBufferCubemapBuilder(final int width, final int height) {
            super(width, height);
        }
        
        @Override
        public FrameBufferCubemap build() {
            return new FrameBufferCubemap(this);
        }
    }
}
