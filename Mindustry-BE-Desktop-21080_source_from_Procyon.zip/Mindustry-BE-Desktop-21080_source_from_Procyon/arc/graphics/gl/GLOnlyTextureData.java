// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import arc.graphics.Pixmap;
import java.nio.Buffer;
import arc.graphics.Gl;
import arc.util.ArcRuntimeException;
import arc.graphics.TextureData;

public class GLOnlyTextureData implements TextureData
{
    int width;
    int height;
    boolean isPrepared;
    int mipLevel;
    int internalFormat;
    int format;
    int type;
    
    public GLOnlyTextureData(final int width, final int height, final int mipMapLevel, final int internalFormat, final int format, final int type) {
        this.width = 0;
        this.height = 0;
        this.isPrepared = false;
        this.mipLevel = 0;
        this.width = width;
        this.height = height;
        this.mipLevel = mipMapLevel;
        this.internalFormat = internalFormat;
        this.format = format;
        this.type = type;
    }
    
    @Override
    public boolean isCustom() {
        return true;
    }
    
    @Override
    public boolean isPrepared() {
        return this.isPrepared;
    }
    
    @Override
    public void prepare() {
        if (this.isPrepared) {
            throw new ArcRuntimeException("Already prepared");
        }
        this.isPrepared = true;
    }
    
    @Override
    public void consumeCustomData(final int target) {
        Gl.texImage2D(target, this.mipLevel, this.internalFormat, this.width, this.height, 0, this.format, this.type, null);
    }
    
    @Override
    public Pixmap consumePixmap() {
        throw new ArcRuntimeException("This TextureData implementation does not return a Pixmap");
    }
    
    @Override
    public boolean disposePixmap() {
        throw new ArcRuntimeException("This TextureData implementation does not return a Pixmap");
    }
    
    @Override
    public int getWidth() {
        return this.width;
    }
    
    @Override
    public int getHeight() {
        return this.height;
    }
    
    @Override
    public Pixmap.Format getFormat() {
        return Pixmap.Format.rgba8888;
    }
    
    @Override
    public boolean useMipMaps() {
        return false;
    }
}
