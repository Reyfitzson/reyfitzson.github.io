// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import arc.graphics.Gl;
import arc.Core;

public class HdpiUtils
{
    private static HdpiMode mode;
    
    public static void setMode(final HdpiMode mode) {
        HdpiUtils.mode = mode;
    }
    
    public static void glScissor(final int x, final int y, final int width, final int height) {
        if (HdpiUtils.mode == HdpiMode.logical && (Core.graphics.getWidth() != Core.graphics.getBackBufferWidth() || Core.graphics.getHeight() != Core.graphics.getBackBufferHeight())) {
            Gl.scissor(toBackBufferX(x), toBackBufferY(y), toBackBufferX(width), toBackBufferY(height));
        }
        else {
            Gl.scissor(x, y, width, height);
        }
    }
    
    public static void glViewport(final int x, final int y, final int width, final int height) {
        if (HdpiUtils.mode == HdpiMode.logical && (Core.graphics.getWidth() != Core.graphics.getBackBufferWidth() || Core.graphics.getHeight() != Core.graphics.getBackBufferHeight())) {
            Gl.viewport(toBackBufferX(x), toBackBufferY(y), toBackBufferX(width), toBackBufferY(height));
        }
        else {
            Gl.viewport(x, y, width, height);
        }
    }
    
    public static int toLogicalX(final int backBufferX) {
        return (int)(backBufferX * Core.graphics.getWidth() / (float)Core.graphics.getBackBufferWidth());
    }
    
    public static int toLogicalY(final int backBufferY) {
        return (int)(backBufferY * Core.graphics.getHeight() / (float)Core.graphics.getBackBufferHeight());
    }
    
    public static int toBackBufferX(final int logicalX) {
        return (int)(logicalX * Core.graphics.getBackBufferWidth() / (float)Core.graphics.getWidth());
    }
    
    public static int toBackBufferY(final int logicalY) {
        return (int)(logicalY * Core.graphics.getBackBufferHeight() / (float)Core.graphics.getHeight());
    }
    
    static {
        HdpiUtils.mode = HdpiMode.logical;
    }
}
