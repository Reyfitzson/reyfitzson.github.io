// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import arc.graphics.GLTexture;
import arc.util.ArcRuntimeException;
import arc.graphics.Gl;
import arc.graphics.Texture;
import arc.graphics.TextureData;
import arc.graphics.Pixmap;
import arc.graphics.Cubemap;

public class FrameBufferCubemap extends GLFrameBuffer<Cubemap>
{
    private static final Cubemap.CubemapSide[] cubemapSides;
    private int currentSide;
    
    FrameBufferCubemap() {
    }
    
    protected FrameBufferCubemap(final GLFrameBufferBuilder<? extends GLFrameBuffer<Cubemap>> bufferBuilder) {
        super(bufferBuilder);
    }
    
    public FrameBufferCubemap(final Pixmap.Format format, final int width, final int height, final boolean hasDepth) {
        this(format, width, height, hasDepth, false);
    }
    
    public FrameBufferCubemap(final Pixmap.Format format, final int width, final int height, final boolean hasDepth, final boolean hasStencil) {
        final FrameBufferCubemapBuilder frameBufferBuilder = new FrameBufferCubemapBuilder(width, height);
        frameBufferBuilder.addBasicColorTextureAttachment(format);
        if (hasDepth) {
            frameBufferBuilder.addBasicDepthRenderBuffer();
        }
        if (hasStencil) {
            frameBufferBuilder.addBasicStencilRenderBuffer();
        }
        this.bufferBuilder = (GLFrameBufferBuilder<? extends GLFrameBuffer<T>>)frameBufferBuilder;
        this.build();
    }
    
    @Override
    protected Cubemap createTexture(final FrameBufferTextureAttachmentSpec attachmentSpec) {
        final GLOnlyTextureData data = new GLOnlyTextureData(this.bufferBuilder.width, this.bufferBuilder.height, 0, attachmentSpec.internalFormat, attachmentSpec.format, attachmentSpec.type);
        final Cubemap result = new Cubemap(data, data, data, data, data, data);
        result.setFilter(Texture.TextureFilter.linear, Texture.TextureFilter.linear);
        result.setWrap(Texture.TextureWrap.clampToEdge, Texture.TextureWrap.clampToEdge);
        return result;
    }
    
    @Override
    protected void disposeColorTexture(final Cubemap colorTexture) {
        colorTexture.dispose();
    }
    
    @Override
    protected void attachFrameBufferColorTexture(final Cubemap texture) {
        final int glHandle = texture.getTextureObjectHandle();
        final Cubemap.CubemapSide[] values;
        final Cubemap.CubemapSide[] sides = values = Cubemap.CubemapSide.values();
        for (final Cubemap.CubemapSide side : values) {
            Gl.framebufferTexture2D(36160, 36064, side.glEnum, glHandle, 0);
        }
    }
    
    @Override
    public void bind() {
        this.currentSide = -1;
        super.bind();
    }
    
    public boolean nextSide() {
        if (this.currentSide > 5) {
            throw new ArcRuntimeException("No remaining sides.");
        }
        if (this.currentSide == 5) {
            return false;
        }
        ++this.currentSide;
        this.bindSide(this.getSide());
        return true;
    }
    
    protected void bindSide(final Cubemap.CubemapSide side) {
        Gl.framebufferTexture2D(36160, 36064, side.glEnum, this.getTexture().getTextureObjectHandle(), 0);
    }
    
    public Cubemap.CubemapSide getSide() {
        return (this.currentSide < 0) ? null : FrameBufferCubemap.cubemapSides[this.currentSide];
    }
    
    static {
        cubemapSides = Cubemap.CubemapSide.values();
    }
}
