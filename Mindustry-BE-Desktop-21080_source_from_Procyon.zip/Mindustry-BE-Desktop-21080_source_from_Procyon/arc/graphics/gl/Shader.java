// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import java.nio.Buffer;
import arc.graphics.Color;
import arc.math.geom.Vec3;
import arc.math.geom.Vec2;
import java.nio.FloatBuffer;
import arc.math.Mat;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import arc.graphics.Gl;
import arc.Core;
import arc.util.ArcRuntimeException;
import arc.util.Log;
import arc.files.Fi;
import arc.util.Buffers;
import java.nio.IntBuffer;
import arc.struct.ObjectIntMap;
import arc.util.Disposable;

public class Shader implements Disposable
{
    public static final String positionAttribute = "a_position";
    public static final String normalAttribute = "a_normal";
    public static final String colorAttribute = "a_color";
    public static final String mixColorAttribute = "a_mix_color";
    public static final String texcoordAttribute = "a_texCoord";
    public static final String tangentAttribute = "a_tangent";
    public static final String binormalAttribute = "a_binormal";
    public static final String boneweightAttribute = "a_boneWeight";
    public static boolean pedantic;
    public static String prependVertexCode;
    public static String prependFragmentCode;
    private final ObjectIntMap<String> uniforms;
    private final ObjectIntMap<String> uniformTypes;
    private final ObjectIntMap<String> uniformSizes;
    private final ObjectIntMap<String> attributes;
    private final ObjectIntMap<String> attributeTypes;
    private final ObjectIntMap<String> attributeSizes;
    private final String vertexShaderSource;
    private final String fragmentShaderSource;
    IntBuffer params;
    IntBuffer type;
    private String log;
    private boolean isCompiled;
    private String[] uniformNames;
    private String[] attributeNames;
    private int program;
    private int vertexShaderHandle;
    private int fragmentShaderHandle;
    private boolean disposed;
    private static final float[] val;
    
    public Shader(String vertexShader, String fragmentShader) {
        this.uniforms = new ObjectIntMap<String>();
        this.uniformTypes = new ObjectIntMap<String>();
        this.uniformSizes = new ObjectIntMap<String>();
        this.attributes = new ObjectIntMap<String>();
        this.attributeTypes = new ObjectIntMap<String>();
        this.attributeSizes = new ObjectIntMap<String>();
        this.params = Buffers.newIntBuffer(1);
        this.type = Buffers.newIntBuffer(1);
        this.log = "";
        if (vertexShader == null) {
            throw new IllegalArgumentException("vertex shader must not be null");
        }
        if (fragmentShader == null) {
            throw new IllegalArgumentException("fragment shader must not be null");
        }
        vertexShader = this.preprocess(vertexShader, false);
        fragmentShader = this.preprocess(fragmentShader, true);
        if (Shader.prependVertexCode != null && Shader.prependVertexCode.length() > 0) {
            vertexShader = Shader.prependVertexCode + vertexShader;
        }
        if (Shader.prependFragmentCode != null && Shader.prependFragmentCode.length() > 0) {
            fragmentShader = Shader.prependFragmentCode + fragmentShader;
        }
        this.compileShaders(this.vertexShaderSource = vertexShader, this.fragmentShaderSource = fragmentShader);
        if (this.isCompiled()) {
            this.fetchAttributes();
            this.fetchUniforms();
            return;
        }
        throw new IllegalArgumentException("Failed to compile shader: " + this.log);
    }
    
    public Shader(final Fi vertexShader, final Fi fragmentShader) {
        this(vertexShader.readString(), fragmentShader.readString());
        if (!this.log.isEmpty()) {
            Log.warn("Shader " + vertexShader + " | " + fragmentShader + ":\n" + this.log, new Object[0]);
        }
    }
    
    public void apply() {
    }
    
    protected String preprocess(String source, final boolean fragment) {
        if (source.contains("#ifdef GL_ES")) {
            throw new ArcRuntimeException("Shader contains GL_ES specific code; this should be handled by the preprocessor. Code: \n```\n" + source + "\n```");
        }
        if (source.contains("#version")) {
            throw new ArcRuntimeException("Shader contains explicit version requirement; this should be handled by the preprocessor. Code: \n```\n" + source + "\n```");
        }
        if (fragment) {
            source = "#ifdef GL_ES\nprecision " + (source.contains("#define HIGHP") ? "highp" : "mediump") + " float;\nprecision mediump int;\n#else\n#define lowp  \n#define mediump \n#define highp \n#endif\n" + source;
        }
        else {
            source = "#ifndef GL_ES\n#define lowp  \n#define mediump \n#define highp \n#endif\n" + source;
        }
        if (Core.gl30 != null) {
            final String version = source.contains("#version ") ? "" : (Core.app.isDesktop() ? (Core.graphics.getGLVersion().atLeast(3, 2) ? "150" : "130") : "300 es");
            return "#version " + version + "\n" + (fragment ? "out lowp vec4 fragColor;\n" : "") + source.replace("varying", fragment ? "in" : "out").replace("attribute", fragment ? "???" : "in").replace("texture2D(", "texture(").replace("textureCube(", "texture(").replace("gl_FragColor", "fragColor");
        }
        return source;
    }
    
    private void compileShaders(final String vertexShader, final String fragmentShader) {
        this.vertexShaderHandle = this.loadShader(35633, vertexShader);
        this.fragmentShaderHandle = this.loadShader(35632, fragmentShader);
        if (this.vertexShaderHandle == -1 || this.fragmentShaderHandle == -1) {
            this.isCompiled = false;
            return;
        }
        this.program = this.linkProgram(this.createProgram());
        if (this.program == -1) {
            this.isCompiled = false;
            return;
        }
        this.isCompiled = true;
    }
    
    private int loadShader(final int type, final String source) {
        final IntBuffer intbuf = Buffers.newIntBuffer(1);
        final int shader = Gl.createShader(type);
        if (shader == 0) {
            return -1;
        }
        Gl.shaderSource(shader, source);
        Gl.compileShader(shader);
        Gl.getShaderiv(shader, 35713, intbuf);
        final String infoLog = Gl.getShaderInfoLog(shader);
        if (!infoLog.isEmpty()) {
            this.log += ((type == 35633) ? "Vertex shader\n" : "Fragment shader:\n");
            this.log += infoLog;
        }
        final int compiled = intbuf.get(0);
        if (compiled == 0) {
            return -1;
        }
        return shader;
    }
    
    protected int createProgram() {
        final int program = Gl.createProgram();
        return (program != 0) ? program : -1;
    }
    
    private int linkProgram(final int program) {
        if (program == -1) {
            return -1;
        }
        Gl.attachShader(program, this.vertexShaderHandle);
        Gl.attachShader(program, this.fragmentShaderHandle);
        Gl.linkProgram(program);
        final ByteBuffer tmp = ByteBuffer.allocateDirect(4);
        tmp.order(ByteOrder.nativeOrder());
        final IntBuffer intbuf = tmp.asIntBuffer();
        Gl.getProgramiv(program, 35714, intbuf);
        final int linked = intbuf.get(0);
        if (linked == 0) {
            this.log = Gl.getProgramInfoLog(program);
            return -1;
        }
        return program;
    }
    
    public String getLog() {
        if (this.isCompiled) {
            return this.log = Gl.getProgramInfoLog(this.program);
        }
        return this.log;
    }
    
    public boolean isCompiled() {
        return this.isCompiled;
    }
    
    private int fetchAttributeLocation(final String name) {
        int location;
        if ((location = this.attributes.get(name, -2)) == -2) {
            location = Gl.getAttribLocation(this.program, name);
            this.attributes.put(name, location);
        }
        return location;
    }
    
    private int fetchUniformLocation(final String name) {
        return this.fetchUniformLocation(name, Shader.pedantic);
    }
    
    public int fetchUniformLocation(final String name, final boolean pedantic) {
        int location;
        if ((location = this.uniforms.get(name, -2)) == -2) {
            location = Gl.getUniformLocation(this.program, name);
            if (location == -1 && pedantic) {
                throw new IllegalArgumentException("no uniform with name '" + name + "' in shader");
            }
            this.uniforms.put(name, location);
        }
        return location;
    }
    
    public void setUniformi(final String name, final int value) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform1i(location, value);
    }
    
    public void setUniformi(final int location, final int value) {
        Gl.uniform1i(location, value);
    }
    
    public void setUniformi(final String name, final int value1, final int value2) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform2i(location, value1, value2);
    }
    
    public void setUniformi(final int location, final int value1, final int value2) {
        Gl.uniform2i(location, value1, value2);
    }
    
    public void setUniformi(final String name, final int value1, final int value2, final int value3) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform3i(location, value1, value2, value3);
    }
    
    public void setUniformi(final int location, final int value1, final int value2, final int value3) {
        Gl.uniform3i(location, value1, value2, value3);
    }
    
    public void setUniformi(final String name, final int value1, final int value2, final int value3, final int value4) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform4i(location, value1, value2, value3, value4);
    }
    
    public void setUniformi(final int location, final int value1, final int value2, final int value3, final int value4) {
        Gl.uniform4i(location, value1, value2, value3, value4);
    }
    
    public void setUniformf(final String name, final float value) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform1f(location, value);
    }
    
    public void setUniformf(final int location, final float value) {
        Gl.uniform1f(location, value);
    }
    
    public void setUniformf(final String name, final float value1, final float value2) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform2f(location, value1, value2);
    }
    
    public void setUniformf(final int location, final float value1, final float value2) {
        Gl.uniform2f(location, value1, value2);
    }
    
    public void setUniformf(final String name, final float value1, final float value2, final float value3) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform3f(location, value1, value2, value3);
    }
    
    public void setUniformf(final int location, final float value1, final float value2, final float value3) {
        Gl.uniform3f(location, value1, value2, value3);
    }
    
    public void setUniformf(final String name, final float value1, final float value2, final float value3, final float value4) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform4f(location, value1, value2, value3, value4);
    }
    
    public void setUniformf(final int location, final float value1, final float value2, final float value3, final float value4) {
        Gl.uniform4f(location, value1, value2, value3, value4);
    }
    
    public void setUniform1fv(final String name, final float[] values, final int offset, final int length) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform1fv(location, length, values, offset);
    }
    
    public void setUniform1fv(final int location, final float[] values, final int offset, final int length) {
        Gl.uniform1fv(location, length, values, offset);
    }
    
    public void setUniform2fv(final String name, final float[] values, final int offset, final int length) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform2fv(location, length / 2, values, offset);
    }
    
    public void setUniform2fv(final int location, final float[] values, final int offset, final int length) {
        Gl.uniform2fv(location, length / 2, values, offset);
    }
    
    public void setUniform3fv(final String name, final float[] values, final int offset, final int length) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform3fv(location, length / 3, values, offset);
    }
    
    public void setUniform3fv(final int location, final float[] values, final int offset, final int length) {
        Gl.uniform3fv(location, length / 3, values, offset);
    }
    
    public void setUniform4fv(final String name, final float[] values, final int offset, final int length) {
        final int location = this.fetchUniformLocation(name);
        Gl.uniform4fv(location, length / 4, values, offset);
    }
    
    public void setUniform4fv(final int location, final float[] values, final int offset, final int length) {
        Gl.uniform4fv(location, length / 4, values, offset);
    }
    
    public void setUniformMatrix(final String name, final Mat matrix) {
        this.setUniformMatrix(name, matrix, false);
    }
    
    public void setUniformMatrix(final String name, final Mat matrix, final boolean transpose) {
        this.setUniformMatrix(this.fetchUniformLocation(name), matrix, transpose);
    }
    
    public void setUniformMatrix(final int location, final Mat matrix) {
        this.setUniformMatrix(location, matrix, false);
    }
    
    public void setUniformMatrix(final int location, final Mat matrix, final boolean transpose) {
        Gl.uniformMatrix3fv(location, 1, transpose, matrix.val, 0);
    }
    
    public void setUniformMatrix4(final String name, final float[] val) {
        Gl.uniformMatrix4fv(this.fetchUniformLocation(name), 1, false, val, 0);
    }
    
    public void setUniformMatrix4(final String name, final Mat mat) {
        Gl.uniformMatrix4fv(this.fetchUniformLocation(name), 1, false, copyTransform(mat), 0);
    }
    
    public void setUniformMatrix4(final String name, final Mat mat, final float near, final float far) {
        Gl.uniformMatrix4fv(this.fetchUniformLocation(name), 1, false, copyTransform(mat, near, far), 0);
    }
    
    public void setUniformMatrix3fv(final String name, final FloatBuffer buffer, final int count, final boolean transpose) {
        buffer.position(0);
        final int location = this.fetchUniformLocation(name);
        Gl.uniformMatrix3fv(location, count, transpose, buffer);
    }
    
    public void setUniformMatrix4fv(final String name, final FloatBuffer buffer, final int count, final boolean transpose) {
        buffer.position(0);
        final int location = this.fetchUniformLocation(name);
        Gl.uniformMatrix4fv(location, count, transpose, buffer);
    }
    
    public void setUniformMatrix4fv(final int location, final float[] values, final int offset, final int length) {
        Gl.uniformMatrix4fv(location, length / 16, false, values, offset);
    }
    
    public void setUniformMatrix4fv(final String name, final float[] values, final int offset, final int length) {
        this.setUniformMatrix4fv(this.fetchUniformLocation(name), values, offset, length);
    }
    
    public void setUniformf(final String name, final Vec2 values) {
        this.setUniformf(name, values.x, values.y);
    }
    
    public void setUniformf(final int location, final Vec2 values) {
        this.setUniformf(location, values.x, values.y);
    }
    
    public void setUniformf(final String name, final Vec3 values) {
        this.setUniformf(name, values.x, values.y, values.z);
    }
    
    public void setUniformf(final int location, final Vec3 values) {
        this.setUniformf(location, values.x, values.y, values.z);
    }
    
    public void setUniformf(final String name, final Color values) {
        this.setUniformf(name, values.r, values.g, values.b, values.a);
    }
    
    public void setUniformf(final int location, final Color values) {
        this.setUniformf(location, values.r, values.g, values.b, values.a);
    }
    
    public void setVertexAttribute(final String name, final int size, final int type, final boolean normalize, final int stride, final Buffer buffer) {
        final int location = this.fetchAttributeLocation(name);
        if (location == -1) {
            return;
        }
        Gl.vertexAttribPointer(location, size, type, normalize, stride, buffer);
    }
    
    public void setVertexAttribute(final int location, final int size, final int type, final boolean normalize, final int stride, final Buffer buffer) {
        Gl.vertexAttribPointer(location, size, type, normalize, stride, buffer);
    }
    
    public void setVertexAttribute(final String name, final int size, final int type, final boolean normalize, final int stride, final int offset) {
        final int location = this.fetchAttributeLocation(name);
        if (location == -1) {
            return;
        }
        Gl.vertexAttribPointer(location, size, type, normalize, stride, offset);
    }
    
    public void setVertexAttribute(final int location, final int size, final int type, final boolean normalize, final int stride, final int offset) {
        Gl.vertexAttribPointer(location, size, type, normalize, stride, offset);
    }
    
    public void bind() {
        Gl.useProgram(this.program);
    }
    
    @Override
    public void dispose() {
        if (this.disposed) {
            return;
        }
        Gl.useProgram(0);
        Gl.deleteShader(this.vertexShaderHandle);
        Gl.deleteShader(this.fragmentShaderHandle);
        Gl.deleteProgram(this.program);
        this.disposed = true;
    }
    
    @Override
    public boolean isDisposed() {
        return this.disposed;
    }
    
    public void disableVertexAttribute(final String name) {
        final int location = this.fetchAttributeLocation(name);
        if (location == -1) {
            return;
        }
        Gl.disableVertexAttribArray(location);
    }
    
    public void disableVertexAttribute(final int location) {
        Gl.disableVertexAttribArray(location);
    }
    
    public void enableVertexAttribute(final String name) {
        final int location = this.fetchAttributeLocation(name);
        if (location == -1) {
            return;
        }
        Gl.enableVertexAttribArray(location);
    }
    
    public void enableVertexAttribute(final int location) {
        Gl.enableVertexAttribArray(location);
    }
    
    public void setAttributef(final String name, final float value1, final float value2, final float value3, final float value4) {
        final int location = this.fetchAttributeLocation(name);
        Gl.vertexAttrib4f(location, value1, value2, value3, value4);
    }
    
    private void fetchUniforms() {
        this.params.clear();
        Gl.getProgramiv(this.program, 35718, this.params);
        final int numUniforms = this.params.get(0);
        this.uniformNames = new String[numUniforms];
        for (int i = 0; i < numUniforms; ++i) {
            this.params.clear();
            this.params.put(0, 1);
            this.type.clear();
            final String name = Gl.getActiveUniform(this.program, i, this.params, this.type);
            final int location = Gl.getUniformLocation(this.program, name);
            this.uniforms.put(name, location);
            this.uniformTypes.put(name, this.type.get(0));
            this.uniformSizes.put(name, this.params.get(0));
            this.uniformNames[i] = name;
        }
    }
    
    private void fetchAttributes() {
        this.params.clear();
        Gl.getProgramiv(this.program, 35721, this.params);
        final int numAttributes = this.params.get(0);
        this.attributeNames = new String[numAttributes];
        for (int i = 0; i < numAttributes; ++i) {
            this.params.clear();
            this.params.put(0, 1);
            this.type.clear();
            final String name = Gl.getActiveAttrib(this.program, i, this.params, this.type);
            final int location = Gl.getAttribLocation(this.program, name);
            this.attributes.put(name, location);
            this.attributeTypes.put(name, this.type.get(0));
            this.attributeSizes.put(name, this.params.get(0));
            this.attributeNames[i] = name;
        }
    }
    
    public boolean hasAttribute(final String name) {
        return this.attributes.containsKey(name);
    }
    
    public int getAttributeType(final String name) {
        return this.attributeTypes.get(name, 0);
    }
    
    public int getAttributeLocation(final String name) {
        return this.attributes.get(name, -1);
    }
    
    public int getAttributeSize(final String name) {
        return this.attributeSizes.get(name, 0);
    }
    
    public boolean hasUniform(final String name) {
        return this.uniforms.containsKey(name);
    }
    
    public int getUniformType(final String name) {
        return this.uniformTypes.get(name, 0);
    }
    
    public int getUniformLocation(final String name) {
        return this.uniforms.get(name, -1);
    }
    
    public int getUniformSize(final String name) {
        return this.uniformSizes.get(name, 0);
    }
    
    public String[] getAttributes() {
        return this.attributeNames;
    }
    
    public String[] getUniforms() {
        return this.uniformNames;
    }
    
    public String getVertexShaderSource() {
        return this.vertexShaderSource;
    }
    
    public String getFragmentShaderSource() {
        return this.fragmentShaderSource;
    }
    
    public static float[] copyTransform(final Mat matrix) {
        Shader.val[4] = matrix.val[3];
        Shader.val[1] = matrix.val[1];
        Shader.val[0] = matrix.val[0];
        Shader.val[5] = matrix.val[4];
        Shader.val[10] = matrix.val[8];
        Shader.val[12] = matrix.val[6];
        Shader.val[13] = matrix.val[7];
        Shader.val[15] = 1.0f;
        return Shader.val;
    }
    
    public static float[] copyTransform(final Mat matrix, final float near, final float far) {
        Shader.val[4] = matrix.val[3];
        Shader.val[1] = matrix.val[1];
        Shader.val[0] = matrix.val[0];
        Shader.val[5] = matrix.val[4];
        Shader.val[10] = matrix.val[8];
        Shader.val[12] = matrix.val[6];
        Shader.val[13] = matrix.val[7];
        Shader.val[15] = 1.0f;
        final float z_orth = -2.0f / (far - near);
        final float tz = -(far + near) / (far - near);
        Shader.val[10] = z_orth;
        Shader.val[14] = tz;
        return Shader.val;
    }
    
    static {
        Shader.pedantic = false;
        Shader.prependVertexCode = "";
        Shader.prependFragmentCode = "";
        val = new float[16];
    }
}
