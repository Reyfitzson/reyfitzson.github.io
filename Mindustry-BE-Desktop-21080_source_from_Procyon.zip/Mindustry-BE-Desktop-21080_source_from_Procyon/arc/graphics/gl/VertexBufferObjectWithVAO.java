// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import arc.graphics.VertexAttribute;
import arc.Core;
import java.nio.Buffer;
import arc.graphics.Gl;
import arc.util.Buffers;
import arc.struct.IntSeq;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import arc.graphics.Mesh;
import java.nio.IntBuffer;

public class VertexBufferObjectWithVAO implements VertexData
{
    static final IntBuffer tmpHandle;
    final Mesh mesh;
    final FloatBuffer buffer;
    final ByteBuffer byteBuffer;
    final boolean isStatic;
    final int usage;
    int bufferHandle;
    boolean isDirty;
    boolean isBound;
    int vaoHandle;
    IntSeq cachedLocations;
    
    public VertexBufferObjectWithVAO(final boolean isStatic, final int numVertices, final Mesh mesh) {
        this.isDirty = false;
        this.isBound = false;
        this.vaoHandle = -1;
        this.cachedLocations = new IntSeq();
        this.isStatic = isStatic;
        this.mesh = mesh;
        this.byteBuffer = Buffers.newUnsafeByteBuffer(this.mesh.vertexSize * numVertices);
        (this.buffer = this.byteBuffer.asFloatBuffer()).flip();
        this.byteBuffer.flip();
        this.bufferHandle = Gl.genBuffer();
        this.usage = (isStatic ? 35044 : 35040);
        this.createVAO();
    }
    
    @Override
    public int size() {
        return this.buffer.limit() * 4 / this.mesh.vertexSize;
    }
    
    @Override
    public int max() {
        return this.byteBuffer.capacity() / this.mesh.vertexSize;
    }
    
    @Override
    public FloatBuffer buffer() {
        this.isDirty = true;
        return this.buffer;
    }
    
    private void bufferChanged() {
        if (this.isBound) {
            Gl.bufferData(34962, this.byteBuffer.limit(), this.byteBuffer, this.usage);
            this.isDirty = false;
        }
    }
    
    @Override
    public void set(final float[] vertices, final int offset, final int count) {
        this.isDirty = true;
        Buffers.copy(vertices, this.byteBuffer, count, offset);
        this.buffer.position(0);
        this.buffer.limit(count);
        this.bufferChanged();
    }
    
    @Override
    public void update(final int targetOffset, final float[] vertices, final int sourceOffset, final int count) {
        this.isDirty = true;
        final int pos = this.byteBuffer.position();
        this.byteBuffer.position(targetOffset * 4);
        Buffers.copy(vertices, sourceOffset, count, this.byteBuffer);
        this.byteBuffer.position(pos);
        this.buffer.position(0);
        this.bufferChanged();
    }
    
    @Override
    public void bind(final Shader shader) {
        Core.gl30.glBindVertexArray(this.vaoHandle);
        this.bindAttributes(shader);
        this.bindData();
        this.isBound = true;
    }
    
    private void bindAttributes(final Shader shader) {
        boolean stillValid = this.cachedLocations.size != 0;
        if (stillValid) {
            int location;
            for (int i = 0; stillValid && i < this.mesh.attributes.length; stillValid = (location == this.cachedLocations.get(i)), ++i) {
                final VertexAttribute attribute = this.mesh.attributes[i];
                location = shader.getAttributeLocation(attribute.alias);
            }
        }
        if (!stillValid) {
            Gl.bindBuffer(34962, this.bufferHandle);
            this.unbindAttributes(shader);
            this.cachedLocations.clear();
            int offset = 0;
            for (int j = 0; j < this.mesh.attributes.length; ++j) {
                final VertexAttribute attribute2 = this.mesh.attributes[j];
                this.cachedLocations.add(shader.getAttributeLocation(attribute2.alias));
                final int aoffset = offset;
                offset += attribute2.size;
                final int location2 = this.cachedLocations.get(j);
                if (location2 >= 0) {
                    shader.enableVertexAttribute(location2);
                    shader.setVertexAttribute(location2, attribute2.components, attribute2.type, attribute2.normalized, this.mesh.vertexSize, aoffset);
                }
            }
        }
    }
    
    private void unbindAttributes(final Shader shader) {
        if (this.cachedLocations.size == 0) {
            return;
        }
        for (int i = 0; i < this.mesh.attributes.length; ++i) {
            final int location = this.cachedLocations.get(i);
            if (location >= 0) {
                shader.disableVertexAttribute(location);
            }
        }
    }
    
    private void bindData() {
        if (this.isDirty) {
            Core.gl.glBindBuffer(34962, this.bufferHandle);
            this.byteBuffer.limit(this.buffer.limit() * 4);
            Core.gl.glBufferData(34962, this.byteBuffer.limit(), this.byteBuffer, this.usage);
            this.isDirty = false;
        }
    }
    
    @Override
    public void unbind(final Shader shader) {
        Core.gl30.glBindVertexArray(0);
        this.isBound = false;
    }
    
    @Override
    public void dispose() {
        Core.gl.glBindBuffer(34962, 0);
        Core.gl.glDeleteBuffer(this.bufferHandle);
        this.bufferHandle = 0;
        Buffers.disposeUnsafeByteBuffer(this.byteBuffer);
        this.deleteVAO();
    }
    
    private void createVAO() {
        VertexBufferObjectWithVAO.tmpHandle.clear();
        Core.gl30.glGenVertexArrays(1, VertexBufferObjectWithVAO.tmpHandle);
        this.vaoHandle = VertexBufferObjectWithVAO.tmpHandle.get();
    }
    
    private void deleteVAO() {
        if (this.vaoHandle != -1) {
            VertexBufferObjectWithVAO.tmpHandle.clear();
            VertexBufferObjectWithVAO.tmpHandle.put(this.vaoHandle);
            VertexBufferObjectWithVAO.tmpHandle.flip();
            Core.gl30.glDeleteVertexArrays(1, VertexBufferObjectWithVAO.tmpHandle);
            this.vaoHandle = -1;
        }
    }
    
    static {
        tmpHandle = Buffers.newIntBuffer(1);
    }
}
