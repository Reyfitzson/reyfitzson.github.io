// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import arc.graphics.GLTexture;
import arc.graphics.Gl;
import arc.graphics.TextureData;
import arc.graphics.g2d.Draw;
import arc.graphics.Pixmap;
import arc.graphics.Texture;

public class FrameBuffer extends GLFrameBuffer<Texture>
{
    private Pixmap.Format format;
    
    protected FrameBuffer(final GLFrameBufferBuilder<? extends GLFrameBuffer<Texture>> bufferBuilder) {
        super(bufferBuilder);
    }
    
    public FrameBuffer() {
        this(2, 2);
    }
    
    public FrameBuffer(final int width, final int height) {
        this(Pixmap.Format.rgba8888, width, height, false, false);
    }
    
    public FrameBuffer(final Pixmap.Format format, final int width, final int height) {
        this(format, width, height, false, false);
    }
    
    public FrameBuffer(final Pixmap.Format format, final int width, final int height, final boolean hasDepth) {
        this(format, width, height, hasDepth, false);
    }
    
    public FrameBuffer(final int width, final int height, final boolean hasDepth) {
        this(Pixmap.Format.rgba8888, width, height, hasDepth, false);
    }
    
    public FrameBuffer(final Pixmap.Format format, final int width, final int height, final boolean hasDepth, final boolean hasStencil) {
        this.create(format, width, height, hasDepth, hasStencil);
    }
    
    protected void create(final Pixmap.Format format, int width, int height, final boolean hasDepth, final boolean hasStencil) {
        width = Math.max(width, 2);
        height = Math.max(height, 2);
        this.format = format;
        final FrameBufferBuilder frameBufferBuilder = new FrameBufferBuilder(width, height);
        frameBufferBuilder.addBasicColorTextureAttachment(format);
        if (hasDepth) {
            frameBufferBuilder.addBasicDepthRenderBuffer();
        }
        if (hasStencil) {
            frameBufferBuilder.addBasicStencilRenderBuffer();
        }
        this.bufferBuilder = (GLFrameBufferBuilder<? extends GLFrameBuffer<T>>)frameBufferBuilder;
        this.build();
    }
    
    public void blit(final Shader shader) {
        Draw.blit(this, shader);
    }
    
    public void resize(int width, int height) {
        width = Math.max(width, 2);
        height = Math.max(height, 2);
        if (width == this.getWidth() && height == this.getHeight()) {
            return;
        }
        final Texture.TextureFilter min = this.getTexture().getMinFilter();
        final Texture.TextureFilter mag = this.getTexture().getMagFilter();
        final boolean hasDepth = this.depthbufferHandle != 0;
        final boolean hasStencil = this.stencilbufferHandle != 0;
        this.dispose();
        final FrameBufferBuilder frameBufferBuilder = new FrameBufferBuilder(width, height);
        frameBufferBuilder.addBasicColorTextureAttachment(this.format);
        if (hasDepth) {
            frameBufferBuilder.addBasicDepthRenderBuffer();
        }
        if (hasStencil) {
            frameBufferBuilder.addBasicStencilRenderBuffer();
        }
        this.bufferBuilder = (GLFrameBufferBuilder<? extends GLFrameBuffer<T>>)frameBufferBuilder;
        this.textureAttachments.clear();
        this.framebufferHandle = 0;
        this.depthbufferHandle = 0;
        this.stencilbufferHandle = 0;
        this.depthStencilPackedBufferHandle = 0;
        final boolean b = false;
        this.isMRT = b;
        this.hasDepthStencilPackedBuffer = b;
        this.build();
        this.getTexture().setFilter(min, mag);
    }
    
    public static void unbind() {
        GLFrameBuffer.unbind();
    }
    
    @Override
    protected Texture createTexture(final FrameBufferTextureAttachmentSpec attachmentSpec) {
        final GLOnlyTextureData data = new GLOnlyTextureData(this.bufferBuilder.width, this.bufferBuilder.height, 0, attachmentSpec.internalFormat, attachmentSpec.format, attachmentSpec.type);
        final Texture result = new Texture(data);
        result.setFilter(Texture.TextureFilter.linear, Texture.TextureFilter.linear);
        result.setWrap(Texture.TextureWrap.clampToEdge, Texture.TextureWrap.clampToEdge);
        return result;
    }
    
    @Override
    protected void disposeColorTexture(final Texture colorTexture) {
        colorTexture.dispose();
    }
    
    @Override
    protected void attachFrameBufferColorTexture(final Texture texture) {
        Gl.framebufferTexture2D(36160, 36064, 3553, texture.getTextureObjectHandle(), 0);
    }
}
