// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.gl;

import arc.graphics.VertexAttribute;
import java.nio.ShortBuffer;
import java.nio.Buffer;
import arc.graphics.Gl;
import arc.util.Buffers;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import arc.graphics.Mesh;

public class VertexArray implements VertexData
{
    final Mesh mesh;
    final FloatBuffer buffer;
    final ByteBuffer byteBuffer;
    boolean isBound;
    
    public VertexArray(final int numVertices, final Mesh mesh) {
        this.isBound = false;
        this.mesh = mesh;
        this.byteBuffer = Buffers.newUnsafeByteBuffer(this.mesh.vertexSize * numVertices);
        (this.buffer = this.byteBuffer.asFloatBuffer()).flip();
        this.byteBuffer.flip();
        this.byteBuffer.asFloatBuffer();
    }
    
    @Override
    public void render(final IndexData indices, final int primitiveType, final int offset, final int count) {
        if (indices.size() > 0) {
            final ShortBuffer buffer = indices.buffer();
            final int oldPosition = buffer.position();
            final int oldLimit = buffer.limit();
            buffer.position(offset);
            buffer.limit(offset + count);
            Gl.drawElements(primitiveType, count, 5123, buffer);
            buffer.position(oldPosition);
            buffer.limit(oldLimit);
        }
        else {
            Gl.drawArrays(primitiveType, offset, count);
        }
    }
    
    @Override
    public void dispose() {
        Buffers.disposeUnsafeByteBuffer(this.byteBuffer);
    }
    
    @Override
    public FloatBuffer buffer() {
        return this.buffer;
    }
    
    @Override
    public int size() {
        return this.buffer.limit() * 4 / this.mesh.vertexSize;
    }
    
    @Override
    public int max() {
        return this.byteBuffer.capacity() / this.mesh.vertexSize;
    }
    
    @Override
    public void set(final float[] vertices, final int offset, final int count) {
        Buffers.copy(vertices, this.byteBuffer, count, offset);
        this.buffer.position(0);
        this.buffer.limit(count);
    }
    
    @Override
    public void update(final int targetOffset, final float[] vertices, final int sourceOffset, final int count) {
        final int pos = this.byteBuffer.position();
        this.byteBuffer.position(targetOffset * 4);
        Buffers.copy(vertices, sourceOffset, count, this.byteBuffer);
        this.byteBuffer.position(pos);
    }
    
    @Override
    public void bind(final Shader shader) {
        this.byteBuffer.limit(this.buffer.limit() * 4);
        int offset = 0;
        for (final VertexAttribute attribute : this.mesh.attributes) {
            final int location = shader.getAttributeLocation(attribute.alias);
            final int aoffset = offset;
            offset += attribute.size;
            if (location >= 0) {
                shader.enableVertexAttribute(location);
                if (attribute.type == 5126) {
                    this.buffer.position(aoffset / 4);
                    shader.setVertexAttribute(location, attribute.components, attribute.type, attribute.normalized, this.mesh.vertexSize, this.buffer);
                }
                else {
                    this.byteBuffer.position(aoffset);
                    shader.setVertexAttribute(location, attribute.components, attribute.type, attribute.normalized, this.mesh.vertexSize, this.byteBuffer);
                }
            }
        }
        this.isBound = true;
    }
    
    @Override
    public void unbind(final Shader shader) {
        for (final VertexAttribute attribute : this.mesh.attributes) {
            shader.disableVertexAttribute(attribute.alias);
        }
        this.isBound = false;
    }
}
