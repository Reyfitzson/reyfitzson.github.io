// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

public final class VertexAttribute
{
    public static final VertexAttribute position;
    public static final VertexAttribute position3;
    public static final VertexAttribute texCoords;
    public static final VertexAttribute normal;
    public static final VertexAttribute color;
    public static final VertexAttribute mixColor;
    public final int components;
    public final boolean normalized;
    public final int type;
    public final String alias;
    public final int size;
    
    public VertexAttribute(final int components, final String alias) {
        this(components, 5126, false, alias);
    }
    
    public VertexAttribute(final int components, final int type, final boolean normalized, final String alias) {
        this.components = components;
        this.type = type;
        this.normalized = normalized;
        this.alias = alias;
        int realSize = 0;
        switch (type) {
            case 5126:
            case 5132: {
                realSize = 4 * components;
                break;
            }
            case 5120:
            case 5121: {
                realSize = components;
                break;
            }
            case 5122:
            case 5123: {
                realSize = 2 * components;
                break;
            }
        }
        this.size = realSize;
    }
    
    static {
        position = new VertexAttribute(2, "a_position");
        position3 = new VertexAttribute(3, "a_position");
        texCoords = new VertexAttribute(2, "a_texCoord0");
        normal = new VertexAttribute(3, "a_normal");
        color = new VertexAttribute(4, 5121, true, "a_color");
        mixColor = new VertexAttribute(4, 5121, true, "a_mix_color");
    }
}
