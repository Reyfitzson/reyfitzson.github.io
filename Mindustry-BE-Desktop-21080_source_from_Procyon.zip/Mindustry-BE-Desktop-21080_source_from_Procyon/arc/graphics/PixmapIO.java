// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import java.util.zip.Checksum;
import java.util.zip.CheckedOutputStream;
import java.util.zip.CRC32;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.io.DataOutputStream;
import java.util.zip.DeflaterOutputStream;
import java.io.OutputStream;
import java.io.Closeable;
import arc.util.io.Streams;
import arc.struct.ByteSeq;
import java.util.zip.Deflater;
import arc.util.Disposable;
import java.io.IOException;
import arc.util.ArcRuntimeException;
import arc.files.Fi;

public class PixmapIO
{
    public static void writePNG(final Fi file, final Pixmap pixmap) {
        try {
            final PNG writer = new PNG((int)(pixmap.getWidth() * pixmap.getHeight() * 1.5f));
            try {
                writer.setFlipY(false);
                writer.write(file, pixmap);
            }
            finally {
                writer.dispose();
            }
        }
        catch (IOException ex) {
            throw new ArcRuntimeException("Error writing PNG: " + file, ex);
        }
    }
    
    public static class PNG implements Disposable
    {
        private static final byte[] SIGNATURE;
        private static final int IHDR = 1229472850;
        private static final int IDAT = 1229209940;
        private static final int IEND = 1229278788;
        private static final byte COLOR_ARGB = 6;
        private static final byte COMPRESSION_DEFLATE = 0;
        private static final byte FILTER_NONE = 0;
        private static final byte INTERLACE_NONE = 0;
        private static final byte PAETH = 4;
        private final ChunkBuffer buffer;
        private final Deflater deflater;
        private ByteSeq lineOutBytes;
        private ByteSeq curLineBytes;
        private ByteSeq prevLineBytes;
        private boolean flipY;
        private int lastLineLen;
        
        public PNG() {
            this(16384);
        }
        
        public PNG(final int initialBufferSize) {
            this.flipY = true;
            this.buffer = new ChunkBuffer(initialBufferSize);
            this.deflater = new Deflater();
        }
        
        public void setFlipY(final boolean flipY) {
            this.flipY = flipY;
        }
        
        public void setCompression(final int level) {
            this.deflater.setLevel(level);
        }
        
        public void write(final Fi file, final Pixmap pixmap) throws IOException {
            final OutputStream output = file.write(false);
            try {
                this.write(output, pixmap);
            }
            finally {
                Streams.close(output);
            }
        }
        
        public void write(final OutputStream output, final Pixmap pixmap) throws IOException {
            final DeflaterOutputStream deflaterOutput = new DeflaterOutputStream(this.buffer, this.deflater);
            final DataOutputStream dataOutput = new DataOutputStream(output);
            dataOutput.write(PNG.SIGNATURE);
            this.buffer.writeInt(1229472850);
            this.buffer.writeInt(pixmap.getWidth());
            this.buffer.writeInt(pixmap.getHeight());
            this.buffer.writeByte(8);
            this.buffer.writeByte(6);
            this.buffer.writeByte(0);
            this.buffer.writeByte(0);
            this.buffer.writeByte(0);
            this.buffer.endChunk(dataOutput);
            this.buffer.writeInt(1229209940);
            this.deflater.reset();
            final int lineLen = pixmap.getWidth() * 4;
            byte[] lineOut;
            byte[] curLine;
            byte[] prevLine;
            if (this.lineOutBytes == null) {
                final ByteSeq lineOutBytes = new ByteSeq(lineLen);
                this.lineOutBytes = lineOutBytes;
                lineOut = lineOutBytes.items;
                final ByteSeq curLineBytes = new ByteSeq(lineLen);
                this.curLineBytes = curLineBytes;
                curLine = curLineBytes.items;
                final ByteSeq prevLineBytes = new ByteSeq(lineLen);
                this.prevLineBytes = prevLineBytes;
                prevLine = prevLineBytes.items;
            }
            else {
                lineOut = this.lineOutBytes.ensureCapacity(lineLen);
                curLine = this.curLineBytes.ensureCapacity(lineLen);
                prevLine = this.prevLineBytes.ensureCapacity(lineLen);
                for (int i = 0, n = this.lastLineLen; i < n; ++i) {
                    prevLine[i] = 0;
                }
            }
            this.lastLineLen = lineLen;
            final ByteBuffer pixels = pixmap.getPixels();
            final int oldPosition = pixels.position();
            final boolean rgba8888 = pixmap.getFormat() == Pixmap.Format.rgba8888;
            for (int y = 0, h = pixmap.getHeight(); y < h; ++y) {
                final int py = this.flipY ? (h - y - 1) : y;
                if (rgba8888) {
                    pixels.position(py * lineLen);
                    pixels.get(curLine, 0, lineLen);
                }
                else {
                    int px = 0;
                    int x = 0;
                    while (px < pixmap.getWidth()) {
                        final int pixel = pixmap.getPixel(px, py);
                        curLine[x++] = (byte)(pixel >> 24 & 0xFF);
                        curLine[x++] = (byte)(pixel >> 16 & 0xFF);
                        curLine[x++] = (byte)(pixel >> 8 & 0xFF);
                        curLine[x++] = (byte)(pixel & 0xFF);
                        ++px;
                    }
                }
                lineOut[0] = (byte)(curLine[0] - prevLine[0]);
                lineOut[1] = (byte)(curLine[1] - prevLine[1]);
                lineOut[2] = (byte)(curLine[2] - prevLine[2]);
                lineOut[3] = (byte)(curLine[3] - prevLine[3]);
                for (int x2 = 4; x2 < lineLen; ++x2) {
                    final int a = curLine[x2 - 4] & 0xFF;
                    final int b = prevLine[x2] & 0xFF;
                    int c = prevLine[x2 - 4] & 0xFF;
                    final int p = a + b - c;
                    int pa = p - a;
                    if (pa < 0) {
                        pa = -pa;
                    }
                    int pb = p - b;
                    if (pb < 0) {
                        pb = -pb;
                    }
                    int pc = p - c;
                    if (pc < 0) {
                        pc = -pc;
                    }
                    if (pa <= pb && pa <= pc) {
                        c = a;
                    }
                    else if (pb <= pc) {
                        c = b;
                    }
                    lineOut[x2] = (byte)(curLine[x2] - c);
                }
                deflaterOutput.write(4);
                deflaterOutput.write(lineOut, 0, lineLen);
                final byte[] temp = curLine;
                curLine = prevLine;
                prevLine = temp;
            }
            pixels.position(oldPosition);
            deflaterOutput.finish();
            this.buffer.endChunk(dataOutput);
            this.buffer.writeInt(1229278788);
            this.buffer.endChunk(dataOutput);
            output.flush();
        }
        
        @Override
        public void dispose() {
            this.deflater.end();
        }
        
        static {
            SIGNATURE = new byte[] { -119, 80, 78, 71, 13, 10, 26, 10 };
        }
        
        static class ChunkBuffer extends DataOutputStream
        {
            final ByteArrayOutputStream buffer;
            final CRC32 crc;
            
            ChunkBuffer(final int initialSize) {
                this(new ByteArrayOutputStream(initialSize), new CRC32());
            }
            
            private ChunkBuffer(final ByteArrayOutputStream buffer, final CRC32 crc) {
                super(new CheckedOutputStream(buffer, crc));
                this.buffer = buffer;
                this.crc = crc;
            }
            
            public void endChunk(final DataOutputStream target) throws IOException {
                this.flush();
                target.writeInt(this.buffer.size() - 4);
                this.buffer.writeTo(target);
                target.writeInt((int)this.crc.getValue());
                this.buffer.reset();
                this.crc.reset();
            }
        }
    }
}
