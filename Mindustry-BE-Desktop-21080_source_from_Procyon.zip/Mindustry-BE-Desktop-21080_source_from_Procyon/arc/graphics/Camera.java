// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import arc.math.geom.Rect;
import arc.Core;
import arc.math.Mat;
import arc.math.geom.Vec2;

public class Camera
{
    private static final Vec2 tmpVector;
    public final Vec2 position;
    public final Mat mat;
    public final Mat inv;
    public float width;
    public float height;
    
    public Camera() {
        this.position = new Vec2();
        this.mat = new Mat();
        this.inv = new Mat();
    }
    
    public void update() {
        this.mat.setOrtho(this.position.x - this.width / 2.0f, this.position.y - this.height / 2.0f, this.width, this.height);
        this.inv.set(this.mat).inv();
    }
    
    public void resize(final float viewportWidth, final float viewportHeight) {
        this.width = viewportWidth;
        this.height = viewportHeight;
        this.update();
    }
    
    public Vec2 unproject(final Vec2 screenCoords, final float viewportX, final float viewportY, final float viewportWidth, final float viewportHeight) {
        float x = screenCoords.x;
        float y = screenCoords.y;
        x -= viewportX;
        y -= viewportY;
        screenCoords.x = 2.0f * x / viewportWidth - 1.0f;
        screenCoords.y = 2.0f * y / viewportHeight - 1.0f;
        screenCoords.mul(this.inv);
        return screenCoords;
    }
    
    public Vec2 unproject(final Vec2 screenCoords) {
        this.unproject(screenCoords, 0.0f, 0.0f, (float)Core.graphics.getWidth(), (float)Core.graphics.getHeight());
        return screenCoords;
    }
    
    public Vec2 unproject(final float screenX, final float screenY) {
        this.unproject(Camera.tmpVector.set(screenX, screenY), 0.0f, 0.0f, (float)Core.graphics.getWidth(), (float)Core.graphics.getHeight());
        return Camera.tmpVector;
    }
    
    public Vec2 project(final Vec2 worldCoords) {
        this.project(worldCoords, 0.0f, 0.0f, (float)Core.graphics.getWidth(), (float)Core.graphics.getHeight());
        return worldCoords;
    }
    
    public Vec2 project(final float screenX, final float screenY) {
        this.project(Camera.tmpVector.set(screenX, screenY), 0.0f, 0.0f, (float)Core.graphics.getWidth(), (float)Core.graphics.getHeight());
        return Camera.tmpVector;
    }
    
    public Vec2 project(final Vec2 worldCoords, final float viewportX, final float viewportY, final float viewportWidth, final float viewportHeight) {
        worldCoords.mul(this.mat);
        worldCoords.x = viewportWidth * (worldCoords.x + 1.0f) / 2.0f + viewportX;
        worldCoords.y = viewportHeight * (worldCoords.y + 1.0f) / 2.0f + viewportY;
        return worldCoords;
    }
    
    public Rect bounds(final Rect out) {
        return out.setSize(this.width, this.height).setCenter(this.position);
    }
    
    static {
        tmpVector = new Vec2();
    }
}
