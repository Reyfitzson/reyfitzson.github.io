// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics;

import java.nio.Buffer;
import arc.graphics.gl.MipMapGenerator;
import arc.util.Disposable;

public abstract class GLTexture implements Disposable
{
    public final int glTarget;
    public int width;
    public int height;
    protected int glHandle;
    protected Texture.TextureFilter minFilter;
    protected Texture.TextureFilter magFilter;
    protected Texture.TextureWrap uWrap;
    protected Texture.TextureWrap vWrap;
    
    public GLTexture(final int glTarget) {
        this(glTarget, Gl.genTexture());
    }
    
    public GLTexture(final int glTarget, final int glHandle) {
        this.minFilter = Texture.TextureFilter.nearest;
        this.magFilter = Texture.TextureFilter.nearest;
        this.uWrap = Texture.TextureWrap.clampToEdge;
        this.vWrap = Texture.TextureWrap.clampToEdge;
        this.glTarget = glTarget;
        this.glHandle = glHandle;
    }
    
    protected static void uploadImageData(final int target, final TextureData data) {
        uploadImageData(target, data, 0);
    }
    
    public static void uploadImageData(final int target, final TextureData data, final int miplevel) {
        if (data == null) {
            return;
        }
        if (!data.isPrepared()) {
            data.prepare();
        }
        if (data.isCustom()) {
            data.consumeCustomData(target);
            return;
        }
        Pixmap pixmap = data.consumePixmap();
        boolean disposePixmap = data.disposePixmap();
        if (data.getFormat() != pixmap.getFormat()) {
            final Pixmap tmp = new Pixmap(pixmap.getWidth(), pixmap.getHeight(), data.getFormat());
            tmp.setBlending(Pixmap.Blending.none);
            tmp.drawPixmap(pixmap, 0, 0, 0, 0, pixmap.getWidth(), pixmap.getHeight());
            if (data.disposePixmap()) {
                pixmap.dispose();
            }
            pixmap = tmp;
            disposePixmap = true;
        }
        Gl.pixelStorei(3317, 1);
        if (data.useMipMaps()) {
            MipMapGenerator.generateMipMap(target, pixmap, pixmap.getWidth(), pixmap.getHeight());
        }
        else {
            Gl.texImage2D(target, miplevel, pixmap.getGLInternalFormat(), pixmap.getWidth(), pixmap.getHeight(), 0, pixmap.getGLFormat(), pixmap.getGLType(), pixmap.getPixels());
        }
        if (disposePixmap) {
            pixmap.dispose();
        }
    }
    
    public abstract int getDepth();
    
    public void bind() {
        Gl.bindTexture(this.glTarget, this.glHandle);
    }
    
    public void bind(final int unit) {
        Gl.activeTexture(33984 + unit);
        Gl.bindTexture(this.glTarget, this.glHandle);
    }
    
    public Texture.TextureFilter getMinFilter() {
        return this.minFilter;
    }
    
    public Texture.TextureFilter getMagFilter() {
        return this.magFilter;
    }
    
    public Texture.TextureWrap getUWrap() {
        return this.uWrap;
    }
    
    public Texture.TextureWrap getVWrap() {
        return this.vWrap;
    }
    
    public int getTextureObjectHandle() {
        return this.glHandle;
    }
    
    public void unsafeSetWrap(final Texture.TextureWrap u, final Texture.TextureWrap v) {
        this.unsafeSetWrap(u, v, false);
    }
    
    public void unsafeSetWrap(final Texture.TextureWrap u, final Texture.TextureWrap v, final boolean force) {
        if (u != null && (force || this.uWrap != u)) {
            Gl.texParameteri(this.glTarget, 10242, u.getGLEnum());
            this.uWrap = u;
        }
        if (v != null && (force || this.vWrap != v)) {
            Gl.texParameteri(this.glTarget, 10243, v.getGLEnum());
            this.vWrap = v;
        }
    }
    
    public void setWrap(final Texture.TextureWrap wrap) {
        this.setWrap(wrap, wrap);
    }
    
    public void setWrap(final Texture.TextureWrap u, final Texture.TextureWrap v) {
        this.uWrap = u;
        this.vWrap = v;
        this.bind();
        Gl.texParameteri(this.glTarget, 10242, u.getGLEnum());
        Gl.texParameteri(this.glTarget, 10243, v.getGLEnum());
    }
    
    public void unsafeSetFilter(final Texture.TextureFilter minFilter, final Texture.TextureFilter magFilter) {
        this.unsafeSetFilter(minFilter, magFilter, false);
    }
    
    public void unsafeSetFilter(final Texture.TextureFilter minFilter, final Texture.TextureFilter magFilter, final boolean force) {
        if (minFilter != null && (force || this.minFilter != minFilter)) {
            Gl.texParameteri(this.glTarget, 10241, minFilter.glEnum);
            this.minFilter = minFilter;
        }
        if (magFilter != null && (force || this.magFilter != magFilter)) {
            Gl.texParameteri(this.glTarget, 10240, magFilter.glEnum);
            this.magFilter = magFilter;
        }
    }
    
    public void setFilter(final Texture.TextureFilter filter) {
        this.setFilter(filter, filter);
    }
    
    public void setFilter(final Texture.TextureFilter minFilter, final Texture.TextureFilter magFilter) {
        this.minFilter = minFilter;
        this.magFilter = magFilter;
        this.bind();
        Gl.texParameteri(this.glTarget, 10241, minFilter.glEnum);
        Gl.texParameteri(this.glTarget, 10240, magFilter.glEnum);
    }
    
    protected void delete() {
        if (this.glHandle != 0) {
            Gl.deleteTexture(this.glHandle);
            this.glHandle = 0;
        }
    }
    
    @Override
    public void dispose() {
        this.delete();
    }
}
