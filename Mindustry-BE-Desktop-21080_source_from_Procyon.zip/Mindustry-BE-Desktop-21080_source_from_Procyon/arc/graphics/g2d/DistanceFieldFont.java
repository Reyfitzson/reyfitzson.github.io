// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import java.util.Iterator;
import arc.graphics.Texture;
import arc.graphics.gl.Shader;
import arc.files.Fi;
import arc.struct.Seq;

public class DistanceFieldFont extends Font
{
    private float distanceFieldSmoothing;
    
    public DistanceFieldFont(final FontData data, final Seq<TextureRegion> pageRegions, final boolean integer) {
        super(data, pageRegions, integer);
    }
    
    public DistanceFieldFont(final FontData data, final TextureRegion region, final boolean integer) {
        super(data, region, integer);
    }
    
    public DistanceFieldFont(final Fi fontFile, final boolean flip) {
        super(fontFile, flip);
    }
    
    public DistanceFieldFont(final Fi fontFile, final Fi imageFile, final boolean flip, final boolean integer) {
        super(fontFile, imageFile, flip, integer);
    }
    
    public DistanceFieldFont(final Fi fontFile, final Fi imageFile, final boolean flip) {
        super(fontFile, imageFile, flip);
    }
    
    public DistanceFieldFont(final Fi fontFile, final TextureRegion region, final boolean flip) {
        super(fontFile, region, flip);
    }
    
    public DistanceFieldFont(final Fi fontFile, final TextureRegion region) {
        super(fontFile, region);
    }
    
    public DistanceFieldFont(final Fi fontFile) {
        super(fontFile);
    }
    
    public static Shader createDistanceFieldShader() {
        final String vertexShader = "attribute vec4 a_position;\nattribute vec4 a_color;\nattribute vec2 a_texCoord0;\nuniform mat4 u_projTrans;\nvarying vec4 v_color;\nvarying vec2 v_texCoords;\n\nvoid main(){\n\tv_color = a_color;\n\tv_color.a = v_color.a * (255.0/254.0);\n\tv_texCoords = a_texCoord0;\n\tgl_Position =  u_projTrans * a_position;\n}\n";
        final String fragmentShader = "uniform sampler2D u_texture;\nuniform float u_smoothing;\nvarying vec4 v_color;\nvarying vec2 v_texCoords;\n\nvoid main(){\n\tif (u_smoothing > 0.0) {\n\t\tfloat smoothing = 0.25 / u_smoothing;\n\t\tfloat distance = texture2D(u_texture, v_texCoords).a;\n\t\tfloat alpha = smoothstep(0.5 - smoothing, 0.5 + smoothing, distance);\n\t\tgl_FragColor = vec4(v_color.rgb, alpha * v_color.a);\n\t} else {\n\t\tgl_FragColor = v_color * texture2D(u_texture, v_texCoords);\n\t}\n}\n";
        return new Shader(vertexShader, fragmentShader);
    }
    
    @Override
    protected void load(final FontData data) {
        super.load(data);
        final Seq<TextureRegion> regions = this.getRegions();
        for (final TextureRegion region : regions) {
            region.texture.setFilter(Texture.TextureFilter.linear, Texture.TextureFilter.linear);
        }
    }
    
    @Override
    public FontCache newFontCache() {
        return new DistanceFieldFontCache(this, this.integer);
    }
    
    public float getDistanceFieldSmoothing() {
        return this.distanceFieldSmoothing;
    }
    
    public void setDistanceFieldSmoothing(final float distanceFieldSmoothing) {
        this.distanceFieldSmoothing = distanceFieldSmoothing;
    }
    
    private static class DistanceFieldFontCache extends FontCache
    {
        public DistanceFieldFontCache(final DistanceFieldFont font) {
            super(font, font.usesIntegerPositions());
        }
        
        public DistanceFieldFontCache(final DistanceFieldFont font, final boolean integer) {
            super(font, integer);
        }
        
        private float getSmoothingFactor() {
            final DistanceFieldFont font = (DistanceFieldFont)super.getFont();
            return font.getDistanceFieldSmoothing() * font.getScaleX();
        }
        
        private void setSmoothingUniform(final float smoothing) {
            Draw.flush();
            Draw.getShader().setUniformf("u_smoothing", smoothing);
        }
        
        @Override
        public void draw() {
            this.setSmoothingUniform(this.getSmoothingFactor());
            super.draw();
            this.setSmoothingUniform(0.0f);
        }
        
        @Override
        public void draw(final int start, final int end) {
            this.setSmoothingUniform(this.getSmoothingFactor());
            super.draw(start, end);
            this.setSmoothingUniform(0.0f);
        }
    }
}
