// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.graphics.Color;
import arc.graphics.gl.Shader;
import arc.graphics.Blending;
import arc.math.Mat;
import arc.graphics.Texture;
import arc.graphics.Mesh;
import arc.util.Disposable;

public abstract class Batch implements Disposable
{
    protected Mesh mesh;
    protected float z;
    protected boolean sortAscending;
    protected int idx;
    protected Texture lastTexture;
    protected boolean apply;
    protected final Mat transformMatrix;
    protected final Mat projectionMatrix;
    protected final Mat combinedMatrix;
    protected Blending blending;
    protected Shader shader;
    protected Shader customShader;
    protected boolean ownsShader;
    protected final Color color;
    protected float colorPacked;
    protected final Color mixColor;
    protected float mixColorPacked;
    
    public Batch() {
        this.sortAscending = true;
        this.idx = 0;
        this.lastTexture = null;
        this.transformMatrix = new Mat();
        this.projectionMatrix = new Mat();
        this.combinedMatrix = new Mat();
        this.blending = Blending.normal;
        this.customShader = null;
        this.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        this.colorPacked = Color.whiteFloatBits;
        this.mixColor = Color.clear;
        this.mixColorPacked = Color.clearFloatBits;
    }
    
    protected void z(final float z) {
        this.z = (this.sortAscending ? z : (-z));
    }
    
    protected void setSort(final boolean sort) {
    }
    
    protected void setSortAscending(final boolean ascend) {
        this.sortAscending = ascend;
    }
    
    protected void setColor(final Color tint) {
        this.color.set(tint);
        this.colorPacked = tint.toFloatBits();
    }
    
    protected void setColor(final float r, final float g, final float b, final float a) {
        this.color.set(r, g, b, a);
        this.colorPacked = this.color.toFloatBits();
    }
    
    protected Color getColor() {
        return this.color;
    }
    
    protected void setPackedColor(final float packedColor) {
        this.color.abgr8888(packedColor);
        this.colorPacked = packedColor;
    }
    
    protected float getPackedColor() {
        return this.colorPacked;
    }
    
    protected void setMixColor(final Color tint) {
        this.mixColor.set(tint);
        this.mixColorPacked = tint.toFloatBits();
    }
    
    protected void setMixColor(final float r, final float g, final float b, final float a) {
        this.mixColor.set(r, g, b, a);
        this.mixColorPacked = this.mixColor.toFloatBits();
    }
    
    protected Color getMixColor() {
        return this.mixColor;
    }
    
    protected void setPackedMixColor(final float packedColor) {
        this.mixColor.abgr8888(packedColor);
        this.mixColorPacked = packedColor;
    }
    
    protected float getPackedMixColor() {
        return this.mixColorPacked;
    }
    
    protected abstract void draw(final Texture p0, final float[] p1, final int p2, final int p3);
    
    protected abstract void draw(final TextureRegion p0, final float p1, final float p2, final float p3, final float p4, final float p5, final float p6, final float p7);
    
    protected void draw(final Runnable request) {
        request.run();
    }
    
    protected abstract void flush();
    
    protected void setBlending(final Blending blending) {
        if (this.blending != blending) {
            this.flush();
        }
        this.blending = blending;
    }
    
    @Override
    public void dispose() {
        if (this.mesh != null) {
            this.mesh.dispose();
        }
        if (this.ownsShader && this.shader != null) {
            this.shader.dispose();
        }
    }
    
    protected Mat getProjection() {
        return this.projectionMatrix;
    }
    
    protected Mat getTransform() {
        return this.transformMatrix;
    }
    
    protected void setProjection(final Mat projection) {
        this.flush();
        this.projectionMatrix.set(projection);
    }
    
    protected void setTransform(final Mat transform) {
        this.flush();
        this.transformMatrix.set(transform);
    }
    
    protected void setupMatrices() {
        this.combinedMatrix.set(this.projectionMatrix).mul(this.transformMatrix);
        this.getShader().setUniformMatrix4("u_projTrans", this.combinedMatrix);
        this.getShader().setUniformi("u_texture", 0);
    }
    
    protected void switchTexture(final Texture texture) {
        this.flush();
        this.lastTexture = texture;
    }
    
    protected void setShader(final Shader shader) {
        this.setShader(shader, true);
    }
    
    protected void setShader(final Shader shader, final boolean apply) {
        this.flush();
        this.customShader = shader;
        this.apply = apply;
    }
    
    protected Shader getShader() {
        return (this.customShader == null) ? this.shader : this.customShader;
    }
}
