// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.math.geom.Vec2;
import arc.func.Cons;
import arc.math.Mat;
import arc.math.geom.Position;
import arc.graphics.Blending;
import arc.util.Tmp;
import arc.math.Mathf;
import arc.graphics.Gl;
import arc.Core;
import arc.graphics.gl.FrameBuffer;
import arc.graphics.Texture;
import arc.graphics.gl.Shader;
import arc.math.geom.Rect;
import arc.util.Nullable;
import arc.graphics.Camera;
import arc.graphics.Color;

public class Draw
{
    private static ScreenQuad squad;
    private static final Color[] carr;
    private static final float[] vertices;
    @Nullable
    private static Camera lastProj;
    private static Rect lastViewport;
    public static float scl;
    public static float xscl;
    public static float yscl;
    
    private static ScreenQuad getQuad() {
        if (Draw.squad == null) {
            Draw.squad = new ScreenQuad();
        }
        return Draw.squad;
    }
    
    public static void blit(final Shader shader) {
        shader.bind();
        shader.apply();
        getQuad().render(shader);
    }
    
    public static void blit(final Texture texture, final Shader shader) {
        texture.bind(0);
        shader.bind();
        shader.apply();
        getQuad().render(shader);
    }
    
    public static void blit(final FrameBuffer buffer, final Shader shader) {
        blit(buffer.getTexture(), shader);
    }
    
    public static void batch(final Batch nextBatch) {
        flush();
        Core.batch = nextBatch;
    }
    
    public static void batch(final Batch nextBatch, final Runnable run) {
        final Batch prev = Core.batch;
        prev.flush();
        Core.batch = nextBatch;
        run.run();
        nextBatch.flush();
        Core.batch = prev;
    }
    
    public static void stencil(final Runnable stencil, final Runnable contents) {
        beginStencil();
        stencil.run();
        beginStenciled();
        contents.run();
        endStencil();
    }
    
    public static void beginStencil() {
        flush();
        Gl.stencilMask(255);
        Gl.colorMask(false, false, false, false);
        Gl.enable(2960);
        Gl.stencilFunc(519, 1, 255);
        Gl.stencilMask(255);
        Gl.stencilOp(7681, 7681, 7681);
    }
    
    public static void beginStenciled() {
        flush();
        Gl.stencilOp(7680, 7680, 7680);
        Gl.colorMask(true, true, true, true);
        Gl.stencilFunc(514, 1, 255);
    }
    
    public static void endStencil() {
        flush();
        Gl.disable(2960);
    }
    
    public static void scl(final float nscl) {
        scl(nscl, nscl);
    }
    
    public static void scl(final float nxscl, final float nyscl) {
        Draw.xscl = nxscl;
        Draw.yscl = nyscl;
    }
    
    public static void scl() {
        Draw.xscl = (Draw.yscl = 1.0f);
    }
    
    public static Shader getShader() {
        return Core.batch.getShader();
    }
    
    public static void shader(final Shader shader) {
        shader(shader, true);
    }
    
    public static void shader(final Shader shader, final boolean apply) {
        Core.batch.setShader(shader, apply);
    }
    
    public static void shader() {
        Core.batch.setShader(null);
    }
    
    public static void sort(final boolean sort) {
        Core.batch.setSort(sort);
    }
    
    public static void sortAscending(final boolean ascend) {
        Core.batch.setSortAscending(ascend);
    }
    
    public static float z() {
        return Core.batch.sortAscending ? Core.batch.z : (-Core.batch.z);
    }
    
    public static void z(final float z) {
        Core.batch.z(z);
    }
    
    public static Color getColor() {
        return Core.batch.getColor();
    }
    
    public static Color getMixColor() {
        return Core.batch.getMixColor();
    }
    
    public static void mixcol(final Color color, final float a) {
        Core.batch.setMixColor(color.r, color.g, color.b, Mathf.clamp(a));
    }
    
    public static void mixcol() {
        Core.batch.setPackedMixColor(Color.clearFloatBits);
    }
    
    public static void tint(final Color a, final Color b, final float s) {
        Tmp.c1.set(a).lerp(b, s);
        Core.batch.setColor(Tmp.c1.r, Tmp.c1.g, Tmp.c1.b, Core.batch.getColor().a);
    }
    
    public static void tint(final Color color) {
        Core.batch.setColor(color.r, color.g, color.b, Core.batch.getColor().a);
    }
    
    public static void colorMul(final Color color, final float mul) {
        color(color.r * mul, color.g * mul, color.b * mul, 1.0f);
    }
    
    public static void color(final Color color) {
        Core.batch.setColor(color);
    }
    
    public static void color(final Color color, final float alpha) {
        Core.batch.setColor(color.r, color.g, color.b, alpha);
    }
    
    public static void color(final int color) {
        Core.batch.setColor(Tmp.c1.rgba8888(color));
    }
    
    public static void color(final float color) {
        Core.batch.setPackedColor(color);
    }
    
    public static void color(final Color a, final Color b, final Color c, final float progress) {
        Draw.carr[0] = a;
        Draw.carr[1] = b;
        Draw.carr[2] = c;
        color(Tmp.c1.lerp(Draw.carr, progress));
    }
    
    public static void color(final Color a, final Color b, final float s) {
        Core.batch.setColor(Tmp.c1.set(a).lerp(b, s));
    }
    
    public static void color() {
        Core.batch.setPackedColor(Color.whiteFloatBits);
    }
    
    public static void color(final float r, final float g, final float b) {
        Core.batch.setColor(r, g, b, 1.0f);
    }
    
    public static void color(final float r, final float g, final float b, final float a) {
        Core.batch.setColor(r, g, b, a);
    }
    
    public static void colorl(final float l) {
        color(l, l, l);
    }
    
    public static void colorl(final float l, final float a) {
        color(l, l, l, a);
    }
    
    public static void blend(final Blending blending) {
        Core.batch.setBlending(blending);
    }
    
    public static void blend() {
        blend(Blending.normal);
    }
    
    public static void reset() {
        color();
        mixcol();
        Draw.xscl = (Draw.yscl = 1.0f);
        Lines.stroke(1.0f);
    }
    
    public static void alpha(final float alpha) {
        Core.batch.setColor(Core.batch.getColor().r, Core.batch.getColor().g, Core.batch.getColor().b, alpha);
    }
    
    public static void fbo(final FrameBuffer buffer, final int worldWidth, final int worldHeight, final int tilesize) {
        fbo(buffer.getTexture(), worldWidth, worldHeight, tilesize);
    }
    
    public static void fbo(final Texture texture, final int worldWidth, final int worldHeight, final int tilesize) {
        final float ww = (float)(worldWidth * tilesize);
        final float wh = (float)(worldHeight * tilesize);
        final float x = Core.camera.position.x + tilesize / 2.0f;
        final float y = Core.camera.position.y + tilesize / 2.0f;
        final float u = (x - Core.camera.width / 2.0f) / ww;
        final float v = (y - Core.camera.height / 2.0f) / wh;
        final float u2 = (x + Core.camera.width / 2.0f) / ww;
        final float v2 = (y + Core.camera.height / 2.0f) / wh;
        Tmp.tr1.set(texture);
        Tmp.tr1.set(u, v2, u2, v);
        rect(Tmp.tr1, Core.camera.position.x, Core.camera.position.y, Core.camera.width, Core.camera.height);
    }
    
    public static void draw(final float z, final Runnable run) {
        z(z);
        Core.batch.draw(run);
    }
    
    public static void drawRange(final float z, final Runnable begin, final Runnable end) {
        drawRange(z, 0.001f, begin, end);
    }
    
    public static void drawRange(final float z, final float range, final Runnable begin, final Runnable end) {
        draw(z - range, begin);
        draw(z + range, end);
    }
    
    public static void rect() {
        Fill.rect(Core.camera.position.x, Core.camera.position.y, Core.camera.width, Core.camera.height);
    }
    
    public static void rect(final String region, final float x, final float y, final float w, final float h) {
        rect(Core.atlas.find(region), x, y, w, h);
    }
    
    public static void rect(final TextureRegion region, final float x, final float y, final float w, final float h) {
        Core.batch.draw(region, x - w / 2.0f, y - h / 2.0f, 0.0f, 0.0f, w, h, 0.0f);
    }
    
    public static void rect(final TextureRegion region, final float x, final float y) {
        rect(region, x, y, region.width * Draw.scl * Draw.xscl, region.height * Draw.scl * Draw.yscl);
    }
    
    public static void rect(final String region, final float x, final float y) {
        rect(Core.atlas.find(region), x, y);
    }
    
    public static void rect(final TextureRegion region, final float x, final float y, final float w, final float h, final float originX, final float originY, final float rotation) {
        Core.batch.draw(region, x - w / 2.0f, y - h / 2.0f, originX, originY, w, h, rotation);
    }
    
    public static void rect(final String region, final float x, final float y, final float w, final float h, final float originX, final float originY, final float rotation) {
        Core.batch.draw(Core.atlas.find(region), x - w / 2.0f, y - h / 2.0f, originX, originY, w, h, rotation);
    }
    
    public static void rect(final TextureRegion region, final float x, final float y, final float w, final float h, final float rotation) {
        rect(region, x, y, w, h, w / 2.0f, h / 2.0f, rotation);
    }
    
    public static void rect(final String region, final float x, final float y, final float w, final float h, final float rotation) {
        rect(Core.atlas.find(region), x, y, w, h, w / 2.0f, h / 2.0f, rotation);
    }
    
    public static void rect(final TextureRegion region, final Position pos, final float w, final float h) {
        rect(region, pos.getX(), pos.getY(), w, h);
    }
    
    public static void rect(final TextureRegion region, final Position pos, final float w, final float h, final float rotation) {
        rect(region, pos.getX(), pos.getY(), w, h, rotation);
    }
    
    public static void rect(final TextureRegion region, final Position pos, final float rotation) {
        rect(region, pos.getX(), pos.getY(), rotation);
    }
    
    public static void rect(final TextureRegion region, final float x, final float y, final float rotation) {
        rect(region, x, y, region.width * Draw.scl * Draw.xscl, region.height * Draw.scl * Draw.yscl, rotation);
    }
    
    public static void rect(final String region, final float x, final float y, final float rotation) {
        rect(Core.atlas.find(region), x, y, rotation);
    }
    
    public static void vert(final Texture texture, final float[] vertices, final int offset, final int length) {
        Core.batch.draw(texture, vertices, offset, length);
    }
    
    public static void flush() {
        Core.batch.flush();
    }
    
    public static void proj(final float x, final float y, final float w, final float h) {
        flush();
        Draw.lastProj = null;
        Core.batch.getProjection().setOrtho(x, y, w, h);
    }
    
    public static Rect lastViewport() {
        return Draw.lastViewport;
    }
    
    public static void proj(final Camera proj) {
        proj(proj.mat);
    }
    
    public static void proj(final Mat proj) {
        Draw.lastProj = ((Core.camera != null && Core.camera.mat == proj) ? Core.camera : null);
        if (Draw.lastProj != null) {
            Draw.lastProj.bounds(Draw.lastViewport);
        }
        Core.batch.setProjection(proj);
    }
    
    public static Mat proj() {
        Draw.lastProj = null;
        return Core.batch.getProjection();
    }
    
    public static void trans(final Mat trans) {
        Core.batch.setTransform(trans);
    }
    
    public static Mat trans() {
        return Core.batch.getTransform();
    }
    
    public static boolean isCamera() {
        return Draw.lastProj == Core.camera;
    }
    
    public static TextureRegion wrap(final Texture texture) {
        Tmp.tr2.set(texture);
        return Tmp.tr2;
    }
    
    public static void rectv(final TextureRegion region, final float x, final float y, final float width, final float height, final Cons<Vec2> tweaker) {
        rectv(region, x, y, width, height, 0.0f, tweaker);
    }
    
    public static void rectv(final TextureRegion region, final float x, final float y, final float width, final float height, final float rotation, final Cons<Vec2> tweaker) {
        rectv(region, x, y, width, height, width / 2.0f, height / 2.0f, rotation, tweaker);
    }
    
    public static void rectv(final TextureRegion region, float x, float y, final float width, final float height, final float originX, final float originY, final float rotation, final Cons<Vec2> tweaker) {
        x -= width / 2.0f;
        y -= height / 2.0f;
        final float worldOriginX = x + originX;
        final float worldOriginY = y + originY;
        final float fx = -originX;
        final float fy = -originY;
        final float fx2 = width - originX;
        final float fy2 = height - originY;
        final float cos = Mathf.cosDeg(rotation);
        final float sin = Mathf.sinDeg(rotation);
        float x2 = cos * fx - sin * fy + worldOriginX;
        float y2 = sin * fx + cos * fy + worldOriginY;
        float x3 = cos * fx - sin * fy2 + worldOriginX;
        float y3 = sin * fx + cos * fy2 + worldOriginY;
        float x4 = cos * fx2 - sin * fy2 + worldOriginX;
        float y4 = sin * fx2 + cos * fy2 + worldOriginY;
        float x5 = x2 + (x4 - x3);
        float y5 = y4 - (y3 - y2);
        tweaker.get(Tmp.v1.set(x2, y2));
        x2 = Tmp.v1.x;
        y2 = Tmp.v1.y;
        tweaker.get(Tmp.v1.set(x3, y3));
        x3 = Tmp.v1.x;
        y3 = Tmp.v1.y;
        tweaker.get(Tmp.v1.set(x4, y4));
        x4 = Tmp.v1.x;
        y4 = Tmp.v1.y;
        tweaker.get(Tmp.v1.set(x5, y5));
        x5 = Tmp.v1.x;
        y5 = Tmp.v1.y;
        final float u = region.u;
        final float v = region.v2;
        final float u2 = region.u2;
        final float v2 = region.v;
        final float color = Core.batch.getPackedColor();
        final float mixColor = Core.batch.getPackedMixColor();
        Draw.vertices[0] = x2;
        Draw.vertices[1] = y2;
        Draw.vertices[2] = color;
        Draw.vertices[3] = u;
        Draw.vertices[4] = v;
        Draw.vertices[5] = mixColor;
        Draw.vertices[6] = x3;
        Draw.vertices[7] = y3;
        Draw.vertices[8] = color;
        Draw.vertices[9] = u;
        Draw.vertices[10] = v2;
        Draw.vertices[11] = mixColor;
        Draw.vertices[12] = x4;
        Draw.vertices[13] = y4;
        Draw.vertices[14] = color;
        Draw.vertices[15] = u2;
        Draw.vertices[16] = v2;
        Draw.vertices[17] = mixColor;
        Draw.vertices[18] = x5;
        Draw.vertices[19] = y5;
        Draw.vertices[20] = color;
        Draw.vertices[21] = u2;
        Draw.vertices[22] = v;
        Draw.vertices[23] = mixColor;
        vert(region.texture, Draw.vertices, 0, Draw.vertices.length);
    }
    
    static {
        carr = new Color[3];
        vertices = new float[24];
        Draw.lastViewport = new Rect();
        Draw.scl = 1.0f;
        Draw.xscl = 1.0f;
        Draw.yscl = 1.0f;
    }
}
