// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.math.Angles;
import arc.math.Mathf;
import arc.graphics.Color;
import arc.Core;
import arc.struct.FloatSeq;

public class Fill
{
    private static float[] vertices;
    private static TextureRegion circleRegion;
    private static FloatSeq polyFloats;
    
    public static void quad(final float x1, final float y1, final float x2, final float y2, final float x3, final float y3, final float x4, final float y4) {
        final float color = Core.batch.getPackedColor();
        quad(x1, y1, color, x2, y2, color, x3, y3, color, x4, y4, color);
    }
    
    public static void quad(final float x1, final float y1, final float c1, final float x2, final float y2, final float c2, final float x3, final float y3, final float c3, final float x4, final float y4, final float c4) {
        final TextureRegion region = Core.atlas.white();
        final float mcolor = Core.batch.getPackedMixColor();
        final float u = region.u;
        final float v = region.v;
        Fill.vertices[0] = x1;
        Fill.vertices[1] = y1;
        Fill.vertices[2] = c1;
        Fill.vertices[3] = u;
        Fill.vertices[4] = v;
        Fill.vertices[5] = mcolor;
        Fill.vertices[6] = x2;
        Fill.vertices[7] = y2;
        Fill.vertices[8] = c2;
        Fill.vertices[9] = u;
        Fill.vertices[10] = v;
        Fill.vertices[11] = mcolor;
        Fill.vertices[12] = x3;
        Fill.vertices[13] = y3;
        Fill.vertices[14] = c3;
        Fill.vertices[15] = u;
        Fill.vertices[16] = v;
        Fill.vertices[17] = mcolor;
        Fill.vertices[18] = x4;
        Fill.vertices[19] = y4;
        Fill.vertices[20] = c4;
        Fill.vertices[21] = u;
        Fill.vertices[22] = v;
        Fill.vertices[23] = mcolor;
        Draw.vert(region.texture, Fill.vertices, 0, Fill.vertices.length);
    }
    
    public static void quad(final TextureRegion region, final float x1, final float y1, final float x2, final float y2, final float x3, final float y3, final float x4, final float y4) {
        final float u = region.u;
        final float v = region.v;
        final float u2 = region.u2;
        final float v2 = region.v2;
        final float color = Core.batch.getPackedColor();
        final float mcolor = Core.batch.getPackedMixColor();
        Fill.vertices[0] = x1;
        Fill.vertices[1] = y1;
        Fill.vertices[2] = color;
        Fill.vertices[3] = u;
        Fill.vertices[4] = v;
        Fill.vertices[5] = mcolor;
        Fill.vertices[6] = x2;
        Fill.vertices[7] = y2;
        Fill.vertices[8] = color;
        Fill.vertices[9] = u;
        Fill.vertices[10] = v2;
        Fill.vertices[11] = mcolor;
        Fill.vertices[12] = x3;
        Fill.vertices[13] = y3;
        Fill.vertices[14] = color;
        Fill.vertices[15] = u2;
        Fill.vertices[16] = v2;
        Fill.vertices[17] = mcolor;
        Fill.vertices[18] = x4;
        Fill.vertices[19] = y4;
        Fill.vertices[20] = color;
        Fill.vertices[21] = u2;
        Fill.vertices[22] = v;
        Fill.vertices[23] = mcolor;
        Draw.vert(region.texture, Fill.vertices, 0, Fill.vertices.length);
    }
    
    public static void tri(final float x1, final float y1, final float x2, final float y2, final float x3, final float y3) {
        quad(x1, y1, x2, y2, x3, y3, x3, y3);
    }
    
    public static void dropShadowRect(final float x, final float y, final float width, final float height, final float blur, final float opacity) {
        dropShadow(x + width / 2.0f, y + height / 2.0f, width, height, blur, opacity);
    }
    
    public static void dropShadow(final float x, final float y, final float width, final float height, final float blur, final float opacity) {
        final float edge = Color.clearFloatBits;
        final float center = Color.toFloatBits(0.0f, 0.0f, 0.0f, opacity);
        final float inside = blur / 2.0f;
        final float outside = blur;
        final float x2 = x - Math.max(width / 2.0f - inside, 0.0f);
        final float y2 = y - Math.max(height / 2.0f - inside, 0.0f);
        final float x3 = x + Math.max(width / 2.0f - inside, 0.0f);
        final float y3 = y + Math.max(height / 2.0f - inside, 0.0f);
        final float bx1 = x2 - outside;
        final float by1 = y2 - outside;
        final float bx2 = x3 + outside;
        final float by2 = y3 + outside;
        quad(x2, y2, center, x3, y2, center, x3, y3, center, x2, y3, center);
        quad(x2, y2, center, bx1, by1, edge, bx2, by1, edge, x3, y2, center);
        quad(x3, y2, center, bx2, by1, edge, bx2, by2, edge, x3, y3, center);
        quad(x2, y3, center, bx1, by2, edge, bx2, by2, edge, x3, y3, center);
        quad(x2, y2, center, bx1, by1, edge, bx1, by2, edge, x2, y3, center);
    }
    
    public static void light(final float x, final float y, int sides, final float radius, final Color center, final Color edge) {
        final float centerf = center.toFloatBits();
        final float edgef = edge.toFloatBits();
        sides = Mathf.ceil(sides / 2.0f) * 2;
        final float space = 360.0f / sides;
        for (int i = 0; i < sides; i += 2) {
            final float px = Angles.trnsx(space * i, radius);
            final float py = Angles.trnsy(space * i, radius);
            final float px2 = Angles.trnsx(space * (i + 1), radius);
            final float py2 = Angles.trnsy(space * (i + 1), radius);
            final float px3 = Angles.trnsx(space * (i + 2), radius);
            final float py3 = Angles.trnsy(space * (i + 2), radius);
            quad(x, y, centerf, x + px, y + py, edgef, x + px2, y + py2, edgef, x + px3, y + py3, edgef);
        }
    }
    
    public static void polyBegin() {
        Fill.polyFloats.clear();
    }
    
    public static void polyPoint(final float x, final float y) {
        Fill.polyFloats.add(x, y);
    }
    
    public static void polyEnd() {
        poly(Fill.polyFloats.items, Fill.polyFloats.size);
    }
    
    public static void poly(final float[] vertices, final int length) {
        if (length < 6) {
            return;
        }
        for (int i = 2; i < length - 4; i += 6) {
            quad(vertices[0], vertices[1], vertices[i], vertices[i + 1], vertices[i + 2], vertices[i + 3], vertices[i + 4], vertices[i + 5]);
        }
    }
    
    public static void poly(final FloatSeq vertices) {
        poly(vertices.items, vertices.size);
    }
    
    public static void poly(final float x, final float y, final int sides, final float radius) {
        poly(x, y, sides, radius, 0.0f);
    }
    
    public static void poly(final float x, final float y, final int sides, final float radius, final float rotation) {
        if (sides == 3) {
            final float space = 120.0f;
            final float px = Angles.trnsx(rotation, radius);
            final float py = Angles.trnsy(rotation, radius);
            final float px2 = Angles.trnsx(space + rotation, radius);
            final float py2 = Angles.trnsy(space + rotation, radius);
            final float px3 = Angles.trnsx(space * 2.0f + rotation, radius);
            final float py3 = Angles.trnsy(space * 2.0f + rotation, radius);
            tri(x + px, y + py, x + px2, y + py2, x + px3, y + py3);
        }
        else {
            final float space = 360.0f / sides;
            for (int i = 0; i < sides; i += 2) {
                final float px4 = Angles.trnsx(space * i + rotation, radius);
                final float py4 = Angles.trnsy(space * i + rotation, radius);
                final float px5 = Angles.trnsx(space * (i + 1) + rotation, radius);
                final float py5 = Angles.trnsy(space * (i + 1) + rotation, radius);
                final float px6 = Angles.trnsx(space * (i + 2) + rotation, radius);
                final float py6 = Angles.trnsy(space * (i + 2) + rotation, radius);
                quad(x, y, x + px4, y + py4, x + px5, y + py5, x + px6, y + py6);
            }
            final int mod = sides % 2;
            if (mod == 0 || sides < 4) {
                return;
            }
            final int j = sides - 2;
            final float px7 = Angles.trnsx(space * j + rotation, radius);
            final float py7 = Angles.trnsy(space * j + rotation, radius);
            final float px8 = Angles.trnsx(space * (j + 1) + rotation, radius);
            final float py8 = Angles.trnsy(space * (j + 1) + rotation, radius);
            tri(x, y, x + px7, y + py7, x + px8, y + py8);
        }
    }
    
    public static void circle(final float x, final float y, final float radius) {
        if (Fill.circleRegion == null || Fill.circleRegion.texture.isDisposed()) {
            Fill.circleRegion = Core.atlas.find("circle");
        }
        Draw.rect(Fill.circleRegion, x, y, radius * 2.0f, radius * 2.0f);
    }
    
    public static void rect(final float x, final float y, final float w, final float h) {
        Draw.rect(Core.atlas.white(), x, y, w, h);
    }
    
    public static void rect(final float x, final float y, final float w, final float h, final float rot) {
        Draw.rect(Core.atlas.white(), x, y, w, h, rot);
    }
    
    public static void crect(final float x, final float y, final float w, final float h) {
        Draw.rect(Core.atlas.white(), x + w / 2.0f, y + h / 2.0f, w, h);
    }
    
    public static void rects(final float x, final float y, final float w, final float h, final float skew) {
        quad(x, y, x + w, y, x + w + skew, y + h, x + skew, y + h);
    }
    
    public static void square(final float x, final float y, final float radius) {
        rect(x, y, radius * 2.0f, radius * 2.0f);
    }
    
    public static void square(final float x, final float y, final float radius, final float rotation) {
        Draw.rect(Core.atlas.white(), x, y, radius * 2.0f, radius * 2.0f, rotation);
    }
    
    static {
        Fill.vertices = new float[24];
        Fill.polyFloats = new FloatSeq();
    }
}
