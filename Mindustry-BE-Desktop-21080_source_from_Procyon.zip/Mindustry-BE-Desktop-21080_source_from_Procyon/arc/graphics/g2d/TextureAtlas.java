// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import java.io.Closeable;
import arc.util.io.Streams;
import java.io.Reader;
import java.io.InputStreamReader;
import arc.scene.style.TextureRegionDrawable;
import arc.scene.style.ScaledNinePatchDrawable;
import java.util.Iterator;
import java.io.IOException;
import arc.util.ArcRuntimeException;
import java.io.BufferedReader;
import arc.files.Fi;
import arc.Core;
import arc.graphics.Pixmaps;
import arc.graphics.Pixmap;
import arc.scene.style.Drawable;
import arc.struct.ObjectMap;
import arc.struct.Seq;
import arc.graphics.Texture;
import arc.struct.ObjectSet;
import java.util.Comparator;
import arc.util.Disposable;

public class TextureAtlas implements Disposable
{
    static final String[] tuple;
    static final Comparator<TextureAtlasData.Region> indexComparator;
    private final ObjectSet<Texture> textures;
    private final Seq<AtlasRegion> regions;
    private final ObjectMap<String, Drawable> drawables;
    private final ObjectMap<String, AtlasRegion> regionmap;
    private final ObjectMap<Texture, Pixmap> pixmaps;
    protected float drawableScale;
    protected AtlasRegion error;
    protected AtlasRegion white;
    
    public static TextureAtlas blankAtlas() {
        final TextureAtlas a = new TextureAtlas();
        a.white = new AtlasRegion(Pixmaps.blankTextureRegion());
        return a;
    }
    
    public TextureAtlas() {
        this.textures = new ObjectSet<Texture>(4);
        this.regions = new Seq<AtlasRegion>();
        this.drawables = new ObjectMap<String, Drawable>();
        this.regionmap = new ObjectMap<String, AtlasRegion>();
        this.pixmaps = new ObjectMap<Texture, Pixmap>();
        this.drawableScale = 1.0f;
    }
    
    public TextureAtlas(final String internalPackFile) {
        this(Core.files.internal(internalPackFile));
    }
    
    public TextureAtlas(final Fi packFile) {
        this(packFile, packFile.parent());
    }
    
    public TextureAtlas(final Fi packFile, final boolean flip) {
        this(packFile, packFile.parent(), flip);
    }
    
    public TextureAtlas(final Fi packFile, final Fi imagesDir) {
        this(packFile, imagesDir, false);
    }
    
    public TextureAtlas(final Fi packFile, final Fi imagesDir, final boolean flip) {
        this(new TextureAtlasData(packFile, imagesDir, flip));
    }
    
    public TextureAtlas(final TextureAtlasData data) {
        this.textures = new ObjectSet<Texture>(4);
        this.regions = new Seq<AtlasRegion>();
        this.drawables = new ObjectMap<String, Drawable>();
        this.regionmap = new ObjectMap<String, AtlasRegion>();
        this.pixmaps = new ObjectMap<Texture, Pixmap>();
        this.drawableScale = 1.0f;
        if (data != null) {
            this.load(data);
        }
    }
    
    public void setDrawableScale(final float scale) {
        this.drawableScale = scale;
    }
    
    static String readValue(final BufferedReader reader) throws IOException {
        final String line = reader.readLine();
        final int colon = line.indexOf(58);
        if (colon == -1) {
            throw new ArcRuntimeException("Invalid line: " + line);
        }
        return line.substring(colon + 1).trim();
    }
    
    static int readTuple(final BufferedReader reader) throws IOException {
        final String line = reader.readLine();
        final int colon = line.indexOf(58);
        if (colon == -1) {
            throw new ArcRuntimeException("Invalid line: " + line);
        }
        int i = 0;
        int lastMatch = colon + 1;
        for (i = 0; i < 3; ++i) {
            final int comma = line.indexOf(44, lastMatch);
            if (comma == -1) {
                break;
            }
            TextureAtlas.tuple[i] = line.substring(lastMatch, comma).trim();
            lastMatch = comma + 1;
        }
        TextureAtlas.tuple[i] = line.substring(lastMatch).trim();
        return i + 1;
    }
    
    private void load(final TextureAtlasData data) {
        final ObjectMap<TextureAtlasData.AtlasPage, Texture> pageToTexture = new ObjectMap<TextureAtlasData.AtlasPage, Texture>();
        for (final TextureAtlasData.AtlasPage page : data.pages) {
            Texture texture = null;
            if (page.texture == null) {
                texture = new Texture(page.textureFile, page.format, page.useMipMaps);
                texture.setFilter(page.minFilter, page.magFilter);
                texture.setWrap(page.uWrap, page.vWrap);
            }
            else {
                texture = page.texture;
                texture.setFilter(page.minFilter, page.magFilter);
                texture.setWrap(page.uWrap, page.vWrap);
            }
            this.textures.add(texture);
            pageToTexture.put(page, texture);
        }
        for (final TextureAtlasData.Region region : data.regions) {
            final int width = region.width;
            final int height = region.height;
            final AtlasRegion atlasRegion = new AtlasRegion(pageToTexture.get(region.page), region.left, region.top, region.rotate ? height : width, region.rotate ? width : height);
            atlasRegion.index = region.index;
            atlasRegion.name = region.name;
            atlasRegion.offsetX = region.offsetX;
            atlasRegion.offsetY = region.offsetY;
            atlasRegion.originalHeight = region.originalHeight;
            atlasRegion.originalWidth = region.originalWidth;
            atlasRegion.rotate = region.rotate;
            atlasRegion.splits = region.splits;
            atlasRegion.pads = region.pads;
            if (region.flip) {
                atlasRegion.flip(false, true);
            }
            this.regions.add(atlasRegion);
            this.regionmap.put(atlasRegion.name, atlasRegion);
        }
        this.error = this.find("error");
    }
    
    public PixmapRegion getPixmap(final String name) {
        return this.getPixmap(this.find(name));
    }
    
    public PixmapRegion getPixmap(final AtlasRegion region) {
        if (region.pixmapRegion == null) {
            final Pixmap pix = this.pixmaps.get(region.texture, () -> region.texture.getTextureData().getPixmap());
            region.pixmapRegion = new PixmapRegion(pix, region.getX(), region.getY(), region.width, region.height);
        }
        return region.pixmapRegion;
    }
    
    public void disposePixmap(final Texture texture) {
        if (this.pixmaps.containsKey(texture)) {
            this.pixmaps.get(texture).dispose();
            this.pixmaps.remove(texture);
        }
    }
    
    public PixmapRegion getPixmap(final TextureRegion region) {
        return this.getPixmap((AtlasRegion)region);
    }
    
    public AtlasRegion addRegion(final String name, final Texture texture, final int x, final int y, final int width, final int height) {
        this.textures.add(texture);
        final AtlasRegion region = new AtlasRegion(texture, x, y, width, height);
        region.name = name;
        region.originalWidth = width;
        region.originalHeight = height;
        region.index = -1;
        this.regions.add(region);
        this.regionmap.put(name, region);
        return region;
    }
    
    public AtlasRegion addRegion(final String name, final TextureRegion textureRegion) {
        return this.addRegion(name, textureRegion.texture, textureRegion.getX(), textureRegion.getY(), textureRegion.width, textureRegion.height);
    }
    
    public Seq<AtlasRegion> getRegions() {
        return this.regions;
    }
    
    public ObjectMap<String, AtlasRegion> getRegionMap() {
        return this.regionmap;
    }
    
    public AtlasRegion white() {
        if (this.white == null) {
            this.white = this.find("white");
        }
        return this.white;
    }
    
    public boolean setErrorRegion(final String name) {
        if (this.error != null || !this.has(name)) {
            return false;
        }
        this.error = this.find(name);
        return true;
    }
    
    public boolean isFound(final TextureRegion region) {
        return region != this.error;
    }
    
    public AtlasRegion find(final String name) {
        final AtlasRegion r = this.regionmap.get(name);
        if (r == null && this.error == null && !name.equals("error")) {
            throw new IllegalArgumentException("The region \"" + name + "\" does not exist!");
        }
        if (r == null) {
            return this.error;
        }
        return r;
    }
    
    public TextureRegion find(final String name, final String def) {
        return this.find(name, this.find(def));
    }
    
    public TextureRegion find(final String name, final TextureRegion def) {
        final TextureRegion region = this.regionmap.get(name);
        return (region == null || region == this.error) ? def : region;
    }
    
    public boolean has(final String s) {
        return this.regionmap.containsKey(s);
    }
    
    public <T extends Drawable> T getDrawable(final String name) {
        return (T)this.drawable(name);
    }
    
    public Drawable drawable(final String name) {
        if (this.drawables.containsKey(name)) {
            return this.drawables.get(name);
        }
        Drawable out = null;
        if (this.has(name)) {
            final AtlasRegion region = this.find(name);
            if (region.splits != null) {
                final int[] splits = region.splits;
                final NinePatch patch = new NinePatch(region, splits[0], splits[1], splits[2], splits[3]);
                final int[] pads = region.pads;
                if (pads != null) {
                    patch.setPadding((float)pads[0], (float)pads[1], (float)pads[2], (float)pads[3]);
                }
                out = new ScaledNinePatchDrawable(patch, this.drawableScale);
            }
            else {
                out = new TextureRegionDrawable(region, this.drawableScale);
            }
        }
        if (this.error == null && out == null) {
            throw new IllegalArgumentException("No drawable '" + name + "' found.");
        }
        if (out == null) {
            out = new TextureRegionDrawable(this.error);
        }
        this.drawables.put(name, out);
        return out;
    }
    
    public Seq<AtlasRegion> findRegions(final String name) {
        final Seq<AtlasRegion> matched = new Seq<AtlasRegion>(AtlasRegion.class);
        for (int i = 0, n = this.regions.size; i < n; ++i) {
            final AtlasRegion region = this.regions.get(i);
            if (region.name.equals(name)) {
                matched.add(new AtlasRegion(region));
            }
        }
        return matched;
    }
    
    public NinePatch createPatch(final String name) {
        int i = 0;
        final int n = this.regions.size;
        while (i < n) {
            final AtlasRegion region = this.regions.get(i);
            if (region.name.equals(name)) {
                final int[] splits = region.splits;
                if (splits == null) {
                    throw new IllegalArgumentException("Region does not have ninepatch splits: " + name);
                }
                final NinePatch patch = new NinePatch(region, splits[0], splits[1], splits[2], splits[3]);
                if (region.pads != null) {
                    patch.setPadding((float)region.pads[0], (float)region.pads[1], (float)region.pads[2], (float)region.pads[3]);
                }
                return patch;
            }
            else {
                ++i;
            }
        }
        return null;
    }
    
    public ObjectSet<Texture> getTextures() {
        return this.textures;
    }
    
    public Texture texture() {
        return this.textures.first();
    }
    
    @Override
    public void dispose() {
        for (final Texture texture : this.textures) {
            texture.dispose();
        }
        for (final Pixmap pixmap : this.pixmaps.values()) {
            if (!pixmap.isDisposed()) {
                pixmap.dispose();
            }
        }
        this.textures.clear();
        this.pixmaps.clear();
    }
    
    static {
        tuple = new String[4];
        int i1;
        int i2;
        indexComparator = ((region1, region2) -> {
            i1 = region1.index;
            if (i1 == -1) {
                i1 = Integer.MAX_VALUE;
            }
            i2 = region2.index;
            if (i2 == -1) {
                i2 = Integer.MAX_VALUE;
            }
            return i1 - i2;
        });
    }
    
    public static class TextureAtlasData
    {
        final Seq<AtlasPage> pages;
        final Seq<Region> regions;
        
        public TextureAtlasData(final Fi packFile, final Fi imagesDir, final boolean flip) {
            this.pages = new Seq<AtlasPage>();
            this.regions = new Seq<Region>();
            final BufferedReader reader = new BufferedReader(new InputStreamReader(packFile.read()), 64);
            try {
                AtlasPage pageImage = null;
                while (true) {
                    final String line = reader.readLine();
                    if (line == null) {
                        break;
                    }
                    if (line.trim().length() == 0) {
                        pageImage = null;
                    }
                    else if (pageImage == null) {
                        final Fi file = imagesDir.child(line);
                        float width = 0.0f;
                        float height = 0.0f;
                        if (TextureAtlas.readTuple(reader) == 2) {
                            width = (float)Integer.parseInt(TextureAtlas.tuple[0]);
                            height = (float)Integer.parseInt(TextureAtlas.tuple[1]);
                            TextureAtlas.readTuple(reader);
                        }
                        final Pixmap.Format format = Pixmap.Format.valueOf(TextureAtlas.tuple[0]);
                        TextureAtlas.readTuple(reader);
                        final Texture.TextureFilter min = Texture.TextureFilter.valueOf(TextureAtlas.tuple[0]);
                        final Texture.TextureFilter max = Texture.TextureFilter.valueOf(TextureAtlas.tuple[1]);
                        final String direction = TextureAtlas.readValue(reader);
                        Texture.TextureWrap repeatX = Texture.TextureWrap.clampToEdge;
                        Texture.TextureWrap repeatY = Texture.TextureWrap.clampToEdge;
                        if (direction.equals("x")) {
                            repeatX = Texture.TextureWrap.repeat;
                        }
                        else if (direction.equals("y")) {
                            repeatY = Texture.TextureWrap.repeat;
                        }
                        else if (direction.equals("xy")) {
                            repeatX = Texture.TextureWrap.repeat;
                            repeatY = Texture.TextureWrap.repeat;
                        }
                        pageImage = new AtlasPage(file, width, height, min.isMipMap(), format, min, max, repeatX, repeatY);
                        this.pages.add(pageImage);
                    }
                    else {
                        final boolean rotate = Boolean.valueOf(TextureAtlas.readValue(reader));
                        TextureAtlas.readTuple(reader);
                        final int left = Integer.parseInt(TextureAtlas.tuple[0]);
                        final int top = Integer.parseInt(TextureAtlas.tuple[1]);
                        TextureAtlas.readTuple(reader);
                        final int width2 = Integer.parseInt(TextureAtlas.tuple[0]);
                        final int height2 = Integer.parseInt(TextureAtlas.tuple[1]);
                        final Region region = new Region();
                        region.page = pageImage;
                        region.left = left;
                        region.top = top;
                        region.width = width2;
                        region.height = height2;
                        region.name = line;
                        region.rotate = rotate;
                        if (TextureAtlas.readTuple(reader) == 4) {
                            region.splits = new int[] { Integer.parseInt(TextureAtlas.tuple[0]), Integer.parseInt(TextureAtlas.tuple[1]), Integer.parseInt(TextureAtlas.tuple[2]), Integer.parseInt(TextureAtlas.tuple[3]) };
                            if (TextureAtlas.readTuple(reader) == 4) {
                                region.pads = new int[] { Integer.parseInt(TextureAtlas.tuple[0]), Integer.parseInt(TextureAtlas.tuple[1]), Integer.parseInt(TextureAtlas.tuple[2]), Integer.parseInt(TextureAtlas.tuple[3]) };
                                TextureAtlas.readTuple(reader);
                            }
                        }
                        region.originalWidth = Integer.parseInt(TextureAtlas.tuple[0]);
                        region.originalHeight = Integer.parseInt(TextureAtlas.tuple[1]);
                        TextureAtlas.readTuple(reader);
                        region.offsetX = (float)Integer.parseInt(TextureAtlas.tuple[0]);
                        region.offsetY = (float)Integer.parseInt(TextureAtlas.tuple[1]);
                        region.index = Integer.parseInt(TextureAtlas.readValue(reader));
                        if (flip) {
                            region.flip = true;
                        }
                        this.regions.add(region);
                    }
                }
            }
            catch (Exception ex) {
                throw new ArcRuntimeException("Error reading pack file: " + packFile, ex);
            }
            finally {
                Streams.close(reader);
            }
            this.regions.sort(TextureAtlas.indexComparator);
        }
        
        public Seq<AtlasPage> getPages() {
            return this.pages;
        }
        
        public Seq<Region> getRegions() {
            return this.regions;
        }
        
        public static class AtlasPage
        {
            public final Fi textureFile;
            public final float width;
            public final float height;
            public final boolean useMipMaps;
            public final Pixmap.Format format;
            public final Texture.TextureFilter minFilter;
            public final Texture.TextureFilter magFilter;
            public final Texture.TextureWrap uWrap;
            public final Texture.TextureWrap vWrap;
            public Texture texture;
            
            public AtlasPage(final Fi handle, final float width, final float height, final boolean useMipMaps, final Pixmap.Format format, final Texture.TextureFilter minFilter, final Texture.TextureFilter magFilter, final Texture.TextureWrap uWrap, final Texture.TextureWrap vWrap) {
                this.width = width;
                this.height = height;
                this.textureFile = handle;
                this.useMipMaps = useMipMaps;
                this.format = format;
                this.minFilter = minFilter;
                this.magFilter = magFilter;
                this.uWrap = uWrap;
                this.vWrap = vWrap;
            }
        }
        
        public static class Region
        {
            public AtlasPage page;
            public int index;
            public String name;
            public float offsetX;
            public float offsetY;
            public int originalWidth;
            public int originalHeight;
            public boolean rotate;
            public int left;
            public int top;
            public int width;
            public int height;
            public boolean flip;
            public int[] splits;
            public int[] pads;
        }
    }
    
    public static class AtlasRegion extends TextureRegion
    {
        PixmapRegion pixmapRegion;
        public int index;
        public String name;
        public float offsetX;
        public float offsetY;
        public int packedWidth;
        public int packedHeight;
        public int originalWidth;
        public int originalHeight;
        public boolean rotate;
        public int[] splits;
        public int[] pads;
        
        public AtlasRegion(final Texture texture, final int x, final int y, final int width, final int height) {
            super(texture, x, y, width, height);
            this.originalWidth = width;
            this.originalHeight = height;
            this.packedWidth = width;
            this.packedHeight = height;
        }
        
        public AtlasRegion() {
        }
        
        public AtlasRegion(final AtlasRegion region) {
            this.set(region);
            this.index = region.index;
            this.name = region.name;
            this.offsetX = region.offsetX;
            this.offsetY = region.offsetY;
            this.packedWidth = region.packedWidth;
            this.packedHeight = region.packedHeight;
            this.originalWidth = region.originalWidth;
            this.originalHeight = region.originalHeight;
            this.rotate = region.rotate;
            this.splits = region.splits;
        }
        
        public AtlasRegion(final TextureRegion region) {
            this.set(region);
            this.name = "unknown";
        }
        
        @Override
        public void flip(final boolean x, final boolean y) {
            super.flip(x, y);
            if (x) {
                this.offsetX = this.originalWidth - this.offsetX - this.getRotatedPackedWidth();
            }
            if (y) {
                this.offsetY = this.originalHeight - this.offsetY - this.getRotatedPackedHeight();
            }
        }
        
        public float getRotatedPackedWidth() {
            return this.rotate ? ((float)this.packedHeight) : ((float)this.packedWidth);
        }
        
        public float getRotatedPackedHeight() {
            return this.rotate ? ((float)this.packedWidth) : ((float)this.packedHeight);
        }
        
        @Override
        public String toString() {
            return this.name;
        }
    }
}
