// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.graphics.gl.Shader;
import arc.graphics.VertexAttribute;
import arc.graphics.Mesh;
import arc.util.Disposable;

public class ScreenQuad implements Disposable
{
    public final Mesh mesh;
    
    public ScreenQuad() {
        (this.mesh = new Mesh(true, 4, 0, new VertexAttribute[] { VertexAttribute.position, VertexAttribute.texCoords })).setVertices(new float[] { -1.0f, -1.0f, 0.0f, 0.0f, 1.0f, -1.0f, 1.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, -1.0f, 1.0f, 0.0f, 1.0f });
    }
    
    public void render(final Shader shader) {
        this.mesh.render(shader, 6, 0, 4);
    }
    
    @Override
    public void dispose() {
        this.mesh.dispose();
    }
}
