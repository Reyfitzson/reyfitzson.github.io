// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.math.Mat;
import arc.graphics.Camera;
import arc.util.Tmp;
import arc.Core;
import arc.graphics.gl.HdpiUtils;
import arc.graphics.Gl;
import arc.struct.Seq;
import arc.math.geom.Vec2;
import arc.math.geom.Rect;

public class ScissorStack
{
    static final Rect viewport;
    static Vec2 tmp;
    private static Seq<Rect> scissors;
    
    public static boolean push(final Rect scissor) {
        fix(scissor);
        if (ScissorStack.scissors.size == 0) {
            if (scissor.width < 1.0f || scissor.height < 1.0f) {
                return false;
            }
            Draw.flush();
            Gl.enable(3089);
        }
        else {
            final Rect parent = ScissorStack.scissors.get(ScissorStack.scissors.size - 1);
            final float minX = Math.max(parent.x, scissor.x);
            final float maxX = Math.min(parent.x + parent.width, scissor.x + scissor.width);
            if (maxX - minX < 1.0f) {
                return false;
            }
            final float minY = Math.max(parent.y, scissor.y);
            final float maxY = Math.min(parent.y + parent.height, scissor.y + scissor.height);
            if (maxY - minY < 1.0f) {
                return false;
            }
            Draw.flush();
            scissor.x = minX;
            scissor.y = minY;
            scissor.width = maxX - minX;
            scissor.height = Math.max(1.0f, maxY - minY);
        }
        ScissorStack.scissors.add(scissor);
        HdpiUtils.glScissor((int)scissor.x, (int)scissor.y, (int)scissor.width, (int)scissor.height);
        return true;
    }
    
    public static Rect pop() {
        Draw.flush();
        final Rect old = ScissorStack.scissors.pop();
        if (ScissorStack.scissors.size == 0) {
            Gl.disable(3089);
        }
        else {
            final Rect scissor = ScissorStack.scissors.peek();
            HdpiUtils.glScissor((int)scissor.x, (int)scissor.y, (int)scissor.width, (int)scissor.height);
        }
        return old;
    }
    
    public static boolean pushWorld(final Rect scissorWorld) {
        calculateScissors(Core.camera, Tmp.m1.idt(), Tmp.r1.set(scissorWorld), scissorWorld);
        return push(scissorWorld);
    }
    
    public static Rect peek() {
        return ScissorStack.scissors.peek();
    }
    
    private static void fix(final Rect rect) {
        rect.x = (float)Math.round(rect.x);
        rect.y = (float)Math.round(rect.y);
        rect.width = (float)Math.round(rect.width);
        rect.height = (float)Math.round(rect.height);
        if (rect.width < 0.0f) {
            rect.width = -rect.width;
            rect.x -= rect.width;
        }
        if (rect.height < 0.0f) {
            rect.height = -rect.height;
            rect.y -= rect.height;
        }
    }
    
    public static void calculateScissors(final Camera camera, final Mat batchTransform, final Rect area, final Rect scissor) {
        calculateScissors(camera, 0.0f, 0.0f, (float)Core.graphics.getWidth(), (float)Core.graphics.getHeight(), batchTransform, area, scissor);
    }
    
    public static void calculateScissors(final Camera camera, final float viewportX, final float viewportY, final float viewportWidth, final float viewportHeight, final Mat batchTransform, final Rect area, final Rect scissor) {
        ScissorStack.tmp.set(area.x, area.y);
        ScissorStack.tmp.mul(batchTransform);
        camera.project(ScissorStack.tmp, viewportX, viewportY, viewportWidth, viewportHeight);
        scissor.x = ScissorStack.tmp.x;
        scissor.y = ScissorStack.tmp.y;
        ScissorStack.tmp.set(area.x + area.width, area.y + area.height);
        ScissorStack.tmp.mul(batchTransform);
        camera.project(ScissorStack.tmp, viewportX, viewportY, viewportWidth, viewportHeight);
        scissor.width = ScissorStack.tmp.x - scissor.x;
        scissor.height = ScissorStack.tmp.y - scissor.y;
    }
    
    public static Rect getViewport() {
        if (ScissorStack.scissors.size == 0) {
            ScissorStack.viewport.set(0.0f, 0.0f, (float)Core.graphics.getWidth(), (float)Core.graphics.getHeight());
            return ScissorStack.viewport;
        }
        final Rect scissor = ScissorStack.scissors.peek();
        ScissorStack.viewport.set(scissor);
        return ScissorStack.viewport;
    }
    
    static {
        viewport = new Rect();
        ScissorStack.tmp = new Vec2();
        ScissorStack.scissors = new Seq<Rect>();
    }
}
