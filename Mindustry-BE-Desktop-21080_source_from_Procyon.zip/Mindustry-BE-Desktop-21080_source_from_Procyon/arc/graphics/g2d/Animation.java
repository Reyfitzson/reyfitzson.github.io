// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.math.Mathf;
import java.lang.reflect.Array;
import arc.struct.Seq;

public class Animation<T>
{
    T[] keyFrames;
    private float frameDuration;
    private float animationDuration;
    private int lastFrameNumber;
    private float lastStateTime;
    private PlayMode playMode;
    
    public Animation(final float frameDuration, final Seq<? extends T> keyFrames) {
        this.playMode = PlayMode.normal;
        this.frameDuration = frameDuration;
        final Class arrayType = keyFrames.items.getClass().getComponentType();
        final T[] frames = (T[])Array.newInstance(arrayType, keyFrames.size);
        for (int i = 0, n = keyFrames.size; i < n; ++i) {
            frames[i] = (T)keyFrames.get(i);
        }
        this.setKeyFrames(frames);
    }
    
    public Animation(final float frameDuration, final Seq<? extends T> keyFrames, final PlayMode playMode) {
        this(frameDuration, keyFrames);
        this.setPlayMode(playMode);
    }
    
    public Animation(final float frameDuration, final T... keyFrames) {
        this.playMode = PlayMode.normal;
        this.frameDuration = frameDuration;
        this.setKeyFrames(keyFrames);
    }
    
    public T getKeyFrame(final float stateTime, final boolean looping) {
        final PlayMode oldPlayMode = this.playMode;
        if (looping && (this.playMode == PlayMode.normal || this.playMode == PlayMode.reversed)) {
            if (this.playMode == PlayMode.normal) {
                this.playMode = PlayMode.loop;
            }
            else {
                this.playMode = PlayMode.loopReversed;
            }
        }
        else if (!looping && this.playMode != PlayMode.normal && this.playMode != PlayMode.reversed) {
            if (this.playMode == PlayMode.loopReversed) {
                this.playMode = PlayMode.reversed;
            }
            else {
                this.playMode = PlayMode.loop;
            }
        }
        final T frame = this.getKeyFrame(stateTime);
        this.playMode = oldPlayMode;
        return frame;
    }
    
    public T getKeyFrame(final float stateTime) {
        final int frameNumber = this.getKeyFrameIndex(stateTime);
        return this.keyFrames[frameNumber];
    }
    
    public int getKeyFrameIndex(final float stateTime) {
        if (this.keyFrames.length == 1) {
            return 0;
        }
        int frameNumber = (int)(stateTime / this.frameDuration);
        switch (this.playMode) {
            case normal: {
                frameNumber = Math.min(this.keyFrames.length - 1, frameNumber);
                break;
            }
            case loop: {
                frameNumber %= this.keyFrames.length;
                break;
            }
            case loopPingPong: {
                frameNumber %= this.keyFrames.length * 2 - 2;
                if (frameNumber >= this.keyFrames.length) {
                    frameNumber = this.keyFrames.length - 2 - (frameNumber - this.keyFrames.length);
                    break;
                }
                break;
            }
            case loopRandom: {
                final int lastFrameNumber = (int)(this.lastStateTime / this.frameDuration);
                if (lastFrameNumber != frameNumber) {
                    frameNumber = Mathf.random(this.keyFrames.length - 1);
                    break;
                }
                frameNumber = this.lastFrameNumber;
                break;
            }
            case reversed: {
                frameNumber = Math.max(this.keyFrames.length - frameNumber - 1, 0);
                break;
            }
            case loopReversed: {
                frameNumber %= this.keyFrames.length;
                frameNumber = this.keyFrames.length - frameNumber - 1;
                break;
            }
        }
        this.lastFrameNumber = frameNumber;
        this.lastStateTime = stateTime;
        return frameNumber;
    }
    
    public T[] getKeyFrames() {
        return this.keyFrames;
    }
    
    protected void setKeyFrames(final T... keyFrames) {
        this.keyFrames = keyFrames;
        this.animationDuration = keyFrames.length * this.frameDuration;
    }
    
    public PlayMode getPlayMode() {
        return this.playMode;
    }
    
    public void setPlayMode(final PlayMode playMode) {
        this.playMode = playMode;
    }
    
    public boolean isAnimationFinished(final float stateTime) {
        final int frameNumber = (int)(stateTime / this.frameDuration);
        return this.keyFrames.length - 1 < frameNumber;
    }
    
    public float getFrameDuration() {
        return this.frameDuration;
    }
    
    public void setFrameDuration(final float frameDuration) {
        this.frameDuration = frameDuration;
        this.animationDuration = this.keyFrames.length * frameDuration;
    }
    
    public float getAnimationDuration() {
        return this.animationDuration;
    }
    
    public enum PlayMode
    {
        normal, 
        reversed, 
        loop, 
        loopReversed, 
        loopPingPong, 
        loopRandom;
    }
}
