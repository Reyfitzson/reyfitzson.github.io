// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.graphics.Blending;

public class QueueBatch extends SortedSpriteBatch
{
    public QueueBatch() {
        this.sort = true;
    }
    
    public void setBlending(final Blending blending) {
        this.blending = blending;
    }
    
    public void flush() {
        super.flush();
    }
    
    @Override
    protected void setSort(final boolean sort) {
    }
    
    @Override
    protected void sortRequests() {
    }
}
