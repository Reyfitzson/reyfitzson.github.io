// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.graphics.Pixmaps;
import arc.graphics.Color;
import arc.graphics.Pixmap;

public class PixmapRegion
{
    public Pixmap pixmap;
    public int x;
    public int y;
    public int width;
    public int height;
    
    public PixmapRegion(final Pixmap pixmap, final int x, final int y, final int width, final int height) {
        this.set(pixmap, x, y, width, height);
    }
    
    public PixmapRegion(final Pixmap pixmap) {
        this.set(pixmap);
    }
    
    public int getPixel(final int x, final int y) {
        return this.pixmap.getPixel(this.x + x, this.y + y);
    }
    
    public int getPixel(final int x, final int y, final Color color) {
        final int c = this.getPixel(x, y);
        color.set(c);
        return c;
    }
    
    public PixmapRegion set(final Pixmap pixmap) {
        return this.set(pixmap, 0, 0, pixmap.getWidth(), pixmap.getHeight());
    }
    
    public PixmapRegion set(final Pixmap pixmap, final int x, final int y, final int width, final int height) {
        this.pixmap = pixmap;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        return this;
    }
    
    public Pixmap crop() {
        return Pixmaps.crop(this.pixmap, this.x, this.y, this.width, this.height);
    }
}
