// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.graphics.Color;
import arc.math.geom.Rect;
import arc.math.Angles;
import arc.math.geom.Position;
import arc.math.Mathf;
import arc.Core;
import arc.struct.FloatSeq;
import arc.math.geom.Vec2;

public class Lines
{
    public static boolean useLegacyLine;
    private static float stroke;
    private static Vec2 vector;
    private static Vec2 u;
    private static Vec2 v;
    private static Vec2 inner;
    private static Vec2 outer;
    private static FloatSeq floats;
    private static FloatSeq floatBuilder;
    private static boolean building;
    private static float circlePrecision;
    
    public static void setCirclePrecision(final float amount) {
        Lines.circlePrecision = amount;
    }
    
    public static int circleVertices(final float rad) {
        return 11 + (int)(rad * Lines.circlePrecision);
    }
    
    public static void lineAngle(final float x, final float y, final float angle, final float length, final boolean cap) {
        Lines.vector.set(1.0f, 1.0f).setLength(length).setAngle(angle);
        line(x, y, x + Lines.vector.x, y + Lines.vector.y, cap);
    }
    
    public static void lineAngle(final float x, final float y, final float angle, final float length) {
        Lines.vector.set(1.0f, 1.0f).setLength(length).setAngle(angle);
        line(x, y, x + Lines.vector.x, y + Lines.vector.y);
    }
    
    public static void lineAngle(final float x, final float y, final float offset, final float angle, final float length) {
        Lines.vector.set(1.0f, 1.0f).setLength(length + offset).setAngle(angle);
        line(x, y, x + Lines.vector.x, y + Lines.vector.y);
    }
    
    public static void lineAngleCenter(final float x, final float y, final float angle, final float length) {
        Lines.vector.trns(angle, length);
        line(x - Lines.vector.x / 2.0f, y - Lines.vector.y / 2.0f, x + Lines.vector.x / 2.0f, y + Lines.vector.y / 2.0f);
    }
    
    public static void line(final float x, final float y, final float x2, final float y2) {
        line(x, y, x2, y2, true);
    }
    
    public static void line(final float x, final float y, final float x2, final float y2, final boolean cap) {
        line(Core.atlas.white(), x, y, x2, y2, cap);
    }
    
    public static void line(final TextureRegion region, final float x, final float y, final float x2, final float y2, final boolean cap) {
        if (Lines.useLegacyLine) {
            final float length = Mathf.dst(x, y, x2, y2) + (cap ? Lines.stroke : 0.0f);
            final float angle = Mathf.atan2(x2 - x, y2 - y) * 57.295776f;
            if (cap) {
                Draw.rect(region, x - Lines.stroke / 2.0f + length / 2.0f, y, length, Lines.stroke, Lines.stroke / 2.0f, Lines.stroke / 2.0f, angle);
            }
            else {
                Draw.rect(region, x + length / 2.0f, y, length, Lines.stroke, 0.0f, Lines.stroke / 2.0f, angle);
            }
        }
        else {
            final float hstroke = Lines.stroke / 2.0f;
            final float len = Mathf.len(x2 - x, y2 - y);
            final float diffx = (x2 - x) / len * hstroke;
            final float diffy = (y2 - y) / len * hstroke;
            if (cap) {
                Fill.quad(region, x - diffx - diffy, y - diffy + diffx, x - diffx + diffy, y - diffy - diffx, x2 + diffx + diffy, y2 + diffy - diffx, x2 + diffx - diffy, y2 + diffy + diffx);
            }
            else {
                Fill.quad(region, x - diffy, y + diffx, x + diffy, y - diffx, x2 + diffy, y2 - diffx, x2 - diffy, y2 + diffx);
            }
        }
    }
    
    public static void linePoint(final Position p) {
        linePoint(p.getX(), p.getY());
    }
    
    public static void linePoint(final float x, final float y) {
        if (!Lines.building) {
            throw new IllegalStateException("Not building");
        }
        Lines.floatBuilder.add(x, y);
    }
    
    public static void beginLine() {
        if (Lines.building) {
            throw new IllegalStateException("Already building");
        }
        Lines.floatBuilder.clear();
        Lines.building = true;
    }
    
    public static void endLine() {
        endLine(false);
    }
    
    public static void endLine(final boolean wrap) {
        if (!Lines.building) {
            throw new IllegalStateException("Not building");
        }
        polyline(Lines.floatBuilder, wrap);
        Lines.building = false;
    }
    
    public static void polyline(final FloatSeq points, final boolean wrap) {
        polyline(points.items, points.size, wrap);
    }
    
    public static void polyline(final float[] points, final int length, final boolean wrap) {
        if (length < 4) {
            return;
        }
        if (!wrap) {
            for (int i = 0; i < length - 2; i += 2) {
                final float cx = points[i];
                final float cy = points[i + 1];
                final float cx2 = points[i + 2];
                final float cy2 = points[i + 3];
                line(cx, cy, cx2, cy2);
            }
        }
        else {
            Lines.floats.clear();
            for (int i = 0; i < length; i += 2) {
                final float x0 = points[Mathf.mod(i - 2, length)];
                final float y0 = points[Mathf.mod(i - 1, length)];
                final float x2 = points[i];
                final float y2 = points[i + 1];
                final float x3 = points[(i + 2) % length];
                final float y3 = points[(i + 3) % length];
                final float ang0 = Angles.angle(x0, y0, x2, y2);
                final float ang2 = Angles.angle(x2, y2, x3, y3);
                final float beta = Mathf.sinDeg(ang2 - ang0);
                Lines.u.set(x0, y0).sub(x2, y2).scl(1.0f / Mathf.dst(x0, y0, x2, y2)).scl(Lines.stroke / (2.0f * beta));
                Lines.v.set(x3, y3).sub(x2, y2).scl(1.0f / Mathf.dst(x3, y3, x2, y2)).scl(Lines.stroke / (2.0f * beta));
                Lines.inner.set(x2, y2).add(Lines.u).add(Lines.v);
                Lines.outer.set(x2, y2).sub(Lines.u).sub(Lines.v);
                Lines.floats.add(Lines.inner.x, Lines.inner.y, Lines.outer.x, Lines.outer.y);
            }
            for (int i = 0; i < Lines.floats.size; i += 4) {
                final float x4 = Lines.floats.items[i];
                final float y4 = Lines.floats.items[i + 1];
                final float x5 = Lines.floats.items[(i + 2) % Lines.floats.size];
                final float y5 = Lines.floats.items[(i + 3) % Lines.floats.size];
                final float x6 = Lines.floats.items[(i + 4) % Lines.floats.size];
                final float y6 = Lines.floats.items[(i + 5) % Lines.floats.size];
                final float x7 = Lines.floats.items[(i + 6) % Lines.floats.size];
                final float y7 = Lines.floats.items[(i + 7) % Lines.floats.size];
                Fill.quad(x4, y4, x6, y6, x7, y7, x5, y5);
            }
        }
    }
    
    public static void dashLine(final float x1, final float y1, final float x2, final float y2, final int divisions) {
        final float dx = x2 - x1;
        final float dy = y2 - y1;
        for (int i = 0; i < divisions; ++i) {
            if (i % 2 == 0) {
                line(x1 + i / (float)divisions * dx, y1 + i / (float)divisions * dy, x1 + (i + 1.0f) / divisions * dx, y1 + (i + 1.0f) / divisions * dy);
            }
        }
    }
    
    public static void circle(final float x, final float y, final float rad) {
        poly(x, y, circleVertices(rad), rad);
    }
    
    public static void dashCircle(final float x, final float y, final float radius) {
        final float scaleFactor = 0.6f;
        int sides = 10 + (int)(radius * scaleFactor);
        if (sides % 2 == 1) {
            ++sides;
        }
        Lines.vector.set(0.0f, 0.0f);
        for (int i = 0; i < sides; ++i) {
            if (i % 2 != 0) {
                Lines.vector.set(radius, 0.0f).setAngle(360.0f / sides * i + 90.0f);
                final float x2 = Lines.vector.x;
                final float y2 = Lines.vector.y;
                Lines.vector.set(radius, 0.0f).setAngle(360.0f / sides * (i + 1) + 90.0f);
                line(x2 + x, y2 + y, Lines.vector.x + x, Lines.vector.y + y);
            }
        }
    }
    
    public static void spikes(final float x, final float y, final float radius, final float length, final int spikes, final float rot) {
        Lines.vector.set(0.0f, 1.0f);
        final float step = 360.0f / spikes;
        for (int i = 0; i < spikes; ++i) {
            Lines.vector.setAngle(i * step + rot);
            Lines.vector.setLength(radius);
            final float x2 = Lines.vector.x;
            final float y2 = Lines.vector.y;
            Lines.vector.setLength(radius + length);
            line(x + x2, y + y2, x + Lines.vector.x, y + Lines.vector.y);
        }
    }
    
    public static void spikes(final float x, final float y, final float rad, final float length, final int spikes) {
        spikes(x, y, rad, length, spikes, 0.0f);
    }
    
    public static void quad(final float x1, final float y1, final float x2, final float y2, final float x3, final float y3, final float x4, final float y4) {
        Lines.floatBuilder.clear();
        Lines.floatBuilder.add(x1, y1, x2, y2);
        Lines.floatBuilder.add(x3, y3, x4, y4);
        polyline(Lines.floatBuilder, true);
    }
    
    public static void poly(final float x, final float y, final int sides, final float radius, final float angle) {
        final float space = 360.0f / sides;
        final float hstep = Lines.stroke / 2.0f / Mathf.cosDeg(space / 2.0f);
        final float r1 = radius - hstep;
        final float r2 = radius + hstep;
        for (int i = 0; i < sides; ++i) {
            final float a = space * i + angle;
            final float cos = Mathf.cosDeg(a);
            final float sin = Mathf.sinDeg(a);
            final float cos2 = Mathf.cosDeg(a + space);
            final float sin2 = Mathf.sinDeg(a + space);
            Fill.quad(x + r1 * cos, y + r1 * sin, x + r1 * cos2, y + r1 * sin2, x + r2 * cos2, y + r2 * sin2, x + r2 * cos, y + r2 * sin);
        }
    }
    
    public static void poly(final float x, final float y, final int sides, final float radius) {
        poly(x, y, sides, radius, 0.0f);
    }
    
    public static void poly(final Vec2[] vertices, final float offsetx, final float offsety, final float scl) {
        for (int i = 0; i < vertices.length; ++i) {
            final Vec2 current = vertices[i];
            final Vec2 next = (i == vertices.length - 1) ? vertices[0] : vertices[i + 1];
            line(current.x * scl + offsetx, current.y * scl + offsety, next.x * scl + offsetx, next.y * scl + offsety);
        }
    }
    
    public static void polySeg(final int sides, final int from, final int to, final float x, final float y, final float radius, final float angle) {
        Lines.vector.set(0.0f, 0.0f);
        for (int i = from; i < to; ++i) {
            Lines.vector.set(radius, 0.0f).setAngle(360.0f / sides * i + angle + 90.0f);
            final float x2 = Lines.vector.x;
            final float y2 = Lines.vector.y;
            Lines.vector.set(radius, 0.0f).setAngle(360.0f / sides * (i + 1) + angle + 90.0f);
            line(x2 + x, y2 + y, Lines.vector.x + x, Lines.vector.y + y);
        }
    }
    
    public static void curve(final float x1, final float y1, final float cx1, final float cy1, final float cx2, final float cy2, final float x2, final float y2, int segments) {
        final float subdiv_step = 1.0f / segments;
        final float subdiv_step2 = subdiv_step * subdiv_step;
        final float subdiv_step3 = subdiv_step * subdiv_step * subdiv_step;
        final float pre1 = 3.0f * subdiv_step;
        final float pre2 = 3.0f * subdiv_step2;
        final float pre3 = 6.0f * subdiv_step2;
        final float pre4 = 6.0f * subdiv_step3;
        final float tmp1x = x1 - cx1 * 2.0f + cx2;
        final float tmp1y = y1 - cy1 * 2.0f + cy2;
        final float tmp2x = (cx1 - cx2) * 3.0f - x1 + x2;
        final float tmp2y = (cy1 - cy2) * 3.0f - y1 + y2;
        float fx = x1;
        float fy = y1;
        float dfx = (cx1 - x1) * pre1 + tmp1x * pre2 + tmp2x * subdiv_step3;
        float dfy = (cy1 - y1) * pre1 + tmp1y * pre2 + tmp2y * subdiv_step3;
        float ddfx = tmp1x * pre3 + tmp2x * pre4;
        float ddfy = tmp1y * pre3 + tmp2y * pre4;
        final float dddfx = tmp2x * pre4;
        final float dddfy = tmp2y * pre4;
        while (segments-- > 0) {
            final float fxold = fx;
            final float fyold = fy;
            fx += dfx;
            fy += dfy;
            dfx += ddfx;
            dfy += ddfy;
            ddfx += dddfx;
            ddfy += dddfy;
            line(fxold, fyold, fx, fy);
        }
        line(fx, fy, x2, y2);
    }
    
    public static void swirl(final float x, final float y, final float radius, final float finion) {
        swirl(x, y, radius, finion, 0.0f);
    }
    
    public static void swirl(final float x, final float y, final float radius, final float finion, final float angle) {
        final int sides = 50;
        final int max = (int)(sides * (finion + 0.001f));
        Lines.vector.set(0.0f, 0.0f);
        Lines.floats.clear();
        for (int i = 0; i < max; ++i) {
            Lines.vector.set(radius, 0.0f).setAngle(360.0f / sides * i + angle);
            final float x2 = Lines.vector.x;
            final float y2 = Lines.vector.y;
            Lines.vector.set(radius, 0.0f).setAngle(360.0f / sides * (i + 1) + angle);
            Lines.floats.add(x2 + x, y2 + y);
        }
        polyline(Lines.floats, false);
    }
    
    public static void square(final float x, final float y, final float rad) {
        rect(x - rad, y - rad, rad * 2.0f, rad * 2.0f);
    }
    
    public static void square(final float x, final float y, final float rad, final float rot) {
        poly(x, y, 4, rad, rot - 45.0f);
    }
    
    public static void rect(float x, float y, float width, float height, final float xspace, final float yspace) {
        x -= xspace;
        y -= yspace;
        width += xspace * 2.0f;
        height += yspace * 2.0f;
        Fill.crect(x, y, width, Lines.stroke);
        Fill.crect(x, y + height, width, -Lines.stroke);
        Fill.crect(x + width, y, -Lines.stroke, height);
        Fill.crect(x, y, Lines.stroke, height);
    }
    
    public static void rect(final float x, final float y, final float width, final float height) {
        rect(x, y, width, height, 0);
    }
    
    public static void rect(final Rect rect) {
        rect(rect.x, rect.y, rect.width, rect.height, 0);
    }
    
    public static void rect(final float x, final float y, final float width, final float height, final int space) {
        rect(x, y, width, height, (float)space, (float)space);
    }
    
    public static void stroke(final float thick) {
        Lines.stroke = thick;
    }
    
    public static void stroke(final float thick, final Color color) {
        Lines.stroke = thick;
        Draw.color(color);
    }
    
    public static float getStroke() {
        return Lines.stroke;
    }
    
    static {
        Lines.useLegacyLine = false;
        Lines.stroke = 1.0f;
        Lines.vector = new Vec2();
        Lines.u = new Vec2();
        Lines.v = new Vec2();
        Lines.inner = new Vec2();
        Lines.outer = new Vec2();
        Lines.floats = new FloatSeq(20);
        Lines.floatBuilder = new FloatSeq(20);
        Lines.circlePrecision = 0.4f;
    }
}
