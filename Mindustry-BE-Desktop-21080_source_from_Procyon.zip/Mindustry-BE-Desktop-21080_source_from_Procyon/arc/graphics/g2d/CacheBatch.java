// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.graphics.gl.Shader;
import arc.graphics.Texture;
import arc.math.Mat;
import arc.graphics.Color;

public class CacheBatch extends Batch
{
    SpriteCache cache;
    float[] tmpVertices;
    
    public CacheBatch(final int size) {
        this(new SpriteCache(size, false));
    }
    
    public CacheBatch(final SpriteCache cache) {
        this.tmpVertices = new float[20];
        this.cache = cache;
    }
    
    public void flush() {
    }
    
    public void setColor(final Color tint) {
        this.cache.setColor(tint);
    }
    
    public void setColor(final float r, final float g, final float b, final float a) {
        this.cache.setColor(r, g, b, a);
    }
    
    public void setPackedColor(final float color) {
        this.cache.setPackedColor(color);
    }
    
    public Color getColor() {
        return this.cache.getColor();
    }
    
    public float getPackedColor() {
        return this.cache.getColor().toFloatBits();
    }
    
    public void setProjection(final Mat projection) {
        this.cache.setProjectionMatrix(projection);
    }
    
    public void beginCache() {
        this.cache.beginCache();
    }
    
    public int endCache() {
        return this.cache.endCache();
    }
    
    @Override
    protected void draw(final Texture texture, final float[] spriteVertices, final int offset, final int count) {
        final float[] vertices = (count / 6 * 5 == this.tmpVertices.length) ? this.tmpVertices : new float[count / 6 * 5];
        for (int i = 0; i < count / 6; ++i) {
            final int index = i * 6;
            final int dest = i * 5;
            vertices[dest] = spriteVertices[offset + index];
            vertices[dest + 1] = spriteVertices[offset + index + 1];
            vertices[dest + 2] = spriteVertices[offset + index + 2];
            vertices[dest + 3] = spriteVertices[offset + index + 3];
            vertices[dest + 4] = spriteVertices[offset + index + 4];
        }
        this.cache.add(texture, vertices, 0, vertices.length);
    }
    
    @Override
    protected void draw(final TextureRegion region, final float x, final float y, final float originX, final float originY, final float width, final float height, final float rotation) {
        this.cache.add(region, x, y, originX, originY, width, height, 1.0f, 1.0f, rotation);
    }
    
    public void setShader(final Shader shader) {
        this.setShader(shader, true);
    }
    
    public void setShader(final Shader shader, final boolean apply) {
        final boolean drawing = this.cache.isDrawing();
        if (drawing) {
            this.cache.end();
        }
        this.cache.setShader(shader);
        if (drawing) {
            this.cache.begin();
        }
        if (apply && shader != null) {
            shader.apply();
        }
    }
    
    @Override
    public void dispose() {
        super.dispose();
        this.cache.dispose();
    }
    
    public void beginDraw() {
        this.cache.begin();
    }
    
    public void endDraw() {
        this.cache.end();
    }
    
    public void drawCache(final int id) {
        this.cache.draw(id);
    }
}
