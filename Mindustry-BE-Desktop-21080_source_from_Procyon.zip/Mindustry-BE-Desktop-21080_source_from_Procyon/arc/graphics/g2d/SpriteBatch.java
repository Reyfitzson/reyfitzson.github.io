// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.math.Mathf;
import arc.graphics.Texture;
import arc.graphics.Gl;
import arc.graphics.Mesh;
import arc.graphics.VertexAttribute;
import arc.Core;
import arc.graphics.gl.Shader;

public class SpriteBatch extends Batch
{
    public static final int VERTEX_SIZE = 6;
    public static final int SPRITE_SIZE = 24;
    protected final float[] vertices;
    int totalRenderCalls;
    int maxSpritesInBatch;
    
    public SpriteBatch() {
        this(4096, null);
    }
    
    public SpriteBatch(final int size) {
        this(size, null);
    }
    
    public SpriteBatch(final int size, final Shader defaultShader) {
        this.totalRenderCalls = 0;
        this.maxSpritesInBatch = 0;
        if (size > 8191) {
            throw new IllegalArgumentException("Can't have more than 8191 sprites per batch: " + size);
        }
        if (size > 0) {
            this.projectionMatrix.setOrtho(0.0f, 0.0f, (float)Core.graphics.getWidth(), (float)Core.graphics.getHeight());
            this.mesh = new Mesh(true, false, size * 4, size * 6, new VertexAttribute[] { VertexAttribute.position, VertexAttribute.color, VertexAttribute.texCoords, VertexAttribute.mixColor });
            this.vertices = new float[size * 24];
            final int len = size * 6;
            final short[] indices = new short[len];
            short j = 0;
            for (int i = 0; i < len; i += 6, j += 4) {
                indices[i] = j;
                indices[i + 1] = (short)(j + 1);
                indices[i + 2] = (short)(j + 2);
                indices[i + 3] = (short)(j + 2);
                indices[i + 4] = (short)(j + 3);
                indices[i + 5] = j;
            }
            this.mesh.setIndices(indices);
            if (defaultShader == null) {
                this.shader = createShader();
                this.ownsShader = true;
            }
            else {
                this.shader = defaultShader;
            }
        }
        else {
            this.vertices = new float[0];
            this.shader = null;
        }
    }
    
    @Override
    protected void flush() {
        if (this.idx == 0) {
            return;
        }
        this.getShader().bind();
        this.setupMatrices();
        if (this.customShader != null && this.apply) {
            this.customShader.apply();
        }
        Gl.depthMask(false);
        ++this.totalRenderCalls;
        final int spritesInBatch = this.idx / 24;
        if (spritesInBatch > this.maxSpritesInBatch) {
            this.maxSpritesInBatch = spritesInBatch;
        }
        final int count = spritesInBatch * 6;
        this.blending.apply();
        this.lastTexture.bind();
        final Mesh mesh = this.mesh;
        mesh.setVertices(this.vertices, 0, this.idx);
        mesh.getIndicesBuffer().position(0);
        mesh.getIndicesBuffer().limit(count);
        mesh.render(this.getShader(), 4, 0, count);
        this.idx = 0;
    }
    
    @Override
    protected void draw(final Texture texture, final float[] spriteVertices, int offset, int count) {
        int remainingVertices;
        final int verticesLength = remainingVertices = this.vertices.length;
        if (texture != this.lastTexture) {
            this.switchTexture(texture);
        }
        else {
            remainingVertices -= this.idx;
            if (remainingVertices == 0) {
                this.flush();
                remainingVertices = verticesLength;
            }
        }
        int copyCount = Math.min(remainingVertices, count);
        System.arraycopy(spriteVertices, offset, this.vertices, this.idx, copyCount);
        this.idx += copyCount;
        for (count -= copyCount; count > 0; count -= copyCount) {
            offset += copyCount;
            this.flush();
            copyCount = Math.min(verticesLength, count);
            System.arraycopy(spriteVertices, offset, this.vertices, 0, copyCount);
            this.idx += copyCount;
        }
    }
    
    @Override
    protected void draw(final TextureRegion region, final float x, final float y, final float originX, final float originY, final float width, final float height, final float rotation) {
        final Texture texture = region.texture;
        if (texture != this.lastTexture) {
            this.switchTexture(texture);
        }
        else if (this.idx == this.vertices.length) {
            this.flush();
        }
        final float[] vertices = this.vertices;
        final int idx = this.idx;
        this.idx += 24;
        if (!Mathf.zero(rotation)) {
            final float worldOriginX = x + originX;
            final float worldOriginY = y + originY;
            final float fx = -originX;
            final float fy = -originY;
            final float fx2 = width - originX;
            final float fy2 = height - originY;
            final float cos = Mathf.cosDeg(rotation);
            final float sin = Mathf.sinDeg(rotation);
            final float x2 = cos * fx - sin * fy + worldOriginX;
            final float y2 = sin * fx + cos * fy + worldOriginY;
            final float x3 = cos * fx - sin * fy2 + worldOriginX;
            final float y3 = sin * fx + cos * fy2 + worldOriginY;
            final float x4 = cos * fx2 - sin * fy2 + worldOriginX;
            final float y4 = sin * fx2 + cos * fy2 + worldOriginY;
            final float x5 = x2 + (x4 - x3);
            final float y5 = y4 - (y3 - y2);
            final float u = region.u;
            final float v = region.v2;
            final float u2 = region.u2;
            final float v2 = region.v;
            final float color = this.colorPacked;
            final float mixColor = this.mixColorPacked;
            vertices[idx] = x2;
            vertices[idx + 1] = y2;
            vertices[idx + 2] = color;
            vertices[idx + 3] = u;
            vertices[idx + 4] = v;
            vertices[idx + 5] = mixColor;
            vertices[idx + 6] = x3;
            vertices[idx + 7] = y3;
            vertices[idx + 8] = color;
            vertices[idx + 9] = u;
            vertices[idx + 10] = v2;
            vertices[idx + 11] = mixColor;
            vertices[idx + 12] = x4;
            vertices[idx + 13] = y4;
            vertices[idx + 14] = color;
            vertices[idx + 15] = u2;
            vertices[idx + 16] = v2;
            vertices[idx + 17] = mixColor;
            vertices[idx + 18] = x5;
            vertices[idx + 19] = y5;
            vertices[idx + 20] = color;
            vertices[idx + 21] = u2;
            vertices[idx + 22] = v;
            vertices[idx + 23] = mixColor;
        }
        else {
            final float fx3 = x + width;
            final float fy3 = y + height;
            final float u3 = region.u;
            final float v3 = region.v2;
            final float u4 = region.u2;
            final float v4 = region.v;
            final float color2 = this.colorPacked;
            final float mixColor2 = this.mixColorPacked;
            vertices[idx] = x;
            vertices[idx + 1] = y;
            vertices[idx + 2] = color2;
            vertices[idx + 3] = u3;
            vertices[idx + 4] = v3;
            vertices[idx + 5] = mixColor2;
            vertices[idx + 6] = x;
            vertices[idx + 7] = fy3;
            vertices[idx + 8] = color2;
            vertices[idx + 9] = u3;
            vertices[idx + 10] = v4;
            vertices[idx + 11] = mixColor2;
            vertices[idx + 12] = fx3;
            vertices[idx + 13] = fy3;
            vertices[idx + 14] = color2;
            vertices[idx + 15] = u4;
            vertices[idx + 16] = v4;
            vertices[idx + 17] = mixColor2;
            vertices[idx + 18] = fx3;
            vertices[idx + 19] = y;
            vertices[idx + 20] = color2;
            vertices[idx + 21] = u4;
            vertices[idx + 22] = v3;
            vertices[idx + 23] = mixColor2;
        }
    }
    
    public static Shader createShader() {
        return new Shader("attribute vec4 a_position;\nattribute vec4 a_color;\nattribute vec2 a_texCoord0;\nattribute vec4 a_mix_color;\nuniform mat4 u_projTrans;\nvarying vec4 v_color;\nvarying vec4 v_mix_color;\nvarying vec2 v_texCoords;\n\nvoid main(){\n   v_color = a_color;\n   v_color.a = v_color.a * (255.0/254.0);\n   v_mix_color = a_mix_color;\n   v_mix_color.a *= (255.0/254.0);\n   v_texCoords = a_texCoord0;\n   gl_Position = u_projTrans * a_position;\n}", "\nvarying lowp vec4 v_color;\nvarying lowp vec4 v_mix_color;\nvarying highp vec2 v_texCoords;\nuniform highp sampler2D u_texture;\n\nvoid main(){\n  vec4 c = texture2D(u_texture, v_texCoords);\n  gl_FragColor = v_color * mix(c, vec4(v_mix_color.rgb, c.a), v_mix_color.a);\n}");
    }
}
