// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.graphics.Gl;
import arc.math.Mathf;
import java.nio.FloatBuffer;
import arc.util.ArcRuntimeException;
import java.util.Arrays;
import arc.Core;
import arc.graphics.VertexAttribute;
import arc.graphics.Color;
import arc.struct.IntSeq;
import arc.graphics.Texture;
import arc.struct.Seq;
import arc.graphics.gl.Shader;
import arc.math.Mat;
import arc.graphics.Mesh;
import arc.util.Disposable;

public class SpriteCache implements Disposable
{
    static final int VERTEX_SIZE = 5;
    private static final float[] tempVertices;
    private final Mesh mesh;
    private final Mat transformMatrix;
    private final Mat projectionMatrix;
    private final Mat combinedMatrix;
    private final Shader shader;
    private final Seq<Texture> textures;
    private final IntSeq counts;
    private final Color color;
    public int renderCalls;
    public int totalRenderCalls;
    private boolean drawing;
    private Seq<Cache> caches;
    private Cache currentCache;
    private float colorPacked;
    private Shader customShader;
    
    public SpriteCache() {
        this(1000, false);
    }
    
    public SpriteCache(final int size, final boolean useIndices) {
        this(size, 16, createDefaultShader(), useIndices);
    }
    
    public SpriteCache(final int size, final int cacheSize, final boolean useIndices) {
        this(size, cacheSize, createDefaultShader(), useIndices);
    }
    
    public SpriteCache(final int size, final int cacheSize, final Shader shader, final boolean useIndices) {
        this.transformMatrix = new Mat();
        this.projectionMatrix = new Mat();
        this.combinedMatrix = new Mat();
        this.textures = new Seq<Texture>(8);
        this.counts = new IntSeq(8);
        this.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        this.renderCalls = 0;
        this.totalRenderCalls = 0;
        this.colorPacked = Color.whiteFloatBits;
        this.customShader = null;
        this.shader = shader;
        if (useIndices && size > 8191) {
            throw new IllegalArgumentException("Can't have more than 8191 sprites per batch: " + size);
        }
        (this.mesh = new Mesh(true, size * (useIndices ? 4 : 6), useIndices ? (size * 6) : 0, new VertexAttribute[] { VertexAttribute.position, VertexAttribute.color, VertexAttribute.texCoords })).setAutoBind(false);
        this.caches = new Seq<Cache>(cacheSize);
        if (useIndices) {
            final int length = size * 6;
            final short[] indices = new short[length];
            short j = 0;
            for (int i = 0; i < length; i += 6, j += 4) {
                indices[i] = j;
                indices[i + 1] = (short)(j + 1);
                indices[i + 2] = (short)(j + 2);
                indices[i + 3] = (short)(j + 2);
                indices[i + 4] = (short)(j + 3);
                indices[i + 5] = j;
            }
            this.mesh.setIndices(indices);
        }
        this.projectionMatrix.setOrtho(0.0f, 0.0f, (float)Core.graphics.getWidth(), (float)Core.graphics.getHeight());
    }
    
    public static Shader createDefaultShader() {
        final String vertexShader = "attribute vec4 a_position;\nattribute vec4 a_color;\nattribute vec2 a_texCoord0;\nuniform mat4 u_projectionViewMatrix;\nvarying vec4 v_color;\nvarying vec2 v_texCoords;\n\nvoid main(){\n   v_color = a_color;\n   v_color.a = v_color.a * (255.0/254.0);\n   v_texCoords = a_texCoord0;\n   gl_Position =  u_projectionViewMatrix * a_position;\n}\n";
        final String fragmentShader = "varying vec4 v_color;\nvarying vec2 v_texCoords;\nuniform sampler2D u_texture;\nvoid main(){\n  gl_FragColor = v_color * texture2D(u_texture, v_texCoords);\n}";
        return new Shader(vertexShader, fragmentShader);
    }
    
    public Seq<Cache> getCaches() {
        return this.caches;
    }
    
    public void setColor(final float r, final float g, final float b, final float a) {
        this.color.set(r, g, b, a);
        this.colorPacked = this.color.toFloatBits();
    }
    
    public Color getColor() {
        return this.color;
    }
    
    public void setColor(final Color tint) {
        this.color.set(tint);
        this.colorPacked = tint.toFloatBits();
    }
    
    public float getPackedColor() {
        return this.colorPacked;
    }
    
    public void setPackedColor(final float packedColor) {
        this.color.abgr8888(packedColor);
        this.colorPacked = packedColor;
    }
    
    public void beginCache() {
        if (this.drawing) {
            throw new IllegalStateException("end must be called before beginCache");
        }
        if (this.currentCache != null) {
            throw new IllegalStateException("endCache must be called before begin.");
        }
        this.mesh.getVerticesBuffer().position(this.caches.isEmpty() ? 0 : (this.caches.peek().offset + this.caches.peek().maxCount));
        this.currentCache = new Cache(this.caches.size, this.mesh.getVerticesBuffer().position());
        this.caches.add(this.currentCache);
        this.mesh.getVerticesBuffer().limit(this.mesh.getVerticesBuffer().capacity());
    }
    
    public void beginCache(final int cacheID) {
        if (this.drawing) {
            throw new IllegalStateException("end must be called before beginCache");
        }
        if (this.currentCache != null) {
            throw new IllegalStateException("endCache must be called before begin.");
        }
        this.currentCache = this.caches.get(cacheID);
        Arrays.fill(this.currentCache.counts, 0);
        this.mesh.getVerticesBuffer().position(this.currentCache.offset);
    }
    
    public int endCache() {
        if (this.currentCache == null) {
            throw new IllegalStateException("beginCache must be called before endCache.");
        }
        final Cache cache = this.currentCache;
        final int cacheCount = this.mesh.getVerticesBuffer().position() - cache.offset;
        if (cache.textures == null) {
            cache.maxCount = cacheCount;
            cache.textureCount = this.textures.size;
            cache.textures = this.textures.toArray(Texture.class);
            cache.counts = new int[cache.textureCount];
            for (int i = 0, n = this.counts.size; i < n; ++i) {
                cache.counts[i] = this.counts.get(i);
            }
        }
        else {
            if (cacheCount > cache.maxCount) {
                throw new ArcRuntimeException("If a cache is not the last created, it cannot be redefined with more entries than when it was first created: " + cacheCount + " (" + cache.maxCount + " max)");
            }
            cache.textureCount = this.textures.size;
            if (cache.textures.length < cache.textureCount) {
                cache.textures = new Texture[cache.textureCount];
            }
            for (int i = 0, n = cache.textureCount; i < n; ++i) {
                cache.textures[i] = this.textures.get(i);
            }
            if (cache.counts.length < cache.textureCount) {
                cache.counts = new int[cache.textureCount];
            }
            for (int i = 0, n = cache.textureCount; i < n; ++i) {
                cache.counts[i] = this.counts.get(i);
            }
            final FloatBuffer vertices = this.mesh.getVerticesBuffer();
            vertices.position(0);
            final Cache lastCache = this.caches.get(this.caches.size - 1);
            vertices.limit(lastCache.offset + lastCache.maxCount);
        }
        this.currentCache = null;
        this.textures.clear();
        this.counts.clear();
        if (Core.app.isWeb()) {
            this.mesh.getVerticesBuffer().position(0);
        }
        return cache.id;
    }
    
    public void clear() {
        this.caches.clear();
        this.mesh.getVerticesBuffer().clear().flip();
    }
    
    public int reserve(final int sprites) {
        if (this.currentCache == null) {
            throw new IllegalStateException("beginCache must be called before ensureSize.");
        }
        final int spriteSize = 5 * ((this.mesh.getNumIndices() > 0) ? 4 : 6);
        final int currentUsed = this.currentCache.maxCount;
        final int required = sprites * spriteSize;
        final int toAdd = required - currentUsed;
        if (toAdd > 0) {
            final Cache currentCache = this.currentCache;
            currentCache.maxCount += toAdd;
            this.mesh.getVerticesBuffer().position(this.currentCache.offset + this.currentCache.maxCount);
            return toAdd / spriteSize;
        }
        return 0;
    }
    
    public void add(final Texture texture, final float[] vertices, final int offset, final int length) {
        if (this.currentCache == null) {
            throw new IllegalStateException("beginCache must be called before add.");
        }
        if (this.mesh.getVerticesBuffer().position() + length >= this.mesh.getVerticesBuffer().limit()) {
            throw new IllegalStateException("Out of vertex space! Size: " + this.mesh.getVerticesBuffer().capacity() + " Required: " + (this.mesh.getVerticesBuffer().position() + length));
        }
        final int verticesPerImage = (this.mesh.getNumIndices() > 0) ? 4 : 6;
        final int count = length / (verticesPerImage * 5) * 6;
        final int lastIndex = this.textures.size - 1;
        if (lastIndex < 0 || this.textures.get(lastIndex) != texture) {
            this.textures.add(texture);
            this.counts.add(count);
        }
        else {
            this.counts.incr(lastIndex, count);
        }
        this.mesh.getVerticesBuffer().put(vertices, offset, length);
    }
    
    public void add(final TextureRegion region, final float x, final float y) {
        this.add(region, x, y, (float)region.width, (float)region.height);
    }
    
    public void add(final TextureRegion region, final float x, final float y, final float width, final float height) {
        final float fx2 = x + width;
        final float fy2 = y + height;
        final float u = region.u;
        final float v = region.v2;
        final float u2 = region.u2;
        final float v2 = region.v;
        SpriteCache.tempVertices[0] = x;
        SpriteCache.tempVertices[1] = y;
        SpriteCache.tempVertices[2] = this.colorPacked;
        SpriteCache.tempVertices[3] = u;
        SpriteCache.tempVertices[4] = v;
        SpriteCache.tempVertices[5] = x;
        SpriteCache.tempVertices[6] = fy2;
        SpriteCache.tempVertices[7] = this.colorPacked;
        SpriteCache.tempVertices[8] = u;
        SpriteCache.tempVertices[9] = v2;
        SpriteCache.tempVertices[10] = fx2;
        SpriteCache.tempVertices[11] = fy2;
        SpriteCache.tempVertices[12] = this.colorPacked;
        SpriteCache.tempVertices[13] = u2;
        SpriteCache.tempVertices[14] = v2;
        if (this.mesh.getNumIndices() > 0) {
            SpriteCache.tempVertices[15] = fx2;
            SpriteCache.tempVertices[16] = y;
            SpriteCache.tempVertices[17] = this.colorPacked;
            SpriteCache.tempVertices[18] = u2;
            SpriteCache.tempVertices[19] = v;
            this.add(region.texture, SpriteCache.tempVertices, 0, 20);
        }
        else {
            SpriteCache.tempVertices[15] = fx2;
            SpriteCache.tempVertices[16] = fy2;
            SpriteCache.tempVertices[17] = this.colorPacked;
            SpriteCache.tempVertices[18] = u2;
            SpriteCache.tempVertices[19] = v2;
            SpriteCache.tempVertices[20] = fx2;
            SpriteCache.tempVertices[21] = y;
            SpriteCache.tempVertices[22] = this.colorPacked;
            SpriteCache.tempVertices[23] = u2;
            SpriteCache.tempVertices[24] = v;
            SpriteCache.tempVertices[25] = x;
            SpriteCache.tempVertices[26] = y;
            SpriteCache.tempVertices[27] = this.colorPacked;
            SpriteCache.tempVertices[28] = u;
            SpriteCache.tempVertices[29] = v;
            this.add(region.texture, SpriteCache.tempVertices, 0, 30);
        }
    }
    
    public void add(final TextureRegion region, final float x, final float y, final float originX, final float originY, final float width, final float height, final float scaleX, final float scaleY, final float rotation) {
        final float worldOriginX = x + originX;
        final float worldOriginY = y + originY;
        float fx = -originX;
        float fy = -originY;
        float fx2 = width - originX;
        float fy2 = height - originY;
        if (scaleX != 1.0f || scaleY != 1.0f) {
            fx *= scaleX;
            fy *= scaleY;
            fx2 *= scaleX;
            fy2 *= scaleY;
        }
        final float p1x = fx;
        final float p1y = fy;
        final float p2x = fx;
        final float p2y = fy2;
        final float p3x = fx2;
        final float p3y = fy2;
        final float p4x = fx2;
        final float p4y = fy;
        float x2;
        float y2;
        float x3;
        float y3;
        float x4;
        float y4;
        float x5;
        float y5;
        if (rotation != 0.0f) {
            final float cos = Mathf.cosDeg(rotation);
            final float sin = Mathf.sinDeg(rotation);
            x2 = cos * p1x - sin * p1y;
            y2 = sin * p1x + cos * p1y;
            x3 = cos * p2x - sin * p2y;
            y3 = sin * p2x + cos * p2y;
            x4 = cos * p3x - sin * p3y;
            y4 = sin * p3x + cos * p3y;
            x5 = x2 + (x4 - x3);
            y5 = y4 - (y3 - y2);
        }
        else {
            x2 = p1x;
            y2 = p1y;
            x3 = p2x;
            y3 = p2y;
            x4 = p3x;
            y4 = p3y;
            x5 = p4x;
            y5 = p4y;
        }
        x2 += worldOriginX;
        y2 += worldOriginY;
        x3 += worldOriginX;
        y3 += worldOriginY;
        x4 += worldOriginX;
        y4 += worldOriginY;
        x5 += worldOriginX;
        y5 += worldOriginY;
        final float u = region.u;
        final float v = region.v2;
        final float u2 = region.u2;
        final float v2 = region.v;
        SpriteCache.tempVertices[0] = x2;
        SpriteCache.tempVertices[1] = y2;
        SpriteCache.tempVertices[2] = this.colorPacked;
        SpriteCache.tempVertices[3] = u;
        SpriteCache.tempVertices[4] = v;
        SpriteCache.tempVertices[5] = x3;
        SpriteCache.tempVertices[6] = y3;
        SpriteCache.tempVertices[7] = this.colorPacked;
        SpriteCache.tempVertices[8] = u;
        SpriteCache.tempVertices[9] = v2;
        SpriteCache.tempVertices[10] = x4;
        SpriteCache.tempVertices[11] = y4;
        SpriteCache.tempVertices[12] = this.colorPacked;
        SpriteCache.tempVertices[13] = u2;
        SpriteCache.tempVertices[14] = v2;
        if (this.mesh.getNumIndices() > 0) {
            SpriteCache.tempVertices[15] = x5;
            SpriteCache.tempVertices[16] = y5;
            SpriteCache.tempVertices[17] = this.colorPacked;
            SpriteCache.tempVertices[18] = u2;
            SpriteCache.tempVertices[19] = v;
            this.add(region.texture, SpriteCache.tempVertices, 0, 20);
        }
        else {
            SpriteCache.tempVertices[15] = x4;
            SpriteCache.tempVertices[16] = y4;
            SpriteCache.tempVertices[17] = this.colorPacked;
            SpriteCache.tempVertices[18] = u2;
            SpriteCache.tempVertices[19] = v2;
            SpriteCache.tempVertices[20] = x5;
            SpriteCache.tempVertices[21] = y5;
            SpriteCache.tempVertices[22] = this.colorPacked;
            SpriteCache.tempVertices[23] = u2;
            SpriteCache.tempVertices[24] = v;
            SpriteCache.tempVertices[25] = x2;
            SpriteCache.tempVertices[26] = y2;
            SpriteCache.tempVertices[27] = this.colorPacked;
            SpriteCache.tempVertices[28] = u;
            SpriteCache.tempVertices[29] = v;
            this.add(region.texture, SpriteCache.tempVertices, 0, 30);
        }
    }
    
    public void begin() {
        if (this.drawing) {
            throw new IllegalStateException("end must be called before begin.");
        }
        if (this.currentCache != null) {
            throw new IllegalStateException("endCache must be called before begin");
        }
        this.renderCalls = 0;
        this.combinedMatrix.set(this.projectionMatrix).mul(this.transformMatrix);
        final Shader shader = (this.customShader != null) ? this.customShader : this.shader;
        shader.bind();
        shader.setUniformMatrix4("u_projectionViewMatrix", this.combinedMatrix);
        shader.setUniformi("u_texture", 0);
        this.mesh.bind(shader);
        this.drawing = true;
    }
    
    public void end() {
        if (!this.drawing) {
            throw new IllegalStateException("begin must be called before end.");
        }
        this.drawing = false;
        Gl.depthMask(true);
        if (this.customShader != null) {
            this.mesh.unbind(this.customShader);
        }
        else {
            this.mesh.unbind(this.shader);
        }
    }
    
    public void draw(final int cacheID) {
        if (!this.drawing) {
            throw new IllegalStateException("SpriteCache.begin must be called before draw.");
        }
        final Cache cache = this.caches.get(cacheID);
        final int verticesPerImage = (this.mesh.getNumIndices() > 0) ? 4 : 6;
        int offset = cache.offset / (verticesPerImage * 5) * 6;
        final Texture[] textures = cache.textures;
        final int[] counts = cache.counts;
        final int textureCount = cache.textureCount;
        final Shader shader = (this.customShader != null) ? this.customShader : this.shader;
        for (int i = 0; i < textureCount; ++i) {
            final int count = counts[i];
            textures[i].bind();
            this.mesh.render(shader, 4, offset, count);
            offset += count;
        }
        this.renderCalls += textureCount;
        this.totalRenderCalls += textureCount;
    }
    
    public void draw(final int cacheID, int offset, int length) {
        if (!this.drawing) {
            throw new IllegalStateException("SpriteCache.begin must be called before draw.");
        }
        final Cache cache = this.caches.get(cacheID);
        offset = offset * 6 + cache.offset;
        length *= 6;
        final Texture[] textures = cache.textures;
        final int[] counts = cache.counts;
        final int textureCount = cache.textureCount;
        for (int i = 0; i < textureCount; ++i) {
            textures[i].bind();
            int count = counts[i];
            if (count > length) {
                i = textureCount;
                count = length;
            }
            else {
                length -= count;
            }
            if (this.customShader != null) {
                this.mesh.render(this.customShader, 4, offset, count);
            }
            else {
                this.mesh.render(this.shader, 4, offset, count);
            }
            offset += count;
        }
        this.renderCalls += cache.textureCount;
        this.totalRenderCalls += textureCount;
    }
    
    @Override
    public void dispose() {
        this.mesh.dispose();
        if (this.shader != null) {
            this.shader.dispose();
        }
    }
    
    public Mat getProjectionMatrix() {
        return this.projectionMatrix;
    }
    
    public void setProjectionMatrix(final Mat projection) {
        if (this.drawing) {
            throw new IllegalStateException("Can't set the matrix within begin/end.");
        }
        this.projectionMatrix.set(projection);
    }
    
    public Mat getTransformMatrix() {
        return this.transformMatrix;
    }
    
    public void setTransformMatrix(final Mat transform) {
        if (this.drawing) {
            throw new IllegalStateException("Can't set the matrix within begin/end.");
        }
        this.transformMatrix.set(transform);
    }
    
    public void setShader(final Shader shader) {
        this.customShader = shader;
    }
    
    public boolean isDrawing() {
        return this.drawing;
    }
    
    static {
        tempVertices = new float[30];
    }
    
    private static class Cache
    {
        final int id;
        final int offset;
        int maxCount;
        int textureCount;
        Texture[] textures;
        int[] counts;
        
        public Cache(final int id, final int offset) {
            this.id = id;
            this.offset = offset;
        }
    }
}
