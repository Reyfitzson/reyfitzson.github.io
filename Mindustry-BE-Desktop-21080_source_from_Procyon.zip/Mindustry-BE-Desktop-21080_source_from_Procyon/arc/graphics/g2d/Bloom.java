// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.graphics.Texture;
import arc.graphics.Gl;
import arc.graphics.Pixmap;
import arc.Core;
import arc.graphics.gl.FrameBuffer;
import arc.graphics.gl.Shader;

public class Bloom
{
    public static boolean useAlphaChannelAsMask;
    public int blurPasses;
    private Shader thresholdShader;
    private Shader bloomShader;
    private Shader blurShader;
    private FrameBuffer buffer;
    private FrameBuffer pingPong1;
    private FrameBuffer pingPong2;
    private float bloomIntensity;
    private float originalIntensity;
    private float threshold;
    private boolean blending;
    private boolean capturing;
    private float r;
    private float g;
    private float b;
    private float a;
    
    public void resume() {
        this.bloomShader.bind();
        this.bloomShader.setUniformi("u_texture0", 0);
        this.bloomShader.setUniformi("u_texture1", 1);
        this.setSize(this.pingPong1.getWidth(), this.pingPong1.getHeight());
        this.setThreshold(this.threshold);
        this.setBloomIntesity(this.bloomIntensity);
        this.setOriginalIntesity(this.originalIntensity);
    }
    
    public Bloom() {
        this.blurPasses = 1;
        this.blending = false;
        this.capturing = false;
        this.init(Core.graphics.getWidth() / 4, Core.graphics.getHeight() / 4, false, false);
    }
    
    public Bloom(final boolean useBlending) {
        this.blurPasses = 1;
        this.blending = false;
        this.capturing = false;
        this.init(Core.graphics.getWidth() / 4, Core.graphics.getHeight() / 4, false, useBlending);
    }
    
    public Bloom(final int width, final int height, final boolean hasDepth, final boolean useBlending) {
        this.blurPasses = 1;
        this.blending = false;
        this.capturing = false;
        this.init(width, height, hasDepth, useBlending);
    }
    
    public void resize(final int width, final int height) {
        final boolean changed = this.pingPong1.getWidth() != width || this.pingPong1.getHeight() != height;
        if (changed) {
            this.pingPong1.resize(width, height);
            this.pingPong2.resize(width, height);
            this.buffer.resize(Core.graphics.getWidth(), Core.graphics.getHeight());
            this.setSize(width, height);
        }
    }
    
    private void init(final int width, final int height, final boolean hasDepth, final boolean useBlending) {
        this.blending = useBlending;
        final Pixmap.Format format = useBlending ? Pixmap.Format.rgba8888 : Pixmap.Format.rgb888;
        this.buffer = new FrameBuffer(format, Core.graphics.getWidth(), Core.graphics.getHeight(), hasDepth);
        this.pingPong1 = new FrameBuffer(format, width, height, false);
        this.pingPong2 = new FrameBuffer(format, width, height, false);
        final String alpha = useBlending ? "alpha_" : "";
        this.bloomShader = createShader("screenspace", alpha + "bloom");
        if (Bloom.useAlphaChannelAsMask) {
            this.thresholdShader = createShader("screenspace", "maskedthreshold");
        }
        else {
            this.thresholdShader = createShader("screenspace", alpha + "threshold");
        }
        this.blurShader = createShader("blurspace", alpha + "gaussian");
        this.setSize(width, height);
        this.setBloomIntesity(2.5f);
        this.setOriginalIntesity(1.0f);
        this.setThreshold(0.5f);
        this.bloomShader.bind();
        this.bloomShader.setUniformi("u_texture0", 0);
        this.bloomShader.setUniformi("u_texture1", 1);
    }
    
    public void setClearColor(final float r, final float g, final float b, final float a) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;
    }
    
    public void capture() {
        if (!this.capturing) {
            this.capturing = true;
            this.buffer.begin();
            Gl.clearColor(this.r, this.g, this.b, this.a);
            Gl.clear(16640);
        }
    }
    
    public void capturePause() {
        if (this.capturing) {
            this.capturing = false;
            this.buffer.end();
        }
    }
    
    public void captureContinue() {
        if (!this.capturing) {
            this.capturing = true;
            this.buffer.begin();
        }
    }
    
    public void render() {
        if (this.capturing) {
            this.capturing = false;
            this.buffer.end();
        }
        Gl.disable(3042);
        Gl.disable(2929);
        Gl.depthMask(false);
        this.gaussianBlur();
        if (this.blending) {
            Gl.enable(3042);
            Gl.blendFunc(770, 771);
        }
        this.pingPong1.getTexture().bind(1);
        this.buffer.blit(this.bloomShader);
    }
    
    private void gaussianBlur() {
        this.pingPong1.begin();
        this.buffer.blit(this.thresholdShader);
        this.pingPong1.end();
        for (int i = 0; i < this.blurPasses; ++i) {
            this.pingPong2.begin();
            this.blurShader.bind();
            this.blurShader.setUniformf("dir", 1.0f, 0.0f);
            this.pingPong1.blit(this.blurShader);
            this.pingPong2.end();
            this.pingPong1.begin();
            this.blurShader.bind();
            this.blurShader.setUniformf("dir", 0.0f, 1.0f);
            this.pingPong2.blit(this.blurShader);
            this.pingPong1.end();
        }
    }
    
    public void setBloomIntesity(final float intensity) {
        this.bloomIntensity = intensity;
        this.bloomShader.bind();
        this.bloomShader.setUniformf("BloomIntensity", intensity);
    }
    
    public void setOriginalIntesity(final float intensity) {
        this.originalIntensity = intensity;
        this.bloomShader.bind();
        this.bloomShader.setUniformf("OriginalIntensity", intensity);
    }
    
    public void setThreshold(final float threshold) {
        this.threshold = threshold;
        this.thresholdShader.bind();
        this.thresholdShader.setUniformf("threshold", threshold, 1.0f / (1.0f - threshold));
    }
    
    private void setSize(final int width, final int height) {
        this.blurShader.bind();
        this.blurShader.setUniformf("size", (float)width, (float)height);
    }
    
    public void dispose() {
        try {
            this.buffer.dispose();
            this.pingPong1.dispose();
            this.pingPong2.dispose();
            this.blurShader.dispose();
            this.bloomShader.dispose();
            this.thresholdShader.dispose();
        }
        catch (Throwable t) {}
    }
    
    private static Shader createShader(final String vertexName, final String fragmentName) {
        return new Shader(Core.files.internal("bloomshaders/" + vertexName + ".vert"), Core.files.internal("bloomshaders/" + fragmentName + ".frag"));
    }
    
    static {
        Bloom.useAlphaChannelAsMask = false;
    }
}
