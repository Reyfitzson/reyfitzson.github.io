// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.util.Structs;
import java.util.Comparator;
import arc.graphics.TextureData;
import arc.graphics.gl.PixmapTextureData;
import arc.struct.OrderedMap;
import arc.struct.ObjectMap;
import java.io.Writer;
import arc.graphics.PixmapIO;
import java.io.IOException;
import arc.files.Fi;
import java.util.Arrays;
import arc.graphics.Texture;
import java.util.Iterator;
import arc.util.ArcRuntimeException;
import java.nio.Buffer;
import arc.graphics.Gl;
import arc.math.geom.Rect;
import arc.graphics.Color;
import arc.graphics.Pixmap;
import arc.struct.Seq;
import arc.util.Disposable;

public class PixmapPacker implements Disposable
{
    final Seq<Page> pages;
    boolean packToTexture;
    boolean disposed;
    int pageWidth;
    int pageHeight;
    Pixmap.Format pageFormat;
    int padding;
    boolean duplicateBorder;
    boolean stripWhitespaceX;
    boolean stripWhitespaceY;
    Color transparentColor;
    PackStrategy packStrategy;
    private Color c;
    
    public PixmapPacker(final int pageWidth, final int pageHeight, final Pixmap.Format pageFormat, final int padding, final boolean duplicateBorder) {
        this(pageWidth, pageHeight, pageFormat, padding, duplicateBorder, false, false, new GuillotineStrategy());
    }
    
    public PixmapPacker(final int pageWidth, final int pageHeight, final Pixmap.Format pageFormat, final int padding, final boolean duplicateBorder, final PackStrategy packStrategy) {
        this(pageWidth, pageHeight, pageFormat, padding, duplicateBorder, false, false, packStrategy);
    }
    
    public PixmapPacker(final int pageWidth, final int pageHeight, final Pixmap.Format pageFormat, final int padding, final boolean duplicateBorder, final boolean stripWhitespaceX, final boolean stripWhitespaceY, final PackStrategy packStrategy) {
        this.pages = new Seq<Page>();
        this.transparentColor = new Color(0.0f, 0.0f, 0.0f, 0.0f);
        this.c = new Color();
        this.pageWidth = pageWidth;
        this.pageHeight = pageHeight;
        this.pageFormat = pageFormat;
        this.padding = padding;
        this.duplicateBorder = duplicateBorder;
        this.stripWhitespaceX = stripWhitespaceX;
        this.stripWhitespaceY = stripWhitespaceY;
        this.packStrategy = packStrategy;
    }
    
    public void sort(final Seq<Pixmap> images) {
        this.packStrategy.sort(images);
    }
    
    public synchronized Rect pack(final Pixmap image) {
        return this.pack(null, image);
    }
    
    public synchronized Rect pack(final String name, final Pixmap image) {
        return this.pack(name, new PixmapRegion(image));
    }
    
    public synchronized Rect pack(String name, PixmapRegion image) {
        if (this.disposed) {
            return null;
        }
        final boolean isPatch = name != null && name.endsWith(".9");
        Pixmap pixmapToDispose = null;
        PixmapPackerRect rect;
        if (isPatch) {
            rect = new PixmapPackerRect(0, 0, image.width, image.height);
            pixmapToDispose = new Pixmap(image.width, image.height, image.pixmap.getFormat());
            rect.splits = this.getSplits(image);
            rect.pads = this.getPads(image, rect.splits);
            pixmapToDispose.draw(image, 0, 0, 0, 0, image.width, image.height);
            image = new PixmapRegion(pixmapToDispose);
            name = name.split("\\.")[0];
        }
        else {
            rect = new PixmapPackerRect(0, 0, image.width, image.height);
        }
        if (rect.width <= this.pageWidth && rect.height <= this.pageHeight) {
            final Page page = this.packStrategy.pack(this, name, rect);
            if (name != null) {
                page.rects.put(name, rect);
                page.addedRects.add(name);
            }
            final int rectX = (int)rect.x;
            final int rectY = (int)rect.y;
            final int rectWidth = (int)rect.width;
            final int rectHeight = (int)rect.height;
            if (this.packToTexture && !this.duplicateBorder && page.texture != null && !page.dirty) {
                page.texture.bind();
                Gl.texSubImage2D(page.texture.glTarget, 0, rectX, rectY, rectWidth, rectHeight, image.pixmap.getGLFormat(), image.pixmap.getGLType(), image.pixmap.getPixels());
            }
            else {
                page.dirty = true;
            }
            page.image.setBlending(Pixmap.Blending.none);
            page.image.draw(image, rectX, rectY);
            if (this.duplicateBorder) {
                final int imageWidth = image.width;
                final int imageHeight = image.height;
                page.image.draw(image, 0, 0, 1, 1, rectX - 1, rectY - 1, 1, 1);
                page.image.draw(image, imageWidth - 1, 0, 1, 1, rectX + rectWidth, rectY - 1, 1, 1);
                page.image.draw(image, 0, imageHeight - 1, 1, 1, rectX - 1, rectY + rectHeight, 1, 1);
                page.image.draw(image, imageWidth - 1, imageHeight - 1, 1, 1, rectX + rectWidth, rectY + rectHeight, 1, 1);
                page.image.draw(image, 0, 0, imageWidth, 1, rectX, rectY - 1, rectWidth, 1);
                page.image.draw(image, 0, imageHeight - 1, imageWidth, 1, rectX, rectY + rectHeight, rectWidth, 1);
                page.image.draw(image, 0, 0, 1, imageHeight, rectX - 1, rectY, 1, rectHeight);
                page.image.draw(image, imageWidth - 1, 0, 1, imageHeight, rectX + rectWidth, rectY, 1, rectHeight);
            }
            if (pixmapToDispose != null) {
                pixmapToDispose.dispose();
            }
            return rect;
        }
        if (name == null) {
            throw new ArcRuntimeException("Page size too small for pixmap.");
        }
        throw new ArcRuntimeException("Page size too small for pixmap: " + name);
    }
    
    public Seq<Page> getPages() {
        return this.pages;
    }
    
    public synchronized Rect getRect(final String name) {
        for (final Page page : this.pages) {
            final Rect rect = page.rects.get(name);
            if (rect != null) {
                return rect;
            }
        }
        return null;
    }
    
    public synchronized Page getPage(final String name) {
        for (final Page page : this.pages) {
            final Rect rect = page.rects.get(name);
            if (rect != null) {
                return page;
            }
        }
        return null;
    }
    
    public synchronized int getPageIndex(final String name) {
        for (int i = 0; i < this.pages.size; ++i) {
            final Rect rect = this.pages.get(i).rects.get(name);
            if (rect != null) {
                return i;
            }
        }
        return -1;
    }
    
    @Override
    public synchronized void dispose() {
        for (final Page page : this.pages) {
            if (page.texture == null) {
                page.image.dispose();
            }
        }
        this.disposed = true;
    }
    
    public synchronized TextureAtlas generateTextureAtlas(final Texture.TextureFilter minFilter, final Texture.TextureFilter magFilter, final boolean useMipMaps) {
        final TextureAtlas atlas = new TextureAtlas();
        this.updateTextureAtlas(atlas, minFilter, magFilter, useMipMaps, true);
        return atlas;
    }
    
    public synchronized void updateTextureAtlas(final TextureAtlas atlas, final Texture.TextureFilter minFilter, final Texture.TextureFilter magFilter, final boolean useMipMaps) {
        this.updateTextureAtlas(atlas, minFilter, magFilter, useMipMaps, true);
    }
    
    public synchronized void updateTextureAtlas(final TextureAtlas atlas, final Texture.TextureFilter minFilter, final Texture.TextureFilter magFilter, final boolean useMipMaps, final boolean clearRects) {
        this.updatePageTextures(minFilter, magFilter, useMipMaps);
        for (final Page page : this.pages) {
            if (page.addedRects.size > 0) {
                for (final String name : page.addedRects) {
                    final PixmapPackerRect rect = page.rects.get(name);
                    final TextureAtlas.AtlasRegion region = new TextureAtlas.AtlasRegion(page.texture, (int)rect.x, (int)rect.y, (int)rect.width, (int)rect.height);
                    if (rect.splits != null) {
                        region.splits = rect.splits;
                        region.pads = rect.pads;
                    }
                    region.name = name;
                    region.index = -1;
                    region.offsetX = (float)rect.offsetX;
                    region.offsetY = (float)(int)(rect.originalHeight - rect.height - rect.offsetY);
                    region.originalWidth = rect.originalWidth;
                    region.originalHeight = rect.originalHeight;
                    atlas.getRegions().add(region);
                    atlas.getRegionMap().put(name, region);
                }
                if (clearRects) {
                    page.addedRects.clear();
                }
                atlas.getTextures().add(page.texture);
            }
        }
    }
    
    public synchronized void updateTextureRegions(final Seq<TextureRegion> regions, final Texture.TextureFilter minFilter, final Texture.TextureFilter magFilter, final boolean useMipMaps) {
        this.updatePageTextures(minFilter, magFilter, useMipMaps);
        while (regions.size < this.pages.size) {
            regions.add(new TextureRegion(this.pages.get(regions.size).texture));
        }
    }
    
    public synchronized void updatePageTextures(final Texture.TextureFilter minFilter, final Texture.TextureFilter magFilter, final boolean useMipMaps) {
        for (final Page page : this.pages) {
            page.updateTexture(minFilter, magFilter, useMipMaps);
        }
    }
    
    public int getPageWidth() {
        return this.pageWidth;
    }
    
    public void setPageWidth(final int pageWidth) {
        this.pageWidth = pageWidth;
    }
    
    public int getPageHeight() {
        return this.pageHeight;
    }
    
    public void setPageHeight(final int pageHeight) {
        this.pageHeight = pageHeight;
    }
    
    public Pixmap.Format getPageFormat() {
        return this.pageFormat;
    }
    
    public void setPageFormat(final Pixmap.Format pageFormat) {
        this.pageFormat = pageFormat;
    }
    
    public int getPadding() {
        return this.padding;
    }
    
    public void setPadding(final int padding) {
        this.padding = padding;
    }
    
    public boolean getDuplicateBorder() {
        return this.duplicateBorder;
    }
    
    public void setDuplicateBorder(final boolean duplicateBorder) {
        this.duplicateBorder = duplicateBorder;
    }
    
    public boolean getPackToTexture() {
        return this.packToTexture;
    }
    
    public void setPackToTexture(final boolean packToTexture) {
        this.packToTexture = packToTexture;
    }
    
    public Color getTransparentColor() {
        return this.transparentColor;
    }
    
    public void setTransparentColor(final Color color) {
        this.transparentColor.set(color);
    }
    
    private int[] getSplits(final PixmapRegion raster) {
        int startX = this.getSplitPoint(raster, 1, 0, true, true);
        int endX = this.getSplitPoint(raster, startX, 0, false, true);
        int startY = this.getSplitPoint(raster, 0, 1, true, false);
        int endY = this.getSplitPoint(raster, 0, startY, false, false);
        this.getSplitPoint(raster, endX + 1, 0, true, true);
        this.getSplitPoint(raster, 0, endY + 1, true, false);
        if (startX == 0 && endX == 0 && startY == 0 && endY == 0) {
            return null;
        }
        if (startX != 0) {
            --startX;
            endX = raster.width - 2 - (endX - 1);
        }
        else {
            endX = raster.width - 2;
        }
        if (startY != 0) {
            --startY;
            endY = raster.height - 2 - (endY - 1);
        }
        else {
            endY = raster.height - 2;
        }
        return new int[] { startX, endX, startY, endY };
    }
    
    private int[] getPads(final PixmapRegion raster, final int[] splits) {
        final int bottom = raster.height - 1;
        final int right = raster.width - 1;
        int startX = this.getSplitPoint(raster, 1, bottom, true, true);
        int startY = this.getSplitPoint(raster, right, 1, true, false);
        int endX = 0;
        int endY = 0;
        if (startX != 0) {
            endX = this.getSplitPoint(raster, startX + 1, bottom, false, true);
        }
        if (startY != 0) {
            endY = this.getSplitPoint(raster, right, startY + 1, false, false);
        }
        this.getSplitPoint(raster, endX + 1, bottom, true, true);
        this.getSplitPoint(raster, right, endY + 1, true, false);
        if (startX == 0 && endX == 0 && startY == 0 && endY == 0) {
            return null;
        }
        if (startX == 0 && endX == 0) {
            startX = -1;
            endX = -1;
        }
        else if (startX > 0) {
            --startX;
            endX = raster.width - 2 - (endX - 1);
        }
        else {
            endX = raster.width - 2;
        }
        if (startY == 0 && endY == 0) {
            startY = -1;
            endY = -1;
        }
        else if (startY > 0) {
            --startY;
            endY = raster.height - 2 - (endY - 1);
        }
        else {
            endY = raster.height - 2;
        }
        final int[] pads = { startX, endX, startY, endY };
        if (splits != null && Arrays.equals(pads, splits)) {
            return null;
        }
        return pads;
    }
    
    private int getSplitPoint(final PixmapRegion raster, final int startX, final int startY, final boolean startPoint, final boolean xAxis) {
        final int[] rgba = new int[4];
        int next = xAxis ? startX : startY;
        final int end = xAxis ? raster.width : raster.height;
        final int breakA = startPoint ? 255 : 0;
        int x = startX;
        int y = startY;
        while (next != end) {
            if (xAxis) {
                x = next;
            }
            else {
                y = next;
            }
            final int colint = raster.getPixel(x, y);
            this.c.set(colint);
            rgba[0] = (int)(this.c.r * 255.0f);
            rgba[1] = (int)(this.c.g * 255.0f);
            rgba[2] = (int)(this.c.b * 255.0f);
            rgba[3] = (int)(this.c.a * 255.0f);
            if (rgba[3] == breakA) {
                return next;
            }
            ++next;
        }
        return 0;
    }
    
    public void save(final Fi file) throws IOException {
        this.save(file, Texture.TextureFilter.nearest, Texture.TextureFilter.nearest);
    }
    
    public void save(final Fi file, final Texture.TextureFilter minFilter, final Texture.TextureFilter maxFilter) throws IOException {
        final Writer writer = file.writer(false);
        int index = 0;
        for (final Page page : this.pages) {
            if (page.rects.size > 0) {
                final Fi pageFile = file.sibling(file.nameWithoutExtension() + "_" + ++index + ".PNG");
                PixmapIO.writePNG(pageFile, page.image);
                writer.write("\n");
                writer.write(pageFile.name() + "\n");
                writer.write("size: " + page.image.getWidth() + "," + page.image.getHeight() + "\n");
                writer.write("format: " + this.pageFormat.name() + "\n");
                writer.write("filter: " + minFilter.name() + "," + maxFilter.name() + "\n");
                writer.write("repeat: none\n");
                for (final String name : page.rects.keys()) {
                    writer.write(name + "\n");
                    final PixmapPackerRect rect = page.rects.get(name);
                    writer.write("  rotate: false\n");
                    writer.write("  xy: " + (int)rect.x + "," + (int)rect.y + "\n");
                    writer.write("  size: " + (int)rect.width + "," + (int)rect.height + "\n");
                    if (rect.splits != null) {
                        writer.write("  split: " + rect.splits[0] + ", " + rect.splits[1] + ", " + rect.splits[2] + ", " + rect.splits[3] + "\n");
                        if (rect.pads != null) {
                            writer.write("  pad: " + rect.pads[0] + ", " + rect.pads[1] + ", " + rect.pads[2] + ", " + rect.pads[3] + "\n");
                        }
                    }
                    writer.write("  orig: " + rect.originalWidth + ", " + rect.originalHeight + "\n");
                    writer.write("  offset: " + rect.offsetX + ", " + (int)(rect.originalHeight - rect.height - rect.offsetY) + "\n");
                    writer.write("  index: -1\n");
                }
            }
        }
        writer.close();
    }
    
    public static class Page
    {
        final Seq<String> addedRects;
        OrderedMap<String, PixmapPackerRect> rects;
        Pixmap image;
        Texture texture;
        boolean dirty;
        
        public Page(final PixmapPacker packer) {
            this.addedRects = new Seq<String>();
            this.rects = new OrderedMap<String, PixmapPackerRect>();
            this.image = new Pixmap(packer.pageWidth, packer.pageHeight, packer.pageFormat);
            final Color transparentColor = packer.getTransparentColor();
            this.image.setColor(transparentColor);
            this.image.fill();
        }
        
        public Page(final Pixmap pixmap) {
            this.addedRects = new Seq<String>();
            this.rects = new OrderedMap<String, PixmapPackerRect>();
            this.image = pixmap;
        }
        
        public void setDirty(final boolean dirty) {
            this.dirty = dirty;
        }
        
        public Pixmap getPixmap() {
            return this.image;
        }
        
        public OrderedMap<String, PixmapPackerRect> getRects() {
            return this.rects;
        }
        
        public Texture getTexture() {
            return this.texture;
        }
        
        public boolean updateTexture(final Texture.TextureFilter minFilter, final Texture.TextureFilter magFilter, final boolean useMipMaps) {
            if (this.texture != null) {
                if (!this.dirty) {
                    return false;
                }
                this.texture.load(this.texture.getTextureData());
            }
            else {
                (this.texture = new Texture(new PixmapTextureData(this.image, this.image.getFormat(), useMipMaps, false)) {
                    @Override
                    public void dispose() {
                        super.dispose();
                        if (!Page.this.image.isDisposed()) {
                            Page.this.image.dispose();
                        }
                    }
                }).setFilter(minFilter, magFilter);
            }
            this.dirty = false;
            return true;
        }
    }
    
    public static class GuillotineStrategy implements PackStrategy
    {
        Comparator<Pixmap> comparator;
        
        @Override
        public void sort(final Seq<Pixmap> pixmaps) {
            if (this.comparator == null) {
                this.comparator = Structs.comparingInt(o -> Math.max(o.getWidth(), o.getHeight()));
            }
            pixmaps.sort(this.comparator);
        }
        
        @Override
        public Page pack(final PixmapPacker packer, final String name, final Rect rect) {
            GuillotinePage page;
            if (packer.pages.size == 0) {
                page = new GuillotinePage(packer);
                packer.pages.add(page);
            }
            else {
                page = packer.pages.peek();
            }
            final int padding = packer.padding;
            rect.width += padding;
            rect.height += padding;
            Node node = this.insert(page.root, rect);
            if (node == null) {
                page = new GuillotinePage(packer);
                packer.pages.add(page);
                node = this.insert(page.root, rect);
            }
            node.full = true;
            rect.set(node.rect.x, node.rect.y, node.rect.width - padding, node.rect.height - padding);
            return page;
        }
        
        private Node insert(final Node node, final Rect rect) {
            if (!node.full && node.leftChild != null && node.rightChild != null) {
                Node newNode = this.insert(node.leftChild, rect);
                if (newNode == null) {
                    newNode = this.insert(node.rightChild, rect);
                }
                return newNode;
            }
            if (node.full) {
                return null;
            }
            if (node.rect.width == rect.width && node.rect.height == rect.height) {
                return node;
            }
            if (node.rect.width < rect.width || node.rect.height < rect.height) {
                return null;
            }
            node.leftChild = new Node();
            node.rightChild = new Node();
            final int deltaWidth = (int)node.rect.width - (int)rect.width;
            final int deltaHeight = (int)node.rect.height - (int)rect.height;
            if (deltaWidth > deltaHeight) {
                node.leftChild.rect.x = node.rect.x;
                node.leftChild.rect.y = node.rect.y;
                node.leftChild.rect.width = rect.width;
                node.leftChild.rect.height = node.rect.height;
                node.rightChild.rect.x = node.rect.x + rect.width;
                node.rightChild.rect.y = node.rect.y;
                node.rightChild.rect.width = node.rect.width - rect.width;
                node.rightChild.rect.height = node.rect.height;
            }
            else {
                node.leftChild.rect.x = node.rect.x;
                node.leftChild.rect.y = node.rect.y;
                node.leftChild.rect.width = node.rect.width;
                node.leftChild.rect.height = rect.height;
                node.rightChild.rect.x = node.rect.x;
                node.rightChild.rect.y = node.rect.y + rect.height;
                node.rightChild.rect.width = node.rect.width;
                node.rightChild.rect.height = node.rect.height - rect.height;
            }
            return this.insert(node.leftChild, rect);
        }
        
        static final class Node
        {
            public final Rect rect;
            public Node leftChild;
            public Node rightChild;
            public boolean full;
            
            Node() {
                this.rect = new Rect();
            }
        }
        
        public static class GuillotinePage extends Page
        {
            Node root;
            
            public GuillotinePage(final PixmapPacker packer) {
                super(packer);
                this.root = new Node();
                this.root.rect.x = (float)packer.padding;
                this.root.rect.y = (float)packer.padding;
                this.root.rect.width = (float)(packer.pageWidth - packer.padding * 2);
                this.root.rect.height = (float)(packer.pageHeight - packer.padding * 2);
            }
            
            public GuillotinePage(final PixmapPacker packer, final Pixmap base) {
                super(base);
                this.root = new Node();
                this.root.rect.x = (float)packer.padding;
                this.root.rect.y = (float)packer.padding;
                this.root.rect.width = (float)(packer.pageWidth - packer.padding * 2);
                this.root.rect.height = (float)(packer.pageHeight - packer.padding * 2);
            }
        }
    }
    
    public static class SkylineStrategy implements PackStrategy
    {
        Comparator<Pixmap> comparator;
        
        @Override
        public void sort(final Seq<Pixmap> images) {
            if (this.comparator == null) {
                this.comparator = ((o1, o2) -> o1.getHeight() - o2.getHeight());
            }
            images.sort(this.comparator);
        }
        
        @Override
        public Page pack(final PixmapPacker packer, final String name, final Rect rect) {
            final int padding = packer.padding;
            final int pageWidth = packer.pageWidth - padding * 2;
            final int pageHeight = packer.pageHeight - padding * 2;
            final int rectWidth = (int)rect.width + padding;
            final int rectHeight = (int)rect.height + padding;
            for (int i = 0, n = packer.pages.size; i < n; ++i) {
                final SkylinePage page = packer.pages.get(i);
                SkylinePage.Row bestRow = null;
                for (int ii = 0, nn = page.rows.size - 1; ii < nn; ++ii) {
                    final SkylinePage.Row row = page.rows.get(ii);
                    if (row.x + rectWidth < pageWidth) {
                        if (row.y + rectHeight < pageHeight) {
                            if (rectHeight <= row.height) {
                                if (bestRow == null || row.height < bestRow.height) {
                                    bestRow = row;
                                }
                            }
                        }
                    }
                }
                if (bestRow == null) {
                    final SkylinePage.Row row2 = page.rows.peek();
                    if (row2.y + rectHeight >= pageHeight) {
                        continue;
                    }
                    if (row2.x + rectWidth < pageWidth) {
                        row2.height = Math.max(row2.height, rectHeight);
                        bestRow = row2;
                    }
                    else if (row2.y + row2.height + rectHeight < pageHeight) {
                        bestRow = new SkylinePage.Row();
                        bestRow.y = row2.y + row2.height;
                        bestRow.height = rectHeight;
                        page.rows.add(bestRow);
                    }
                }
                if (bestRow != null) {
                    rect.x = (float)bestRow.x;
                    rect.y = (float)bestRow.y;
                    final SkylinePage.Row row4 = bestRow;
                    row4.x += rectWidth;
                    return page;
                }
            }
            final SkylinePage page2 = new SkylinePage(packer);
            packer.pages.add(page2);
            final SkylinePage.Row row3 = new SkylinePage.Row();
            row3.x = padding + rectWidth;
            row3.y = padding;
            row3.height = rectHeight;
            page2.rows.add(row3);
            rect.x = (float)padding;
            rect.y = (float)padding;
            return page2;
        }
        
        static class SkylinePage extends Page
        {
            Seq<Row> rows;
            
            public SkylinePage(final PixmapPacker packer) {
                super(packer);
                this.rows = new Seq<Row>();
            }
            
            static class Row
            {
                int x;
                int y;
                int height;
            }
        }
    }
    
    public static class PixmapPackerRect extends Rect
    {
        public int[] splits;
        public int[] pads;
        int offsetX;
        int offsetY;
        int originalWidth;
        int originalHeight;
        
        public PixmapPackerRect(final int x, final int y, final int width, final int height) {
            super((float)x, (float)y, (float)width, (float)height);
            this.offsetX = 0;
            this.offsetY = 0;
            this.originalWidth = width;
            this.originalHeight = height;
        }
        
        public PixmapPackerRect(final int x, final int y, final int width, final int height, final int left, final int top, final int originalWidth, final int originalHeight) {
            super((float)x, (float)y, (float)width, (float)height);
            this.offsetX = left;
            this.offsetY = top;
            this.originalWidth = originalWidth;
            this.originalHeight = originalHeight;
        }
    }
    
    public interface PackStrategy
    {
        void sort(final Seq<Pixmap> p0);
        
        Page pack(final PixmapPacker p0, final String p1, final Rect p2);
    }
}
