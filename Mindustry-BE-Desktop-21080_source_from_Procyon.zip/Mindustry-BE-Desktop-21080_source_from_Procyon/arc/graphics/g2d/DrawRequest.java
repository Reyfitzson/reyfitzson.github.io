// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.graphics.Blending;
import arc.graphics.Texture;

class DrawRequest implements Comparable<DrawRequest>
{
    TextureRegion region;
    float x;
    float y;
    float z;
    float originX;
    float originY;
    float width;
    float height;
    float rotation;
    float color;
    float mixColor;
    float[] vertices;
    Texture texture;
    Blending blending;
    Runnable run;
    
    DrawRequest() {
        this.region = new TextureRegion();
        this.vertices = new float[24];
    }
    
    @Override
    public int compareTo(final DrawRequest o) {
        return Float.compare(this.z, o.z);
    }
}
