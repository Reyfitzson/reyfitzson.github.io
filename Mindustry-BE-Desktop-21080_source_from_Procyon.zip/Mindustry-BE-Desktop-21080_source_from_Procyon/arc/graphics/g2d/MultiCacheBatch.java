// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import java.util.Iterator;
import arc.graphics.Texture;
import arc.util.Pack;
import arc.math.Mat;
import arc.graphics.Color;
import arc.graphics.gl.Shader;
import arc.struct.Seq;

public class MultiCacheBatch extends Batch
{
    private static final int maxSpritesPerCache = 102000;
    Seq<SpriteCache> caches;
    Shader shader;
    int currentid;
    int maxCacheSize;
    int offset;
    boolean recaching;
    
    public MultiCacheBatch(final int maxCacheSize) {
        this.caches = new Seq<SpriteCache>();
        this.shader = SpriteCache.createDefaultShader();
        this.currentid = -1;
        this.recaching = false;
        this.maxCacheSize = maxCacheSize;
    }
    
    SpriteCache currentCache() {
        final int needed = (this.currentid == -1) ? (this.offset / 102000) : this.currentid;
        if (needed >= this.caches.size) {
            this.caches.add(new SpriteCache(102000, 16, this.shader, false));
        }
        return this.caches.get(needed);
    }
    
    public void flush() {
    }
    
    public void setColor(final Color tint) {
        this.currentCache().setColor(tint);
    }
    
    public void setColor(final float r, final float g, final float b, final float a) {
        this.currentCache().setColor(r, g, b, a);
    }
    
    public void setPackedColor(final float color) {
        this.currentCache().setPackedColor(color);
    }
    
    public Color getColor() {
        return this.currentCache().getColor();
    }
    
    public float getPackedColor() {
        return this.currentCache().getPackedColor();
    }
    
    public void setProjection(final Mat projection) {
        this.currentid = 0;
        this.currentCache().setProjectionMatrix(projection);
    }
    
    public void reserve(final int amount) {
        this.offset += this.currentCache().reserve(amount);
    }
    
    public void beginCache(final int id) {
        final int cacheID = Pack.leftShort(id);
        final int batch = Pack.rightShort(id);
        this.caches.get(batch).beginCache(cacheID);
        this.currentid = batch;
        this.recaching = true;
    }
    
    public void beginCache() {
        this.currentid = this.offset / 102000;
        if (this.currentid < (this.offset + this.maxCacheSize) / 102000) {
            this.offset += this.maxCacheSize - this.offset % this.maxCacheSize + 2;
            this.currentid = this.offset / 102000;
        }
        this.currentCache().beginCache();
        this.recaching = false;
    }
    
    public int endCache() {
        final int id = Pack.shortInt((short)this.currentCache().endCache(), (short)this.currentid);
        this.currentid = -1;
        this.recaching = false;
        return id;
    }
    
    @Override
    protected void draw(final Texture texture, final float[] spriteVertices, final int offset, final int count) {
    }
    
    @Override
    protected void draw(final TextureRegion region, final float x, final float y, final float originX, final float originY, final float width, final float height, final float rotation) {
        this.currentCache().add(region, x, y, originX, originY, width, height, 1.0f, 1.0f, rotation);
        if (!this.recaching) {
            ++this.offset;
        }
    }
    
    public void setShader(final Shader shader, final boolean apply) {
        final boolean drawing = this.currentCache().isDrawing();
        if (drawing) {
            this.currentCache().end();
        }
        this.currentCache().setShader(shader);
        if (drawing) {
            this.currentCache().begin();
        }
        if (apply && shader != null) {
            shader.apply();
        }
    }
    
    @Override
    public void dispose() {
        super.dispose();
        for (final SpriteCache cache : this.caches) {
            cache.dispose();
        }
        this.shader.dispose();
    }
    
    public void beginDraw() {
        this.currentid = 0;
        this.currentCache().begin();
    }
    
    public void endDraw() {
        this.currentCache().end();
        this.currentid = -1;
    }
    
    public void drawCache(final int id) {
        final int cacheID = Pack.leftShort(id);
        final int batch = Pack.rightShort(id);
        if (this.currentid != batch) {
            final SpriteCache prev = this.currentCache();
            prev.end();
            this.currentid = batch;
            this.currentCache().setProjectionMatrix(prev.getProjectionMatrix());
            this.currentCache().begin();
        }
        this.currentCache().draw(cacheID);
    }
}
