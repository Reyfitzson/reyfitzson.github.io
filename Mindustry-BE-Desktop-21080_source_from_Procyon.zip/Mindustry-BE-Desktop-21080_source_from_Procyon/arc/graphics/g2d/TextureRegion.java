// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.Core;
import arc.graphics.Texture;

public class TextureRegion
{
    public Texture texture;
    public float u;
    public float v;
    public float u2;
    public float v2;
    public int width;
    public int height;
    
    public TextureRegion() {
    }
    
    public TextureRegion(final Texture texture) {
        if (texture == null) {
            throw new IllegalArgumentException("texture cannot be null.");
        }
        this.texture = texture;
        this.set(0, 0, texture.width, texture.height);
    }
    
    public TextureRegion(final Texture texture, final int width, final int height) {
        this.texture = texture;
        this.set(0, 0, width, height);
    }
    
    public TextureRegion(final Texture texture, final int x, final int y, final int width, final int height) {
        this.texture = texture;
        this.set(x, y, width, height);
    }
    
    public TextureRegion(final Texture texture, final float u, final float v, final float u2, final float v2) {
        this.texture = texture;
        this.set(u, v, u2, v2);
    }
    
    public TextureRegion(final TextureRegion region) {
        this.set(region);
    }
    
    public TextureRegion(final TextureRegion region, final int x, final int y, final int width, final int height) {
        this.set(region, x, y, width, height);
    }
    
    public static TextureRegion[][] split(final Texture texture, final int tileWidth, final int tileHeight) {
        final TextureRegion region = new TextureRegion(texture);
        return region.split(tileWidth, tileHeight);
    }
    
    public TextureAtlas.AtlasRegion asAtlas() {
        return (TextureAtlas.AtlasRegion)this;
    }
    
    public boolean found() {
        return Core.atlas != null && Core.atlas.error != this;
    }
    
    public void set(final Texture texture) {
        this.texture = texture;
        this.set(0, 0, texture.width, texture.height);
    }
    
    public void set(final int x, final int y, final int width, final int height) {
        final float invTexWidth = 1.0f / this.texture.width;
        final float invTexHeight = 1.0f / this.texture.height;
        this.set(x * invTexWidth, y * invTexHeight, (x + width) * invTexWidth, (y + height) * invTexHeight);
        this.width = Math.abs(width);
        this.height = Math.abs(height);
    }
    
    public void set(float u, float v, float u2, float v2) {
        final int texWidth = this.texture.width;
        final int texHeight = this.texture.height;
        this.width = Math.round(Math.abs(u2 - u) * texWidth);
        this.height = Math.round(Math.abs(v2 - v) * texHeight);
        if (this.width == 1 && this.height == 1) {
            final float adjustX = 0.25f / texWidth;
            u += adjustX;
            u2 -= adjustX;
            final float adjustY = 0.25f / texHeight;
            v += adjustY;
            v2 -= adjustY;
        }
        this.u = u;
        this.v = v;
        this.u2 = u2;
        this.v2 = v2;
    }
    
    public void set(final TextureRegion region) {
        this.texture = region.texture;
        this.set(region.u, region.v, region.u2, region.v2);
    }
    
    public void set(final TextureRegion region, final int x, final int y, final int width, final int height) {
        this.texture = region.texture;
        this.set(region.getX() + x, region.getY() + y, width, height);
    }
    
    public void set(final Texture texture, final int x, final int y, final int width, final int height) {
        this.texture = texture;
        this.set(x, y, width, height);
    }
    
    public void setU(final float u) {
        this.u = u;
        this.width = Math.round(Math.abs(this.u2 - u) * this.texture.width);
    }
    
    public void setV(final float v) {
        this.v = v;
        this.height = Math.round(Math.abs(this.v2 - v) * this.texture.height);
    }
    
    public void setU2(final float u2) {
        this.u2 = u2;
        this.width = Math.round(Math.abs(u2 - this.u) * this.texture.width);
    }
    
    public void setV2(final float v2) {
        this.v2 = v2;
        this.height = Math.round(Math.abs(v2 - this.v) * this.texture.height);
    }
    
    public int getX() {
        return Math.round(this.u * this.texture.width);
    }
    
    public void setX(final int x) {
        this.setU(x / (float)this.texture.width);
    }
    
    public int getY() {
        return Math.round(this.v * this.texture.height);
    }
    
    public void setY(final int y) {
        this.setV(y / (float)this.texture.height);
    }
    
    public void setWidth(final int width) {
        if (this.isFlipX()) {
            this.setU(this.u2 + width / (float)this.texture.width);
        }
        else {
            this.setU2(this.u + width / (float)this.texture.width);
        }
    }
    
    public void setHeight(final int height) {
        if (this.isFlipY()) {
            this.setV(this.v2 + height / (float)this.texture.height);
        }
        else {
            this.setV2(this.v + height / (float)this.texture.height);
        }
    }
    
    public void flip(final boolean x, final boolean y) {
        if (x) {
            final float temp = this.u;
            this.u = this.u2;
            this.u2 = temp;
        }
        if (y) {
            final float temp = this.v;
            this.v = this.v2;
            this.v2 = temp;
        }
    }
    
    public boolean isFlipX() {
        return this.u > this.u2;
    }
    
    public boolean isFlipY() {
        return this.v > this.v2;
    }
    
    public void scroll(final float xAmount, final float yAmount) {
        if (xAmount != 0.0f) {
            final float width = (this.u2 - this.u) * this.texture.width;
            this.u = (this.u + xAmount) % 1.0f;
            this.u2 = this.u + width / this.texture.width;
        }
        if (yAmount != 0.0f) {
            final float height = (this.v2 - this.v) * this.texture.height;
            this.v = (this.v + yAmount) % 1.0f;
            this.v2 = this.v + height / this.texture.height;
        }
    }
    
    public TextureRegion[][] split(final int tileWidth, final int tileHeight) {
        if (this.texture == null) {
            return null;
        }
        int x = this.getX();
        int y = this.getY();
        final int width = this.width;
        final int height = this.height;
        final int sw = width / tileWidth;
        final int sh = height / tileHeight;
        final int startX = x;
        final TextureRegion[][] tiles = new TextureRegion[sw][sh];
        for (int cy = 0; cy < sh; ++cy, y += tileHeight) {
            x = startX;
            for (int cx = 0; cx < sw; ++cx, x += tileWidth) {
                tiles[cx][cy] = new TextureRegion(this.texture, x, y, tileWidth, tileHeight);
            }
        }
        return tiles;
    }
    
    @Override
    public String toString() {
        return "TextureRegion{texture=" + this.texture + ", width=" + this.width + ", height=" + this.height + '}';
    }
}
