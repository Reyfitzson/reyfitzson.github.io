// 
// Decompiled by Procyon v0.5.36
// 

package arc.graphics.g2d;

import arc.graphics.Texture;
import arc.graphics.Blending;
import arc.graphics.gl.Shader;
import arc.struct.Seq;

public class SortedSpriteBatch extends SpriteBatch
{
    protected Seq<DrawRequest> requestPool;
    protected Seq<DrawRequest> requests;
    protected boolean sort;
    protected boolean flushing;
    
    public SortedSpriteBatch() {
        this.requestPool = new Seq<DrawRequest>(10000);
        this.requests = new Seq<DrawRequest>(DrawRequest.class);
    }
    
    @Override
    protected void setSort(final boolean sort) {
        if (this.sort != sort) {
            this.flush();
        }
        this.sort = sort;
    }
    
    @Override
    protected void setShader(final Shader shader, final boolean apply) {
        if (!this.flushing && this.sort) {
            throw new IllegalArgumentException("Shaders cannot be set while sorting is enabled. Set shaders inside Draw.run(...).");
        }
        super.setShader(shader, apply);
    }
    
    @Override
    protected void setBlending(final Blending blending) {
        this.blending = blending;
    }
    
    @Override
    protected void draw(final Texture texture, final float[] spriteVertices, final int offset, final int count) {
        if (this.sort && !this.flushing) {
            for (int i = offset; i < count; i += 24) {
                final DrawRequest req = this.obtain();
                req.z = this.z;
                System.arraycopy(spriteVertices, i, req.vertices, 0, req.vertices.length);
                req.texture = texture;
                req.blending = this.blending;
                req.run = null;
                this.requests.add(req);
            }
        }
        else {
            super.draw(texture, spriteVertices, offset, count);
        }
    }
    
    @Override
    protected void draw(final TextureRegion region, final float x, final float y, final float originX, final float originY, final float width, final float height, final float rotation) {
        if (this.sort && !this.flushing) {
            final DrawRequest req = this.obtain();
            req.x = x;
            req.y = y;
            req.z = this.z;
            req.originX = originX;
            req.originY = originY;
            req.width = width;
            req.height = height;
            req.color = this.colorPacked;
            req.rotation = rotation;
            req.region.set(region);
            req.mixColor = this.mixColorPacked;
            req.blending = this.blending;
            req.texture = null;
            req.run = null;
            this.requests.add(req);
        }
        else {
            super.draw(region, x, y, originX, originY, width, height, rotation);
        }
    }
    
    @Override
    protected void draw(final Runnable request) {
        if (this.sort && !this.flushing) {
            final DrawRequest req = this.obtain();
            req.run = request;
            req.blending = this.blending;
            req.mixColor = this.mixColorPacked;
            req.color = this.colorPacked;
            req.z = this.z;
            req.texture = null;
            this.requests.add(req);
        }
        else {
            super.draw(request);
        }
    }
    
    protected DrawRequest obtain() {
        return (this.requestPool.size > 0) ? this.requestPool.pop() : new DrawRequest();
    }
    
    @Override
    protected void flush() {
        this.flushRequests();
        super.flush();
    }
    
    protected void flushRequests() {
        if (!this.flushing && !this.requests.isEmpty()) {
            this.flushing = true;
            this.sortRequests();
            final float preColor = this.colorPacked;
            final float preMixColor = this.mixColorPacked;
            final Blending preBlending = this.blending;
            for (int j = 0; j < this.requests.size; ++j) {
                final DrawRequest req = this.requests.items[j];
                this.colorPacked = req.color;
                this.mixColorPacked = req.mixColor;
                super.setBlending(req.blending);
                if (req.run != null) {
                    req.run.run();
                }
                else if (req.texture != null) {
                    super.draw(req.texture, req.vertices, 0, req.vertices.length);
                }
                else {
                    super.draw(req.region, req.x, req.y, req.originX, req.originY, req.width, req.height, req.rotation);
                }
            }
            this.colorPacked = preColor;
            this.mixColorPacked = preMixColor;
            this.color.abgr8888(this.colorPacked);
            this.mixColor.abgr8888(this.mixColorPacked);
            this.blending = preBlending;
            this.requestPool.addAll(this.requests);
            this.requests.size = 0;
            this.flushing = false;
        }
    }
    
    protected void sortRequests() {
        this.requests.sort();
    }
}
