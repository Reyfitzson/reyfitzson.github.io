// 
// Decompiled by Procyon v0.5.36
// 

package arc;

import arc.func.Cons;
import arc.struct.Seq;
import arc.struct.ObjectMap;

public class Events
{
    private static final ObjectMap<Object, Seq<Cons<?>>> events;
    
    public static <T> void on(final Class<T> type, final Cons<T> listener) {
        Events.events.get(type, Seq::new).add(listener);
    }
    
    public static void run(final Object type, final Runnable listener) {
        Events.events.get(type, Seq::new).add(e -> listener.run());
    }
    
    public static <T> void remove(final Class<T> type, final Cons<T> listener) {
        Events.events.get(type, Seq::new).remove(listener);
    }
    
    public static <T> void fire(final T type) {
        fire(type.getClass(), type);
    }
    
    public static <T> void fire(final Class<?> ctype, final T type) {
        if (Events.events.get(type) != null) {
            Events.events.get(type).each(e -> e.get(type));
        }
        if (Events.events.get(ctype) != null) {
            Events.events.get(ctype).each(e -> e.get(type));
        }
    }
    
    static {
        events = new ObjectMap<Object, Seq<Cons<?>>>();
    }
}
