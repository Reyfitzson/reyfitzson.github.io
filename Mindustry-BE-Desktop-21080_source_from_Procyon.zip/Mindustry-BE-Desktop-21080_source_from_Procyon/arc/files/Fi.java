// 
// Decompiled by Procyon v0.5.36
// 

package arc.files;

import arc.util.OS;
import java.io.FilenameFilter;
import java.io.FileFilter;
import arc.struct.Seq;
import arc.func.Boolf;
import arc.func.Cons;
import arc.graphics.PixmapIO;
import arc.graphics.Pixmap;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.util.zip.InflaterInputStream;
import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import arc.util.io.Reads;
import java.io.DataOutput;
import java.io.DataOutputStream;
import arc.util.io.Writes;
import java.nio.ByteOrder;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.ByteBuffer;
import java.io.BufferedReader;
import java.io.UnsupportedEncodingException;
import java.io.Closeable;
import arc.util.io.Streams;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import arc.Core;
import java.io.IOException;
import arc.util.ArcRuntimeException;
import arc.Files;
import java.io.File;

public class Fi
{
    protected File file;
    protected Files.FileType type;
    
    protected Fi() {
    }
    
    public Fi(final String fileName) {
        this.file = new File(fileName);
        this.type = Files.FileType.absolute;
    }
    
    public Fi(final File file) {
        this.file = file;
        this.type = Files.FileType.absolute;
    }
    
    public Fi(final String fileName, final Files.FileType type) {
        this.type = type;
        this.file = new File(fileName);
    }
    
    protected Fi(final File file, final Files.FileType type) {
        this.file = file;
        this.type = type;
    }
    
    public static Fi get(final String path) {
        return new Fi(path);
    }
    
    public static Fi tempFile(final String prefix) {
        try {
            return new Fi(File.createTempFile(prefix, null));
        }
        catch (IOException ex) {
            throw new ArcRuntimeException("Unable to create temp file.", ex);
        }
    }
    
    public static Fi tempDirectory(final String prefix) {
        try {
            final File file = File.createTempFile(prefix, null);
            if (!file.delete()) {
                throw new IOException("Unable to delete temp file: " + file);
            }
            if (!file.mkdir()) {
                throw new IOException("Unable to create temp directory: " + file);
            }
            return new Fi(file);
        }
        catch (IOException ex) {
            throw new ArcRuntimeException("Unable to create temp file.", ex);
        }
    }
    
    private static void emptyDirectory(final File file, final boolean preserveTree) {
        if (file.exists()) {
            final File[] files = file.listFiles();
            if (files != null) {
                for (int i = 0, n = files.length; i < n; ++i) {
                    if (!files[i].isDirectory()) {
                        files[i].delete();
                    }
                    else if (preserveTree) {
                        emptyDirectory(files[i], true);
                    }
                    else {
                        deleteDirectory(files[i]);
                    }
                }
            }
        }
    }
    
    private static boolean deleteDirectory(final File file) {
        emptyDirectory(file, false);
        return file.delete();
    }
    
    private static void copyFile(final Fi source, final Fi dest) {
        try {
            dest.write(source.read(), false);
        }
        catch (Exception ex) {
            throw new ArcRuntimeException("Error copying source file: " + source.file + " (" + source.type + ")\nTo destination: " + dest.file + " (" + dest.type + ")", ex);
        }
    }
    
    private static void copyDirectory(final Fi sourceDir, final Fi destDir) {
        destDir.mkdirs();
        final Fi[] list;
        final Fi[] files = list = sourceDir.list();
        for (final Fi srcFile : list) {
            final Fi destFile = destDir.child(srcFile.name());
            if (srcFile.isDirectory()) {
                copyDirectory(srcFile, destFile);
            }
            else {
                copyFile(srcFile, destFile);
            }
        }
    }
    
    public String path() {
        return this.file.getPath().replace('\\', '/');
    }
    
    public String absolutePath() {
        return this.file.getAbsolutePath().replace('\\', '/');
    }
    
    public String name() {
        return this.file.getName().isEmpty() ? this.file.getPath() : this.file.getName();
    }
    
    public boolean extEquals(final String ext) {
        return this.extension().equalsIgnoreCase(ext);
    }
    
    public String extension() {
        final String name = this.file.getName();
        final int dotIndex = name.lastIndexOf(46);
        if (dotIndex == -1) {
            return "";
        }
        return name.substring(dotIndex + 1);
    }
    
    public String nameWithoutExtension() {
        final String name = this.file.getName();
        final int dotIndex = name.lastIndexOf(46);
        if (dotIndex == -1) {
            return name;
        }
        return name.substring(0, dotIndex);
    }
    
    public String pathWithoutExtension() {
        final String path = this.file.getPath().replace('\\', '/');
        final int dotIndex = path.lastIndexOf(46);
        if (dotIndex == -1) {
            return path;
        }
        return path.substring(0, dotIndex);
    }
    
    public Files.FileType type() {
        return this.type;
    }
    
    public File file() {
        if (this.type == Files.FileType.external) {
            return new File(Core.files.getExternalStoragePath(), this.file.getPath());
        }
        return this.file;
    }
    
    public InputStream read() {
        if (this.type == Files.FileType.classpath || (this.type == Files.FileType.internal && !this.file().exists()) || (this.type == Files.FileType.local && !this.file().exists())) {
            final InputStream input = Fi.class.getResourceAsStream("/" + this.file.getPath().replace('\\', '/'));
            if (input == null) {
                throw new ArcRuntimeException("File not found: " + this.file + " (" + this.type + ")");
            }
            return input;
        }
        else {
            try {
                return new FileInputStream(this.file());
            }
            catch (Exception ex) {
                if (this.file().isDirectory()) {
                    throw new ArcRuntimeException("Cannot open a stream to a directory: " + this.file + " (" + this.type + ")", ex);
                }
                throw new ArcRuntimeException("Error reading file: " + this.file + " (" + this.type + ")", ex);
            }
        }
    }
    
    public BufferedInputStream read(final int bufferSize) {
        return new BufferedInputStream(this.read(), bufferSize);
    }
    
    public Reader reader() {
        return this.reader("UTF-8");
    }
    
    public Reader reader(final String charset) {
        final InputStream stream = this.read();
        try {
            return new InputStreamReader(stream, charset);
        }
        catch (UnsupportedEncodingException ex) {
            Streams.close(stream);
            throw new ArcRuntimeException("Error reading file: " + this, ex);
        }
    }
    
    public BufferedReader reader(final int bufferSize) {
        return this.reader(bufferSize, "UTF-8");
    }
    
    public BufferedReader reader(final int bufferSize, final String charset) {
        try {
            return new BufferedReader(new InputStreamReader(this.read(), charset), bufferSize);
        }
        catch (UnsupportedEncodingException ex) {
            throw new ArcRuntimeException("Error reading file: " + this, ex);
        }
    }
    
    public String readString() {
        return this.readString("UTF-8");
    }
    
    public String readString(final String charset) {
        final StringBuilder output = new StringBuilder(this.estimateLength());
        InputStreamReader reader = null;
        try {
            if (charset == null) {
                reader = new InputStreamReader(this.read());
            }
            else {
                reader = new InputStreamReader(this.read(), charset);
            }
            final char[] buffer = new char[256];
            while (true) {
                final int length = reader.read(buffer);
                if (length == -1) {
                    break;
                }
                output.append(buffer, 0, length);
            }
        }
        catch (IOException ex) {
            throw new ArcRuntimeException("Error reading layout file: " + this, ex);
        }
        finally {
            Streams.close(reader);
        }
        return output.toString();
    }
    
    public byte[] readBytes() {
        final InputStream input = this.read();
        try {
            return Streams.copyBytes(input, this.estimateLength());
        }
        catch (IOException ex) {
            throw new ArcRuntimeException("Error reading file: " + this, ex);
        }
        finally {
            Streams.close(input);
        }
    }
    
    private int estimateLength() {
        final int length = (int)this.length();
        return (length != 0) ? length : 512;
    }
    
    public int readBytes(final byte[] bytes, final int offset, final int size) {
        final InputStream input = this.read();
        int position = 0;
        try {
            while (true) {
                final int count = input.read(bytes, offset + position, size - position);
                if (count <= 0) {
                    break;
                }
                position += count;
            }
        }
        catch (IOException ex) {
            throw new ArcRuntimeException("Error reading file: " + this, ex);
        }
        finally {
            Streams.close(input);
        }
        return position - offset;
    }
    
    public ByteBuffer map() {
        return this.map(FileChannel.MapMode.READ_ONLY);
    }
    
    public ByteBuffer map(final FileChannel.MapMode mode) {
        if (this.type == Files.FileType.classpath) {
            throw new ArcRuntimeException("Cannot map a classpath file: " + this);
        }
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(this.file, (mode == FileChannel.MapMode.READ_ONLY) ? "r" : "rw");
            final FileChannel fileChannel = raf.getChannel();
            final ByteBuffer map = fileChannel.map(mode, 0L, this.file.length());
            map.order(ByteOrder.nativeOrder());
            return map;
        }
        catch (Exception ex) {
            throw new ArcRuntimeException("Error memory mapping file: " + this + " (" + this.type + ")", ex);
        }
        finally {
            Streams.close(raf);
        }
    }
    
    public Writes writes() {
        return new Writes(new DataOutputStream(this.write(false, 4096)));
    }
    
    public Reads reads() {
        return new Reads(new DataInputStream(this.read(4096)));
    }
    
    public Writes writesDeflate() {
        return new Writes(new DataOutputStream(new DeflaterOutputStream(this.write(false, 4096))));
    }
    
    public Reads readsDeflate() {
        return new Reads(new DataInputStream(new InflaterInputStream(this.read(4096))));
    }
    
    public OutputStream write() {
        return this.write(false);
    }
    
    public OutputStream write(final boolean append) {
        if (this.type == Files.FileType.classpath) {
            throw new ArcRuntimeException("Cannot write to a classpath file: " + this.file);
        }
        if (this.type == Files.FileType.internal) {
            throw new ArcRuntimeException("Cannot write to an internal file: " + this.file);
        }
        this.parent().mkdirs();
        try {
            return new FileOutputStream(this.file(), append);
        }
        catch (Exception ex) {
            if (this.file().isDirectory()) {
                throw new ArcRuntimeException("Cannot open a stream to a directory: " + this.file + " (" + this.type + ")", ex);
            }
            throw new ArcRuntimeException("Error writing file: " + this.file + " (" + this.type + ")", ex);
        }
    }
    
    public OutputStream write(final boolean append, final int bufferSize) {
        return new BufferedOutputStream(this.write(append), bufferSize);
    }
    
    public void write(final InputStream input, final boolean append) {
        OutputStream output = null;
        try {
            output = this.write(append);
            Streams.copy(input, output);
        }
        catch (Exception ex) {
            throw new ArcRuntimeException("Error stream writing to file: " + this.file + " (" + this.type + ")", ex);
        }
        finally {
            Streams.close(input);
            Streams.close(output);
        }
    }
    
    public Writer writer(final boolean append) {
        return this.writer(append, "UTF-8");
    }
    
    public Writer writer(final boolean append, final String charset) {
        if (this.type == Files.FileType.classpath) {
            throw new ArcRuntimeException("Cannot write to a classpath file: " + this.file);
        }
        if (this.type == Files.FileType.internal) {
            throw new ArcRuntimeException("Cannot write to an internal file: " + this.file);
        }
        this.parent().mkdirs();
        try {
            final FileOutputStream output = new FileOutputStream(this.file(), append);
            if (charset == null) {
                return new OutputStreamWriter(output);
            }
            return new OutputStreamWriter(output, charset);
        }
        catch (IOException ex) {
            if (this.file().isDirectory()) {
                throw new ArcRuntimeException("Cannot open a stream to a directory: " + this.file + " (" + this.type + ")", ex);
            }
            throw new ArcRuntimeException("Error writing file: " + this.file + " (" + this.type + ")", ex);
        }
    }
    
    public void writePNG(final Pixmap pixmap) {
        PixmapIO.writePNG(this, pixmap);
    }
    
    public void writeString(final String string) {
        this.writeString(string, false);
    }
    
    public void writeString(final String string, final boolean append) {
        this.writeString(string, append, "UTF-8");
    }
    
    public void writeString(final String string, final boolean append, final String charset) {
        Writer writer = null;
        try {
            writer = this.writer(append, charset);
            writer.write(string);
        }
        catch (Exception ex) {
            throw new ArcRuntimeException("Error writing file: " + this.file + " (" + this.type + ")", ex);
        }
        finally {
            Streams.close(writer);
        }
    }
    
    public void writeBytes(final byte[] bytes) {
        this.writeBytes(bytes, false);
    }
    
    public void writeBytes(final byte[] bytes, final boolean append) {
        final OutputStream output = this.write(append);
        try {
            output.write(bytes);
        }
        catch (IOException ex) {
            throw new ArcRuntimeException("Error writing file: " + this.file + " (" + this.type + ")", ex);
        }
        finally {
            Streams.close(output);
        }
    }
    
    public void writeBytes(final byte[] bytes, final int offset, final int length, final boolean append) {
        final OutputStream output = this.write(append);
        try {
            output.write(bytes, offset, length);
        }
        catch (IOException ex) {
            throw new ArcRuntimeException("Error writing file: " + this.file + " (" + this.type + ")", ex);
        }
        finally {
            Streams.close(output);
        }
    }
    
    public void walk(final Cons<Fi> cons) {
        if (this.isDirectory()) {
            for (final Fi file : this.list()) {
                file.walk(cons);
            }
        }
        else {
            cons.get(this);
        }
    }
    
    public Seq<Fi> findAll(final Boolf<Fi> test) {
        final Seq<Fi> out = new Seq<Fi>();
        final Seq<Fi> seq;
        this.walk(f -> {
            if (test.get(f)) {
                seq.add(f);
            }
            return;
        });
        return out;
    }
    
    public Seq<Fi> findAll() {
        final Seq<Fi> out = new Seq<Fi>();
        this.walk(out::add);
        return out;
    }
    
    public Fi[] list() {
        if (this.type == Files.FileType.classpath) {
            throw new ArcRuntimeException("Cannot list a classpath directory: " + this.file);
        }
        final String[] relativePaths = this.file().list();
        if (relativePaths == null) {
            return new Fi[0];
        }
        final Fi[] handles = new Fi[relativePaths.length];
        for (int i = 0, n = relativePaths.length; i < n; ++i) {
            handles[i] = this.child(relativePaths[i]);
        }
        return handles;
    }
    
    public Fi[] list(final FileFilter filter) {
        if (this.type == Files.FileType.classpath) {
            throw new ArcRuntimeException("Cannot list a classpath directory: " + this.file);
        }
        final File file = this.file();
        final String[] relativePaths = file.list();
        if (relativePaths == null) {
            return new Fi[0];
        }
        Fi[] handles = new Fi[relativePaths.length];
        int count = 0;
        for (int i = 0, n = relativePaths.length; i < n; ++i) {
            final String path = relativePaths[i];
            final Fi child = this.child(path);
            if (filter.accept(child.file())) {
                handles[count] = child;
                ++count;
            }
        }
        if (count < relativePaths.length) {
            final Fi[] newHandles = new Fi[count];
            System.arraycopy(handles, 0, newHandles, 0, count);
            handles = newHandles;
        }
        return handles;
    }
    
    public Fi[] list(final FilenameFilter filter) {
        if (this.type == Files.FileType.classpath) {
            throw new ArcRuntimeException("Cannot list a classpath directory: " + this.file);
        }
        final File file = this.file();
        final String[] relativePaths = file.list();
        if (relativePaths == null) {
            return new Fi[0];
        }
        Fi[] handles = new Fi[relativePaths.length];
        int count = 0;
        for (int i = 0, n = relativePaths.length; i < n; ++i) {
            final String path = relativePaths[i];
            if (filter.accept(file, path)) {
                handles[count] = this.child(path);
                ++count;
            }
        }
        if (count < relativePaths.length) {
            final Fi[] newHandles = new Fi[count];
            System.arraycopy(handles, 0, newHandles, 0, count);
            handles = newHandles;
        }
        return handles;
    }
    
    public Fi[] list(final String suffix) {
        if (this.type == Files.FileType.classpath) {
            throw new ArcRuntimeException("Cannot list a classpath directory: " + this.file);
        }
        final String[] relativePaths = this.file().list();
        if (relativePaths == null) {
            return new Fi[0];
        }
        Fi[] handles = new Fi[relativePaths.length];
        int count = 0;
        for (int i = 0, n = relativePaths.length; i < n; ++i) {
            final String path = relativePaths[i];
            if (path.endsWith(suffix)) {
                handles[count] = this.child(path);
                ++count;
            }
        }
        if (count < relativePaths.length) {
            final Fi[] newHandles = new Fi[count];
            System.arraycopy(handles, 0, newHandles, 0, count);
            handles = newHandles;
        }
        return handles;
    }
    
    public boolean isDirectory() {
        return this.type != Files.FileType.classpath && this.file().isDirectory();
    }
    
    public Fi child(final String name) {
        if (this.file.getPath().length() == 0) {
            return new Fi(new File(name), this.type);
        }
        return new Fi(new File(this.file, name), this.type);
    }
    
    public Fi sibling(final String name) {
        if (this.file.getPath().length() == 0) {
            throw new ArcRuntimeException("Cannot get the sibling of the root.");
        }
        return new Fi(new File(this.file.getParent(), name), this.type);
    }
    
    public Fi parent() {
        File parent = this.file.getParentFile();
        if (parent == null) {
            if (OS.isWindows) {
                return new Fi("", this.type) {
                    Fi[] children = Seq.with(File.listRoots()).map(Fi::new).toArray(Fi.class);
                    
                    @Override
                    public Fi parent() {
                        return this;
                    }
                    
                    @Override
                    public boolean isDirectory() {
                        return true;
                    }
                    
                    @Override
                    public boolean exists() {
                        return true;
                    }
                    
                    @Override
                    public Fi child(final String name) {
                        return new Fi(new File(name));
                    }
                    
                    @Override
                    public Fi[] list() {
                        return this.children;
                    }
                    
                    @Override
                    public Fi[] list(final FileFilter filter) {
                        return Seq.select(this.list(), f -> filter.accept(f.file)).toArray(Fi.class);
                    }
                };
            }
            if (this.type == Files.FileType.absolute) {
                parent = new File("/");
            }
            else {
                parent = new File("");
            }
        }
        return new Fi(parent, this.type);
    }
    
    public boolean mkdirs() {
        if (this.type == Files.FileType.classpath) {
            throw new ArcRuntimeException("Cannot mkdirs with a classpath file: " + this.file);
        }
        if (this.type == Files.FileType.internal) {
            throw new ArcRuntimeException("Cannot mkdirs with an internal file: " + this.file);
        }
        return this.file().mkdirs();
    }
    
    public boolean exists() {
        switch (this.type) {
            case internal: {
                if (this.file().exists()) {
                    return true;
                }
                return Fi.class.getResource("/" + this.file.getPath().replace('\\', '/')) != null;
            }
            case classpath: {
                return Fi.class.getResource("/" + this.file.getPath().replace('\\', '/')) != null;
            }
            default: {
                return this.file().exists();
            }
        }
    }
    
    public boolean delete() {
        if (this.type == Files.FileType.classpath) {
            throw new ArcRuntimeException("Cannot delete a classpath file: " + this.file);
        }
        if (this.type == Files.FileType.internal) {
            throw new ArcRuntimeException("Cannot delete an internal file: " + this.file);
        }
        return this.file().delete();
    }
    
    public boolean deleteDirectory() {
        if (this.type == Files.FileType.classpath) {
            throw new ArcRuntimeException("Cannot delete a classpath file: " + this.file);
        }
        if (this.type == Files.FileType.internal) {
            throw new ArcRuntimeException("Cannot delete an internal file: " + this.file);
        }
        return deleteDirectory(this.file());
    }
    
    public void emptyDirectory() {
        this.emptyDirectory(false);
    }
    
    public void emptyDirectory(final boolean preserveTree) {
        if (this.type == Files.FileType.classpath) {
            throw new ArcRuntimeException("Cannot delete a classpath file: " + this.file);
        }
        if (this.type == Files.FileType.internal) {
            throw new ArcRuntimeException("Cannot delete an internal file: " + this.file);
        }
        emptyDirectory(this.file(), preserveTree);
    }
    
    public void copyTo(Fi dest) {
        if (!this.isDirectory()) {
            if (dest.isDirectory()) {
                dest = dest.child(this.name());
            }
            copyFile(this, dest);
            return;
        }
        if (dest.exists()) {
            if (!dest.isDirectory()) {
                throw new ArcRuntimeException("Destination exists but is not a directory: " + dest);
            }
        }
        else {
            dest.mkdirs();
            if (!dest.isDirectory()) {
                throw new ArcRuntimeException("Destination directory cannot be created: " + dest);
            }
        }
        copyDirectory(this, dest.child(this.name()));
    }
    
    public void moveTo(final Fi dest) {
        switch (this.type) {
            case classpath: {
                throw new ArcRuntimeException("Cannot move a classpath file: " + this.file);
            }
            case internal: {
                throw new ArcRuntimeException("Cannot move an internal file: " + this.file);
            }
            case absolute:
            case external: {
                if (this.file().renameTo(dest.file())) {
                    return;
                }
                break;
            }
        }
        this.copyTo(dest);
        this.delete();
        if (this.exists() && this.isDirectory()) {
            this.deleteDirectory();
        }
    }
    
    public long length() {
        if (this.type == Files.FileType.classpath || (this.type == Files.FileType.internal && !this.file.exists())) {
            final InputStream input = this.read();
            try {
                return input.available();
            }
            catch (Exception ex) {}
            finally {
                Streams.close(input);
            }
            return 0L;
        }
        return this.file().length();
    }
    
    public long lastModified() {
        return this.file().lastModified();
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (!(obj instanceof Fi)) {
            return false;
        }
        final Fi other = (Fi)obj;
        return this.type == other.type && this.path().equals(other.path());
    }
    
    @Override
    public int hashCode() {
        int hash = 1;
        hash = hash * 37 + this.type.hashCode();
        hash = hash * 67 + this.path().hashCode();
        return hash;
    }
    
    @Override
    public String toString() {
        return this.file.getPath().replace('\\', '/');
    }
}
