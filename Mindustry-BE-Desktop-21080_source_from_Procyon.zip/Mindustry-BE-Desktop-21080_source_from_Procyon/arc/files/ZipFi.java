// 
// Decompiled by Procyon v0.5.36
// 

package arc.files;

import java.io.InputStream;
import arc.util.Log;
import java.util.Iterator;
import java.io.IOException;
import arc.util.ArcRuntimeException;
import arc.struct.ObjectSet;
import arc.struct.Seq;
import java.util.Collections;
import arc.Files;
import java.io.File;
import java.util.zip.ZipFile;
import arc.util.Nullable;
import java.util.zip.ZipEntry;

public class ZipFi extends Fi
{
    private ZipFi[] children;
    private ZipFi parent;
    private String path;
    @Nullable
    private final ZipEntry entry;
    private final ZipFile zip;
    
    public ZipFi(final Fi zipFileLoc) {
        super(new File(""), Files.FileType.absolute);
        this.children = new ZipFi[0];
        this.entry = null;
        try {
            this.zip = new ZipFile(zipFileLoc.file());
            this.path = "";
            final Seq<String> names = Seq.with(Collections.list(this.zip.entries())).map(z -> z.getName().replace('\\', '/'));
            final ObjectSet<String> paths = new ObjectSet<String>();
            for (String path : names) {
                paths.add(path);
                while (path.contains("/") && !path.equals("/") && path.substring(0, path.length() - 1).contains("/")) {
                    final int index = path.endsWith("/") ? path.substring(0, path.length() - 1).lastIndexOf(47) : path.lastIndexOf(47);
                    path = path.substring(0, index);
                    paths.add(path.endsWith("/") ? path : (path + "/"));
                }
            }
            if (paths.contains("/")) {
                this.file = new File("/");
                paths.remove("/");
            }
            final Object o3;
            final Seq<ZipFi> files = Seq.with(paths).map(s -> {
                if (this.zip.getEntry(s) != null) {
                    // new(arc.files.ZipFi.class)
                    new ZipFi(this.zip.getEntry(s), this.zip);
                }
                else {
                    // new(arc.files.ZipFi.class)
                    new ZipFi(s, this.zip);
                }
                return o3;
            });
            files.add(this);
            files.each(file -> file.parent = files.find(other -> other.isDirectory() && other != file && file.path().startsWith(other.path()) && (!file.path().substring(1 + other.path().length()).contains("/") || (file.path().endsWith("/") && this.countSlahes(file.path().substring(1 + other.path().length())) == 1))));
            files.each(file -> file.children = files.select(f -> f.parent == file).toArray(ZipFi.class));
            this.parent = null;
        }
        catch (IOException e) {
            throw new ArcRuntimeException(e);
        }
    }
    
    private int countSlahes(final String str) {
        int sum = 0;
        for (int i = 0; i < str.length(); ++i) {
            if (str.charAt(i) == '/') {
                ++sum;
            }
        }
        return sum;
    }
    
    private ZipFi(final ZipEntry entry, final ZipFile file) {
        super(new File(entry.getName()), Files.FileType.absolute);
        this.children = new ZipFi[0];
        this.path = entry.getName().replace('\\', '/');
        this.entry = entry;
        this.zip = file;
    }
    
    private ZipFi(final String path, final ZipFile file) {
        super(new File(path), Files.FileType.absolute);
        this.children = new ZipFi[0];
        this.path = path.replace('\\', '/');
        this.entry = null;
        this.zip = file;
    }
    
    @Override
    public boolean delete() {
        try {
            this.zip.close();
            return true;
        }
        catch (IOException e) {
            Log.err(e);
            return false;
        }
    }
    
    @Override
    public boolean exists() {
        return true;
    }
    
    @Override
    public Fi child(final String name) {
        for (final ZipFi child : this.children) {
            if (child.name().equals(name)) {
                return child;
            }
        }
        return new Fi(new File(this.file, name)) {
            @Override
            public boolean exists() {
                return false;
            }
        };
    }
    
    @Override
    public String name() {
        return this.file.getName();
    }
    
    @Override
    public String path() {
        return this.path;
    }
    
    @Override
    public Fi parent() {
        return this.parent;
    }
    
    @Override
    public Fi[] list() {
        return this.children;
    }
    
    @Override
    public boolean isDirectory() {
        return this.entry == null || this.entry.isDirectory();
    }
    
    @Override
    public InputStream read() {
        if (this.entry == null) {
            throw new RuntimeException("Not permitted.");
        }
        try {
            return this.zip.getInputStream(this.entry);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public long length() {
        return this.isDirectory() ? 0L : this.entry.getSize();
    }
    
    @Override
    public String toString() {
        return this.path();
    }
}
