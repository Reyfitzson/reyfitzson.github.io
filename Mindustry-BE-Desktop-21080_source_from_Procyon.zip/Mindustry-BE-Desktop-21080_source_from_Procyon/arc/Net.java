// 
// Decompiled by Procyon v0.5.36
// 

package arc;

import arc.struct.Seq;
import arc.struct.IntMap;
import java.io.InputStream;
import arc.struct.ObjectMap;
import arc.func.Cons;
import arc.util.NetJavaImpl;

public class Net
{
    private NetJavaImpl impl;
    
    public Net() {
        this.impl = new NetJavaImpl();
    }
    
    public void setBlock(final boolean block) {
        this.impl.setBlock(block);
    }
    
    public void http(final HttpRequest httpRequest, final Cons<HttpResponse> success, final Cons<Throwable> failure) {
        this.impl.http(httpRequest, success, failure);
    }
    
    public void httpGet(final String url, final Cons<HttpResponse> success, final Cons<Throwable> failure) {
        this.http(new HttpRequest().method(HttpMethod.GET).url(url), success, failure);
    }
    
    public void httpPost(final String url, final String content, final Cons<HttpResponse> success, final Cons<Throwable> failure) {
        this.http(new HttpRequest().method(HttpMethod.POST).content(content).url(url), success, failure);
    }
    
    public enum HttpMethod
    {
        GET, 
        POST, 
        PUT, 
        DELETE, 
        HEAD, 
        CONNECT, 
        OPTIONS, 
        TRACE;
    }
    
    public static class HttpRequest
    {
        public HttpMethod method;
        public String url;
        public ObjectMap<String, String> headers;
        public int timeout;
        public String content;
        public InputStream contentStream;
        public long contentLength;
        public boolean followRedirects;
        public boolean includeCredentials;
        
        public HttpRequest() {
            this.headers = new ObjectMap<String, String>();
            this.timeout = 2000;
            this.followRedirects = true;
            this.includeCredentials = false;
        }
        
        public HttpRequest(final HttpMethod method) {
            this.headers = new ObjectMap<String, String>();
            this.timeout = 2000;
            this.followRedirects = true;
            this.includeCredentials = false;
            this.method = method;
        }
        
        public HttpRequest method(final HttpMethod method) {
            this.method = method;
            return this;
        }
        
        public HttpRequest url(final String url) {
            this.url = url;
            return this;
        }
        
        public HttpRequest timeout(final int timeout) {
            this.timeout = timeout;
            return this;
        }
        
        public HttpRequest redirects(final boolean followRedirects) {
            this.followRedirects = followRedirects;
            return this;
        }
        
        public HttpRequest credentials(final boolean includeCredentials) {
            this.includeCredentials = includeCredentials;
            return this;
        }
        
        public HttpRequest header(final String name, final String value) {
            this.headers.put(name, value);
            return this;
        }
        
        public HttpRequest content(final String content) {
            this.content = content;
            return this;
        }
        
        public HttpRequest content(final InputStream contentStream, final long contentLength) {
            this.contentStream = contentStream;
            this.contentLength = contentLength;
            return this;
        }
    }
    
    public enum HttpStatus
    {
        UNKNOWN_STATUS(-1), 
        CONTINUE(100), 
        SWITCHING_PROTOCOLS(101), 
        PROCESSING(102), 
        OK(200), 
        CREATED(201), 
        ACCEPTED(202), 
        NON_AUTHORITATIVE_INFORMATION(203), 
        NO_CONTENT(204), 
        RESET_CONTENT(205), 
        PARTIAL_CONTENT(206), 
        MULTI_STATUS(207), 
        MULTIPLE_CHOICES(300), 
        MOVED_PERMANENTLY(301), 
        MOVED_TEMPORARILY(302), 
        SEE_OTHER(303), 
        NOT_MODIFIED(304), 
        USE_PROXY(305), 
        TEMPORARY_REDIRECT(307), 
        BAD_REQUEST(400), 
        UNAUTHORIZED(401), 
        PAYMENT_REQUIRED(402), 
        FORBIDDEN(403), 
        NOT_FOUND(404), 
        METHOD_NOT_ALLOWED(405), 
        NOT_ACCEPTABLE(406), 
        PROXY_AUTHENTICATION_REQUIRED(407), 
        REQUEST_TIMEOUT(408), 
        CONFLICT(409), 
        GONE(410), 
        LENGTH_REQUIRED(411), 
        PRECONDITION_FAILED(412), 
        REQUEST_TOO_LONG(413), 
        REQUEST_URI_TOO_LONG(414), 
        UNSUPPORTED_MEDIA_TYPE(415), 
        REQUESTED_RANGE_NOT_SATISFIABLE(416), 
        EXPECTATION_FAILED(417), 
        INSUFFICIENT_SPACE_ON_RESOURCE(419), 
        METHOD_FAILURE(420), 
        UNPROCESSABLE_ENTITY(422), 
        LOCKED(423), 
        FAILED_DEPENDENCY(424), 
        INTERNAL_SERVER_ERROR(500), 
        NOT_IMPLEMENTED(501), 
        BAD_GATEWAY(502), 
        SERVICE_UNAVAILABLE(503), 
        GATEWAY_TIMEOUT(504), 
        HTTP_VERSION_NOT_SUPPORTED(505), 
        INSUFFICIENT_STORAGE(507);
        
        private static IntMap<HttpStatus> byCode;
        public final int code;
        
        private HttpStatus(final int code) {
            this.code = code;
        }
        
        public static HttpStatus byCode(final int code) {
            if (HttpStatus.byCode == null) {
                HttpStatus.byCode = new IntMap<HttpStatus>();
                for (final HttpStatus status : values()) {
                    HttpStatus.byCode.put(status.code, status);
                }
            }
            return HttpStatus.byCode.get(code, HttpStatus.UNKNOWN_STATUS);
        }
    }
    
    public interface HttpResponse
    {
        byte[] getResult();
        
        String getResultAsString();
        
        InputStream getResultAsStream();
        
        HttpStatus getStatus();
        
        String getHeader(final String p0);
        
        ObjectMap<String, Seq<String>> getHeaders();
    }
}
