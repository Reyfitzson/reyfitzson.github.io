// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.serialization;

import java.io.IOException;
import java.io.Closeable;

public interface BaseJsonWriter extends Closeable
{
    void setOutputType(final JsonWriter.OutputType p0);
    
    void setQuoteLongValues(final boolean p0);
    
    BaseJsonWriter name(final String p0) throws IOException;
    
    BaseJsonWriter object() throws IOException;
    
    BaseJsonWriter array() throws IOException;
    
    BaseJsonWriter value(final Object p0) throws IOException;
    
    BaseJsonWriter object(final String p0) throws IOException;
    
    BaseJsonWriter array(final String p0) throws IOException;
    
    BaseJsonWriter set(final String p0, final Object p1) throws IOException;
    
    BaseJsonWriter pop() throws IOException;
}
