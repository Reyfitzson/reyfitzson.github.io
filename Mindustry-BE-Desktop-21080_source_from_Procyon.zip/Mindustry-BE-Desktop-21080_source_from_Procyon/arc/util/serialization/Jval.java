// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.serialization;

import java.util.Iterator;
import arc.struct.ObjectMap;
import java.util.regex.Pattern;
import java.io.StringReader;
import arc.struct.Seq;
import arc.struct.ArrayMap;
import java.io.StringWriter;
import java.io.Writer;
import arc.util.Structs;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import arc.util.ArcRuntimeException;
import java.io.Reader;
import arc.util.Nullable;

public class Jval
{
    static final String eol;
    public static final Jval TRUE;
    public static final Jval FALSE;
    public static final Jval NULL;
    @Nullable
    private Object value;
    
    Jval(final Object value) {
        this.value = value;
        if (this.getType() == null) {
            throw new IllegalArgumentException("Invalid JSON value: " + value);
        }
    }
    
    public static Jval read(final Reader reader) {
        try {
            return new Hparser(reader).parse();
        }
        catch (IOException e) {
            throw new ArcRuntimeException(e);
        }
    }
    
    public static Jval read(final byte[] bytes) {
        try {
            return new Hparser(new InputStreamReader(new ByteArrayInputStream(bytes))).parse();
        }
        catch (IOException e) {
            throw new ArcRuntimeException(e);
        }
    }
    
    public static Jval read(final String text) {
        try {
            return new Hparser(text).parse();
        }
        catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }
    
    public Jtype getType() {
        return (this.value == null) ? Jtype.nil : ((this.value instanceof Number) ? Jtype.number : ((this.value instanceof String) ? Jtype.string : ((this.value instanceof Boolean) ? Jtype.bool : ((this.value instanceof JsonMap) ? Jtype.object : ((this.value instanceof JsonArray) ? Jtype.array : null)))));
    }
    
    public static Jval valueOf(final int value) {
        return new Jval(value);
    }
    
    public static Jval valueOf(final long value) {
        return new Jval(value);
    }
    
    public static Jval valueOf(final float value) {
        return new Jval(value);
    }
    
    public static Jval valueOf(final double value) {
        return new Jval(value);
    }
    
    public static Jval valueOf(final String string) {
        return (string == null) ? Jval.NULL : new Jval(string);
    }
    
    public static Jval valueOf(final boolean value) {
        return value ? Jval.TRUE : Jval.FALSE;
    }
    
    public boolean isObject() {
        return this.value instanceof JsonMap;
    }
    
    public boolean isArray() {
        return this.value instanceof JsonArray;
    }
    
    public boolean isNumber() {
        return this.value instanceof Number;
    }
    
    public boolean isString() {
        return this.value instanceof Structs;
    }
    
    public boolean isBoolean() {
        return this.value instanceof Boolean;
    }
    
    public boolean isTrue() {
        return this.value == Boolean.TRUE;
    }
    
    public boolean isFalse() {
        return this.value == Boolean.FALSE;
    }
    
    public boolean isNull() {
        return this.value == null;
    }
    
    public JsonMap asObject() {
        if (!(this.value instanceof JsonMap)) {
            throw new UnsupportedOperationException("Not an object: " + this.toString());
        }
        return (JsonMap)this.value;
    }
    
    public JsonArray asArray() {
        if (!(this.value instanceof JsonArray)) {
            throw new UnsupportedOperationException("Not an array: " + this.toString());
        }
        return (JsonArray)this.value;
    }
    
    public int asInt() {
        return this.asNumber().intValue();
    }
    
    public long asLong() {
        return this.asNumber().longValue();
    }
    
    public float asFloat() {
        return this.asNumber().floatValue();
    }
    
    public double asDouble() {
        return this.asNumber().doubleValue();
    }
    
    public String asString() {
        if (!(this.value instanceof String) && !(this.value instanceof Number)) {
            throw new UnsupportedOperationException("Not a string: " + this.toString());
        }
        return String.valueOf(this.value);
    }
    
    public boolean asBool() {
        if (!(this.value instanceof Boolean)) {
            throw new UnsupportedOperationException("Not a bool: " + this.toString());
        }
        return (boolean)this.value;
    }
    
    public Number asNumber() {
        if (!(this.value instanceof Number)) {
            throw new UnsupportedOperationException("Not a number: " + this.toString());
        }
        return (Number)this.value;
    }
    
    public Jval get(final String name) {
        if (name == null) {
            throw new NullPointerException("name is null");
        }
        return this.asObject().get(name);
    }
    
    public void add(final String name, final Jval val) {
        if (name == null) {
            throw new NullPointerException("name is null");
        }
        this.asObject().put(name, val);
    }
    
    public void add(final String name, final String val) {
        this.add(name, valueOf(val));
    }
    
    public Jval remove(final String name) {
        if (name == null) {
            throw new NullPointerException("name is null");
        }
        return this.asObject().removeKey(name);
    }
    
    public boolean has(final String name) {
        if (name == null) {
            throw new NullPointerException("name is null");
        }
        return ((ArrayMap<String, V>)this.asObject()).containsKey(name);
    }
    
    public int getInt(final String name, final int defaultValue) {
        final Jval value = this.get(name);
        return (value != null) ? value.asInt() : defaultValue;
    }
    
    public long getLong(final String name, final long defaultValue) {
        final Jval value = this.get(name);
        return (value != null) ? value.asLong() : defaultValue;
    }
    
    public float getFloat(final String name, final float defaultValue) {
        final Jval value = this.get(name);
        return (value != null) ? value.asFloat() : defaultValue;
    }
    
    public double getDouble(final String name, final double defaultValue) {
        final Jval value = this.get(name);
        return (value != null) ? value.asDouble() : defaultValue;
    }
    
    public boolean getBool(final String name, final boolean defaultValue) {
        final Jval value = this.get(name);
        return (value != null) ? value.asBool() : defaultValue;
    }
    
    @Nullable
    public String getString(final String name) {
        return this.getString(name, "");
    }
    
    public String getString(final String name, final String defaultValue) {
        final Jval value = this.get(name);
        return (value != null && !value.isNull()) ? value.asString() : defaultValue;
    }
    
    public void writeTo(final Writer writer) throws IOException {
        this.writeTo(writer, Jformat.plain);
    }
    
    public void writeTo(final Writer writer, final Jformat format) throws IOException {
        final WritingBuffer buffer = new WritingBuffer(writer, 128);
        switch (format) {
            case plain: {
                new Jwriter(false).save(this, buffer, 0);
                break;
            }
            case formatted: {
                new Jwriter(true).save(this, buffer, 0);
                break;
            }
            case hjson: {
                new Hwriter().save(this, buffer, -1, "", true);
                break;
            }
        }
        buffer.flush();
    }
    
    @Override
    public String toString() {
        final Jtype type = this.getType();
        switch (type) {
            case nil: {
                return "null";
            }
            case number: {
                return (this.value.toString().endsWith(".0") ? this.value.toString().replace(".0", "") : this.value.toString()).replace('E', 'e');
            }
            case string:
            case bool: {
                return this.value.toString();
            }
            default: {
                return this.toString(Jformat.plain);
            }
        }
    }
    
    public String toString(final Jformat format) {
        final StringWriter writer = new StringWriter();
        try {
            this.writeTo(writer, format);
        }
        catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        return writer.toString();
    }
    
    @Override
    public boolean equals(final Object object) {
        return object != null && object.getClass() == this.getClass() && ((this.value == null && ((Jval)object).value == null) || (((Jval)object).value != null && this.value != null && this.value.equals(((Jval)object).value)));
    }
    
    static {
        eol = System.getProperty("line.separator");
        TRUE = new Jval(true);
        FALSE = new Jval(false);
        NULL = new Jval(null);
    }
    
    public static class JsonMap extends ArrayMap<String, Jval>
    {
    }
    
    public static class JsonArray extends Seq<Jval>
    {
    }
    
    static class WritingBuffer extends Writer
    {
        private final Writer writer;
        private final char[] buffer;
        private int fill;
        
        WritingBuffer(final Writer writer, final int bufferSize) {
            this.fill = 0;
            this.writer = writer;
            this.buffer = new char[bufferSize];
        }
        
        @Override
        public void write(final int c) throws IOException {
            if (this.fill > this.buffer.length - 1) {
                this.flush();
            }
            this.buffer[this.fill++] = (char)c;
        }
        
        @Override
        public void write(final char[] cbuf, final int off, final int len) throws IOException {
            if (this.fill > this.buffer.length - len) {
                this.flush();
                if (len > this.buffer.length) {
                    this.writer.write(cbuf, off, len);
                    return;
                }
            }
            System.arraycopy(cbuf, off, this.buffer, this.fill, len);
            this.fill += len;
        }
        
        @Override
        public void write(final String str, final int off, final int len) throws IOException {
            if (this.fill > this.buffer.length - len) {
                this.flush();
                if (len > this.buffer.length) {
                    this.writer.write(str, off, len);
                    return;
                }
            }
            str.getChars(off, off + len, this.buffer, this.fill);
            this.fill += len;
        }
        
        @Override
        public void flush() throws IOException {
            this.writer.write(this.buffer, 0, this.fill);
            this.fill = 0;
        }
        
        @Override
        public void close() {
        }
    }
    
    public enum Jformat
    {
        plain, 
        formatted, 
        hjson;
    }
    
    public enum Jtype
    {
        string, 
        number, 
        object, 
        array, 
        bool, 
        nil;
    }
    
    static class Hparser
    {
        private final String buffer;
        private Reader reader;
        private int index;
        private int line;
        private int lineOffset;
        private int current;
        private StringBuilder captureBuffer;
        private StringBuilder peek;
        private boolean capture;
        private boolean isArray;
        
        Hparser(final String string) {
            this.buffer = string;
            this.reset();
        }
        
        Hparser(final Reader reader) throws IOException {
            this(readToEnd(reader));
        }
        
        static String readToEnd(final Reader reader) throws IOException {
            final char[] part = new char[8192];
            final StringBuilder sb = new StringBuilder();
            int n;
            while ((n = reader.read(part, 0, part.length)) != -1) {
                sb.append(part, 0, n);
            }
            return sb.toString();
        }
        
        static boolean isWhiteSpace(final int ch) {
            return ch == 32 || ch == 9 || ch == 10 || ch == 13;
        }
        
        void reset() {
            final int index = 0;
            this.current = index;
            this.lineOffset = index;
            this.index = index;
            this.line = 1;
            this.peek = new StringBuilder();
            this.reader = new StringReader(this.buffer);
            this.capture = false;
            this.captureBuffer = null;
        }
        
        Jval parse() throws IOException {
            this.read();
            this.skipWhiteSpace();
            switch (this.current) {
                case 91:
                case 123: {
                    return this.checkTrailing(this.readValue());
                }
                default: {
                    try {
                        return this.checkTrailing(this.readObject(true));
                    }
                    catch (Exception exception) {
                        this.reset();
                        this.read();
                        this.skipWhiteSpace();
                        try {
                            return this.checkTrailing(this.readValue());
                        }
                        catch (Exception ex) {
                            throw exception;
                        }
                    }
                    break;
                }
            }
        }
        
        Jval checkTrailing(final Jval v) throws JsonParseException, IOException {
            this.skipWhiteSpace();
            if (!this.isEndOfText()) {
                throw this.error("Extra characters in input: " + this.current);
            }
            return v;
        }
        
        private Jval readValue() throws IOException {
            switch (this.current) {
                case 34:
                case 39: {
                    return this.readString();
                }
                case 91: {
                    return this.readArray();
                }
                case 123: {
                    return this.readObject(false);
                }
                default: {
                    return this.readTfnns();
                }
            }
        }
        
        private Jval readTfnns() throws IOException {
            final StringBuilder value = new StringBuilder();
            final int first = this.current;
            if (Hwriter.isPunctuatorChar(first)) {
                throw this.error("Found a punctuator character '" + (char)first + "' when expecting a quoteless string (check your syntax)");
            }
            value.append((char)this.current);
            while (true) {
                this.read();
                final boolean isEol = this.current < 0 || this.current == 13 || this.current == 10 || (this.current == 44 && this.isArray) || this.current == 93;
                if (isEol || this.current == 44 || this.current == 125 || this.current == 35 || (this.current == 47 && (this.peek() == 47 || this.peek() == 42))) {
                    Label_0392: {
                        switch (first) {
                            case 102:
                            case 110:
                            case 116: {
                                final String trim;
                                final String svalue = trim = value.toString().trim();
                                switch (trim) {
                                    case "false": {
                                        return Jval.FALSE;
                                    }
                                    case "null": {
                                        return Jval.NULL;
                                    }
                                    case "true": {
                                        return Jval.TRUE;
                                    }
                                    default: {
                                        break Label_0392;
                                    }
                                }
                                break;
                            }
                            default: {
                                if (first != 45 && (first < 48 || first > 57)) {
                                    break;
                                }
                                final Jval n = tryParseNumber(value, false);
                                if (n != null) {
                                    return n;
                                }
                                break;
                            }
                        }
                    }
                    if (isEol) {
                        if (value.length() > 0 && value.charAt(value.length() - 1) == ',') {
                            value.setLength(value.length() - 1);
                        }
                        return new Jval(value.toString().trim());
                    }
                }
                value.append((char)this.current);
            }
        }
        
        private Jval readArray() throws IOException {
            this.isArray = true;
            this.read();
            final JsonArray array = new JsonArray();
            this.skipWhiteSpace();
            if (this.readIf(']')) {
                return new Jval(array);
            }
            do {
                this.skipWhiteSpace();
                array.add(this.readValue());
                this.skipWhiteSpace();
                if (this.readIf(',')) {
                    this.skipWhiteSpace();
                }
                if (this.readIf(']')) {
                    this.isArray = false;
                    return new Jval(array);
                }
            } while (!this.isEndOfText());
            throw this.error("End of input while parsing an array (did you forget a closing ']'?)");
        }
        
        private Jval readObject(final boolean objectWithoutBraces) throws IOException {
            if (!objectWithoutBraces) {
                this.read();
            }
            final JsonMap object = new JsonMap();
            this.skipWhiteSpace();
            while (true) {
                if (objectWithoutBraces) {
                    if (this.isEndOfText()) {
                        break;
                    }
                }
                else {
                    if (this.isEndOfText()) {
                        throw this.error("End of input while parsing an object (did you forget a closing '}'?)");
                    }
                    if (this.readIf('}')) {
                        break;
                    }
                }
                final String name = this.readName();
                this.skipWhiteSpace();
                if (!this.readIf(':')) {
                    throw this.expected("':'");
                }
                this.skipWhiteSpace();
                object.put(name, this.readValue());
                this.skipWhiteSpace();
                if (!this.readIf(',')) {
                    continue;
                }
                this.skipWhiteSpace();
            }
            return new Jval(object);
        }
        
        private String readName() throws IOException {
            if (this.current == 34 || this.current == 39) {
                return this.readStringInternal(false);
            }
            final StringBuilder name = new StringBuilder();
            int space = -1;
            final int start = this.index;
            while (this.current != 58) {
                if (isWhiteSpace(this.current)) {
                    if (space < 0) {
                        space = name.length();
                    }
                }
                else {
                    if (this.current < 32) {
                        throw this.error("Name is not closed");
                    }
                    if (Hwriter.isPunctuatorChar(this.current)) {
                        throw this.error("Found '" + (char)this.current + "' where a key name was expected (check your syntax or use quotes if the key name includes {}[],: or whitespace)");
                    }
                    name.append((char)this.current);
                }
                this.read();
            }
            if (name.length() == 0) {
                throw this.error("Found ':' but no key name (for an empty key name use quotes)");
            }
            if (space >= 0 && space != name.length()) {
                this.index = start + space;
                throw this.error("Found whitespace in your key name (use quotes to include)");
            }
            return name.toString();
        }
        
        private String readMlString() throws IOException {
            final StringBuilder sb = new StringBuilder();
            int triple = 0;
            final int indent = this.index - this.lineOffset - 4;
            while (isWhiteSpace(this.current) && this.current != 10) {
                this.read();
            }
            if (this.current == 10) {
                this.read();
                this.skipIndent(indent);
            }
            while (this.current >= 0) {
                if (this.current == 39) {
                    ++triple;
                    this.read();
                    if (triple == 3) {
                        if (sb.charAt(sb.length() - 1) == '\n') {
                            sb.deleteCharAt(sb.length() - 1);
                        }
                        return sb.toString();
                    }
                    continue;
                }
                else {
                    while (triple > 0) {
                        sb.append('\'');
                        --triple;
                    }
                    if (this.current == 10) {
                        sb.append('\n');
                        this.read();
                        this.skipIndent(indent);
                    }
                    else {
                        if (this.current != 13) {
                            sb.append((char)this.current);
                        }
                        this.read();
                    }
                }
            }
            throw this.error("Bad multiline string");
        }
        
        private void skipIndent(int indent) throws IOException {
            while (indent-- > 0 && isWhiteSpace(this.current) && this.current != 10) {
                this.read();
            }
        }
        
        private Jval readString() throws IOException {
            return new Jval(this.readStringInternal(true));
        }
        
        private String readStringInternal(final boolean allowML) throws IOException {
            final int exitCh = this.current;
            this.read();
            this.startCapture();
            while (this.current >= 0 && this.current != exitCh) {
                if (this.current == 92) {
                    this.readEscape();
                }
                else {
                    this.read();
                }
            }
            final String string = this.endCapture();
            this.read();
            if (allowML && exitCh == 39 && this.current == 39 && string.length() == 0) {
                this.read();
                return this.readMlString();
            }
            return string;
        }
        
        private void readEscape() throws IOException {
            this.pauseCapture();
            this.read();
            switch (this.current) {
                case 34:
                case 35:
                case 39:
                case 47:
                case 92: {
                    this.captureBuffer.append((char)this.current);
                    break;
                }
                case 98: {
                    this.captureBuffer.append('\b');
                    break;
                }
                case 102: {
                    this.captureBuffer.append('\f');
                    break;
                }
                case 110: {
                    this.captureBuffer.append('\n');
                    break;
                }
                case 114: {
                    this.captureBuffer.append('\r');
                    break;
                }
                case 116: {
                    this.captureBuffer.append('\t');
                    break;
                }
                case 117: {
                    final char[] hexChars = new char[4];
                    for (int i = 0; i < 4; ++i) {
                        this.read();
                        if (!this.isHexDigit()) {
                            throw this.expected("hexadecimal digit");
                        }
                        hexChars[i] = (char)this.current;
                    }
                    this.captureBuffer.append((char)Integer.parseInt(new String(hexChars), 16));
                    break;
                }
                default: {
                    throw this.expected("valid escape sequence");
                }
            }
            this.capture = true;
            this.read();
        }
        
        private static boolean isDigit(final char ch) {
            return ch >= '0' && ch <= '9';
        }
        
        static Jval tryParseNumber(final StringBuilder value, final boolean stopAtNext) {
            int idx = 0;
            final int len = value.length();
            if (idx < len && value.charAt(idx) == '-') {
                ++idx;
            }
            if (idx >= len) {
                return null;
            }
            final char first = value.charAt(idx++);
            if (!isDigit(first)) {
                return null;
            }
            if (first == '0' && idx < len && isDigit(value.charAt(idx))) {
                return null;
            }
            while (idx < len && isDigit(value.charAt(idx))) {
                ++idx;
            }
            if (idx < len && value.charAt(idx) == '.') {
                if (++idx >= len || !isDigit(value.charAt(idx++))) {
                    return null;
                }
                while (idx < len && isDigit(value.charAt(idx))) {
                    ++idx;
                }
            }
            if (idx < len && Character.toLowerCase(value.charAt(idx)) == 'e') {
                if (++idx < len && (value.charAt(idx) == '+' || value.charAt(idx) == '-')) {
                    ++idx;
                }
                if (idx >= len || !isDigit(value.charAt(idx++))) {
                    return null;
                }
                while (idx < len && isDigit(value.charAt(idx))) {
                    ++idx;
                }
            }
            final int last = idx;
            while (idx < len && isWhiteSpace(value.charAt(idx))) {
                ++idx;
            }
            boolean foundStop = false;
            if (idx < len && stopAtNext) {
                final char ch = value.charAt(idx);
                if (ch == ',' || ch == '}' || ch == ']' || ch == '#' || (ch == '/' && len > idx + 1 && (value.charAt(idx + 1) == '/' || value.charAt(idx + 1) == '*'))) {
                    foundStop = true;
                }
            }
            if (idx < len && !foundStop) {
                return null;
            }
            final String str = value.substring(0, last);
            if (!str.contains(".") && !str.contains(",") && !str.contains("e")) {
                try {
                    return new Jval(Long.parseLong(str));
                }
                catch (NumberFormatException ex) {}
            }
            return new Jval(Double.parseDouble(str));
        }
        
        static Jval tryParseNumber(final String value) throws IOException {
            return tryParseNumber(new StringBuilder(value), true);
        }
        
        private boolean readIf(final char ch) throws IOException {
            if (this.current != ch) {
                return false;
            }
            this.read();
            return true;
        }
        
        private void skipWhiteSpace() throws IOException {
            while (!this.isEndOfText()) {
                while (this.isWhiteSpace()) {
                    this.read();
                }
                if (this.current == 35 || (this.current == 47 && this.peek() == 47)) {
                    do {
                        this.read();
                        if (this.current >= 0) {
                            continue;
                        }
                        break;
                    } while (this.current != 10);
                }
                else {
                    if (this.current != 47 || this.peek() != 42) {
                        break;
                    }
                    this.read();
                    do {
                        this.read();
                    } while (this.current >= 0 && (this.current != 42 || this.peek() != 47));
                    this.read();
                    this.read();
                }
            }
        }
        
        private int peek(final int idx) throws IOException {
            while (idx >= this.peek.length()) {
                final int c = this.reader.read();
                if (c < 0) {
                    return c;
                }
                this.peek.append((char)c);
            }
            return this.peek.charAt(idx);
        }
        
        private int peek() throws IOException {
            return this.peek(0);
        }
        
        private boolean read() throws IOException {
            if (this.current == 10) {
                ++this.line;
                this.lineOffset = this.index;
            }
            if (this.peek.length() > 0) {
                this.current = this.peek.charAt(0);
                this.peek.deleteCharAt(0);
            }
            else {
                this.current = this.reader.read();
            }
            if (this.current < 0) {
                return false;
            }
            ++this.index;
            if (this.capture) {
                this.captureBuffer.append((char)this.current);
            }
            return true;
        }
        
        private void startCapture() {
            if (this.captureBuffer == null) {
                this.captureBuffer = new StringBuilder();
            }
            this.capture = true;
            this.captureBuffer.append((char)this.current);
        }
        
        private void pauseCapture() {
            final int len = this.captureBuffer.length();
            if (len > 0) {
                this.captureBuffer.deleteCharAt(len - 1);
            }
            this.capture = false;
        }
        
        private String endCapture() {
            this.pauseCapture();
            String captured;
            if (this.captureBuffer.length() > 0) {
                captured = this.captureBuffer.toString();
                this.captureBuffer.setLength(0);
            }
            else {
                captured = "";
            }
            this.capture = false;
            return captured;
        }
        
        private JsonParseException expected(final String expected) {
            if (this.isEndOfText()) {
                return this.error("Unexpected end of input");
            }
            return this.error("Expected " + expected);
        }
        
        private JsonParseException error(final String message) {
            final int column = this.index - this.lineOffset;
            final int offset = this.isEndOfText() ? this.index : (this.index - 1);
            return new JsonParseException(message, offset, this.line, column - 1);
        }
        
        private boolean isWhiteSpace() {
            return isWhiteSpace((char)this.current);
        }
        
        private boolean isHexDigit() {
            return (this.current >= 48 && this.current <= 57) || (this.current >= 97 && this.current <= 102) || (this.current >= 65 && this.current <= 70);
        }
        
        private boolean isEndOfText() {
            return this.current == -1;
        }
    }
    
    public static class JsonParseException extends RuntimeException
    {
        public final int offset;
        public final int line;
        public final int column;
        
        JsonParseException(final String message, final int offset, final int line, final int column) {
            super(message + " at " + line + ":" + column);
            this.offset = offset;
            this.line = line;
            this.column = column;
        }
    }
    
    static class Hwriter
    {
        static Pattern needsEscapeName;
        
        void nl(final Writer tw, final int level) throws IOException {
            tw.write(Jval.eol);
            for (int i = 0; i < level; ++i) {
                tw.write("  ");
            }
        }
        
        public void save(final Jval value, final Writer tw, final int level, final String separator, final boolean noIndent) throws IOException {
            if (value == null) {
                tw.write(separator);
                tw.write("null");
                return;
            }
            switch (value.getType()) {
                case object: {
                    final JsonMap obj = value.asObject();
                    if (!noIndent) {
                        tw.write(" ");
                    }
                    if (level >= 0) {
                        tw.write(123);
                    }
                    int index = 0;
                    for (final ObjectMap.Entry<String, Jval> pair : obj) {
                        if (index++ != 0 || level >= 0) {
                            this.nl(tw, level + 1);
                        }
                        tw.write(escapeName(pair.key));
                        tw.write(":");
                        this.save(pair.value, tw, level + 1, " ", false);
                    }
                    if (obj.size > 0) {
                        this.nl(tw, level);
                    }
                    if (level >= 0) {
                        tw.write(125);
                        break;
                    }
                    break;
                }
                case array: {
                    final JsonArray arr = value.asArray();
                    final int n = arr.size;
                    if (!noIndent) {
                        tw.write(" ");
                    }
                    tw.write(91);
                    for (int i = 0; i < n; ++i) {
                        this.nl(tw, level + 1);
                        this.save(arr.get(i), tw, level + 1, "", true);
                    }
                    if (n > 0) {
                        this.nl(tw, level);
                    }
                    tw.write(93);
                    break;
                }
                case bool: {
                    tw.write(separator);
                    tw.write(value.isTrue() ? "true" : "false");
                    break;
                }
                case string: {
                    this.writeString(value.asString(), tw, level, separator);
                    break;
                }
                default: {
                    tw.write(separator);
                    tw.write(value.toString());
                    break;
                }
            }
        }
        
        static String escapeName(final String name) {
            if (name.length() == 0 || Hwriter.needsEscapeName.matcher(name).find()) {
                return "\"" + Jwriter.escapeString(name) + "\"";
            }
            return name;
        }
        
        void writeString(final String value, final Writer tw, final int level, final String separator) throws IOException {
            if (value.length() == 0) {
                tw.write(separator + "\"\"");
                return;
            }
            final char left = value.charAt(0);
            final char right = value.charAt(value.length() - 1);
            final char left2 = (value.length() > 1) ? value.charAt(1) : '\0';
            boolean doEscape = false;
            final char[] charArray;
            final char[] valuec = charArray = value.toCharArray();
            for (final char ch : charArray) {
                if (needsQuotes(ch)) {
                    doEscape = true;
                    break;
                }
            }
            if (doEscape || Hparser.isWhiteSpace(left) || Hparser.isWhiteSpace(right) || left == '\"' || left == '\'' || left == '#' || (left == '/' && (left2 == '*' || left2 == '/')) || isPunctuatorChar(left) || Hparser.tryParseNumber(value) != null || startsWithKeyword(value)) {
                boolean noEscape = true;
                for (final char ch2 : valuec) {
                    if (needsEscape(ch2)) {
                        noEscape = false;
                        break;
                    }
                }
                if (noEscape) {
                    tw.write(separator + "\"" + value + "\"");
                    return;
                }
                boolean noEscapeML = true;
                boolean allWhite = true;
                for (final char ch3 : valuec) {
                    if (needsEscapeML(ch3)) {
                        noEscapeML = false;
                        break;
                    }
                    if (!Hparser.isWhiteSpace(ch3)) {
                        allWhite = false;
                    }
                }
                if (noEscapeML && !allWhite && !value.contains("'''")) {
                    this.writeMLString(value, tw, level, separator);
                }
                else {
                    tw.write(separator + "\"" + Jwriter.escapeString(value) + "\"");
                }
            }
            else {
                tw.write(separator + value);
            }
        }
        
        void writeMLString(final String value, final Writer tw, int level, final String separator) throws IOException {
            final String[] lines = value.replace("\r", "").split("\n", -1);
            if (lines.length == 1) {
                tw.write(separator + "'''");
                tw.write(lines[0]);
                tw.write("'''");
            }
            else {
                ++level;
                this.nl(tw, level);
                tw.write("'''");
                for (final String line : lines) {
                    this.nl(tw, (line.length() > 0) ? level : 0);
                    tw.write(line);
                }
                this.nl(tw, level);
                tw.write("'''");
            }
        }
        
        static boolean startsWithKeyword(final String text) {
            int p;
            if (text.startsWith("true") || text.startsWith("null")) {
                p = 4;
            }
            else {
                if (!text.startsWith("false")) {
                    return false;
                }
                p = 5;
            }
            while (p < text.length() && Hparser.isWhiteSpace(text.charAt(p))) {
                ++p;
            }
            if (p == text.length()) {
                return true;
            }
            final char ch = text.charAt(p);
            return ch == ',' || ch == '}' || ch == ']' || ch == '#' || (ch == '/' && text.length() > p + 1 && (text.charAt(p + 1) == '/' || text.charAt(p + 1) == '*'));
        }
        
        static boolean isPunctuatorChar(final int c) {
            return c == 123 || c == 125 || c == 91 || c == 93 || c == 44 || c == 58;
        }
        
        static boolean needsQuotes(final char c) {
            return c == '\t' || c == '\f' || c == '\b' || c == '\n' || c == '\r';
        }
        
        static boolean needsEscape(final char c) {
            return c == '\"' || c == '\\' || needsQuotes(c);
        }
        
        static boolean needsEscapeML(final char c) {
            switch (c) {
                case '\t':
                case '\n':
                case '\r': {
                    return false;
                }
                default: {
                    return needsQuotes(c);
                }
            }
        }
        
        static {
            Hwriter.needsEscapeName = Pattern.compile("[,\\{\\[\\}\\]\\s:#\"']|//|/\\*");
        }
    }
    
    static class Jwriter
    {
        boolean format;
        
        public Jwriter(final boolean format) {
            this.format = format;
        }
        
        void nl(final Writer tw, final int level) throws IOException {
            if (this.format) {
                tw.write(Jval.eol);
                for (int i = 0; i < level; ++i) {
                    tw.write("  ");
                }
            }
        }
        
        public void save(final Jval value, final Writer tw, final int level) throws IOException {
            boolean following = false;
            switch (value.getType()) {
                case object: {
                    final JsonMap obj = value.asObject();
                    tw.write(123);
                    for (final ObjectMap.Entry<String, Jval> pair : obj) {
                        if (following) {
                            tw.write(",");
                        }
                        this.nl(tw, level + 1);
                        tw.write(34);
                        tw.write(escapeString(pair.key));
                        tw.write("\":");
                        final Jval v = pair.value;
                        final Jtype vType = v.getType();
                        if (this.format && vType != Jtype.array && vType != Jtype.object) {
                            tw.write(" ");
                        }
                        this.save(v, tw, level + 1);
                        following = true;
                    }
                    if (following) {
                        this.nl(tw, level);
                    }
                    tw.write(125);
                    break;
                }
                case array: {
                    final JsonArray arr = value.asArray();
                    final int n = arr.size;
                    if (level != 0) {
                        tw.write(32);
                    }
                    tw.write(91);
                    for (int i = 0; i < n; ++i) {
                        if (following) {
                            tw.write(",");
                        }
                        final Jval v2 = arr.get(i);
                        final Jtype vType2 = v2.getType();
                        if (vType2 != Jtype.array) {
                            this.nl(tw, level + 1);
                        }
                        this.save(v2, tw, level + 1);
                        following = true;
                    }
                    if (following) {
                        this.nl(tw, level);
                    }
                    tw.write(93);
                    break;
                }
                case bool: {
                    tw.write(value.isTrue() ? "true" : "false");
                    break;
                }
                case string: {
                    tw.write(34);
                    tw.write(escapeString(value.asString()));
                    tw.write(34);
                    break;
                }
                default: {
                    tw.write(value.toString());
                    break;
                }
            }
        }
        
        static String escapeString(final String src) {
            if (src == null) {
                return null;
            }
            for (int i = 0; i < src.length(); ++i) {
                if (getEscapedChar(src.charAt(i)) != null) {
                    final StringBuilder sb = new StringBuilder();
                    if (i > 0) {
                        sb.append(src, 0, i);
                    }
                    return doEscapeString(sb, src, i);
                }
            }
            return src;
        }
        
        private static String doEscapeString(final StringBuilder sb, final String src, final int cur) {
            int start = cur;
            for (int i = cur; i < src.length(); ++i) {
                final String escaped = getEscapedChar(src.charAt(i));
                if (escaped != null) {
                    sb.append(src, start, i);
                    sb.append(escaped);
                    start = i + 1;
                }
            }
            sb.append(src, start, src.length());
            return sb.toString();
        }
        
        private static String getEscapedChar(final char c) {
            switch (c) {
                case '\"': {
                    return "\\\"";
                }
                case '\t': {
                    return "\\t";
                }
                case '\n': {
                    return "\\n";
                }
                case '\r': {
                    return "\\r";
                }
                case '\f': {
                    return "\\f";
                }
                case '\b': {
                    return "\\b";
                }
                case '\\': {
                    return "\\\\";
                }
                default: {
                    return null;
                }
            }
        }
    }
}
