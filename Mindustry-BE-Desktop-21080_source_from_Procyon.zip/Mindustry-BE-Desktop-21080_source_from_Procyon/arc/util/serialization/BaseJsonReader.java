// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.serialization;

import arc.files.Fi;
import java.io.InputStream;

public interface BaseJsonReader
{
    JsonValue parse(final InputStream p0);
    
    default JsonValue parse(final Fi file) {
        return this.parse(file.read());
    }
}
