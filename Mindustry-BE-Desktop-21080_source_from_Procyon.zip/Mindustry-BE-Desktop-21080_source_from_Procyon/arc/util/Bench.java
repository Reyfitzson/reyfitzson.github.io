// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.struct.ObjectMap;

public class Bench
{
    private static long totalStart;
    private static String lastName;
    private static ObjectMap<String, Long> times;
    private static long last;
    
    public static void begin(final String name) {
        if (Bench.lastName != null) {
            endi();
        }
        else {
            Bench.totalStart = Time.millis();
        }
        Bench.last = Time.millis();
        Bench.lastName = name;
    }
    
    public static void end() {
        endi();
        final long total = Time.timeSinceMillis(Bench.totalStart);
        Bench.times.each((name, time) -> Log.info("[PERF] @: @ms (@%)", name, time, (int)(time / (float)total * 100.0f)));
        Log.info("[PERF] TOTAL: @ms", total);
    }
    
    private static void endi() {
        Bench.times.put(Bench.lastName, Time.timeSinceMillis(Bench.last));
        Bench.lastName = null;
    }
    
    static {
        Bench.times = new ObjectMap<String, Long>();
    }
}
