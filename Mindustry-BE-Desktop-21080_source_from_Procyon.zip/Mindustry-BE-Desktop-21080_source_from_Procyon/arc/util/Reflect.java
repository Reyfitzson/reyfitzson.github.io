// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import arc.func.Prov;

public class Reflect
{
    public static boolean isWrapper(final Class<?> type) {
        return type == Byte.class || type == Short.class || type == Integer.class || type == Long.class || type == Character.class || type == Boolean.class || type == Float.class || type == Double.class;
    }
    
    public static <T> Prov<T> cons(final Class<T> type) {
        try {
            final Constructor<T> c = type.getDeclaredConstructor((Class<?>[])new Class[0]);
            c.setAccessible(true);
            final Constructor<Object> constructor;
            return (Prov<T>)(() -> {
                try {
                    return constructor.newInstance(new Object[0]);
                }
                catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
        }
        catch (Exception e2) {
            throw new RuntimeException(e2);
        }
    }
    
    public static <T> T get(final Field field) {
        return get(null, field);
    }
    
    public static <T> T get(final Object object, final Field field) {
        try {
            return (T)field.get(object);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public static <T> T get(final Class<?> type, final Object object, final String name) {
        try {
            final Field field = type.getDeclaredField(name);
            field.setAccessible(true);
            return (T)field.get(object);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public static <T> T get(final Object object, final String name) {
        return get(object.getClass(), object, name);
    }
    
    public static <T> T get(final Class<?> type, final String name) {
        return get(type, null, name);
    }
    
    public static void set(final Class<?> type, final Object object, final String name, final Object value) {
        try {
            final Field field = type.getDeclaredField(name);
            field.setAccessible(true);
            field.set(object, value);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public static void set(final Object object, final String name, final Object value) {
        set(object.getClass(), object, name, value);
    }
    
    public static void set(final Class<?> type, final String name, final Object value) {
        set(type, null, name, value);
    }
    
    public static <T> T make(final String type) {
        try {
            final Class<T> c = (Class<T>)Class.forName(type);
            return c.getDeclaredConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
