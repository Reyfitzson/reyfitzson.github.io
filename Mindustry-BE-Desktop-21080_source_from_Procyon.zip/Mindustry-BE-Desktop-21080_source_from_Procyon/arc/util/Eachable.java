// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.func.Cons;

public interface Eachable<T>
{
    void each(final Cons<? super T> p0);
}
