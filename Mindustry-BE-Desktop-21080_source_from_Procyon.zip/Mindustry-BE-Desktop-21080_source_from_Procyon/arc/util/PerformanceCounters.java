// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.struct.Seq;

public class PerformanceCounters
{
    private static final float nano2seconds = 1.0E-9f;
    public final Seq<PerformanceCounter> counters;
    private long lastTick;
    
    public PerformanceCounters() {
        this.counters = new Seq<PerformanceCounter>();
        this.lastTick = 0L;
    }
    
    public PerformanceCounter add(final String name, final int windowSize) {
        final PerformanceCounter result = new PerformanceCounter(name, windowSize);
        this.counters.add(result);
        return result;
    }
    
    public PerformanceCounter add(final String name) {
        final PerformanceCounter result = new PerformanceCounter(name);
        this.counters.add(result);
        return result;
    }
    
    public void tick() {
        final long t = Time.nanos();
        if (this.lastTick > 0L) {
            this.tick((t - this.lastTick) * 1.0E-9f);
        }
        this.lastTick = t;
    }
    
    public void tick(final float deltaTime) {
        for (int i = 0; i < this.counters.size; ++i) {
            this.counters.get(i).tick(deltaTime);
        }
    }
    
    @Override
    public String toString() {
        this.counters.sort((a, b) -> -Float.compare(a.load.value, b.load.value));
        final StringBuilder sb = new StringBuilder();
        sb.setLength(0);
        for (int i = 0; i < this.counters.size; ++i) {
            this.counters.get(i).toString(sb);
            if (i != this.counters.size - 1) {
                sb.append("\n");
            }
        }
        return sb.toString();
    }
}
