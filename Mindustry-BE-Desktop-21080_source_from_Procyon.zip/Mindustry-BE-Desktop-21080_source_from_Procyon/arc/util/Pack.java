// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

public class Pack
{
    public static int u(final byte b) {
        return b & 0xFF;
    }
    
    public static int u(final short b) {
        return b & 0xFFFF;
    }
    
    public static long u(final int b) {
        return (long)b & 0xFFFFFFFFL;
    }
    
    public static byte byteValue(final boolean b) {
        return (byte)(b ? 1 : 0);
    }
    
    public static int shortInt(final short left, final short right) {
        return left << 16 | (right & 0xFFFF);
    }
    
    public static long longInt(final int x, final int y) {
        return (long)x << 32 | ((long)y & 0xFFFFFFFFL);
    }
    
    public static byte byteByte(final byte left, final byte right) {
        return (byte)(left << 4 | right);
    }
    
    public static byte leftByte(final byte value) {
        return (byte)(value >> 4 & 0xF);
    }
    
    public static byte rightByte(final byte value) {
        return (byte)(value & 0xF);
    }
    
    public static short leftShort(final int field) {
        return (short)(field >>> 16);
    }
    
    public static short rightShort(final int field) {
        return (short)(field & 0xFFFF);
    }
    
    public static int leftInt(final long field) {
        return (int)(field >> 32);
    }
    
    public static int rightInt(final long field) {
        return (int)field;
    }
    
    public static byte leftByte(final short field) {
        return (byte)(field >> 8);
    }
    
    public static byte rightByte(final short field) {
        return (byte)field;
    }
    
    public static short shortByte(final byte left, final byte right) {
        return (short)(left << 8 | (right & 0xFF));
    }
    
    public static byte[] bytes(final int i, final byte[] result) {
        result[0] = (byte)(i >> 24);
        result[1] = (byte)(i >> 16);
        result[2] = (byte)(i >> 8);
        result[3] = (byte)i;
        return result;
    }
    
    public static short[] shorts(final long i, final short[] resultShort) {
        resultShort[0] = (short)(i >> 48);
        resultShort[1] = (short)(i >> 32);
        resultShort[2] = (short)(i >> 16);
        resultShort[3] = (short)i;
        return resultShort;
    }
    
    public static long longShorts(final short[] s) {
        return (long)(0xFFFF & s[0]) << 48 | (long)(0xFFFF & s[1]) << 32 | (long)(0xFFFF & s[2]) << 16 | (long)(0xFFFF & s[3]);
    }
    
    public static int intBytes(final byte b1, final byte b2, final byte b3, final byte b4) {
        return (0xFF & b1) << 24 | (0xFF & b2) << 16 | (0xFF & b3) << 8 | (0xFF & b4);
    }
    
    public static int intBytes(final byte[] array) {
        return (0xFF & array[0]) << 24 | (0xFF & array[1]) << 16 | (0xFF & array[2]) << 8 | (0xFF & array[3]);
    }
}
