// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import java.util.Iterator;
import arc.struct.Seq;

public class TaskQueue
{
    private final Seq<Runnable> runnables;
    private final Seq<Runnable> executedRunnables;
    
    public TaskQueue() {
        this.runnables = new Seq<Runnable>();
        this.executedRunnables = new Seq<Runnable>();
    }
    
    public void run() {
        synchronized (this.runnables) {
            this.executedRunnables.clear();
            this.executedRunnables.addAll(this.runnables);
            this.runnables.clear();
        }
        for (final Runnable runnable : this.executedRunnables) {
            runnable.run();
        }
    }
    
    public int size() {
        return this.runnables.size;
    }
    
    public void clear() {
        synchronized (this.runnables) {
            this.runnables.clear();
        }
    }
    
    public void post(final Runnable runnable) {
        synchronized (this.runnables) {
            this.runnables.add(runnable);
        }
    }
}
