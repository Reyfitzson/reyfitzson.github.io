// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.noise;

import java.util.Random;

public final class Noise
{
    private static int seed;
    private static final int P = 8;
    private static final int B = 256;
    private static final int M = 255;
    private static final int NP = 8;
    private static final int N = 256;
    private static int[] p;
    private static double[][] g2;
    private static double[] g1;
    private static double[][] points;
    
    private static double lerp(final double t, final double a, final double b) {
        return a + t * (b - a);
    }
    
    private static double s_curve(final double t) {
        return t * t * (3.0 - t - t);
    }
    
    public static double rawNoise(final double x) {
        final double t = x + 256.0;
        final int bx0 = (int)t & 0xFF;
        final int bx2 = bx0 + 1 & 0xFF;
        final double rx0 = t - (int)t;
        final double rx2 = rx0 - 1.0;
        final double sx = s_curve(rx0);
        final double u = rx0 * Noise.g1[Noise.p[bx0]];
        final double v = rx2 * Noise.g1[Noise.p[bx2]];
        return lerp(sx, u, v);
    }
    
    public static double snoise(final float x, final float y, final float scale, final float mag, final float exp) {
        return Math.pow(rawNoise(x / scale, y / scale) * mag, exp);
    }
    
    public static float snoise(final float x, final float y, final float scale, final float mag) {
        return (float)(rawNoise(x / scale, y / scale) * mag);
    }
    
    public static float snoise3(final float x, final float y, final float z, final float scale, final float mag) {
        return (float)(rawNoise(x / scale, y / scale, z / scale) * mag);
    }
    
    public static float nnoise(final float x, final float y, final float scale, final float mag) {
        return (float)((snoise(x, y, scale, mag) + mag) / 2.0);
    }
    
    public static float noise(final float x, final float y, final float scale, final float mag) {
        return (float)(snoise(x, y, scale, mag) / 2.0);
    }
    
    public static float noise(final float x, final float y, final float scale, final float mag, final float xp) {
        return (float)(snoise(x, y, scale, mag, xp) / 2.0);
    }
    
    public static float fnoise(final float x, final float y, final float scale, final float mag) {
        return (float)(rawNoise(x / scale, y / scale) * mag);
    }
    
    public static double rawNoise(final double x, final double y) {
        double t = x + 256.0;
        final int bx0 = (int)t & 0xFF;
        final int bx2 = bx0 + 1 & 0xFF;
        final double rx0 = t - (int)t;
        final double rx2 = rx0 - 1.0;
        t = y + 256.0;
        final int by0 = (int)t & 0xFF;
        final int by2 = by0 + 1 & 0xFF;
        final double ry0 = t - (int)t;
        final double ry2 = ry0 - 1.0;
        final int i = Noise.p[bx0];
        final int j = Noise.p[bx2];
        final int b00 = Noise.p[i + by0];
        final int b2 = Noise.p[j + by0];
        final int b3 = Noise.p[i + by2];
        final int b4 = Noise.p[j + by2];
        final double sx = s_curve(rx0);
        final double sy = s_curve(ry0);
        double[] q = Noise.g2[b00];
        double u = rx0 * q[0] + ry0 * q[1];
        q = Noise.g2[b2];
        double v = rx2 * q[0] + ry0 * q[1];
        final double a = lerp(sx, u, v);
        q = Noise.g2[b3];
        u = rx0 * q[0] + ry2 * q[1];
        q = Noise.g2[b4];
        v = rx2 * q[0] + ry2 * q[1];
        final double b5 = lerp(sx, u, v);
        return lerp(sy, a, b5);
    }
    
    static double rawNoise(final double x, final double y, final double z) {
        int bx = (int)(Math.floor(x) % 256.0);
        if (bx < 0) {
            bx += 256;
        }
        final double rx0 = x - Math.floor(x);
        final double rx2 = rx0 - 1.0;
        int by = (int)(Math.floor(y) % 256.0);
        if (by < 0) {
            by += 256;
        }
        final double ry0 = y - Math.floor(y);
        final double ry2 = ry0 - 1.0;
        int bz = (int)(Math.floor(z) % 256.0);
        if (bz < 0) {
            bz += 256;
        }
        double rz = z - Math.floor(z);
        final int b0 = Noise.p[bx];
        ++bx;
        final int b2 = Noise.p[bx];
        final int b3 = Noise.p[b0 + by];
        final int b4 = Noise.p[b2 + by];
        ++by;
        final int b5 = Noise.p[b0 + by];
        final int b6 = Noise.p[b2 + by];
        final double sx = s_curve(rx0);
        final double sy = s_curve(ry0);
        final double sz = s_curve(rz);
        double[] q = G(b3 + bz);
        double u = rx0 * q[0] + ry0 * q[1] + rz * q[2];
        q = G(b4 + bz);
        double v = rx2 * q[0] + ry0 * q[1] + rz * q[2];
        double a = lerp(sx, u, v);
        q = G(b5 + bz);
        u = rx0 * q[0] + ry2 * q[1] + rz * q[2];
        q = G(b6 + bz);
        v = rx2 * q[0] + ry2 * q[1] + rz * q[2];
        double b7 = lerp(sx, u, v);
        final double c = lerp(sy, a, b7);
        ++bz;
        --rz;
        q = G(b3 + bz);
        u = rx0 * q[0] + ry0 * q[1] + rz * q[2];
        q = G(b4 + bz);
        v = rx2 * q[0] + ry0 * q[1] + rz * q[2];
        a = lerp(sx, u, v);
        q = G(b5 + bz);
        u = rx0 * q[0] + ry2 * q[1] + rz * q[2];
        q = G(b6 + bz);
        v = rx2 * q[0] + ry2 * q[1] + rz * q[2];
        b7 = lerp(sx, u, v);
        final double d = lerp(sy, a, b7);
        return lerp(sz, c, d);
    }
    
    private static double[] G(final int i) {
        return Noise.points[i % 32];
    }
    
    public static void setSeed(final int s) {
        Noise.seed = s;
        init();
    }
    
    private static void init() {
        final Random r = new Random(Noise.seed);
        int i;
        for (i = 0; i < 256; ++i) {
            Noise.p[i] = i;
            Noise.g1[i] = 2.0 * r.nextDouble() - 1.0;
            double u;
            double v;
            do {
                u = 2.0 * r.nextDouble() - 1.0;
                v = 2.0 * r.nextDouble() - 1.0;
            } while (u * u + v * v > 1.0 || Math.abs(u) > 2.5 * Math.abs(v) || Math.abs(v) > 2.5 * Math.abs(u) || Math.abs(Math.abs(u) - Math.abs(v)) < 0.4);
            Noise.g2[i][0] = u;
            Noise.g2[i][1] = v;
            normalize2(Noise.g2[i]);
            double w;
            double Hi;
            double Lo;
            double U;
            double V;
            double W;
            do {
                u = 2.0 * r.nextDouble() - 1.0;
                v = 2.0 * r.nextDouble() - 1.0;
                w = 2.0 * r.nextDouble() - 1.0;
                U = Math.abs(u);
                V = Math.abs(v);
                W = Math.abs(w);
                Lo = Math.min(U, Math.min(V, W));
                Hi = Math.max(U, Math.max(V, W));
            } while (u * u + v * v + w * w > 1.0 || Hi > 4.0 * Lo || Math.min(Math.abs(U - V), Math.min(Math.abs(U - W), Math.abs(V - W))) < 0.2);
        }
        while (--i > 0) {
            final int k = Noise.p[i];
            final int j = (int)(r.nextLong() & 0xFFL);
            Noise.p[i] = Noise.p[j];
            Noise.p[j] = k;
        }
        for (i = 0; i < 258; ++i) {
            Noise.p[256 + i] = Noise.p[i];
            Noise.g1[256 + i] = Noise.g1[i];
            for (int j = 0; j < 2; ++j) {
                Noise.g2[256 + i][j] = Noise.g2[i][j];
            }
        }
        final double[] array = Noise.points[3];
        final int n2 = 0;
        final double[] array2 = Noise.points[3];
        final int n3 = 1;
        final double[] array3 = Noise.points[3];
        final int n4 = 2;
        final double sqrt = Math.sqrt(0.3333333333333333);
        array3[n4] = sqrt;
        array[n2] = (array2[n3] = sqrt);
        final double r2 = Math.sqrt(0.5);
        final double s = Math.sqrt(2.0 + r2 + r2);
        for (i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                Noise.points[i][j] = ((i == j) ? (1.0 + r2 + r2) : r2) / s;
            }
        }
        for (i = 0; i <= 1; ++i) {
            for (int j = 0; j <= 1; ++j) {
                for (int k = 0; k <= 1; ++k) {
                    final int n = i + j * 2 + k * 4;
                    if (n > 0) {
                        for (int m = 0; m < 4; ++m) {
                            Noise.points[4 * n + m][0] = ((i == 0) ? 1 : -1) * Noise.points[m][0];
                            Noise.points[4 * n + m][1] = ((j == 0) ? 1 : -1) * Noise.points[m][1];
                            Noise.points[4 * n + m][2] = ((k == 0) ? 1 : -1) * Noise.points[m][2];
                        }
                    }
                }
            }
        }
    }
    
    private static void normalize2(final double[] v) {
        final double s = Math.sqrt(v[0] * v[0] + v[1] * v[1]);
        v[0] /= s;
        v[1] /= s;
    }
    
    static {
        Noise.seed = 100;
        Noise.p = new int[514];
        Noise.g2 = new double[514][2];
        Noise.g1 = new double[514];
        Noise.points = new double[32][3];
        init();
    }
}
