// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.noise;

import java.util.Random;

public class RidgedPerlin
{
    static final int X_NOISE_GEN = 1619;
    static final int Y_NOISE_GEN = 31337;
    static final int Z_NOISE_GEN = 6971;
    static final int SEED_NOISE_GEN = 1013;
    static final int SHIFT_NOISE_GEN = 8;
    float lacunarity;
    double[] spectralWeights;
    private int octaves;
    private int seed;
    
    public RidgedPerlin() {
        this(new Random().nextInt());
    }
    
    public RidgedPerlin(final int seed) {
        this(seed, 1);
    }
    
    public RidgedPerlin(final int seed, final int octaves) {
        this.lacunarity = 2.0f;
        this.spectralWeights = new double[20];
        this.octaves = octaves;
        this.seed = seed;
        final double h = 1.0;
        double frequency = 1.0;
        for (int i = 0; i < this.spectralWeights.length; ++i) {
            this.spectralWeights[i] = Math.pow(frequency, -h);
            frequency *= this.lacunarity;
        }
    }
    
    public static double MakeInt32Range(final double n) {
        if (n >= 1.073741824E9) {
            return 2.0 * (n % 1.073741824E9) - 1.073741824E9;
        }
        if (n <= -1.073741824E9) {
            return 2.0 * (n % 1.073741824E9) + 1.073741824E9;
        }
        return n;
    }
    
    public static double GradientCoherentNoise3D(final double x, final double y, final double z, final int seed) {
        final int quality = 2;
        final int x2 = (x > 0.0) ? ((int)x) : ((int)x - 1);
        final int x3 = x2 + 1;
        final int y2 = (y > 0.0) ? ((int)y) : ((int)y - 1);
        final int y3 = y2 + 1;
        final int z2 = (z > 0.0) ? ((int)z) : ((int)z - 1);
        final int z3 = z2 + 1;
        double xs = 0.0;
        double ys = 0.0;
        double zs = 0.0;
        switch (quality) {
            case 0: {
                xs = x - x2;
                ys = y - y2;
                zs = z - z2;
                break;
            }
            case 1: {
                xs = SCurve3(x - x2);
                ys = SCurve3(y - y2);
                zs = SCurve3(z - z2);
                break;
            }
            case 2: {
                xs = SCurve5(x - x2);
                ys = SCurve5(y - y2);
                zs = SCurve5(z - z2);
                break;
            }
        }
        double n0 = GradientNoise3D(x, y, z, x2, y2, z2, seed);
        double n2 = GradientNoise3D(x, y, z, x3, y2, z2, seed);
        double ix0 = linearInterp(n0, n2, xs);
        n0 = GradientNoise3D(x, y, z, x2, y3, z2, seed);
        n2 = GradientNoise3D(x, y, z, x3, y3, z2, seed);
        double ix2 = linearInterp(n0, n2, xs);
        final double iy0 = linearInterp(ix0, ix2, ys);
        n0 = GradientNoise3D(x, y, z, x2, y2, z3, seed);
        n2 = GradientNoise3D(x, y, z, x3, y2, z3, seed);
        ix0 = linearInterp(n0, n2, xs);
        n0 = GradientNoise3D(x, y, z, x2, y3, z3, seed);
        n2 = GradientNoise3D(x, y, z, x3, y3, z3, seed);
        ix2 = linearInterp(n0, n2, xs);
        final double iy2 = linearInterp(ix0, ix2, ys);
        return linearInterp(iy0, iy2, zs);
    }
    
    public static double GradientNoise3D(final double fx, final double fy, final double fz, final int ix, final int iy, final int iz, final int seed) {
        int vectorIndex = 1619 * ix + 31337 * iy + 6971 * iz + 1013 * seed;
        vectorIndex ^= vectorIndex >> 8;
        vectorIndex &= 0xFF;
        final double xvGradient = VectorTable.getRandomVectors(vectorIndex, 0);
        final double yvGradient = VectorTable.getRandomVectors(vectorIndex, 1);
        final double zvGradient = VectorTable.getRandomVectors(vectorIndex, 2);
        final double xvPoint = fx - ix;
        final double yvPoint = fy - iy;
        final double zvPoint = fz - iz;
        return (xvGradient * xvPoint + yvGradient * yvPoint + zvGradient * zvPoint) * 2.12;
    }
    
    public static double cubicInterp(final double n0, final double n1, final double n2, final double n3, final double a) {
        final double p = n3 - n2 - (n0 - n1);
        final double q = n0 - n1 - p;
        final double r = n2 - n0;
        return p * a * a * a + q * a * a + r * a + n1;
    }
    
    public static double linearInterp(final double n0, final double n1, final double a) {
        return (1.0 - a) * n0 + a * n1;
    }
    
    public static double SCurve3(final double a) {
        return a * a * (3.0 - 2.0 * a);
    }
    
    static double SCurve5(final double a) {
        final double a2 = a * a * a;
        final double a3 = a2 * a;
        final double a4 = a3 * a;
        return 6.0 * a4 - 15.0 * a3 + 10.0 * a2;
    }
    
    public void setSeed(final int seed) {
        this.seed = seed;
    }
    
    public float getValue(final double x, final double y, final float frequency) {
        return this.getValue(x, y, 0.0, frequency);
    }
    
    public float getValue(final double x, final double y, final double z, final float frequency) {
        double x2 = x;
        double y2 = y;
        double z2 = z;
        x2 *= frequency;
        y2 *= frequency;
        z2 *= frequency;
        double value = 0.0;
        double weight = 1.0;
        final double offset = 1.0;
        final double gain = 2.0;
        for (int curOctave = 0; curOctave < this.octaves; ++curOctave) {
            final double nx = MakeInt32Range(x2);
            final double ny = MakeInt32Range(y2);
            final double nz = MakeInt32Range(z2);
            final int seed = this.seed + curOctave & Integer.MAX_VALUE;
            double signal = GradientCoherentNoise3D(nx, ny, nz, seed);
            signal = Math.abs(signal);
            signal = offset - signal;
            signal *= signal;
            signal *= weight;
            weight = signal * gain;
            if (weight > 1.0) {
                weight = 1.0;
            }
            if (weight < 0.0) {
                weight = 0.0;
            }
            value += signal * this.spectralWeights[curOctave];
            x2 *= this.lacunarity;
            y2 *= this.lacunarity;
            z2 *= this.lacunarity;
        }
        return (float)(value * 1.25 - 1.0);
    }
}
