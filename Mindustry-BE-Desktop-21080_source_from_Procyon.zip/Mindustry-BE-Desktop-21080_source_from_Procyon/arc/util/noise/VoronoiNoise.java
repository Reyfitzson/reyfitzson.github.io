// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.noise;

import java.util.Random;
import arc.math.Rand;

public class VoronoiNoise
{
    private static final double SQRT_2 = 1.4142135623730951;
    private static final double SQRT_3 = 1.7320508075688772;
    private boolean useDistance;
    private long seed;
    private boolean useManhattan;
    private Rand rnd;
    
    public VoronoiNoise(final long seed, final boolean useManhattan) {
        this.useDistance = false;
        this.rnd = new Rand();
        this.seed = seed;
        this.useManhattan = useManhattan;
    }
    
    public static double valueNoise2D(final int x, final int z, final long seed) {
        long n = 1619 * x + 6971 * z + 1013L * seed & 0x7FFFFFFFL;
        n ^= n >> 13;
        return 1.0 - (n * (n * n * 60493L + 19990303L) + 1376312589L & 0x7FFFFFFFL) / 1.073741824E9;
    }
    
    public static double valueNoise3D(final int x, final int y, final int z, final long seed) {
        long n = 1619 * x + 31337 * y + 6971 * z + 1013L * seed & 0x7FFFFFFFL;
        n ^= n >> 13;
        return 1.0 - (n * (n * n * 60493L + 19990303L) + 1376312589L & 0x7FFFFFFFL) / 1.073741824E9;
    }
    
    private double getDistance(final double xDist, final double zDist) {
        return this.useManhattan ? (xDist + zDist) : (Math.sqrt(xDist * xDist + zDist * zDist) / 1.4142135623730951);
    }
    
    private double getDistance(final double xDist, final double yDist, final double zDist) {
        return this.useManhattan ? (xDist + yDist + zDist) : (Math.sqrt(xDist * xDist + yDist * yDist + zDist * zDist) / 1.7320508075688772);
    }
    
    public boolean isUseDistance() {
        return this.useDistance;
    }
    
    public void setUseDistance(final boolean useDistance) {
        this.useDistance = useDistance;
    }
    
    public long getSeed() {
        return this.seed;
    }
    
    public void setSeed(final long seed) {
        this.seed = seed;
    }
    
    public double noise(double x, double z, final double frequency) {
        x *= frequency;
        z *= frequency;
        this.rnd.setSeed(this.seed);
        final long result = this.rnd.nextLong();
        final int xInt = (x > 0.0) ? ((int)x) : ((int)x - 1);
        final int zInt = (z > 0.0) ? ((int)z) : ((int)z - 1);
        double minDist = 3.2E7;
        double xCandidate = 0.0;
        double zCandidate = 0.0;
        for (int zCur = zInt - 2; zCur <= zInt + 2; ++zCur) {
            for (int xCur = xInt - 2; xCur <= xInt + 2; ++xCur) {
                final double xPos = xCur + valueNoise2D(xCur, zCur, this.seed);
                final double zPos = zCur + valueNoise2D(xCur, zCur, result);
                final double xDist = xPos - x;
                final double zDist = zPos - z;
                final double dist = xDist * xDist + zDist * zDist;
                if (dist < minDist) {
                    minDist = dist;
                    xCandidate = xPos;
                    zCandidate = zPos;
                }
            }
        }
        if (this.useDistance) {
            final double xDist2 = xCandidate - x;
            final double zDist2 = zCandidate - z;
            return this.getDistance(xDist2, zDist2);
        }
        return valueNoise2D((int)Math.floor(xCandidate), (int)Math.floor(zCandidate), this.seed);
    }
    
    public double noise(double x, double y, double z, final double frequency) {
        x *= frequency;
        y *= frequency;
        z *= frequency;
        final int xInt = (x > 0.0) ? ((int)x) : ((int)x - 1);
        final int yInt = (y > 0.0) ? ((int)y) : ((int)y - 1);
        final int zInt = (z > 0.0) ? ((int)z) : ((int)z - 1);
        double minDist = 3.2E7;
        double xCandidate = 0.0;
        double yCandidate = 0.0;
        double zCandidate = 0.0;
        final Random rand = new Random(this.seed);
        for (int zCur = zInt - 2; zCur <= zInt + 2; ++zCur) {
            for (int yCur = yInt - 2; yCur <= yInt + 2; ++yCur) {
                for (int xCur = xInt - 2; xCur <= xInt + 2; ++xCur) {
                    final double xPos = xCur + valueNoise3D(xCur, yCur, zCur, this.seed);
                    final double yPos = yCur + valueNoise3D(xCur, yCur, zCur, rand.nextLong());
                    final double zPos = zCur + valueNoise3D(xCur, yCur, zCur, rand.nextLong());
                    final double xDist = xPos - x;
                    final double yDist = yPos - y;
                    final double zDist = zPos - z;
                    final double dist = xDist * xDist + yDist * yDist + zDist * zDist;
                    if (dist < minDist) {
                        minDist = dist;
                        xCandidate = xPos;
                        yCandidate = yPos;
                        zCandidate = zPos;
                    }
                }
            }
        }
        if (this.useDistance) {
            final double xDist2 = xCandidate - x;
            final double yDist2 = yCandidate - y;
            final double zDist2 = zCandidate - z;
            return this.getDistance(xDist2, yDist2, zDist2);
        }
        return valueNoise3D((int)Math.floor(xCandidate), (int)Math.floor(yCandidate), (int)Math.floor(zCandidate), this.seed);
    }
}
