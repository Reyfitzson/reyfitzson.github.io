// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.pooling;

import arc.struct.Seq;
import arc.func.Prov;
import arc.struct.ObjectMap;

public class Pools
{
    private static final ObjectMap<Class, Pool> typePools;
    
    private Pools() {
    }
    
    public static <T> Pool<T> get(final Class<T> type, final Prov<T> supplier, final int max) {
        Pool<T> pool = Pools.typePools.get(type);
        if (pool == null) {
            pool = new Pool<T>(4, max) {
                @Override
                protected T newObject() {
                    return supplier.get();
                }
            };
            Pools.typePools.put(type, pool);
        }
        return pool;
    }
    
    public static <T> Pool<T> get(final Class<T> type, final Prov<T> supplier) {
        return get(type, supplier, 5000);
    }
    
    public static <T> void set(final Class<T> type, final Pool<T> pool) {
        Pools.typePools.put(type, pool);
    }
    
    public static synchronized <T> T obtain(final Class<T> type, final Prov<T> supplier) {
        return get(type, supplier).obtain();
    }
    
    public static synchronized void free(final Object object) {
        if (object == null) {
            throw new IllegalArgumentException("Object cannot be null.");
        }
        final Pool pool = Pools.typePools.get(object.getClass());
        if (pool == null) {
            return;
        }
        pool.free(object);
    }
    
    public static void freeAll(final Seq objects) {
        freeAll(objects, false);
    }
    
    public static void freeAll(final Seq objects, final boolean samePool) {
        if (objects == null) {
            throw new IllegalArgumentException("Objects cannot be null.");
        }
        Pool pool = null;
        for (int i = 0, n = objects.size; i < n; ++i) {
            final Object object = objects.get(i);
            if (object != null) {
                if (pool == null) {
                    pool = Pools.typePools.get(object.getClass());
                    if (pool == null) {
                        continue;
                    }
                }
                pool.free(object);
                if (!samePool) {
                    pool = null;
                }
            }
        }
    }
    
    static {
        typePools = new ObjectMap<Class, Pool>();
    }
}
