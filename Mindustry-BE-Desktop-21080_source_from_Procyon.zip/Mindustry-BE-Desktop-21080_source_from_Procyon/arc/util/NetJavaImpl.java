// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import java.util.Iterator;
import java.util.Map;
import java.util.List;
import arc.struct.Seq;
import arc.struct.ObjectMap;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.Closeable;
import arc.util.io.Streams;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import arc.func.Cons;
import arc.Net;
import arc.util.async.AsyncExecutor;

public class NetJavaImpl
{
    private final AsyncExecutor asyncExecutor;
    private boolean block;
    
    public NetJavaImpl() {
        this.asyncExecutor = new AsyncExecutor(6);
    }
    
    public void http(final Net.HttpRequest request, final Cons<Net.HttpResponse> success, final Cons<Throwable> failure) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        arc/Net$HttpRequest.url:Ljava/lang/String;
        //     4: ifnonnull       23
        //     7: aload_3         /* failure */
        //     8: new             Larc/util/ArcRuntimeException;
        //    11: dup            
        //    12: ldc             "can't process a HTTP request without URL set"
        //    14: invokespecial   arc/util/ArcRuntimeException.<init>:(Ljava/lang/String;)V
        //    17: invokeinterface arc/func/Cons.get:(Ljava/lang/Object;)V
        //    22: return         
        //    23: aload_1         /* request */
        //    24: getfield        arc/Net$HttpRequest.method:Larc/Net$HttpMethod;
        //    27: astore          method
        //    29: aload           method
        //    31: getstatic       arc/Net$HttpMethod.GET:Larc/Net$HttpMethod;
        //    34: if_acmpne       118
        //    37: ldc             ""
        //    39: astore          queryString
        //    41: aload_1         /* request */
        //    42: getfield        arc/Net$HttpRequest.content:Ljava/lang/String;
        //    45: astore          value
        //    47: aload           value
        //    49: ifnull          84
        //    52: ldc             ""
        //    54: aload           value
        //    56: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    59: ifne            84
        //    62: new             Ljava/lang/StringBuilder;
        //    65: dup            
        //    66: invokespecial   java/lang/StringBuilder.<init>:()V
        //    69: ldc             "?"
        //    71: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    74: aload           value
        //    76: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    79: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    82: astore          queryString
        //    84: new             Ljava/net/URL;
        //    87: dup            
        //    88: new             Ljava/lang/StringBuilder;
        //    91: dup            
        //    92: invokespecial   java/lang/StringBuilder.<init>:()V
        //    95: aload_1         /* request */
        //    96: getfield        arc/Net$HttpRequest.url:Ljava/lang/String;
        //    99: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   102: aload           queryString
        //   104: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   107: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   110: invokespecial   java/net/URL.<init>:(Ljava/lang/String;)V
        //   113: astore          url
        //   115: goto            131
        //   118: new             Ljava/net/URL;
        //   121: dup            
        //   122: aload_1         /* request */
        //   123: getfield        arc/Net$HttpRequest.url:Ljava/lang/String;
        //   126: invokespecial   java/net/URL.<init>:(Ljava/lang/String;)V
        //   129: astore          url
        //   131: aload           url
        //   133: invokevirtual   java/net/URL.openConnection:()Ljava/net/URLConnection;
        //   136: checkcast       Ljava/net/HttpURLConnection;
        //   139: astore          connection
        //   141: aload           method
        //   143: getstatic       arc/Net$HttpMethod.POST:Larc/Net$HttpMethod;
        //   146: if_acmpeq       157
        //   149: aload           method
        //   151: getstatic       arc/Net$HttpMethod.PUT:Larc/Net$HttpMethod;
        //   154: if_acmpne       161
        //   157: iconst_1       
        //   158: goto            162
        //   161: iconst_0       
        //   162: istore          doingOutPut
        //   164: aload           connection
        //   166: iload           doingOutPut
        //   168: invokevirtual   java/net/HttpURLConnection.setDoOutput:(Z)V
        //   171: aload           connection
        //   173: iconst_1       
        //   174: invokevirtual   java/net/HttpURLConnection.setDoInput:(Z)V
        //   177: aload           connection
        //   179: aload           method
        //   181: invokevirtual   arc/Net$HttpMethod.toString:()Ljava/lang/String;
        //   184: invokevirtual   java/net/HttpURLConnection.setRequestMethod:(Ljava/lang/String;)V
        //   187: aload_1         /* request */
        //   188: getfield        arc/Net$HttpRequest.followRedirects:Z
        //   191: invokestatic    java/net/HttpURLConnection.setFollowRedirects:(Z)V
        //   194: aload_1         /* request */
        //   195: getfield        arc/Net$HttpRequest.headers:Larc/struct/ObjectMap;
        //   198: aload           connection
        //   200: dup            
        //   201: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //   204: pop            
        //   205: invokedynamic   BootstrapMethod #0, get:(Ljava/net/HttpURLConnection;)Larc/func/Cons2;
        //   210: invokevirtual   arc/struct/ObjectMap.each:(Larc/func/Cons2;)V
        //   213: aload           connection
        //   215: aload_1         /* request */
        //   216: getfield        arc/Net$HttpRequest.timeout:I
        //   219: invokevirtual   java/net/HttpURLConnection.setConnectTimeout:(I)V
        //   222: aload           connection
        //   224: aload_1         /* request */
        //   225: getfield        arc/Net$HttpRequest.timeout:I
        //   228: invokevirtual   java/net/HttpURLConnection.setReadTimeout:(I)V
        //   231: aload_0         /* this */
        //   232: iload           doingOutPut
        //   234: aload_1         /* request */
        //   235: aload           connection
        //   237: aload_2         /* success */
        //   238: aload_3         /* failure */
        //   239: invokedynamic   BootstrapMethod #1, run:(ZLarc/Net$HttpRequest;Ljava/net/HttpURLConnection;Larc/func/Cons;Larc/func/Cons;)Ljava/lang/Runnable;
        //   244: invokespecial   arc/util/NetJavaImpl.run:(Ljava/lang/Runnable;)V
        //   247: goto            260
        //   250: astore          e
        //   252: aload_3         /* failure */
        //   253: aload           e
        //   255: invokeinterface arc/func/Cons.get:(Ljava/lang/Object;)V
        //   260: return         
        //    Signature:
        //  (Larc/Net$HttpRequest;Larc/func/Cons<Larc/Net$HttpResponse;>;Larc/func/Cons<Ljava/lang/Throwable;>;)V
        //    StackMapTable: 00 09 17 FF 00 3C 00 08 07 00 64 07 00 65 07 00 66 07 00 66 07 00 67 00 07 00 68 07 00 68 00 00 F8 00 21 FC 00 0C 07 00 69 FC 00 19 07 00 6A 03 40 01 FF 00 57 00 04 07 00 64 07 00 65 07 00 66 07 00 66 00 01 07 00 6B 09
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  23     247    250    260    Ljava/lang/Throwable;
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.decompiler.languages.java.ast.NameVariables.generateNameForVariable(NameVariables.java:264)
        //     at com.strobel.decompiler.languages.java.ast.NameVariables.assignNamesToVariables(NameVariables.java:198)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:276)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void setBlock(final boolean block) {
        this.block = block;
    }
    
    private void run(final Runnable run) {
        if (this.block) {
            run.run();
        }
        else {
            this.asyncExecutor.submit(run);
        }
    }
    
    static class HttpClientResponse implements Net.HttpResponse
    {
        private final HttpURLConnection connection;
        private Net.HttpStatus status;
        
        public HttpClientResponse(final HttpURLConnection connection) throws IOException {
            this.connection = connection;
            this.status = Net.HttpStatus.byCode(connection.getResponseCode());
        }
        
        @Override
        public byte[] getResult() {
            final InputStream input = this.getInputStream();
            if (input == null) {
                return Streams.EMPTY_BYTES;
            }
            try {
                return Streams.copyBytes(input, this.connection.getContentLength());
            }
            catch (IOException e) {
                return Streams.EMPTY_BYTES;
            }
            finally {
                Streams.close(input);
            }
        }
        
        @Override
        public String getResultAsString() {
            final InputStream input = this.getInputStream();
            if (input == null) {
                return "";
            }
            try {
                return Streams.copyString(input, this.connection.getContentLength());
            }
            catch (IOException e) {
                return "";
            }
            finally {
                Streams.close(input);
            }
        }
        
        @Override
        public InputStream getResultAsStream() {
            return this.getInputStream();
        }
        
        @Override
        public Net.HttpStatus getStatus() {
            return this.status;
        }
        
        @Override
        public String getHeader(final String name) {
            return this.connection.getHeaderField(name);
        }
        
        @Override
        public ObjectMap<String, Seq<String>> getHeaders() {
            final ObjectMap<String, Seq<String>> out = new ObjectMap<String, Seq<String>>();
            final Map<String, List<String>> fields = this.connection.getHeaderFields();
            for (final String key : fields.keySet()) {
                if (key != null) {
                    out.put(key, Seq.with((String[])fields.get(key).toArray((T[])new String[0])));
                }
            }
            return out;
        }
        
        private InputStream getInputStream() {
            try {
                return this.connection.getInputStream();
            }
            catch (IOException e) {
                return this.connection.getErrorStream();
            }
        }
    }
}
