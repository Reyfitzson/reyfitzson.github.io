// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;

public class Log
{
    private static final Object[] empty;
    public static boolean useColors;
    public static LogLevel level;
    public static LogHandler logger;
    public static LogFormatter formatter;
    
    public static void log(final LogLevel level, final String text, final Object... args) {
        if (Log.level.ordinal() > level.ordinal()) {
            return;
        }
        Log.logger.log(level, format(text, args));
    }
    
    public static void debug(final String text, final Object... args) {
        log(LogLevel.debug, text, args);
    }
    
    public static void debug(final Object object) {
        debug(String.valueOf(object), Log.empty);
    }
    
    public static void infoList(final Object... args) {
        if (Log.level.ordinal() > LogLevel.info.ordinal()) {
            return;
        }
        final StringBuilder build = new StringBuilder();
        for (final Object o : args) {
            build.append(o);
            build.append(" ");
        }
        info((Object)build.toString());
    }
    
    public static void infoTag(final String tag, final String text) {
        log(LogLevel.info, "[" + tag + "] " + text, new Object[0]);
    }
    
    public static void info(final String text, final Object... args) {
        log(LogLevel.info, text, args);
    }
    
    public static void info(final Object object) {
        info(String.valueOf(object), Log.empty);
    }
    
    public static void warn(final String text, final Object... args) {
        log(LogLevel.warn, text, args);
    }
    
    public static void errTag(final String tag, final String text) {
        log(LogLevel.err, "[" + tag + "] " + text, new Object[0]);
    }
    
    public static void err(final String text, final Object... args) {
        log(LogLevel.err, text, args);
    }
    
    public static void err(final Throwable th) {
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        th.printStackTrace(pw);
        err(sw.toString(), new Object[0]);
    }
    
    public static void err(final String text, final Throwable th) {
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        th.printStackTrace(pw);
        err(text + ": " + sw.toString(), new Object[0]);
    }
    
    public static String format(final String text, final Object... args) {
        return formatColors(text, Log.useColors, args);
    }
    
    public static String formatColors(final String text, final boolean useColors, final Object... args) {
        return Log.formatter.format(text, useColors, args);
    }
    
    public static String removeColors(String text) {
        for (final String color : ColorCodes.codes) {
            text = text.replace("&" + color, "");
        }
        return text;
    }
    
    public static String addColors(String text) {
        for (int i = 0; i < ColorCodes.codes.length; ++i) {
            text = text.replace("&" + ColorCodes.codes[i], ColorCodes.values[i]);
        }
        return text;
    }
    
    static {
        empty = new Object[0];
        Log.useColors = true;
        Log.level = LogLevel.info;
        Log.logger = new DefaultLogHandler();
        Log.formatter = new DefaultLogFormatter();
    }
    
    public enum LogLevel
    {
        debug, 
        info, 
        warn, 
        err, 
        none;
    }
    
    public static class DefaultLogFormatter implements LogFormatter
    {
        @Override
        public String format(String text, final boolean useColors, final Object... args) {
            text = Strings.format(text, args);
            return useColors ? Log.addColors(text) : Log.removeColors(text);
        }
    }
    
    public static class DefaultLogHandler implements LogHandler
    {
        @Override
        public void log(final LogLevel level, final String text) {
            System.out.println(Log.format(((level == LogLevel.debug) ? "&lc&fb" : ((level == LogLevel.info) ? "&fb" : ((level == LogLevel.warn) ? "&ly&fb" : ((level == LogLevel.err) ? "&lr&fb" : "")))) + text + "&fr", new Object[0]));
        }
    }
    
    public static class NoopLogHandler implements LogHandler
    {
        @Override
        public void log(final LogLevel level, final String text) {
        }
    }
    
    public interface LogHandler
    {
        void log(final LogLevel p0, final String p1);
    }
    
    public interface LogFormatter
    {
        String format(final String p0, final boolean p1, final Object... p2);
    }
}
