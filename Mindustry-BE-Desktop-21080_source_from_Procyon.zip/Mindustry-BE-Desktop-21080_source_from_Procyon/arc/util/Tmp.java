// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.math.geom.Bezier;
import arc.math.Mat;
import arc.graphics.g2d.TextureRegion;
import arc.math.geom.Point2;
import arc.graphics.Color;
import arc.math.geom.Circle;
import arc.math.geom.Rect;
import arc.math.geom.Vec3;
import arc.math.geom.Vec2;

public class Tmp
{
    public static final Vec2 v1;
    public static final Vec2 v2;
    public static final Vec2 v3;
    public static final Vec2 v4;
    public static final Vec2 v5;
    public static final Vec2 v6;
    public static final Vec3 v31;
    public static final Vec3 v32;
    public static final Vec3 v33;
    public static final Vec3 v34;
    public static final Rect r1;
    public static final Rect r2;
    public static final Rect r3;
    public static final Circle cr1;
    public static final Circle cr2;
    public static final Circle cr3;
    public static final Vec2 t1;
    public static final Color c1;
    public static final Color c2;
    public static final Color c3;
    public static final Color c4;
    public static final Point2 p1;
    public static final Point2 p2;
    public static final Point2 p3;
    public static final TextureRegion tr1;
    public static final TextureRegion tr2;
    public static final Mat m1;
    public static final Mat m2;
    public static final Mat m3;
    public static final Bezier<Vec2> bz2;
    public static final Bezier<Vec3> bz3;
    
    static {
        v1 = new Vec2();
        v2 = new Vec2();
        v3 = new Vec2();
        v4 = new Vec2();
        v5 = new Vec2();
        v6 = new Vec2();
        v31 = new Vec3();
        v32 = new Vec3();
        v33 = new Vec3();
        v34 = new Vec3();
        r1 = new Rect();
        r2 = new Rect();
        r3 = new Rect();
        cr1 = new Circle();
        cr2 = new Circle();
        cr3 = new Circle();
        t1 = new Vec2();
        c1 = new Color();
        c2 = new Color();
        c3 = new Color();
        c4 = new Color();
        p1 = new Point2();
        p2 = new Point2();
        p3 = new Point2();
        tr1 = new TextureRegion();
        tr2 = new TextureRegion();
        m1 = new Mat();
        m2 = new Mat();
        m3 = new Mat();
        bz2 = new Bezier<Vec2>();
        bz3 = new Bezier<Vec3>();
    }
}
