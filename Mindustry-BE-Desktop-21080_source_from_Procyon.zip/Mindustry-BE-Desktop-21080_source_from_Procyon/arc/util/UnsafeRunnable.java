// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

public interface UnsafeRunnable
{
    void run() throws Throwable;
}
