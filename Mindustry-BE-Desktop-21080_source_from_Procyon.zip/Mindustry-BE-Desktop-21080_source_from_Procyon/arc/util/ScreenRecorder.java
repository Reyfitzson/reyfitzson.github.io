// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.Core;
import java.lang.reflect.Method;

public class ScreenRecorder
{
    private static Runnable record;
    
    public static void record() {
        if (ScreenRecorder.record == null) {
            return;
        }
        ScreenRecorder.record.run();
    }
    
    static {
        try {
            final Class<?> recorderClass = Class.forName("arc.gif.GifRecorder");
            final Object recorder = recorderClass.getConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]);
            Reflect.set(recorder, "exportDirectory", Core.files.local("../../gifs"));
            final Method r = recorderClass.getMethod("update", (Class<?>[])new Class[0]);
            final Object[] args = new Object[0];
            final Method method;
            final Object obj;
            final Object[] args2;
            ScreenRecorder.record = (() -> {
                try {
                    method.invoke(obj, args2);
                }
                catch (Throwable t) {}
            });
        }
        catch (Throwable t2) {}
    }
}
