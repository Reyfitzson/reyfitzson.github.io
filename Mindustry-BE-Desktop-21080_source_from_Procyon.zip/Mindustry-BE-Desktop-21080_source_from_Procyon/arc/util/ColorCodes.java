// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.struct.ObjectMap;

public class ColorCodes
{
    public static String flush;
    public static String reset;
    public static String bold;
    public static String italic;
    public static String underline;
    public static String black;
    public static String red;
    public static String green;
    public static String yellow;
    public static String blue;
    public static String purple;
    public static String cyan;
    public static String lightBlack;
    public static String lightRed;
    public static String lightGreen;
    public static String lightYellow;
    public static String lightBlue;
    public static String lightMagenta;
    public static String lightCyan;
    public static String lightWhite;
    public static String white;
    public static String backDefault;
    public static String backRed;
    public static String backGreen;
    public static String backYellow;
    public static String backBlue;
    public static final String[] codes;
    public static final String[] values;
    
    static {
        ColorCodes.flush = "\u001b[H\u001b[2J";
        ColorCodes.reset = "\u001b[0m";
        ColorCodes.bold = "\u001b[1m";
        ColorCodes.italic = "\u001b[3m";
        ColorCodes.underline = "\u001b[4m";
        ColorCodes.black = "\u001b[30m";
        ColorCodes.red = "\u001b[31m";
        ColorCodes.green = "\u001b[32m";
        ColorCodes.yellow = "\u001b[33m";
        ColorCodes.blue = "\u001b[34m";
        ColorCodes.purple = "\u001b[35m";
        ColorCodes.cyan = "\u001b[36m";
        ColorCodes.lightBlack = "\u001b[90m";
        ColorCodes.lightRed = "\u001b[91m";
        ColorCodes.lightGreen = "\u001b[92m";
        ColorCodes.lightYellow = "\u001b[93m";
        ColorCodes.lightBlue = "\u001b[94m";
        ColorCodes.lightMagenta = "\u001b[95m";
        ColorCodes.lightCyan = "\u001b[96m";
        ColorCodes.lightWhite = "\u001b[97m";
        ColorCodes.white = "\u001b[37m";
        ColorCodes.backDefault = "\u001b[49m";
        ColorCodes.backRed = "\u001b[41m";
        ColorCodes.backGreen = "\u001b[42m";
        ColorCodes.backYellow = "\u001b[43m";
        ColorCodes.backBlue = "\u001b[44m";
        if (OS.isWindows || OS.isAndroid) {
            ColorCodes.flush = (ColorCodes.reset = (ColorCodes.bold = (ColorCodes.underline = (ColorCodes.black = (ColorCodes.red = (ColorCodes.green = (ColorCodes.yellow = (ColorCodes.blue = (ColorCodes.purple = (ColorCodes.cyan = (ColorCodes.lightWhite = (ColorCodes.lightBlack = (ColorCodes.lightRed = (ColorCodes.lightGreen = (ColorCodes.lightYellow = (ColorCodes.lightBlue = (ColorCodes.lightMagenta = (ColorCodes.lightCyan = (ColorCodes.white = (ColorCodes.backDefault = (ColorCodes.backRed = (ColorCodes.backYellow = (ColorCodes.backBlue = (ColorCodes.backGreen = (ColorCodes.italic = "")))))))))))))))))))))))));
        }
        final ObjectMap<String, String> map = ObjectMap.of("ff", ColorCodes.flush, "fr", ColorCodes.reset, "fb", ColorCodes.bold, "fi", ColorCodes.italic, "fu", ColorCodes.underline, "k", ColorCodes.black, "lk", ColorCodes.lightBlack, "lw", ColorCodes.lightWhite, "r", ColorCodes.red, "g", ColorCodes.green, "y", ColorCodes.yellow, "b", ColorCodes.blue, "p", ColorCodes.purple, "c", ColorCodes.cyan, "lr", ColorCodes.lightRed, "lg", ColorCodes.lightGreen, "ly", ColorCodes.lightYellow, "lm", ColorCodes.lightMagenta, "lb", ColorCodes.lightBlue, "lc", ColorCodes.lightCyan, "w", ColorCodes.white, "bd", ColorCodes.backDefault, "br", ColorCodes.backRed, "bg", ColorCodes.backGreen, "by", ColorCodes.backYellow, "bb", ColorCodes.backBlue);
        codes = map.keys().toSeq().toArray(String.class);
        values = map.values().toSeq().toArray(String.class);
    }
}
