// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.async;

import java.util.concurrent.TimeUnit;
import arc.util.ArcRuntimeException;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import arc.util.Disposable;

public class AsyncExecutor implements Disposable
{
    private final ExecutorService executor;
    
    public AsyncExecutor(final int maxConcurrent) {
        final Thread thread;
        this.executor = Executors.newFixedThreadPool(maxConcurrent, r -> {
            thread = new Thread(r, "AsynchExecutor-Thread");
            thread.setDaemon(true);
            thread.setUncaughtExceptionHandler((t, e) -> e.printStackTrace());
            return thread;
        });
    }
    
    public AsyncResult<Void> submit(final Runnable run) {
        return this.submit(() -> {
            run.run();
            return null;
        });
    }
    
    public <T> AsyncResult<T> submit(final AsyncTask<T> task) {
        if (this.executor.isShutdown()) {
            throw new ArcRuntimeException("Cannot run tasks on an executor that has been shutdown (disposed)");
        }
        return new AsyncResult<T>(this.executor.submit(task::call));
    }
    
    @Override
    public void dispose() {
        this.executor.shutdown();
        try {
            this.executor.awaitTermination(Long.MAX_VALUE, TimeUnit.SECONDS);
        }
        catch (InterruptedException e) {
            throw new ArcRuntimeException("Couldn't shutdown loading thread", e);
        }
    }
}
