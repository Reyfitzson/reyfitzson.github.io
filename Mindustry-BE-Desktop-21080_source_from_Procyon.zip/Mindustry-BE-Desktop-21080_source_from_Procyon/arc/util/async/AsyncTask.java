// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.async;

public interface AsyncTask<T>
{
    T call() throws Exception;
}
