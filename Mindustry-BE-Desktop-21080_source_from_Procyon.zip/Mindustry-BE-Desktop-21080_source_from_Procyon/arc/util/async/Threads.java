// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.async;

import arc.util.Time;

public class Threads
{
    public static void yield() {
        Thread.yield();
    }
    
    public static void sleep(final long ms) {
        try {
            Thread.sleep(ms);
        }
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static void sleep(final long ms, final int ns) {
        try {
            Thread.sleep(ms, ns);
        }
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static void throwAppException(final Throwable t) {
        Time.runTask(0.0f, () -> {
            throw new RuntimeException(t);
        });
    }
    
    public static Thread thread(final Runnable runnable) {
        final Thread thread = new Thread(runnable);
        thread.start();
        return thread;
    }
    
    public static Thread daemon(final Runnable runnable) {
        final Thread thread = new Thread(runnable);
        thread.setDaemon(true);
        thread.start();
        return thread;
    }
    
    public static Thread daemon(final String name, final Runnable runnable) {
        final Thread thread = new Thread(runnable, name);
        thread.setDaemon(true);
        thread.start();
        return thread;
    }
}
