// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

public class ArcRuntimeException extends RuntimeException
{
    private static final long serialVersionUID = 6735854402467673117L;
    
    public ArcRuntimeException(final String message) {
        super(message);
    }
    
    public ArcRuntimeException(final Throwable t) {
        super(t);
    }
    
    public ArcRuntimeException(final String message, final Throwable t) {
        super(message, t);
    }
}
