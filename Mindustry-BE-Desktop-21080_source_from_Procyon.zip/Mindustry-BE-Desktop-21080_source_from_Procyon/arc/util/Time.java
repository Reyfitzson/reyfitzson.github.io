// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.util.pooling.Pool;
import java.util.Iterator;
import arc.Core;
import arc.util.pooling.Pools;
import arc.func.Floatp;
import arc.struct.LongSeq;
import arc.struct.Seq;

public class Time
{
    public static final float toSeconds = 60.0f;
    public static final float toMinutes = 3600.0f;
    public static final float toHours = 216000.0f;
    public static float delta;
    public static float time;
    public static float globalTime;
    public static final long nanosPerMilli = 1000000L;
    private static double timeRaw;
    private static double globalTimeRaw;
    private static Seq<DelayRun> runs;
    private static Seq<DelayRun> removal;
    private static LongSeq marks;
    private static Floatp deltaimpl;
    
    public static void run(final float delay, final Runnable r) {
        final DelayRun run = Pools.obtain(DelayRun.class, DelayRun::new);
        run.finish = r;
        run.delay = delay;
        Time.runs.add(run);
    }
    
    public static Timer.Task runTask(final float delay, final Runnable r) {
        return Timer.schedule(r, delay / 60.0f);
    }
    
    public static void mark() {
        Time.marks.add(nanos());
    }
    
    public static float elapsed() {
        if (Time.marks.size == 0) {
            return -1.0f;
        }
        return timeSinceNanos(Time.marks.pop()) / 1000000.0f;
    }
    
    public static void updateGlobal() {
        Time.globalTimeRaw += Core.graphics.getDeltaTime() * 60.0f;
        Time.delta = Time.deltaimpl.get();
        if (Double.isInfinite(Time.timeRaw) || Double.isNaN(Time.timeRaw)) {
            Time.timeRaw = 0.0;
        }
        Time.time = (float)Time.timeRaw;
        Time.globalTime = (float)Time.globalTimeRaw;
    }
    
    public static void update() {
        Time.timeRaw += Time.delta;
        Time.removal.clear();
        if (Double.isInfinite(Time.timeRaw) || Double.isNaN(Time.timeRaw)) {
            Time.timeRaw = 0.0;
        }
        Time.time = (float)Time.timeRaw;
        Time.globalTime = (float)Time.globalTimeRaw;
        for (final DelayRun delayRun : Time.runs) {
            final DelayRun run = delayRun;
            delayRun.delay -= Time.delta;
            if (run.delay <= 0.0f) {
                run.finish.run();
                Time.removal.add(run);
                Pools.free(run);
            }
        }
        Time.runs.removeAll(Time.removal);
    }
    
    public static void clear() {
        Time.runs.clear();
    }
    
    public static void setDeltaProvider(final Floatp impl) {
        Time.deltaimpl = impl;
        Time.delta = impl.get();
    }
    
    public static long nanos() {
        return System.nanoTime();
    }
    
    public static long millis() {
        return System.currentTimeMillis();
    }
    
    public static long nanosToMillis(final long nanos) {
        return nanos / 1000000L;
    }
    
    public static long millisToNanos(final long millis) {
        return millis * 1000000L;
    }
    
    public static long timeSinceNanos(final long prevTime) {
        return nanos() - prevTime;
    }
    
    public static long timeSinceMillis(final long prevTime) {
        return millis() - prevTime;
    }
    
    static {
        Time.delta = 1.0f;
        Time.runs = new Seq<DelayRun>();
        Time.removal = new Seq<DelayRun>();
        Time.marks = new LongSeq();
        Time.deltaimpl = (() -> Math.min(Core.graphics.getDeltaTime() * 60.0f, 3.0f));
    }
    
    public static class DelayRun implements Pool.Poolable
    {
        float delay;
        Runnable finish;
        
        @Override
        public void reset() {
            this.delay = 0.0f;
            this.finish = null;
        }
    }
}
