// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

public class ArcNativesLoader
{
    public static boolean disableNativesLoading;
    private static boolean nativesLoaded;
    
    public static synchronized void load() {
        if (ArcNativesLoader.nativesLoaded) {
            return;
        }
        ArcNativesLoader.nativesLoaded = true;
        if (ArcNativesLoader.disableNativesLoading) {
            return;
        }
        new SharedLibraryLoader().load("arc");
    }
    
    static {
        ArcNativesLoader.disableNativesLoading = false;
    }
}
