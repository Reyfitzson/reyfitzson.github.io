// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import java.nio.ByteOrder;
import java.nio.DoubleBuffer;
import java.nio.LongBuffer;
import java.nio.IntBuffer;
import java.nio.CharBuffer;
import java.nio.ShortBuffer;
import java.nio.FloatBuffer;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import arc.struct.Seq;

public final class Buffers
{
    static final Seq<ByteBuffer> unsafeBuffers;
    static int allocatedUnsafe;
    
    public static void copy(final float[] src, final Buffer dst, final int numFloats, final int offset) {
        if (dst instanceof ByteBuffer) {
            dst.limit(numFloats << 2);
        }
        else if (dst instanceof FloatBuffer) {
            dst.limit(numFloats);
        }
        copyJni(src, dst, numFloats, offset);
        dst.position(0);
    }
    
    public static void copy(final byte[] src, final int srcOffset, final Buffer dst, final int numElements) {
        dst.limit(dst.position() + bytesToElements(dst, numElements));
        copyJni(src, srcOffset, dst, positionInBytes(dst), numElements);
    }
    
    public static void copy(final short[] src, final int srcOffset, final Buffer dst, final int numElements) {
        dst.limit(dst.position() + bytesToElements(dst, numElements << 1));
        copyJni(src, srcOffset, dst, positionInBytes(dst), numElements << 1);
    }
    
    public static void copy(final float[] src, final int srcOffset, final int numElements, final Buffer dst) {
        copyJni(src, srcOffset, dst, positionInBytes(dst), numElements << 2);
    }
    
    public static void copy(final int[] src, final int srcOffset, final Buffer dst, final int numElements) {
        dst.limit(dst.position() + bytesToElements(dst, numElements << 2));
        copyJni(src, srcOffset, dst, positionInBytes(dst), numElements << 2);
    }
    
    public static void copy(final float[] src, final int srcOffset, final Buffer dst, final int numElements) {
        dst.limit(dst.position() + bytesToElements(dst, numElements << 2));
        copyJni(src, srcOffset, dst, positionInBytes(dst), numElements << 2);
    }
    
    public static void copy(final Buffer src, final Buffer dst, final int numElements) {
        final int numBytes = elementsToBytes(src, numElements);
        dst.limit(dst.position() + bytesToElements(dst, numBytes));
        copyJni(src, positionInBytes(src), dst, positionInBytes(dst), numBytes);
    }
    
    private static int positionInBytes(final Buffer dst) {
        return dst.position() << elementShift(dst);
    }
    
    private static int bytesToElements(final Buffer dst, final int bytes) {
        return bytes >>> elementShift(dst);
    }
    
    private static int elementsToBytes(final Buffer dst, final int elements) {
        return elements << elementShift(dst);
    }
    
    private static int elementShift(final Buffer dst) {
        if (dst instanceof ByteBuffer) {
            return 0;
        }
        if (dst instanceof ShortBuffer || dst instanceof CharBuffer) {
            return 1;
        }
        if (dst instanceof IntBuffer) {
            return 2;
        }
        if (dst instanceof LongBuffer) {
            return 3;
        }
        if (dst instanceof FloatBuffer) {
            return 2;
        }
        if (dst instanceof DoubleBuffer) {
            return 3;
        }
        throw new ArcRuntimeException("Can't copy to a " + dst.getClass().getName() + " instance");
    }
    
    public static FloatBuffer newFloatBuffer(final int numFloats) {
        final ByteBuffer buffer = ByteBuffer.allocateDirect(numFloats * 4);
        buffer.order(ByteOrder.nativeOrder());
        return buffer.asFloatBuffer();
    }
    
    public static ShortBuffer newShortBuffer(final int numShorts) {
        final ByteBuffer buffer = ByteBuffer.allocateDirect(numShorts * 2);
        buffer.order(ByteOrder.nativeOrder());
        return buffer.asShortBuffer();
    }
    
    public static ByteBuffer newByteBuffer(final int numBytes) {
        final ByteBuffer buffer = ByteBuffer.allocateDirect(numBytes);
        buffer.order(ByteOrder.nativeOrder());
        return buffer;
    }
    
    public static IntBuffer newIntBuffer(final int numInts) {
        final ByteBuffer buffer = ByteBuffer.allocateDirect(numInts * 4);
        buffer.order(ByteOrder.nativeOrder());
        return buffer.asIntBuffer();
    }
    
    public static void disposeUnsafeByteBuffer(final ByteBuffer buffer) {
        final int size = buffer.capacity();
        synchronized (Buffers.unsafeBuffers) {
            if (!Buffers.unsafeBuffers.remove(buffer, true)) {
                throw new IllegalArgumentException("buffer not allocated with newUnsafeByteBuffer or already disposed");
            }
        }
        Buffers.allocatedUnsafe -= size;
        freeMemory(buffer);
    }
    
    public static boolean isUnsafeByteBuffer(final ByteBuffer buffer) {
        synchronized (Buffers.unsafeBuffers) {
            return Buffers.unsafeBuffers.contains(buffer, true);
        }
    }
    
    public static ByteBuffer newUnsafeByteBuffer(final int numBytes) {
        final ByteBuffer buffer = newDisposableByteBuffer(numBytes);
        buffer.order(ByteOrder.nativeOrder());
        Buffers.allocatedUnsafe += numBytes;
        synchronized (Buffers.unsafeBuffers) {
            Buffers.unsafeBuffers.add(buffer);
        }
        return buffer;
    }
    
    public static long getUnsafeBufferAddress(final Buffer buffer) {
        return getBufferAddress(buffer) + buffer.position();
    }
    
    public static ByteBuffer newUnsafeByteBuffer(final ByteBuffer buffer) {
        Buffers.allocatedUnsafe += buffer.capacity();
        synchronized (Buffers.unsafeBuffers) {
            Buffers.unsafeBuffers.add(buffer);
        }
        return buffer;
    }
    
    public static int getAllocatedBytesUnsafe() {
        return Buffers.allocatedUnsafe;
    }
    
    private static native void freeMemory(final ByteBuffer p0);
    
    private static native ByteBuffer newDisposableByteBuffer(final int p0);
    
    private static native long getBufferAddress(final Buffer p0);
    
    private static native void clear(final ByteBuffer p0, final int p1);
    
    private static native void copyJni(final float[] p0, final Buffer p1, final int p2, final int p3);
    
    private static native void copyJni(final byte[] p0, final int p1, final Buffer p2, final int p3, final int p4);
    
    private static native void copyJni(final short[] p0, final int p1, final Buffer p2, final int p3, final int p4);
    
    private static native void copyJni(final int[] p0, final int p1, final Buffer p2, final int p3, final int p4);
    
    private static native void copyJni(final float[] p0, final int p1, final Buffer p2, final int p3, final int p4);
    
    private static native void copyJni(final Buffer p0, final int p1, final Buffer p2, final int p3, final int p4);
    
    static {
        unsafeBuffers = new Seq<ByteBuffer>();
        Buffers.allocatedUnsafe = 0;
    }
}
