// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import java.nio.ByteBuffer;
import java.nio.Buffer;
import arc.graphics.Gl;
import arc.graphics.Texture;
import arc.math.Mathf;
import arc.graphics.g2d.TextureRegion;
import arc.graphics.Pixmap;
import arc.graphics.PixmapIO;
import arc.Core;
import arc.files.Fi;

public final class ScreenUtils
{
    public static void saveScreenshot(final Fi file) {
        saveScreenshot(file, 0, 0, Core.graphics.getWidth(), Core.graphics.getHeight());
    }
    
    public static void saveScreenshot(final Fi file, final int x, final int y, final int width, final int height) {
        final Pixmap pixmap = getFrameBufferPixmap(x, y, width, height, true);
        PixmapIO.writePNG(file, pixmap);
        pixmap.dispose();
    }
    
    public static TextureRegion getFrameBufferTexture() {
        final int w = Core.graphics.getBackBufferWidth();
        final int h = Core.graphics.getBackBufferHeight();
        return getFrameBufferTexture(0, 0, w, h);
    }
    
    public static TextureRegion getFrameBufferTexture(final int x, final int y, final int w, final int h) {
        final int potW = Mathf.nextPowerOfTwo(w);
        final int potH = Mathf.nextPowerOfTwo(h);
        final Pixmap pixmap = getFrameBufferPixmap(x, y, w, h);
        final Pixmap potPixmap = new Pixmap(potW, potH, Pixmap.Format.rgba8888);
        potPixmap.drawPixmap(pixmap, 0, 0);
        final Texture texture = new Texture(potPixmap);
        final TextureRegion textureRegion = new TextureRegion(texture, 0, h, w, -h);
        potPixmap.dispose();
        pixmap.dispose();
        return textureRegion;
    }
    
    public static Pixmap getFrameBufferPixmap(final int x, final int y, final int w, final int h) {
        Gl.pixelStorei(3333, 1);
        final Pixmap pixmap = new Pixmap(w, h, Pixmap.Format.rgba8888);
        final ByteBuffer pixels = pixmap.getPixels();
        Gl.readPixels(x, y, w, h, 6408, 5121, pixels);
        return pixmap;
    }
    
    public static Pixmap getFrameBufferPixmap(final int x, final int y, final int w, final int h, final boolean flip) {
        final byte[] lines = getFrameBufferPixels(x, y, w, h, flip);
        final Pixmap pixmap = new Pixmap(w, h, Pixmap.Format.rgba8888);
        Buffers.copy(lines, 0, pixmap.getPixels(), lines.length);
        return pixmap;
    }
    
    public static byte[] getFrameBufferPixels(final boolean flipY) {
        final int w = Core.graphics.getBackBufferWidth();
        final int h = Core.graphics.getBackBufferHeight();
        return getFrameBufferPixels(0, 0, w, h, flipY);
    }
    
    public static byte[] getFrameBufferPixels(final int x, final int y, final int w, final int h, final boolean flipY) {
        Gl.pixelStorei(3333, 1);
        final ByteBuffer pixels = Buffers.newByteBuffer(w * h * 4);
        Gl.readPixels(x, y, w, h, 6408, 5121, pixels);
        final int numBytes = w * h * 4;
        final byte[] lines = new byte[numBytes];
        if (flipY) {
            final int numBytesPerLine = w * 4;
            for (int i = 0; i < h; ++i) {
                pixels.position((h - i - 1) * numBytesPerLine);
                pixels.get(lines, i * numBytesPerLine, numBytesPerLine);
            }
        }
        else {
            pixels.clear();
            pixels.get(lines);
        }
        return lines;
    }
}
