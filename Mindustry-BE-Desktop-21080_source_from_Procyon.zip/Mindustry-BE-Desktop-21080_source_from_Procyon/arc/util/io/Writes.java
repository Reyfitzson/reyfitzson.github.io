// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.io;

import java.io.IOException;
import java.io.DataOutput;
import java.io.Closeable;

public class Writes implements Closeable
{
    private static Writes instance;
    public DataOutput output;
    
    public Writes(final DataOutput output) {
        this.output = output;
    }
    
    public static Writes get(final DataOutput output) {
        Writes.instance.output = output;
        return Writes.instance;
    }
    
    public void l(final long i) {
        try {
            this.output.writeLong(i);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void i(final int i) {
        try {
            this.output.writeInt(i);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void b(final int i) {
        try {
            this.output.writeByte(i);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void b(final byte[] array, final int offset, final int length) {
        try {
            this.output.write(array, 0, length);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void b(final byte[] array) {
        this.b(array, 0, array.length);
    }
    
    public void bool(final boolean b) {
        this.b(b ? 1 : 0);
    }
    
    public void s(final int i) {
        try {
            this.output.writeShort(i);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void f(final float f) {
        try {
            this.output.writeFloat(f);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void d(final double d) {
        try {
            this.output.writeDouble(d);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void str(final String str) {
        try {
            this.output.writeUTF(str);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public void close() {
        if (this.output instanceof Closeable) {
            try {
                ((Closeable)this.output).close();
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
    
    static {
        Writes.instance = new Writes(null);
    }
}
