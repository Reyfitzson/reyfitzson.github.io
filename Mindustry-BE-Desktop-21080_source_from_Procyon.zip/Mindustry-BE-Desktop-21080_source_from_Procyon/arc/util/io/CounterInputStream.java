// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.FilterInputStream;

public class CounterInputStream extends FilterInputStream
{
    public int count;
    
    public CounterInputStream(final InputStream inputStream) {
        super(inputStream);
    }
    
    public void resetCount() {
        this.count = 0;
    }
    
    @Override
    public long skip(final long l) throws IOException {
        final long skipped = super.skip(l);
        this.count += (int)skipped;
        return skipped;
    }
    
    @Override
    public int read() throws IOException {
        ++this.count;
        return this.in.read();
    }
    
    @Override
    public int read(final byte[] bytes, final int offset, final int length) throws IOException {
        final int total = this.in.read(bytes, offset, length);
        this.count += total;
        return total;
    }
}
