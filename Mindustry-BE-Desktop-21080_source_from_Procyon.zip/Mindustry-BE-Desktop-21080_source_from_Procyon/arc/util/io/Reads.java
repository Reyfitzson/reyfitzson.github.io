// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.io;

import java.io.IOException;
import java.io.DataInput;
import java.io.Closeable;

public class Reads implements Closeable
{
    private static Reads instance;
    public DataInput input;
    
    public Reads(final DataInput input) {
        this.input = input;
    }
    
    public static Reads get(final DataInput input) {
        Reads.instance.input = input;
        return Reads.instance;
    }
    
    public long l() {
        try {
            return this.input.readLong();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public int i() {
        try {
            return this.input.readInt();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public short s() {
        try {
            return this.input.readShort();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public int us() {
        try {
            return this.input.readUnsignedShort();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public byte b() {
        try {
            return this.input.readByte();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public byte[] b(final byte[] array) {
        return this.b(array, 0, array.length);
    }
    
    public byte[] b(final byte[] array, final int offset, final int length) {
        try {
            this.input.readFully(array, offset, length);
            return array;
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public int ub() {
        try {
            return this.input.readUnsignedByte();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public boolean bool() {
        try {
            return this.input.readBoolean();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public float f() {
        try {
            return this.input.readFloat();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public double d() {
        try {
            return this.input.readDouble();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public String str() {
        try {
            return this.input.readUTF();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void skip(final int amount) {
        try {
            this.input.skipBytes(amount);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public void close() {
        if (this.input instanceof Closeable) {
            try {
                ((Closeable)this.input).close();
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
    
    static {
        Reads.instance = new Reads(null);
    }
}
