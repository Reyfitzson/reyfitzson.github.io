// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.io;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.io.DataOutput;

public class ByteBufferOutput implements DataOutput
{
    public ByteBuffer buffer;
    
    public ByteBufferOutput(final ByteBuffer buffer) {
        this.buffer = buffer;
    }
    
    public ByteBufferOutput() {
    }
    
    public void setBuffer(final ByteBuffer buffer) {
        this.buffer = buffer;
    }
    
    @Override
    public void write(final int i) {
        this.buffer.put((byte)i);
    }
    
    @Override
    public void write(final byte[] bytes) {
        this.buffer.put(bytes);
    }
    
    @Override
    public void write(final byte[] bytes, final int i, final int i1) {
        this.buffer.put(bytes, i, i1);
    }
    
    @Override
    public void writeBoolean(final boolean b) {
        this.buffer.put((byte)(b ? 1 : 0));
    }
    
    @Override
    public void writeByte(final int i) {
        this.buffer.put((byte)i);
    }
    
    @Override
    public void writeShort(final int i) {
        this.buffer.putShort((short)i);
    }
    
    @Override
    public void writeChar(final int i) {
        this.buffer.putChar((char)i);
    }
    
    @Override
    public void writeInt(final int i) {
        this.buffer.putInt(i);
    }
    
    @Override
    public void writeLong(final long l) {
        this.buffer.putLong(l);
    }
    
    @Override
    public void writeFloat(final float v) {
        this.buffer.putFloat(v);
    }
    
    @Override
    public void writeDouble(final double v) {
        this.buffer.putDouble(v);
    }
    
    @Override
    public void writeBytes(final String s) {
        throw new RuntimeException("Stub!");
    }
    
    @Override
    public void writeChars(final String s) {
        throw new RuntimeException("Stub!");
    }
    
    @Override
    public void writeUTF(final String s) {
        try {
            final byte[] bytes = s.getBytes("UTF-8");
            if (bytes.length >= 32767) {
                throw new IllegalArgumentException("Input string is too long!");
            }
            this.buffer.putShort((short)bytes.length);
            this.buffer.put(bytes);
        }
        catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }
}
