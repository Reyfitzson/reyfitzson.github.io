// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.io;

import java.io.ByteArrayOutputStream;

public class ReusableByteOutStream extends ByteArrayOutputStream
{
    public ReusableByteOutStream(final int capacity) {
        super(capacity);
    }
    
    public ReusableByteOutStream() {
    }
    
    public byte[] getBytes() {
        return this.buf;
    }
}
