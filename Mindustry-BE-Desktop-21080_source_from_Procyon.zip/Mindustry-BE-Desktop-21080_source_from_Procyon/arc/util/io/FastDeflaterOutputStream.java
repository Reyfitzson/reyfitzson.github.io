// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.io;

import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;

public class FastDeflaterOutputStream extends DeflaterOutputStream
{
    private final byte[] tmp;
    
    public FastDeflaterOutputStream(final OutputStream outputStream) {
        super(outputStream);
        this.tmp = new byte[] { 0 };
    }
    
    @Override
    public void write(final int var1) throws IOException {
        this.tmp[0] = (byte)(var1 & 0xFF);
        this.write(this.tmp, 0, 1);
    }
}
