// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.io;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.io.DataInput;

public class ByteBufferInput implements DataInput
{
    public ByteBuffer buffer;
    
    public ByteBufferInput(final ByteBuffer buffer) {
        this.buffer = buffer;
    }
    
    public ByteBufferInput() {
    }
    
    public void setBuffer(final ByteBuffer buffer) {
        this.buffer = buffer;
    }
    
    @Override
    public void readFully(final byte[] bytes) {
        this.buffer.get(bytes);
    }
    
    @Override
    public void readFully(final byte[] bytes, final int f, final int to) {
        this.buffer.get(bytes, f, to);
    }
    
    @Override
    public int skipBytes(final int i) {
        this.buffer.position(this.buffer.position() + i);
        return i;
    }
    
    @Override
    public boolean readBoolean() {
        return this.buffer.get() == 1;
    }
    
    @Override
    public byte readByte() {
        return this.buffer.get();
    }
    
    @Override
    public int readUnsignedByte() {
        return this.buffer.get() + 128;
    }
    
    @Override
    public short readShort() {
        return this.buffer.getShort();
    }
    
    @Override
    public int readUnsignedShort() {
        return this.buffer.getShort() + 32768;
    }
    
    @Override
    public char readChar() {
        return this.buffer.getChar();
    }
    
    @Override
    public int readInt() {
        return this.buffer.getInt();
    }
    
    @Override
    public long readLong() {
        return this.buffer.getLong();
    }
    
    @Override
    public float readFloat() {
        return this.buffer.getFloat();
    }
    
    @Override
    public double readDouble() {
        return this.buffer.getDouble();
    }
    
    @Override
    public String readLine() {
        throw new RuntimeException("Stub!");
    }
    
    @Override
    public String readUTF() {
        try {
            final short length = this.buffer.getShort();
            final byte[] bytes = new byte[length];
            this.buffer.get(bytes);
            return new String(bytes, "UTF-8");
        }
        catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }
}
