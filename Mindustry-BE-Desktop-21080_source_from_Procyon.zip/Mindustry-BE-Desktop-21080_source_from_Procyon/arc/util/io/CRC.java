// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.io;

public class CRC
{
    public static int[] table;
    int _value;
    
    public CRC() {
        this._value = -1;
    }
    
    public void init() {
        this._value = -1;
    }
    
    public void update(final byte[] data, final int offset, final int size) {
        for (int i = 0; i < size; ++i) {
            this._value = (CRC.table[(this._value ^ data[offset + i]) & 0xFF] ^ this._value >>> 8);
        }
    }
    
    public void update(final byte[] data) {
        final int size = data.length;
        for (final byte datum : data) {
            this._value = (CRC.table[(this._value ^ datum) & 0xFF] ^ this._value >>> 8);
        }
    }
    
    public void updateByte(final int b) {
        this._value = (CRC.table[(this._value ^ b) & 0xFF] ^ this._value >>> 8);
    }
    
    public int getDigest() {
        return ~this._value;
    }
    
    static {
        CRC.table = new int[256];
        for (int i = 0; i < 256; ++i) {
            int r = i;
            for (int j = 0; j < 8; ++j) {
                if ((r & 0x1) != 0x0) {
                    r = (r >>> 1 ^ 0xEDB88320);
                }
                else {
                    r >>>= 1;
                }
            }
            CRC.table[i] = r;
        }
    }
}
