// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.math.Mathf;
import java.util.Iterator;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import arc.graphics.Color;
import arc.graphics.Colors;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import arc.struct.Seq;
import java.nio.charset.Charset;

public class Strings
{
    private static StringBuilder tmp1;
    private static StringBuilder tmp2;
    public static final Charset utf8;
    
    public static int count(final CharSequence s, final char c) {
        int total = 0;
        for (int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) == c) {
                ++total;
            }
        }
        return total;
    }
    
    public static Seq<Throwable> getCauses(Throwable e) {
        final Seq<Throwable> arr = new Seq<Throwable>();
        while (e != null) {
            arr.add(e);
            e = e.getCause();
        }
        return arr;
    }
    
    public static String getSimpleMessage(final Throwable e) {
        final Throwable fcause = getFinalCause(e);
        return (fcause.getMessage() == null) ? fcause.getClass().getSimpleName() : (fcause.getClass().getSimpleName() + ": " + fcause.getMessage());
    }
    
    public static String getFinalMessage(Throwable e) {
        String message = e.getMessage();
        while (e.getCause() != null) {
            e = e.getCause();
            if (e.getMessage() != null) {
                message = e.getMessage();
            }
        }
        return message;
    }
    
    public static Throwable getFinalCause(Throwable e) {
        while (e.getCause() != null) {
            e = e.getCause();
        }
        return e;
    }
    
    public static String getStackTrace(final Throwable e) {
        final StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }
    
    public static String neatError(final Throwable e) {
        return neatError(e, true);
    }
    
    public static String neatError(Throwable e, final boolean stacktrace) {
        final StringBuilder build = new StringBuilder();
        while (e != null) {
            String name = e.getClass().toString().substring("class ".length()).replace("Exception", "");
            if (name.indexOf(46) != -1) {
                name = name.substring(name.lastIndexOf(46) + 1);
            }
            build.append("> ").append(name);
            if (e.getMessage() != null) {
                build.append(": ");
                build.append("'").append(e.getMessage()).append("'");
            }
            if (stacktrace) {
                for (final StackTraceElement s : e.getStackTrace()) {
                    if (!s.getClassName().contains("MethodAccessor")) {
                        if (!s.getClassName().substring(s.getClassName().lastIndexOf(".") + 1).equals("Method")) {
                            build.append("\n");
                            final String className = s.getClassName();
                            build.append(className.substring(className.lastIndexOf(".") + 1)).append(".").append(s.getMethodName()).append(": ").append(s.getLineNumber());
                        }
                    }
                }
            }
            build.append("\n");
            e = e.getCause();
        }
        return build.toString();
    }
    
    public static String stripColors(final CharSequence str) {
        final StringBuilder out = new StringBuilder(str.length());
        int i = 0;
        while (i < str.length()) {
            final char c = str.charAt(i);
            if (c == '[') {
                final int length = parseColorMarkup(str, i + 1, str.length());
                if (length >= 0) {
                    i += length + 2;
                }
                else {
                    out.append(c);
                    ++i;
                }
            }
            else {
                out.append(c);
                ++i;
            }
        }
        return out.toString();
    }
    
    public static String stripGlyphs(final CharSequence str) {
        final StringBuilder out = new StringBuilder(str.length());
        for (int i = 0; i < str.length(); ++i) {
            final int c = str.charAt(i);
            if (c < 57344 || c > 63743) {
                out.append(c);
            }
        }
        return out.toString();
    }
    
    private static int parseColorMarkup(final CharSequence str, final int start, final int end) {
        if (start >= end) {
            return -1;
        }
        switch (str.charAt(start)) {
            case '#': {
                int colorInt = 0;
                int i = start + 1;
                while (i < end) {
                    final char ch = str.charAt(i);
                    if (ch == ']') {
                        if (i < start + 2) {
                            break;
                        }
                        if (i > start + 9) {
                            break;
                        }
                        if (i - start <= 7) {
                            for (int ii = 0, nn = 9 - (i - start); ii < nn; ++ii) {
                                colorInt <<= 4;
                            }
                            colorInt |= 0xFF;
                        }
                        return i - start;
                    }
                    else {
                        if (ch >= '0' && ch <= '9') {
                            colorInt = colorInt * 16 + (ch - '0');
                        }
                        else if (ch >= 'a' && ch <= 'f') {
                            colorInt = colorInt * 16 + (ch - 'W');
                        }
                        else {
                            if (ch < 'A' || ch > 'F') {
                                break;
                            }
                            colorInt = colorInt * 16 + (ch - '7');
                        }
                        ++i;
                    }
                }
                return -1;
            }
            case '[': {
                return -2;
            }
            case ']': {
                return 0;
            }
            default: {
                int j = start + 1;
                while (j < end) {
                    final char ch2 = str.charAt(j);
                    if (ch2 != ']') {
                        ++j;
                    }
                    else {
                        final Color namedColor = Colors.get(str.subSequence(start, j).toString());
                        if (namedColor == null) {
                            return -1;
                        }
                        return j - start;
                    }
                }
                return -1;
            }
        }
    }
    
    public static int count(final String str, final String substring) {
        int lastIndex = 0;
        int count = 0;
        while (lastIndex != -1) {
            lastIndex = str.indexOf(substring, lastIndex);
            if (lastIndex != -1) {
                ++count;
                lastIndex += substring.length();
            }
        }
        return count;
    }
    
    public static String encode(final String str) {
        try {
            return URLEncoder.encode(str, "UTF-8");
        }
        catch (UnsupportedEncodingException why) {
            throw new RuntimeException(why);
        }
    }
    
    public static String format(final String text, final Object... args) {
        if (args.length > 0) {
            final StringBuilder out = new StringBuilder(text.length() + args.length * 2);
            int argi = 0;
            for (int i = 0; i < text.length(); ++i) {
                final char c = text.charAt(i);
                if (c == '@' && argi < args.length) {
                    out.append(args[argi++]);
                }
                else {
                    out.append(c);
                }
            }
            return out.toString();
        }
        return text;
    }
    
    public static String join(final String separator, final String... strings) {
        final StringBuilder builder = new StringBuilder();
        for (final String s : strings) {
            builder.append(s);
            builder.append(separator);
        }
        builder.setLength(builder.length() - separator.length());
        return builder.toString();
    }
    
    public static String join(final String separator, final Iterable<String> strings) {
        final StringBuilder builder = new StringBuilder();
        for (final String s : strings) {
            builder.append(s);
            builder.append(separator);
        }
        builder.setLength(builder.length() - separator.length());
        return builder.toString();
    }
    
    public static int levenshtein(final String x, final String y) {
        final int[][] dp = new int[x.length() + 1][y.length() + 1];
        for (int i = 0; i <= x.length(); ++i) {
            for (int j = 0; j <= y.length(); ++j) {
                if (i == 0) {
                    dp[i][j] = j;
                }
                else if (j == 0) {
                    dp[i][j] = i;
                }
                else {
                    dp[i][j] = Math.min(Math.min(dp[i - 1][j - 1] + ((x.charAt(i - 1) != y.charAt(j - 1)) ? 1 : 0), dp[i - 1][j] + 1), dp[i][j - 1] + 1);
                }
            }
        }
        return dp[x.length()][y.length()];
    }
    
    public static String animated(final float time, final int length, final float scale, final String replacement) {
        return new String(new char[Math.abs((int)(time / scale) % length)]).replace("\u0000", replacement);
    }
    
    public static String kebabToCamel(final String s) {
        final StringBuilder result = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); ++i) {
            final char c = s.charAt(i);
            if (c != '_' && c != '-') {
                if (i != 0 && (s.charAt(i - 1) == '_' || s.charAt(i - 1) == '-')) {
                    result.append(Character.toUpperCase(c));
                }
                else {
                    result.append(c);
                }
            }
        }
        return result.toString();
    }
    
    public static String camelToKebab(final String s) {
        final StringBuilder result = new StringBuilder(s.length() + 1);
        for (int i = 0; i < s.length(); ++i) {
            final char c = s.charAt(i);
            if (i > 0 && Character.isUpperCase(s.charAt(i))) {
                result.append('-');
            }
            result.append(Character.toLowerCase(c));
        }
        return result.toString();
    }
    
    public static String capitalize(final String s) {
        final StringBuilder result = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); ++i) {
            final char c = s.charAt(i);
            if (c == '_' || c == '-') {
                result.append(" ");
            }
            else if (i == 0 || s.charAt(i - 1) == '_' || s.charAt(i - 1) == '-') {
                result.append(Character.toUpperCase(c));
            }
            else {
                result.append(c);
            }
        }
        return result.toString();
    }
    
    public static String insertSpaces(final String s) {
        final StringBuilder result = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); ++i) {
            final char c = s.charAt(i);
            if (i > 0 && Character.isUpperCase(c)) {
                result.append(' ');
            }
            result.append(c);
        }
        return result.toString();
    }
    
    public static String camelize(final String s) {
        final StringBuilder result = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); ++i) {
            final char c = s.charAt(i);
            if (i == 0) {
                result.append(Character.toLowerCase(c));
            }
            else if (c != ' ') {
                result.append(c);
            }
        }
        return result.toString();
    }
    
    public static boolean canParseInt(final String s) {
        return parseInt(s) != Integer.MIN_VALUE;
    }
    
    public static boolean canParsePositiveInt(final String s) {
        final int p = parseInt(s);
        return p >= 0;
    }
    
    public static int parseInt(final String s, final int defaultValue) {
        return parseInt(s, 10, defaultValue);
    }
    
    public static int parseInt(final String s, final int radix, final int defaultValue) {
        boolean negative = false;
        int i = 0;
        final int len = s.length();
        int limit = -2147483647;
        if (len <= 0) {
            return defaultValue;
        }
        final char firstChar = s.charAt(0);
        if (firstChar < '0') {
            if (firstChar == '-') {
                negative = true;
                limit = Integer.MIN_VALUE;
            }
            else if (firstChar != '+') {
                return defaultValue;
            }
            if (len == 1) {
                return defaultValue;
            }
            ++i;
        }
        int result = 0;
        while (i < len) {
            final int digit = Character.digit(s.charAt(i++), radix);
            if (digit < 0) {
                return defaultValue;
            }
            result *= radix;
            if (result < limit + digit) {
                return defaultValue;
            }
            result -= digit;
        }
        return negative ? result : (-result);
    }
    
    public static long parseLong(final String s, final long defaultValue) {
        return parseLong(s, 10, defaultValue);
    }
    
    public static long parseLong(final String s, final int radix, final long defaultValue) {
        return parseLong(s, radix, 0, s.length(), defaultValue);
    }
    
    public static long parseLong(final String s, final int radix, final int start, final int end, final long defaultValue) {
        boolean negative = false;
        int i = start;
        final int len = end - start;
        long limit = -9223372036854775807L;
        if (len <= 0) {
            return defaultValue;
        }
        final char firstChar = s.charAt(i);
        if (firstChar < '0') {
            if (firstChar == '-') {
                negative = true;
                limit = Long.MIN_VALUE;
            }
            else if (firstChar != '+') {
                return defaultValue;
            }
            if (len == 1) {
                return defaultValue;
            }
            ++i;
        }
        long result = 0L;
        while (i < end) {
            final int digit = Character.digit(s.charAt(i++), radix);
            if (digit < 0) {
                return defaultValue;
            }
            result *= radix;
            if (result < limit + digit) {
                return defaultValue;
            }
            result -= digit;
        }
        return negative ? result : (-result);
    }
    
    public static double parseDouble(final String value, final double defaultValue) {
        final int len = value.length();
        if (len == 0) {
            return defaultValue;
        }
        int start = 0;
        int end = len;
        final char last = value.charAt(len - 1);
        final char first = value.charAt(0);
        if (last == 'F' || last == 'f' || last == '.') {
            --end;
        }
        if (first == '+') {
            start = 1;
        }
        int dot = -1;
        int e = -1;
        for (int i = start; i < end; ++i) {
            final char c = value.charAt(i);
            if (c == '.') {
                dot = i;
            }
            if (c == 'e' || c == 'E') {
                e = i;
            }
        }
        if (dot != -1 && dot < end) {
            if (dot == 1 && first == '-') {
                final long dec = parseLong(value, 10, dot + 1, end, Long.MIN_VALUE);
                if (dec < 0L) {
                    return defaultValue;
                }
                return -dec / Math.pow(10.0, end - dot - 1);
            }
            else {
                final long whole = (start == dot) ? 0L : parseLong(value, 10, start, dot, Long.MIN_VALUE);
                if (whole == Long.MIN_VALUE) {
                    return defaultValue;
                }
                final long dec2 = parseLong(value, 10, dot + 1, end, Long.MIN_VALUE);
                if (dec2 < 0L) {
                    return defaultValue;
                }
                return whole + Math.copySign(dec2 / Math.pow(10.0, end - dot - 1), (double)whole);
            }
        }
        else {
            if (e == -1) {
                final long out = parseLong(value, 10, start, end, Long.MIN_VALUE);
                return (out == Long.MIN_VALUE) ? defaultValue : ((double)out);
            }
            final long whole = parseLong(value, 10, start, e, Long.MIN_VALUE);
            if (whole == Long.MIN_VALUE) {
                return defaultValue;
            }
            final long power = parseLong(value, 10, e + 1, end, Long.MIN_VALUE);
            if (power == Long.MIN_VALUE) {
                return defaultValue;
            }
            return whole * Mathf.pow(10.0f, (float)power);
        }
    }
    
    public static int parseInt(final String s) {
        return parseInt(s, Integer.MIN_VALUE);
    }
    
    public static boolean canParseFloat(final String s) {
        try {
            Float.parseFloat(s);
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }
    
    public static boolean canParsePositiveFloat(final String s) {
        try {
            return Float.parseFloat(s) > 0.0f;
        }
        catch (Exception e) {
            return false;
        }
    }
    
    public static int parsePositiveInt(final String s) {
        final int value = parseInt(s, Integer.MIN_VALUE);
        return (value <= 0) ? Integer.MIN_VALUE : value;
    }
    
    public static float parseFloat(final String s) {
        return parseFloat(s, Float.MIN_VALUE);
    }
    
    public static float parseFloat(final String s, final float defaultValue) {
        try {
            return Float.parseFloat(s);
        }
        catch (Exception e) {
            return defaultValue;
        }
    }
    
    public static String autoFixed(final float value, final int max) {
        final int precision = (Math.abs((int)value - value) <= 1.0E-4f) ? 0 : ((Math.abs((int)(value * 10.0f) - value * 10.0f) <= 1.0E-4f) ? 1 : 2);
        return fixed(value, Math.min(precision, max));
    }
    
    public static String fixed(final float d, final int decimalPlaces) {
        return fixedBuilder(d, decimalPlaces).toString();
    }
    
    public static StringBuilder fixedBuilder(final float d, final int decimalPlaces) {
        if (decimalPlaces < 0 || decimalPlaces > 8) {
            throw new IllegalArgumentException("Unsupported number of decimal places: " + decimalPlaces);
        }
        final StringBuilder dec = Strings.tmp2;
        Strings.tmp2.setLength(0);
        Strings.tmp2.append((int)(d * Math.pow(10.0, decimalPlaces) + 9.999999974752427E-7));
        final int len = dec.length();
        int decimalPosition = len - decimalPlaces;
        final StringBuilder result = Strings.tmp1;
        Strings.tmp1.setLength(0);
        if (decimalPlaces == 0) {
            return dec;
        }
        if (decimalPosition > 0) {
            result.append(dec, 0, decimalPosition);
            result.append(".");
            result.append(dec, decimalPosition, dec.length());
        }
        else {
            result.append("0.");
            while (decimalPosition++ < 0) {
                result.append("0");
            }
            result.append((CharSequence)dec);
        }
        return result;
    }
    
    public static String formatMillis(long val) {
        final StringBuilder buf = new StringBuilder(20);
        String sgn = "";
        if (val < 0L) {
            sgn = "-";
        }
        val = Math.abs(val);
        append(buf, sgn, 0, val / 3600000L);
        val %= 3600000L;
        append(buf, ":", 2, val / 60000L);
        val %= 60000L;
        append(buf, ":", 2, val / 1000L);
        return buf.toString();
    }
    
    private static void append(final StringBuilder tgt, final String pfx, final int dgt, final long val) {
        tgt.append(pfx);
        if (dgt > 1) {
            int pad = dgt - 1;
            for (long xa = val; xa > 9L && pad > 0; --pad, xa /= 10L) {}
            for (int xa2 = 0; xa2 < pad; ++xa2) {
                tgt.append('0');
            }
        }
        tgt.append(val);
    }
    
    public static StringBuilder replace(final StringBuilder builder, final String find, final String replace) {
        final int findLength = find.length();
        final int replaceLength = replace.length();
        int index = 0;
        while (true) {
            index = builder.indexOf(find, index);
            if (index == -1) {
                break;
            }
            builder.replace(index, index + findLength, replace);
            index += replaceLength;
        }
        return builder;
    }
    
    public static StringBuilder replace(final StringBuilder builder, final char find, final String replace) {
        final int replaceLength = replace.length();
        int index = 0;
        while (index != builder.length()) {
            if (builder.charAt(index) == find) {
                builder.replace(index, index + 1, replace);
                index += replaceLength;
            }
            else {
                ++index;
            }
        }
        return builder;
    }
    
    static {
        Strings.tmp1 = new StringBuilder();
        Strings.tmp2 = new StringBuilder();
        utf8 = Charset.forName("UTF-8");
    }
}
