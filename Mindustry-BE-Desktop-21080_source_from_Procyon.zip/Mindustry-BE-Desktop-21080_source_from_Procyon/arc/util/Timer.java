// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.Files;
import arc.ApplicationListener;
import arc.Application;
import arc.Core;
import arc.struct.Seq;

public class Timer
{
    static final Object threadLock;
    static TimerThread thread;
    final Seq<Task> tasks;
    
    public Timer() {
        this.tasks = new Seq<Task>(false, 8);
        this.start();
    }
    
    public static Timer instance() {
        synchronized (Timer.threadLock) {
            final TimerThread thread = thread();
            if (thread.instance == null) {
                thread.instance = new Timer();
            }
            return thread.instance;
        }
    }
    
    private static TimerThread thread() {
        synchronized (Timer.threadLock) {
            if (Timer.thread == null || Timer.thread.files != Core.files) {
                if (Timer.thread != null) {
                    Timer.thread.dispose();
                }
                Timer.thread = new TimerThread();
            }
            return Timer.thread;
        }
    }
    
    public static Task post(final Task task) {
        return instance().postTask(task);
    }
    
    public static Task schedule(final Task task, final float delaySeconds) {
        return instance().scheduleTask(task, delaySeconds);
    }
    
    public static Task schedule(final Task task, final float delaySeconds, final float intervalSeconds) {
        return instance().scheduleTask(task, delaySeconds, intervalSeconds);
    }
    
    public static Task schedule(final Task task, final float delaySeconds, final float intervalSeconds, final int repeatCount) {
        return instance().scheduleTask(task, delaySeconds, intervalSeconds, repeatCount);
    }
    
    public static Task schedule(final Runnable task, final float delaySeconds) {
        return instance().scheduleTask(new Task() {
            @Override
            public void run() {
                task.run();
            }
        }, delaySeconds);
    }
    
    public static Task schedule(final Runnable task, final float delaySeconds, final float intervalSeconds) {
        return instance().scheduleTask(new Task() {
            @Override
            public void run() {
                task.run();
            }
        }, delaySeconds, intervalSeconds);
    }
    
    public static Task schedule(final Runnable task, final float delaySeconds, final float intervalSeconds, final int repeatCount) {
        return instance().scheduleTask(new Task() {
            @Override
            public void run() {
                task.run();
            }
        }, delaySeconds, intervalSeconds, repeatCount);
    }
    
    public Task postTask(final Task task) {
        return this.scheduleTask(task, 0.0f, 0.0f, 0);
    }
    
    public Task scheduleTask(final Task task, final float delaySeconds) {
        return this.scheduleTask(task, delaySeconds, 0.0f, 0);
    }
    
    public Task scheduleTask(final Task task, final float delaySeconds, final float intervalSeconds) {
        return this.scheduleTask(task, delaySeconds, intervalSeconds, -1);
    }
    
    public Task scheduleTask(final Task task, final float delaySeconds, final float intervalSeconds, final int repeatCount) {
        synchronized (this) {
            synchronized (task) {
                if (task.timer != null) {
                    throw new IllegalArgumentException("The same task may not be scheduled twice.");
                }
                task.timer = this;
                task.executeTimeMillis = System.nanoTime() / 1000000L + (long)(delaySeconds * 1000.0f);
                task.intervalMillis = (long)(intervalSeconds * 1000.0f);
                task.repeatCount = repeatCount;
                this.tasks.add(task);
            }
        }
        synchronized (Timer.threadLock) {
            Timer.threadLock.notifyAll();
        }
        return task;
    }
    
    public void stop() {
        synchronized (Timer.threadLock) {
            thread().instances.remove(this, true);
        }
    }
    
    public void start() {
        synchronized (Timer.threadLock) {
            final TimerThread thread = thread();
            final Seq<Timer> instances = thread.instances;
            if (instances.contains(this, true)) {
                return;
            }
            instances.add(this);
            Timer.threadLock.notifyAll();
        }
    }
    
    public synchronized void clear() {
        for (int i = 0, n = this.tasks.size; i < n; ++i) {
            final Task task = this.tasks.get(i);
            synchronized (task) {
                task.executeTimeMillis = 0L;
                task.timer = null;
            }
        }
        this.tasks.clear();
    }
    
    public synchronized boolean isEmpty() {
        return this.tasks.size == 0;
    }
    
    synchronized long update(final long timeMillis, long waitMillis) {
        for (int i = 0, n = this.tasks.size; i < n; ++i) {
            final Task task = this.tasks.get(i);
            synchronized (task) {
                if (task.executeTimeMillis > timeMillis) {
                    waitMillis = Math.min(waitMillis, task.executeTimeMillis - timeMillis);
                }
                else {
                    if (task.repeatCount == 0) {
                        task.timer = null;
                        this.tasks.remove(i);
                        --i;
                        --n;
                    }
                    else {
                        task.executeTimeMillis = timeMillis + task.intervalMillis;
                        waitMillis = Math.min(waitMillis, task.intervalMillis);
                        if (task.repeatCount > 0) {
                            final Task task2 = task;
                            --task2.repeatCount;
                        }
                    }
                    task.app.post(task);
                }
            }
        }
        return waitMillis;
    }
    
    public synchronized void delay(final long delayMillis) {
        for (int i = 0, n = this.tasks.size; i < n; ++i) {
            final Task task = this.tasks.get(i);
            synchronized (task) {
                final Task task2 = task;
                task2.executeTimeMillis += delayMillis;
            }
        }
    }
    
    static {
        threadLock = new Object();
    }
    
    public abstract static class Task implements Runnable
    {
        final Application app;
        long executeTimeMillis;
        long intervalMillis;
        int repeatCount;
        volatile Timer timer;
        
        public Task() {
            this.app = Core.app;
            if (this.app == null) {
                throw new IllegalStateException("Core.app not available.");
            }
        }
        
        @Override
        public abstract void run();
        
        public void cancel() {
            final Timer timer = this.timer;
            if (timer != null) {
                synchronized (timer) {
                    synchronized (this) {
                        this.executeTimeMillis = 0L;
                        this.timer = null;
                        timer.tasks.remove(this, true);
                    }
                }
            }
            else {
                synchronized (this) {
                    this.executeTimeMillis = 0L;
                    this.timer = null;
                }
            }
        }
        
        public boolean isScheduled() {
            return this.timer != null;
        }
        
        public synchronized long getExecuteTimeMillis() {
            return this.executeTimeMillis;
        }
    }
    
    static class TimerThread implements Runnable, ApplicationListener
    {
        final Files files;
        final Seq<Timer> instances;
        Timer instance;
        private long pauseMillis;
        
        public TimerThread() {
            this.instances = new Seq<Timer>(1);
            this.files = Core.files;
            Core.app.addListener(this);
            this.resume();
            final Thread thread = new Thread(this, "Timer");
            thread.setDaemon(true);
            thread.start();
        }
        
        @Override
        public void run() {
            while (true) {
                synchronized (Timer.threadLock) {
                    if (Timer.thread != this || this.files != Core.files) {
                        break;
                    }
                    long waitMillis = 5000L;
                    if (this.pauseMillis == 0L) {
                        final long timeMillis = System.nanoTime() / 1000000L;
                        for (int i = 0, n = this.instances.size; i < n; ++i) {
                            try {
                                waitMillis = this.instances.get(i).update(timeMillis, waitMillis);
                            }
                            catch (Throwable ex) {
                                throw new ArcRuntimeException("Task failed: " + this.instances.get(i).getClass().getName(), ex);
                            }
                        }
                    }
                    if (Timer.thread != this || this.files != Core.files) {
                        break;
                    }
                    try {
                        if (waitMillis <= 0L) {
                            continue;
                        }
                        Timer.threadLock.wait(waitMillis);
                    }
                    catch (InterruptedException ex2) {}
                }
            }
            this.dispose();
        }
        
        @Override
        public void resume() {
            if (Core.app.isDesktop()) {
                return;
            }
            synchronized (Timer.threadLock) {
                final long delayMillis = System.nanoTime() / 1000000L - this.pauseMillis;
                for (int i = 0, n = this.instances.size; i < n; ++i) {
                    this.instances.get(i).delay(delayMillis);
                }
                this.pauseMillis = 0L;
                Timer.threadLock.notifyAll();
            }
        }
        
        @Override
        public void pause() {
            if (Core.app.isDesktop()) {
                return;
            }
            synchronized (Timer.threadLock) {
                this.pauseMillis = System.nanoTime() / 1000000L;
                Timer.threadLock.notifyAll();
            }
        }
        
        @Override
        public void dispose() {
            synchronized (Timer.threadLock) {
                if (Timer.thread == this) {
                    Timer.thread = null;
                }
                this.instances.clear();
                Timer.threadLock.notifyAll();
            }
            Core.app.removeListener(this);
        }
    }
}
