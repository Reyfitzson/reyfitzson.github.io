// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.func.Cons;
import arc.func.Intf;
import arc.func.Floatf;
import arc.func.Func;
import java.util.Comparator;
import arc.struct.Seq;
import arc.math.Mathf;
import java.util.Iterator;
import arc.func.Boolf;

public class Structs
{
    public static boolean eq(final Object a, final Object b) {
        return a == b || (a != null && a.equals(b));
    }
    
    public static <T> T[] arr(final T... array) {
        return array;
    }
    
    public static <T> void filter(final Iterable<T> iterable, final Boolf<T> removal) {
        filter(iterable.iterator(), removal);
    }
    
    public static <T> void filter(final Iterator<T> it, final Boolf<T> removal) {
        while (it.hasNext()) {
            if (removal.get(it.next())) {
                it.remove();
            }
        }
    }
    
    public static <T> T random(final T[] array) {
        if (array.length == 0) {
            return null;
        }
        return array[Mathf.random(array.length - 1)];
    }
    
    public static <T> T select(final T... array) {
        if (array.length == 0) {
            return null;
        }
        return array[Mathf.random(array.length - 1)];
    }
    
    public static <T> int count(final T[] array, final Boolf<T> value) {
        int total = 0;
        for (final T t : array) {
            if (value.get(t)) {
                ++total;
            }
        }
        return total;
    }
    
    public static <T> boolean contains(final T[] array, final T value) {
        for (final T t : array) {
            if (t == value || (value != null && value.equals(t))) {
                return true;
            }
        }
        return false;
    }
    
    public static <T> boolean contains(final T[] array, final Boolf<T> value) {
        return find(array, value) != null;
    }
    
    public static <T> T find(final T[] array, final Boolf<T> value) {
        for (final T t : array) {
            if (value.get(t)) {
                return t;
            }
        }
        return null;
    }
    
    public static <T> int indexOf(final T[] array, final T value) {
        for (int i = 0; i < array.length; ++i) {
            if (array[i] == value) {
                return i;
            }
        }
        return -1;
    }
    
    public static <T> int indexOf(final T[] array, final Boolf<T> value) {
        for (int i = 0; i < array.length; ++i) {
            if (value.get(array[i])) {
                return i;
            }
        }
        return -1;
    }
    
    public static <T> T[] filter(final Class<T> type, final T[] array, final Boolf<T> value) {
        final Seq<T> out = new Seq<T>(true, array.length, type);
        for (final T t : array) {
            if (value.get(t)) {
                out.add(t);
            }
        }
        return out.toArray();
    }
    
    public static <T> Comparator<T> comps(final Comparator<T> first, final Comparator<T> second) {
        final int value;
        return (a, b) -> {
            value = first.compare(a, b);
            return (value != 0) ? value : second.compare(a, b);
        };
    }
    
    public static <T, U> Comparator<T> comparing(final Func<? super T, ? extends U> keyExtractor, final Comparator<? super U> keyComparator) {
        return (c1, c2) -> keyComparator.compare((Object)keyExtractor.get((Object)c1), (Object)keyExtractor.get((Object)c2));
    }
    
    public static <T, U extends Comparable<? super U>> Comparator<T> comparing(final Func<? super T, ? extends U> keyExtractor) {
        return (c1, c2) -> ((Comparable)keyExtractor.get((Object)c1)).compareTo(keyExtractor.get((Object)c2));
    }
    
    public static <T> Comparator<T> comparingFloat(final Floatf<? super T> keyExtractor) {
        return (c1, c2) -> Float.compare(keyExtractor.get((Object)c1), keyExtractor.get((Object)c2));
    }
    
    public static <T> Comparator<T> comparingInt(final Intf<? super T> keyExtractor) {
        return (c1, c2) -> Integer.compare(keyExtractor.get((Object)c1), keyExtractor.get((Object)c2));
    }
    
    public static <T> Comparator<T> comparingBool(final Boolf<? super T> keyExtractor) {
        return (c1, c2) -> Boolean.compare(keyExtractor.get((Object)c1), keyExtractor.get((Object)c2));
    }
    
    public static <T> void each(final Cons<T> cons, final T... objects) {
        for (final T t : objects) {
            cons.get(t);
        }
    }
    
    public static <T> void forEach(final Iterable<T> i, final Cons<T> cons) {
        for (final T t : i) {
            cons.get(t);
        }
    }
    
    public static <T> T findMin(final T[] arr, final Comparator<T> comp) {
        T result = null;
        for (final T t : arr) {
            if (result == null || comp.compare(result, t) < 0) {
                result = t;
            }
        }
        return result;
    }
    
    public static <T> T findMin(final T[] arr, final Floatf<T> proc) {
        T result = null;
        float min = Float.MAX_VALUE;
        for (final T t : arr) {
            final float val = proc.get(t);
            if (val <= min) {
                result = t;
                min = val;
            }
        }
        return result;
    }
    
    public static <T> T findMin(final Iterable<T> arr, final Comparator<T> comp) {
        T result = null;
        for (final T t : arr) {
            if (result == null || comp.compare(result, t) < 0) {
                result = t;
            }
        }
        return result;
    }
    
    public static <T> T findMin(final Iterable<T> arr, final Boolf<T> allow, final Comparator<T> comp) {
        T result = null;
        for (final T t : arr) {
            if (allow.get(t) && (result == null || comp.compare(result, t) < 0)) {
                result = t;
            }
        }
        return result;
    }
    
    public static <T> boolean inBounds(final int x, final int y, final T[][] array) {
        return x >= 0 && y >= 0 && x < array.length && y < array[0].length;
    }
    
    public static boolean inBounds(final int x, final int y, final int[][] array) {
        return x >= 0 && y >= 0 && x < array.length && y < array[0].length;
    }
    
    public static boolean inBounds(final int x, final int y, final float[][] array) {
        return x >= 0 && y >= 0 && x < array.length && y < array[0].length;
    }
    
    public static boolean inBounds(final int x, final int y, final boolean[][] array) {
        return x >= 0 && y >= 0 && x < array.length && y < array[0].length;
    }
    
    public static <T> boolean inBounds(final int x, final int y, final int z, final T[][][] array) {
        return x >= 0 && y >= 0 && z >= 0 && x < array.length && y < array[0].length && z < array[0][0].length;
    }
    
    public static boolean inBounds(final int x, final int y, final int z, final int[][][] array) {
        return x >= 0 && y >= 0 && z >= 0 && x < array.length && y < array[0].length && z < array[0][0].length;
    }
    
    public static boolean inBounds(final int x, final int y, final int z, final int size, final int padding) {
        return x >= padding && y >= padding && z >= padding && x < size - padding && y < size - padding && z < size - padding;
    }
    
    public static boolean inBounds(final int x, final int y, final int width, final int height) {
        return x >= 0 && y >= 0 && x < width && y < height;
    }
}
