// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.util.io.PropertiesUtils;
import java.io.Reader;
import java.io.Closeable;
import arc.util.io.Streams;
import java.util.ArrayList;
import java.util.List;
import java.util.MissingResourceException;
import arc.files.Fi;
import arc.struct.ObjectMap;
import java.util.Locale;

public class I18NBundle
{
    private static final String DEFAULT_ENCODING = "UTF-8";
    private static final Locale ROOT_LOCALE;
    private static boolean simpleFormatter;
    private I18NBundle parent;
    private Locale locale;
    private ObjectMap<String, String> properties;
    private TextFormatter formatter;
    
    public static boolean getSimpleFormatter() {
        return I18NBundle.simpleFormatter;
    }
    
    public static void setSimpleFormatter(final boolean enabled) {
        I18NBundle.simpleFormatter = enabled;
    }
    
    public static I18NBundle createEmptyBundle() {
        final I18NBundle bundle = new I18NBundle();
        bundle.locale = I18NBundle.ROOT_LOCALE;
        bundle.properties = new ObjectMap<String, String>();
        return bundle;
    }
    
    public static I18NBundle createBundle(final Fi baseFileHandle) {
        return createBundleImpl(baseFileHandle, Locale.getDefault(), "UTF-8");
    }
    
    public static I18NBundle createBundle(final Fi baseFileHandle, final Locale locale) {
        return createBundleImpl(baseFileHandle, locale, "UTF-8");
    }
    
    public static I18NBundle createBundle(final Fi baseFileHandle, final String encoding) {
        return createBundleImpl(baseFileHandle, Locale.getDefault(), encoding);
    }
    
    public static I18NBundle createBundle(final Fi baseFileHandle, final Locale locale, final String encoding) {
        return createBundleImpl(baseFileHandle, locale, encoding);
    }
    
    private static I18NBundle createBundleImpl(final Fi baseFileHandle, final Locale locale, final String encoding) {
        if (baseFileHandle == null || locale == null || encoding == null) {
            throw new NullPointerException();
        }
        I18NBundle baseBundle = null;
        Locale targetLocale = locale;
        I18NBundle bundle;
        do {
            final List<Locale> candidateLocales = getCandidateLocales(targetLocale);
            bundle = loadBundleChain(baseFileHandle, encoding, candidateLocales, 0, baseBundle);
            if (bundle != null) {
                final Locale bundleLocale = bundle.locale;
                final boolean isBaseBundle = bundleLocale.equals(I18NBundle.ROOT_LOCALE);
                if (!isBaseBundle) {
                    break;
                }
                if (bundleLocale.equals(locale)) {
                    break;
                }
                if (candidateLocales.size() == 1 && bundleLocale.equals(candidateLocales.get(0))) {
                    break;
                }
                if (baseBundle == null) {
                    baseBundle = bundle;
                }
            }
            targetLocale = getFallbackLocale(targetLocale);
        } while (targetLocale != null);
        if (bundle == null) {
            if (baseBundle == null) {
                throw new MissingResourceException("Can't find bundle for base file handle " + baseFileHandle.path() + ", locale " + locale, baseFileHandle + "_" + locale, "");
            }
            bundle = baseBundle;
        }
        return bundle;
    }
    
    private static List<Locale> getCandidateLocales(final Locale locale) {
        final String language = locale.getLanguage();
        final String country = locale.getCountry();
        final String variant = locale.getVariant();
        final List<Locale> locales = new ArrayList<Locale>(4);
        if (variant.length() > 0) {
            locales.add(locale);
        }
        if (country.length() > 0) {
            locales.add(locales.isEmpty() ? locale : new Locale(language, country));
        }
        if (language.length() > 0) {
            locales.add(locales.isEmpty() ? locale : new Locale(language));
        }
        locales.add(I18NBundle.ROOT_LOCALE);
        return locales;
    }
    
    private static Locale getFallbackLocale(final Locale locale) {
        final Locale defaultLocale = Locale.getDefault();
        return locale.equals(defaultLocale) ? null : defaultLocale;
    }
    
    private static I18NBundle loadBundleChain(final Fi baseFileHandle, final String encoding, final List<Locale> candidateLocales, final int candidateIndex, final I18NBundle baseBundle) {
        final Locale targetLocale = candidateLocales.get(candidateIndex);
        I18NBundle parent = null;
        if (candidateIndex != candidateLocales.size() - 1) {
            parent = loadBundleChain(baseFileHandle, encoding, candidateLocales, candidateIndex + 1, baseBundle);
        }
        else if (baseBundle != null && targetLocale.equals(I18NBundle.ROOT_LOCALE)) {
            return baseBundle;
        }
        final I18NBundle bundle = loadBundle(baseFileHandle, encoding, targetLocale);
        if (bundle != null) {
            bundle.parent = parent;
            return bundle;
        }
        return parent;
    }
    
    private static I18NBundle loadBundle(final Fi baseFileHandle, final String encoding, final Locale targetLocale) {
        I18NBundle bundle = null;
        Reader reader = null;
        try {
            final Fi fileHandle = toFileHandle(baseFileHandle, targetLocale);
            if (checkFileExistence(fileHandle)) {
                bundle = new I18NBundle();
                reader = fileHandle.reader(encoding);
                bundle.load(reader);
            }
        }
        finally {
            Streams.close(reader);
        }
        if (bundle != null) {
            bundle.setLocale(targetLocale);
        }
        return bundle;
    }
    
    private static boolean checkFileExistence(final Fi fh) {
        try {
            fh.read().close();
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }
    
    private static Fi toFileHandle(final Fi baseFileHandle, final Locale locale) {
        final StringBuilder sb = new StringBuilder(baseFileHandle.name());
        if (!locale.equals(I18NBundle.ROOT_LOCALE)) {
            final String language = locale.getLanguage();
            final String country = locale.getCountry();
            final String variant = locale.getVariant();
            final boolean emptyLanguage = "".equals(language);
            final boolean emptyCountry = "".equals(country);
            final boolean emptyVariant = "".equals(variant);
            if (!emptyLanguage || !emptyCountry || !emptyVariant) {
                sb.append('_');
                if (!emptyVariant) {
                    sb.append(language).append('_').append(country).append('_').append(variant);
                }
                else if (!emptyCountry) {
                    sb.append(language).append('_').append(country);
                }
                else {
                    sb.append(language);
                }
            }
        }
        return baseFileHandle.sibling(sb.append(".properties").toString());
    }
    
    private void load(final Reader reader) {
        PropertiesUtils.load(this.properties = new ObjectMap<String, String>(), reader);
    }
    
    public Locale getLocale() {
        return this.locale;
    }
    
    private void setLocale(final Locale locale) {
        this.locale = locale;
        this.formatter = new TextFormatter(locale, !I18NBundle.simpleFormatter);
    }
    
    public final String get(final String key) {
        String result = this.properties.get(key);
        if (result == null) {
            if (this.parent != null) {
                result = this.parent.get(key);
            }
            if (result == null) {
                return "???" + key + "???";
            }
        }
        return result;
    }
    
    public String get(final String key, final String def) {
        return this.has(key) ? this.get(key) : def;
    }
    
    public String getOrNull(final String key) {
        return this.has(key) ? this.get(key) : null;
    }
    
    public String getNotNull(final String key) {
        final String s = this.getOrNull(key);
        if (s == null) {
            throw new MissingResourceException("No key with name \"" + key + "\" found!", this.getClass().getName(), key);
        }
        return s;
    }
    
    public Iterable<String> getKeys() {
        return (Iterable<String>)this.properties.keys();
    }
    
    public ObjectMap<String, String> getProperties() {
        return this.properties;
    }
    
    public void setProperties(final ObjectMap<String, String> properties) {
        this.properties = properties;
    }
    
    public boolean has(final String key) {
        return this.properties.containsKey(key) || (this.parent != null && this.parent.has(key));
    }
    
    public String format(final String key, final Object... args) {
        return this.formatter.format(this.get(key), args);
    }
    
    public String formatFloat(final String key, final float value, final int places) {
        return this.formatter.format(this.get(key), Strings.fixed(value, places));
    }
    
    public void debug(final String placeholder) {
        final ObjectMap.Keys<String> keys = this.properties.keys();
        if (keys == null) {
            return;
        }
        for (final String s : keys) {
            this.properties.put(s, placeholder);
        }
    }
    
    public I18NBundle getParent() {
        return this.parent;
    }
    
    static {
        ROOT_LOCALE = new Locale("", "", "");
        I18NBundle.simpleFormatter = false;
    }
}
