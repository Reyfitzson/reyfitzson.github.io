// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import java.util.Arrays;

public class Interval
{
    float[] times;
    
    public Interval(final int capacity) {
        this.times = new float[capacity];
    }
    
    public Interval() {
        this(1);
    }
    
    public boolean get(final float time) {
        return this.get(0, time);
    }
    
    public boolean get(final int id, final float time) {
        if (id >= this.times.length) {
            throw new RuntimeException("Out of bounds! Max timer size is " + this.times.length + "!");
        }
        final boolean got = this.check(id, time);
        if (got) {
            this.times[id] = Time.time;
        }
        return got;
    }
    
    public boolean check(final int id, final float time) {
        return Time.time - this.times[id] >= time || Time.time < this.times[id];
    }
    
    public void reset(final int id, final float time) {
        this.times[id] = Time.time - time;
    }
    
    public void clear() {
        Arrays.fill(this.times, 0.0f);
    }
    
    public float getTime(final int id) {
        return Time.time - this.times[id];
    }
    
    public float[] getTimes() {
        return this.times;
    }
}
