// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

public class Ratekeeper
{
    public int occurences;
    public long lastTime;
    
    public boolean allow(final long spacing, final int cap) {
        if (Time.timeSinceMillis(this.lastTime) > spacing) {
            this.occurences = 0;
            this.lastTime = Time.millis();
        }
        ++this.occurences;
        return this.occurences <= cap;
    }
}
