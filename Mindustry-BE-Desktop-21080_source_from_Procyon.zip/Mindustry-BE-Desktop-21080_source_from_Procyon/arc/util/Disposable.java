// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

public interface Disposable
{
    void dispose();
    
    default boolean isDisposed() {
        return false;
    }
}
