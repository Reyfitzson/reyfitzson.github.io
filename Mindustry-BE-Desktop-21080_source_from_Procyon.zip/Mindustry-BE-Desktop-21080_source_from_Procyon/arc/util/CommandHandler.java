// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.func.Cons;
import arc.struct.Seq;
import arc.struct.ObjectMap;

public class CommandHandler
{
    private final ObjectMap<String, Command> commands;
    private final Seq<Command> orderedCommands;
    private String prefix;
    
    public CommandHandler(final String prefix) {
        this.commands = new ObjectMap<String, Command>();
        this.orderedCommands = new Seq<Command>();
        this.prefix = prefix;
    }
    
    public void setPrefix(final String prefix) {
        this.prefix = prefix;
    }
    
    public String getPrefix() {
        return this.prefix;
    }
    
    public CommandResponse handleMessage(final String message) {
        return this.handleMessage(message, null);
    }
    
    public CommandResponse handleMessage(String message, final Object params) {
        if (message == null || !message.startsWith(this.prefix)) {
            return new CommandResponse(ResponseType.noCommand, null, null);
        }
        message = message.substring(this.prefix.length());
        final String commandstr = message.contains(" ") ? message.substring(0, message.indexOf(" ")) : message;
        String argstr = message.contains(" ") ? message.substring(commandstr.length() + 1) : "";
        final Seq<String> result = new Seq<String>();
        final Command command = this.commands.get(commandstr);
        if (command != null) {
            int index = 0;
            boolean satisfied = false;
            while (index < command.params.length || argstr.isEmpty()) {
                if (!argstr.isEmpty()) {
                    if (command.params[index].optional || index >= command.params.length - 1 || command.params[index + 1].optional) {
                        satisfied = true;
                    }
                    if (command.params[index].variadic) {
                        result.add(argstr);
                    }
                    else {
                        final int next = argstr.indexOf(" ");
                        if (next != -1) {
                            final String arg = argstr.substring(0, next);
                            argstr = argstr.substring(arg.length() + 1);
                            result.add(arg);
                            ++index;
                            continue;
                        }
                        if (!satisfied) {
                            return new CommandResponse(ResponseType.fewArguments, command, commandstr);
                        }
                        result.add(argstr);
                    }
                }
                if (!satisfied && command.params.length > 0 && !command.params[0].optional) {
                    return new CommandResponse(ResponseType.fewArguments, command, commandstr);
                }
                command.runner.accept(result.toArray(String.class), params);
                return new CommandResponse(ResponseType.valid, command, commandstr);
            }
            return new CommandResponse(ResponseType.manyArguments, command, commandstr);
        }
        return new CommandResponse(ResponseType.unknownCommand, null, commandstr);
    }
    
    public void removeCommand(final String text) {
        final Command c = this.commands.get(text);
        if (c == null) {
            return;
        }
        this.commands.remove(text);
        this.orderedCommands.remove(c);
    }
    
    public <T> Command register(final String text, final String description, final CommandRunner<T> runner) {
        final Command cmd = new Command(text, "", description, runner);
        this.commands.put(text.toLowerCase(), cmd);
        this.orderedCommands.add(cmd);
        return cmd;
    }
    
    public <T> Command register(final String text, final String params, final String description, final CommandRunner<T> runner) {
        final Command cmd = new Command(text, params, description, runner);
        this.commands.put(text.toLowerCase(), cmd);
        this.orderedCommands.add(cmd);
        return cmd;
    }
    
    public Command register(final String text, final String description, final Cons<String[]> runner) {
        return this.register(text, description, (args, p) -> runner.get(args));
    }
    
    public Command register(final String text, final String params, final String description, final Cons<String[]> runner) {
        return this.register(text, params, description, (args, p) -> runner.get(args));
    }
    
    public Seq<Command> getCommandList() {
        return this.orderedCommands;
    }
    
    public enum ResponseType
    {
        noCommand, 
        unknownCommand, 
        fewArguments, 
        manyArguments, 
        valid;
    }
    
    public static class Command
    {
        public final String text;
        public final String paramText;
        public final String description;
        public final CommandParam[] params;
        final CommandRunner runner;
        
        public Command(final String text, final String paramText, final String description, final CommandRunner runner) {
            this.text = text;
            this.paramText = paramText;
            this.runner = runner;
            this.description = description;
            final String[] psplit = paramText.split(" ");
            if (paramText.length() == 0) {
                this.params = new CommandParam[0];
            }
            else {
                this.params = new CommandParam[psplit.length];
                boolean hadOptional = false;
                for (int i = 0; i < this.params.length; ++i) {
                    final String param = psplit[i];
                    if (param.length() <= 2) {
                        throw new IllegalArgumentException("Malformed param '" + param + "'");
                    }
                    final char l = param.charAt(0);
                    final char r = param.charAt(param.length() - 1);
                    boolean variadic = false;
                    boolean optional;
                    if (l == '<' && r == '>') {
                        if (hadOptional) {
                            throw new IllegalArgumentException("Can't have non-optional param after optional param!");
                        }
                        optional = false;
                    }
                    else {
                        if (l != '[' || r != ']') {
                            throw new IllegalArgumentException("Malformed param '" + param + "'");
                        }
                        optional = true;
                    }
                    if (optional) {
                        hadOptional = true;
                    }
                    String fname = param.substring(1, param.length() - 1);
                    if (fname.endsWith("...")) {
                        if (i != this.params.length - 1) {
                            throw new IllegalArgumentException("A variadic parameter should be the last parameter!");
                        }
                        fname = fname.substring(0, fname.length() - 3);
                        variadic = true;
                    }
                    this.params[i] = new CommandParam(fname, optional, variadic);
                }
            }
        }
    }
    
    public static class CommandParam
    {
        public final String name;
        public final boolean optional;
        public final boolean variadic;
        
        public CommandParam(final String name, final boolean optional, final boolean variadic) {
            this.name = name;
            this.optional = optional;
            this.variadic = variadic;
        }
    }
    
    public static class CommandResponse
    {
        public final ResponseType type;
        public final Command command;
        public final String runCommand;
        
        public CommandResponse(final ResponseType type, final Command command, final String runCommand) {
            this.type = type;
            this.command = command;
            this.runCommand = runCommand;
        }
    }
    
    public interface CommandRunner<T>
    {
        void accept(final String[] p0, final T p1);
    }
}
