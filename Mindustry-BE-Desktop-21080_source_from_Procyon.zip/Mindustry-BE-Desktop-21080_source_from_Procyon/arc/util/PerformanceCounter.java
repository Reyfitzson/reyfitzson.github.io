// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.math.FloatCounter;

public class PerformanceCounter
{
    private static final float nano2seconds = 1.0E-9f;
    public final FloatCounter time;
    public final FloatCounter load;
    public final String name;
    public float current;
    public boolean valid;
    private long startTime;
    private long lastTick;
    
    public PerformanceCounter(final String name) {
        this(name, 5);
    }
    
    public PerformanceCounter(final String name, final int windowSize) {
        this.current = 0.0f;
        this.valid = false;
        this.startTime = 0L;
        this.lastTick = 0L;
        this.name = name;
        this.time = new FloatCounter(windowSize);
        this.load = new FloatCounter(1);
    }
    
    public void tick() {
        final long t = Time.nanos();
        if (this.lastTick > 0L) {
            this.tick((t - this.lastTick) * 1.0E-9f);
        }
        this.lastTick = t;
    }
    
    public void tick(final float delta) {
        if (!this.valid) {
            Log.err("[PerformanceCounter] Invalid data, check if you called PerformanceCounter#stop()", new Object[0]);
            return;
        }
        this.time.put(this.current / 1.0E-9f);
        final float currentLoad = (delta == 0.0f) ? 0.0f : (this.current / delta);
        this.load.put((delta > 1.0f) ? currentLoad : (delta * currentLoad + (1.0f - delta) * this.load.latest));
        this.current = 0.0f;
        this.valid = false;
    }
    
    public void start() {
        this.startTime = Time.nanos();
        this.valid = false;
    }
    
    public void stop() {
        if (this.startTime > 0L) {
            this.current += (Time.nanos() - this.startTime) * 1.0E-9f;
            this.startTime = 0L;
            this.valid = true;
        }
    }
    
    public void reset() {
        this.time.reset();
        this.load.reset();
        this.startTime = 0L;
        this.lastTick = 0L;
        this.current = 0.0f;
        this.valid = false;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        return this.toString(sb).toString();
    }
    
    public StringBuilder toString(final StringBuilder sb) {
        sb.append(this.name).append(":\n  time: ");
        this.commas(sb, (int)this.time.value);
        sb.append("\n  load: ").append((int)(this.load.value * 100.0f)).append('%');
        return sb;
    }
    
    private void commas(final StringBuilder builder, int number) {
        final StringBuilder sub = new StringBuilder();
        int index = 0;
        while (number > 0) {
            final int digit = number % 10;
            sub.append(digit);
            number /= 10;
            if (++index % 3 == 0 && number > 0) {
                sub.append(',');
            }
        }
        builder.append((CharSequence)sub.reverse());
    }
}
