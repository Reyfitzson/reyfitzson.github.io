// 
// Decompiled by Procyon v0.5.36
// 

package arc.util.viewport;

import arc.graphics.Camera;
import arc.util.Scaling;

public class FitViewport extends ScalingViewport
{
    public FitViewport(final float worldWidth, final float worldHeight) {
        super(Scaling.fit, worldWidth, worldHeight);
    }
    
    public FitViewport(final float worldWidth, final float worldHeight, final Camera camera) {
        super(Scaling.fit, worldWidth, worldHeight, camera);
    }
}
