// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

import arc.files.Fi;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import arc.Core;

public class OS
{
    public static final int cores;
    public static final String username;
    public static final String userhome;
    public static boolean isWindows;
    public static boolean isLinux;
    public static boolean isMac;
    public static boolean isIos;
    public static boolean isAndroid;
    public static boolean isARM;
    public static boolean is64Bit;
    
    public static String getAppDataDirectoryString(final String appname) {
        if (OS.isWindows) {
            return env("AppData") + "\\\\" + appname;
        }
        if (OS.isIos || OS.isAndroid) {
            return Core.files.getLocalStoragePath();
        }
        if (OS.isLinux) {
            if (System.getenv("XDG_DATA_HOME") != null) {
                String dir = System.getenv("XDG_DATA_HOME");
                if (!dir.endsWith("/")) {
                    dir += "/";
                }
                return dir + appname + "/";
            }
            return prop("user.home") + "/.local/share/" + appname + "/";
        }
        else {
            if (OS.isMac) {
                return prop("user.home") + "/Library/Application Support/" + appname + "/";
            }
            return null;
        }
    }
    
    public static String exec(final String... args) {
        try {
            final Process process = Runtime.getRuntime().exec(args);
            final BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
            final StringBuilder result = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line).append("\n");
            }
            final BufferedReader inerr = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            while ((line = inerr.readLine()) != null) {
                result.append(line).append("\n");
            }
            return result.toString();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static boolean execSafe(final String command) {
        try {
            final BufferedReader in = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(command).getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            return true;
        }
        catch (Throwable t) {
            return false;
        }
    }
    
    public static Fi getAppDataDirectory(final String appname) {
        return Core.files.absolute(getAppDataDirectoryString(appname));
    }
    
    public static boolean hasProp(final String name) {
        return System.getProperty(name) != null;
    }
    
    public static String prop(final String name) {
        return System.getProperty(name);
    }
    
    public static boolean hasEnv(final String name) {
        return System.getenv(name) != null;
    }
    
    public static String env(final String name) {
        return System.getenv(name);
    }
    
    public static String propNoNull(final String name) {
        final String s = prop(name);
        return (s == null) ? "" : s;
    }
    
    static {
        cores = Runtime.getRuntime().availableProcessors();
        username = prop("user.name");
        userhome = prop("user.home");
        OS.isWindows = propNoNull("os.name").contains("Windows");
        OS.isLinux = (propNoNull("os.name").contains("Linux") || propNoNull("os.name").contains("BSD"));
        OS.isMac = propNoNull("os.name").contains("Mac");
        OS.isIos = false;
        OS.isAndroid = false;
        OS.isARM = (propNoNull("os.arch").startsWith("arm") || propNoNull("os.arch").startsWith("aarch64"));
        OS.is64Bit = (propNoNull("os.arch").contains("64") || propNoNull("os.arch").startsWith("armv8"));
        if (propNoNull("java.runtime.name").contains("Android Runtime") || propNoNull("java.vm.vendor").contains("The Android Project") || propNoNull("java.vendor").contains("The Android Project")) {
            OS.isAndroid = true;
            OS.isWindows = false;
            OS.isLinux = false;
            OS.isMac = false;
            OS.is64Bit = false;
        }
        if (propNoNull("moe.platform.name").equals("iOS") || (!OS.isAndroid && !OS.isWindows && !OS.isLinux && !OS.isMac)) {
            OS.isIos = true;
            OS.isAndroid = false;
            OS.isWindows = false;
            OS.isLinux = false;
            OS.isMac = false;
            OS.is64Bit = false;
        }
    }
}
