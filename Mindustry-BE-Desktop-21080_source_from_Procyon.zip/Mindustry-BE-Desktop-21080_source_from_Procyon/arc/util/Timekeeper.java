// 
// Decompiled by Procyon v0.5.36
// 

package arc.util;

public class Timekeeper
{
    private final long intervalms;
    private long time;
    
    public Timekeeper(final float seconds) {
        this.intervalms = (int)(seconds * 1000.0f);
    }
    
    public boolean get() {
        return Time.timeSinceMillis(this.time) > this.intervalms;
    }
    
    public void reset() {
        this.time = Time.millis();
    }
}
