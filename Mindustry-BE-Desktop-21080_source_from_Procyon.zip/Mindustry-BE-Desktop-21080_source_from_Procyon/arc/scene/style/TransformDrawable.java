// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.style;

public interface TransformDrawable extends Drawable
{
    void draw(final float p0, final float p1, final float p2, final float p3, final float p4, final float p5, final float p6, final float p7, final float p8);
}
