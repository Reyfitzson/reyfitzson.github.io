// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.style;

import arc.scene.ui.layout.Scl;
import arc.graphics.g2d.Draw;
import arc.util.Tmp;
import arc.graphics.Color;
import arc.graphics.g2d.TextureRegion;

public class TextureRegionDrawable extends BaseDrawable implements TransformDrawable
{
    protected TextureRegion region;
    protected Color tint;
    protected float scale;
    
    public TextureRegionDrawable() {
        this.tint = new Color(1.0f, 1.0f, 1.0f);
        this.scale = 1.0f;
    }
    
    public TextureRegionDrawable(final TextureRegion region) {
        this.tint = new Color(1.0f, 1.0f, 1.0f);
        this.scale = 1.0f;
        this.setRegion(region);
    }
    
    public TextureRegionDrawable(final TextureRegion region, final float scale) {
        this.tint = new Color(1.0f, 1.0f, 1.0f);
        this.scale = 1.0f;
        this.scale = scale;
        this.setRegion(region);
    }
    
    public TextureRegionDrawable(final TextureRegionDrawable drawable) {
        super(drawable);
        this.tint = new Color(1.0f, 1.0f, 1.0f);
        this.scale = 1.0f;
        this.setRegion(drawable.region);
    }
    
    @Override
    public float imageSize() {
        return (float)this.region.width;
    }
    
    @Override
    public void draw(final float x, final float y, final float width, final float height) {
        Draw.color(Tmp.c1.set(this.tint).mul(Draw.getColor()).toFloatBits());
        Draw.rect(this.region, x + width / 2.0f, y + height / 2.0f, width, height);
    }
    
    @Override
    public void draw(final float x, final float y, final float originX, final float originY, final float width, final float height, final float scaleX, final float scaleY, final float rotation) {
        Draw.color(Tmp.c1.set(this.tint).mul(Draw.getColor()).toFloatBits());
        Draw.rect(this.region, x + width / 2.0f, y + height / 2.0f, width * scaleX, height * scaleY, originX, originY, rotation);
    }
    
    public TextureRegionDrawable set(final TextureRegion region) {
        this.setRegion(region);
        return this;
    }
    
    public TextureRegion getRegion() {
        return this.region;
    }
    
    public void setRegion(final TextureRegion region) {
        this.region = region;
        this.setMinWidth(Scl.scl(this.scale * region.width));
        this.setMinHeight(Scl.scl(this.scale * region.height));
    }
    
    public Drawable tint(final float r, final float g, final float b, final float a) {
        return this.tint(Tmp.c1.set(r, g, b, a));
    }
    
    public Drawable tint(final Color tint) {
        final TextureRegionDrawable drawable = new TextureRegionDrawable(this.region);
        drawable.tint.set(tint);
        return drawable;
    }
}
