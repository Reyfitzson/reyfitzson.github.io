// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.style;

import arc.scene.ui.layout.Scl;
import arc.graphics.g2d.NinePatch;

public class ScaledNinePatchDrawable extends NinePatchDrawable
{
    private float scale;
    
    public ScaledNinePatchDrawable(final NinePatch patch) {
        this(patch, 1.0f);
    }
    
    public ScaledNinePatchDrawable(final NinePatch patch, final float multiplier) {
        this.scale = Scl.scl(1.0f);
        this.scale = Scl.scl(multiplier);
        this.setPatch(patch);
    }
    
    public ScaledNinePatchDrawable(final NinePatchDrawable drawable) {
        super(drawable);
        this.scale = Scl.scl(1.0f);
    }
    
    @Override
    public void draw(final float x, final float y, final float width, final float height) {
        this.getPatch().draw(x, y, 0.0f, 0.0f, width / this.scale, height / this.scale, this.scale, this.scale, 0.0f);
    }
    
    @Override
    public void setPatch(final NinePatch patch) {
        super.setPatch(patch);
        this.setMinWidth(patch.getTotalWidth() * this.scale);
        this.setMinHeight(patch.getTotalHeight() * this.scale);
    }
    
    @Override
    public float getLeftWidth() {
        return this.patch.getPadLeft() * this.scale;
    }
    
    @Override
    public float getRightWidth() {
        return this.patch.getPadRight() * this.scale;
    }
    
    @Override
    public float getTopHeight() {
        return this.patch.getPadTop() * this.scale;
    }
    
    @Override
    public float getBottomHeight() {
        return this.patch.getPadBottom() * this.scale;
    }
}
