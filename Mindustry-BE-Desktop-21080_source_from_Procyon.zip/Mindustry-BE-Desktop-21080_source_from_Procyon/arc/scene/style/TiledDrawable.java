// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.style;

import arc.graphics.Texture;
import arc.util.Tmp;
import arc.graphics.g2d.Draw;
import arc.graphics.g2d.TextureRegion;
import arc.graphics.Color;

public class TiledDrawable extends TextureRegionDrawable
{
    private final Color color;
    private float tileWidth;
    private float tileHeight;
    
    public TiledDrawable() {
        this.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    public TiledDrawable(final TextureRegion region) {
        super(region);
        this.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    public TiledDrawable(final TextureRegionDrawable drawable) {
        super(drawable);
        this.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    @Override
    public void setRegion(final TextureRegion region) {
        super.setRegion(region);
        this.tileWidth = (float)region.width;
        this.tileHeight = (float)region.height;
    }
    
    public void setTileSize(final float w, final float h) {
        this.tileWidth = w;
        this.tileHeight = h;
    }
    
    @Override
    public void draw(float x, float y, final float width, final float height) {
        final TextureRegion region = this.getRegion();
        final float regionWidth = this.tileWidth;
        final float regionHeight = this.tileHeight;
        final int fullX = (int)(width / regionWidth);
        final int fullY = (int)(height / regionHeight);
        final float remainingX = width - regionWidth * fullX;
        final float remainingY = height - regionHeight * fullY;
        final float startX = x;
        final float startY = y;
        Draw.color(this.color);
        for (int i = 0; i < fullX; ++i) {
            y = startY;
            for (int ii = 0; ii < fullY; ++ii) {
                Draw.rect(region, x, y, regionWidth, regionHeight);
                y += regionHeight;
            }
            x += regionWidth;
        }
        final Texture texture = region.texture;
        final float u = region.u;
        final float v2 = region.v2;
        if (remainingX > 0.0f) {
            final float u2 = u + remainingX / texture.width;
            float v3 = region.v;
            y = startY;
            for (int ii2 = 0; ii2 < fullY; ++ii2) {
                Tmp.tr1.set(texture);
                Tmp.tr1.set(u, v2, u2, v3);
                Draw.rect(Tmp.tr1, x + remainingX / 2.0f, y + remainingY / 2.0f, remainingX, remainingY);
                y += regionHeight;
            }
            if (remainingY > 0.0f) {
                v3 = v2 - remainingY / texture.height;
                Tmp.tr1.set(texture);
                Tmp.tr1.set(u, v2, u2, v3);
                Draw.rect(Tmp.tr1, x + remainingX / 2.0f, y + remainingY / 2.0f, remainingX, remainingY);
            }
        }
        if (remainingY > 0.0f) {
            final float u2 = region.u2;
            final float v3 = v2 - remainingY / texture.height;
            x = startX;
            for (int j = 0; j < fullX; ++j) {
                Tmp.tr1.set(texture);
                Tmp.tr1.set(u, v2, u2, v3);
                Draw.rect(Tmp.tr1, x + remainingX / 2.0f, y + remainingY / 2.0f, remainingX, remainingY);
                x += regionWidth;
            }
        }
    }
    
    @Override
    public void draw(final float x, final float y, final float originX, final float originY, final float width, final float height, final float scaleX, final float scaleY, final float rotation) {
        throw new UnsupportedOperationException();
    }
    
    public Color getColor() {
        return this.color;
    }
    
    @Override
    public TiledDrawable tint(final Color tint) {
        final TiledDrawable drawable = new TiledDrawable(this);
        drawable.color.set(tint);
        drawable.setLeftWidth(this.getLeftWidth());
        drawable.setRightWidth(this.getRightWidth());
        drawable.setTopHeight(this.getTopHeight());
        drawable.setBottomHeight(this.getBottomHeight());
        return drawable;
    }
}
