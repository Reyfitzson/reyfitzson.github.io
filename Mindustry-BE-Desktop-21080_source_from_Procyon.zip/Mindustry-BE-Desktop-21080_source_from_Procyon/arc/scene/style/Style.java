// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.style;

public abstract class Style
{
}
