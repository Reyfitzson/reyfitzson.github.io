// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.style;

import arc.graphics.Color;
import arc.graphics.g2d.NinePatch;

public class NinePatchDrawable extends BaseDrawable implements TransformDrawable
{
    protected NinePatch patch;
    
    public NinePatchDrawable() {
    }
    
    public NinePatchDrawable(final NinePatch patch) {
        this.setPatch(patch);
    }
    
    public NinePatchDrawable(final NinePatchDrawable drawable) {
        super(drawable);
        this.setPatch(drawable.patch);
    }
    
    @Override
    public void draw(final float x, final float y, final float width, final float height) {
        this.patch.draw(x, y, width, height);
    }
    
    @Override
    public void draw(final float x, final float y, final float originX, final float originY, final float width, final float height, final float scaleX, final float scaleY, final float rotation) {
        this.patch.draw(x, y, originX, originY, width, height, scaleX, scaleY, rotation);
    }
    
    public NinePatch getPatch() {
        return this.patch;
    }
    
    public void setPatch(final NinePatch patch) {
        this.patch = patch;
        this.setMinWidth(patch.getTotalWidth());
        this.setMinHeight(patch.getTotalHeight());
        this.setTopHeight(patch.getPadTop());
        this.setRightWidth(patch.getPadRight());
        this.setBottomHeight(patch.getPadBottom());
        this.setLeftWidth(patch.getPadLeft());
    }
    
    public NinePatchDrawable tint(final Color tint) {
        final NinePatchDrawable drawable = new NinePatchDrawable(this);
        drawable.setPatch(new NinePatch(drawable.getPatch(), tint));
        return drawable;
    }
}
