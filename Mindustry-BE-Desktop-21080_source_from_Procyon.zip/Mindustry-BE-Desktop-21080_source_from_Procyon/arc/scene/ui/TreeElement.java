// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import arc.scene.Group;
import arc.scene.style.Drawable;
import arc.graphics.Color;
import arc.graphics.g2d.Draw;
import arc.scene.event.EventListener;
import arc.scene.event.InputEvent;
import arc.scene.Element;
import arc.Core;
import arc.scene.event.ClickListener;
import arc.scene.utils.Selection;
import arc.struct.Seq;
import arc.scene.ui.layout.WidgetGroup;

public class TreeElement extends WidgetGroup
{
    final Seq<TreeElementNode> rootNodes;
    final Selection<TreeElementNode> selection;
    TreeStyle style;
    float ySpacing;
    float iconSpacingLeft;
    float iconSpacingRight;
    float padding;
    float indentSpacing;
    TreeElementNode overNode;
    TreeElementNode rangeStart;
    private float leftColumnWidth;
    private float prefWidth;
    private float prefHeight;
    private boolean sizeInvalid;
    private TreeElementNode foundNode;
    private ClickListener clickListener;
    
    public TreeElement() {
        this(Core.scene.getStyle(TreeStyle.class));
    }
    
    public TreeElement(final TreeStyle style) {
        this.rootNodes = new Seq<TreeElementNode>();
        this.ySpacing = 4.0f;
        this.iconSpacingLeft = 2.0f;
        this.iconSpacingRight = 2.0f;
        this.padding = 0.0f;
        this.sizeInvalid = true;
        (this.selection = new Selection<TreeElementNode>() {
            @Override
            protected void changed() {
                switch (this.size()) {
                    case 0: {
                        TreeElement.this.rangeStart = null;
                        break;
                    }
                    case 1: {
                        TreeElement.this.rangeStart = this.first();
                        break;
                    }
                }
            }
        }).setActor(this);
        this.selection.setMultiple(true);
        this.setStyle(style);
        this.initialize();
    }
    
    static boolean findExpandedObjects(final Seq<TreeElementNode> nodes, final Seq<Object> objects) {
        final boolean expanded = false;
        for (int i = 0, n = nodes.size; i < n; ++i) {
            final TreeElementNode node = nodes.get(i);
            if (node.expanded && !findExpandedObjects(node.children, objects)) {
                objects.add(node.object);
            }
        }
        return expanded;
    }
    
    static TreeElementNode findNode(final Seq<TreeElementNode> nodes, final Object object) {
        for (int i = 0, n = nodes.size; i < n; ++i) {
            final TreeElementNode node = nodes.get(i);
            if (object.equals(node.object)) {
                return node;
            }
        }
        for (int i = 0, n = nodes.size; i < n; ++i) {
            final TreeElementNode node = nodes.get(i);
            final TreeElementNode found = findNode(node.children, object);
            if (found != null) {
                return found;
            }
        }
        return null;
    }
    
    static void collapseAll(final Seq<TreeElementNode> nodes) {
        for (int i = 0, n = nodes.size; i < n; ++i) {
            final TreeElementNode node = nodes.get(i);
            node.setExpanded(false);
            collapseAll(node.children);
        }
    }
    
    static void expandAll(final Seq<TreeElementNode> nodes) {
        for (int i = 0, n = nodes.size; i < n; ++i) {
            nodes.get(i).expandAll();
        }
    }
    
    private void initialize() {
        this.addListener(this.clickListener = new ClickListener() {
            @Override
            public void clicked(final InputEvent event, final float x, final float y) {
                final TreeElementNode node = TreeElement.this.getNodeAt(y);
                if (node == null) {
                    return;
                }
                if (node != TreeElement.this.getNodeAt(this.getTouchDownY())) {
                    return;
                }
                if (TreeElement.this.selection.getMultiple() && TreeElement.this.selection.hasItems() && Core.input.shift()) {
                    if (TreeElement.this.rangeStart == null) {
                        TreeElement.this.rangeStart = node;
                    }
                    final TreeElementNode rangeStart = TreeElement.this.rangeStart;
                    if (!Core.input.ctrl()) {
                        TreeElement.this.selection.clear();
                    }
                    final float start = rangeStart.element.y;
                    final float end = node.element.y;
                    if (start > end) {
                        TreeElement.this.selectNodes(TreeElement.this.rootNodes, end, start);
                    }
                    else {
                        TreeElement.this.selectNodes(TreeElement.this.rootNodes, start, end);
                        TreeElement.this.selection.items().orderedItems().reverse();
                    }
                    TreeElement.this.selection.fireChangeEvent();
                    TreeElement.this.rangeStart = rangeStart;
                    return;
                }
                if (node.children.size > 0 && (!TreeElement.this.selection.getMultiple() || !Core.input.ctrl())) {
                    float rowX = node.element.x;
                    if (node.icon != null) {
                        rowX -= TreeElement.this.iconSpacingRight + node.icon.getMinWidth();
                    }
                    if (x < rowX) {
                        node.setExpanded(!node.expanded);
                        return;
                    }
                }
                if (!node.isSelectable()) {
                    return;
                }
                TreeElement.this.selection.choose(node);
                if (!TreeElement.this.selection.isEmpty()) {
                    TreeElement.this.rangeStart = node;
                }
            }
            
            @Override
            public boolean mouseMoved(final InputEvent event, final float x, final float y) {
                TreeElement.this.setOverNode(TreeElement.this.getNodeAt(y));
                return false;
            }
            
            @Override
            public void exit(final InputEvent event, final float x, final float y, final int pointer, final Element toActor) {
                super.exit(event, x, y, pointer, toActor);
                if (toActor == null || !toActor.isDescendantOf(TreeElement.this)) {
                    TreeElement.this.setOverNode(null);
                }
            }
        });
    }
    
    public void add(final TreeElementNode node) {
        this.insert(this.rootNodes.size, node);
    }
    
    public void insert(final int index, final TreeElementNode node) {
        this.remove(node);
        node.parent = null;
        this.rootNodes.insert(index, node);
        node.addToTree(this);
        this.invalidateHierarchy();
    }
    
    public void remove(final TreeElementNode node) {
        if (node.parent != null) {
            node.parent.remove(node);
            return;
        }
        this.rootNodes.remove(node, true);
        node.removeFromTree(this);
        this.invalidateHierarchy();
    }
    
    @Override
    public void clearChildren() {
        super.clearChildren();
        this.setOverNode(null);
        this.rootNodes.clear();
        this.selection.clear();
    }
    
    public Seq<TreeElementNode> getNodes() {
        return this.rootNodes;
    }
    
    @Override
    public void invalidate() {
        super.invalidate();
        this.sizeInvalid = true;
    }
    
    private void computeSize() {
        this.sizeInvalid = false;
        this.prefWidth = this.style.plus.getMinWidth();
        this.prefWidth = Math.max(this.prefWidth, this.style.minus.getMinWidth());
        this.prefHeight = this.getHeight();
        this.leftColumnWidth = 0.0f;
        this.computeSize(this.rootNodes, this.indentSpacing);
        this.leftColumnWidth += this.iconSpacingLeft + this.padding;
        this.prefWidth += this.leftColumnWidth + this.padding;
        this.prefHeight = this.getHeight() - this.prefHeight;
    }
    
    private void computeSize(final Seq<TreeElementNode> nodes, final float indent) {
        final float ySpacing = this.ySpacing;
        final float spacing = this.iconSpacingLeft + this.iconSpacingRight;
        for (int i = 0, n = nodes.size; i < n; ++i) {
            final TreeElementNode node = nodes.get(i);
            float rowWidth = indent + this.iconSpacingRight;
            final Element element = node.element;
            if (element != null) {
                rowWidth += element.getPrefWidth();
                node.height = element.getPrefHeight();
                element.pack();
            }
            else {
                rowWidth += element.getWidth();
                node.height = element.getHeight();
            }
            if (node.icon != null) {
                rowWidth += spacing + node.icon.getMinWidth();
                node.height = Math.max(node.height, node.icon.getMinHeight());
            }
            this.prefWidth = Math.max(this.prefWidth, rowWidth);
            this.prefHeight -= node.height + ySpacing;
            if (node.expanded) {
                this.computeSize(node.children, indent + this.indentSpacing);
            }
        }
    }
    
    @Override
    public void layout() {
        if (this.sizeInvalid) {
            this.computeSize();
        }
        this.layout(this.rootNodes, this.leftColumnWidth + this.indentSpacing + this.iconSpacingRight, this.getHeight() - this.ySpacing / 2.0f);
    }
    
    private float layout(final Seq<TreeElementNode> nodes, final float indent, float y) {
        final float ySpacing = this.ySpacing;
        for (int i = 0, n = nodes.size; i < n; ++i) {
            final TreeElementNode node = nodes.get(i);
            float x = indent;
            if (node.icon != null) {
                x += node.icon.getMinWidth();
            }
            y -= node.getHeight();
            node.element.setPosition(x, y);
            y -= ySpacing;
            if (node.expanded) {
                y = this.layout(node.children, indent + this.indentSpacing, y);
            }
        }
        return y;
    }
    
    @Override
    public void draw() {
        this.drawBackground();
        final Color color = this.color;
        Draw.color(color.r, color.g, color.b, color.a * this.parentAlpha);
        this.draw(this.rootNodes, this.leftColumnWidth);
        super.draw();
    }
    
    protected void drawBackground() {
        if (this.style.background != null) {
            final Color color = this.color;
            Draw.color(color.r, color.g, color.b, color.a * this.parentAlpha);
            this.style.background.draw(this.x, this.y, this.getWidth(), this.getHeight());
        }
    }
    
    private void draw(final Seq<TreeElementNode> nodes, final float indent) {
        final Drawable plus = this.style.plus;
        final Drawable minus = this.style.minus;
        final float x = this.x;
        final float y = this.y;
        for (int i = 0, n = nodes.size; i < n; ++i) {
            final TreeElementNode node = nodes.get(i);
            final Element element = node.element;
            if (this.selection.contains(node) && this.style.selection != null) {
                this.style.selection.draw(x, y + element.y - this.ySpacing / 2.0f, this.getWidth(), node.height + this.ySpacing);
            }
            else if (node == this.overNode && this.style.over != null) {
                this.style.over.draw(x, y + element.y - this.ySpacing / 2.0f, this.getWidth(), node.height + this.ySpacing);
            }
            if (node.icon != null) {
                final float iconY = element.y + Math.round((node.height - node.icon.getMinHeight()) / 2.0f);
                Draw.color(element.color);
                node.icon.draw(x + node.element.x - this.iconSpacingRight - node.icon.getMinWidth(), y + iconY, node.icon.getMinWidth(), node.icon.getMinHeight());
                Draw.color(Color.white);
            }
            if (node.children.size != 0) {
                final Drawable expandIcon = node.expanded ? minus : plus;
                final float iconY2 = element.y + Math.round((node.height - expandIcon.getMinHeight()) / 2.0f);
                expandIcon.draw(x + indent - this.iconSpacingLeft, y + iconY2, expandIcon.getMinWidth(), expandIcon.getMinHeight());
                if (node.expanded) {
                    this.draw(node.children, indent + this.indentSpacing);
                }
            }
        }
    }
    
    public TreeElementNode getNodeAt(final float y) {
        this.foundNode = null;
        this.getNodeAt(this.rootNodes, y, this.getHeight());
        return this.foundNode;
    }
    
    private float getNodeAt(final Seq<TreeElementNode> nodes, final float y, float rowY) {
        for (int i = 0, n = nodes.size; i < n; ++i) {
            final TreeElementNode node = nodes.get(i);
            final float height = node.height;
            rowY -= node.getHeight() - height;
            if (y >= rowY - height - this.ySpacing && y < rowY) {
                this.foundNode = node;
                return -1.0f;
            }
            rowY -= height + this.ySpacing;
            if (node.expanded) {
                rowY = this.getNodeAt(node.children, y, rowY);
                if (rowY == -1.0f) {
                    return -1.0f;
                }
            }
        }
        return rowY;
    }
    
    void selectNodes(final Seq<TreeElementNode> nodes, final float low, final float high) {
        for (int i = 0, n = nodes.size; i < n; ++i) {
            final TreeElementNode node = nodes.get(i);
            if (node.element.y < low) {
                break;
            }
            if (node.isSelectable()) {
                if (node.element.y <= high) {
                    this.selection.add(node);
                }
                if (node.expanded) {
                    this.selectNodes(node.children, low, high);
                }
            }
        }
    }
    
    public Selection<TreeElementNode> getSelection() {
        return this.selection;
    }
    
    public TreeStyle getStyle() {
        return this.style;
    }
    
    public void setStyle(final TreeStyle style) {
        this.style = style;
        this.indentSpacing = Math.max(style.plus.getMinWidth(), style.minus.getMinWidth()) + this.iconSpacingLeft;
    }
    
    public Seq<TreeElementNode> getRootNodes() {
        return this.rootNodes;
    }
    
    public TreeElementNode getOverNode() {
        return this.overNode;
    }
    
    public void setOverNode(final TreeElementNode overNode) {
        this.overNode = overNode;
    }
    
    public Object getOverObject() {
        if (this.overNode == null) {
            return null;
        }
        return this.overNode.getObject();
    }
    
    public void setPadding(final float padding) {
        this.padding = padding;
    }
    
    public float getIndentSpacing() {
        return this.indentSpacing;
    }
    
    public float getYSpacing() {
        return this.ySpacing;
    }
    
    public void setYSpacing(final float ySpacing) {
        this.ySpacing = ySpacing;
    }
    
    public void setIconSpacing(final float left, final float right) {
        this.iconSpacingLeft = left;
        this.iconSpacingRight = right;
    }
    
    @Override
    public float getPrefWidth() {
        if (this.sizeInvalid) {
            this.computeSize();
        }
        return this.prefWidth;
    }
    
    @Override
    public float getPrefHeight() {
        if (this.sizeInvalid) {
            this.computeSize();
        }
        return this.prefHeight;
    }
    
    public void findExpandedObjects(final Seq objects) {
        findExpandedObjects(this.rootNodes, objects);
    }
    
    public void restoreExpandedObjects(final Seq objects) {
        for (int i = 0, n = objects.size; i < n; ++i) {
            final TreeElementNode node = this.findNode(objects.get(i));
            if (node != null) {
                node.setExpanded(true);
                node.expandTo();
            }
        }
    }
    
    public TreeElementNode findNode(final Object object) {
        if (object == null) {
            throw new IllegalArgumentException("object cannot be null.");
        }
        return findNode(this.rootNodes, object);
    }
    
    public void collapseAll() {
        collapseAll(this.rootNodes);
    }
    
    public void expandAll() {
        expandAll(this.rootNodes);
    }
    
    public ClickListener getClickListener() {
        return this.clickListener;
    }
    
    public static class TreeElementNode
    {
        final Element element;
        final Seq<TreeElementNode> children;
        TreeElementNode parent;
        boolean selectable;
        boolean expanded;
        Drawable icon;
        float height;
        Object object;
        
        public TreeElementNode(final Element element) {
            this.children = new Seq<TreeElementNode>(0);
            this.selectable = true;
            if (element == null) {
                throw new IllegalArgumentException("element cannot be null.");
            }
            this.element = element;
        }
        
        protected void addToTree(final TreeElement tree) {
            tree.addChild(this.element);
            if (!this.expanded) {
                return;
            }
            for (int i = 0, n = this.children.size; i < n; ++i) {
                this.children.get(i).addToTree(tree);
            }
        }
        
        protected void removeFromTree(final TreeElement tree) {
            tree.removeChild(this.element);
            if (!this.expanded) {
                return;
            }
            final Object[] children = this.children.items;
            for (int i = 0, n = this.children.size; i < n; ++i) {
                ((TreeElementNode)children[i]).removeFromTree(tree);
            }
        }
        
        public void add(final TreeElementNode node) {
            this.insert(this.children.size, node);
        }
        
        public void addAll(final Seq<TreeElementNode> nodes) {
            for (int i = 0, n = nodes.size; i < n; ++i) {
                this.insert(this.children.size, nodes.get(i));
            }
        }
        
        public void insert(final int index, final TreeElementNode node) {
            node.parent = this;
            this.children.insert(index, node);
            this.updateChildren();
        }
        
        public void remove() {
            final TreeElement tree = this.getTree();
            if (tree != null) {
                tree.remove(this);
            }
            else if (this.parent != null) {
                this.parent.remove(this);
            }
        }
        
        public void remove(final TreeElementNode node) {
            this.children.remove(node, true);
            if (!this.expanded) {
                return;
            }
            final TreeElement tree = this.getTree();
            if (tree == null) {
                return;
            }
            node.removeFromTree(tree);
            if (this.children.size == 0) {
                this.expanded = false;
            }
        }
        
        public void removeAll() {
            final TreeElement tree = this.getTree();
            if (tree != null) {
                for (int i = 0, n = this.children.size; i < n; ++i) {
                    this.children.get(i).removeFromTree(tree);
                }
            }
            this.children.clear();
        }
        
        public TreeElement getTree() {
            final Group parent = this.element.parent;
            if (!(parent instanceof TreeElement)) {
                return null;
            }
            return (TreeElement)parent;
        }
        
        public Element getActor() {
            return this.element;
        }
        
        public boolean isExpanded() {
            return this.expanded;
        }
        
        public void setExpanded(final boolean expanded) {
            if (expanded == this.expanded) {
                return;
            }
            this.expanded = expanded;
            if (this.children.size == 0) {
                return;
            }
            final TreeElement tree = this.getTree();
            if (tree == null) {
                return;
            }
            if (expanded) {
                for (int i = 0, n = this.children.size; i < n; ++i) {
                    this.children.get(i).addToTree(tree);
                }
            }
            else {
                for (int i = 0, n = this.children.size; i < n; ++i) {
                    this.children.get(i).removeFromTree(tree);
                }
            }
            tree.invalidateHierarchy();
        }
        
        public Seq<TreeElementNode> getChildren() {
            return this.children;
        }
        
        public void updateChildren() {
            if (!this.expanded) {
                return;
            }
            final TreeElement tree = this.getTree();
            if (tree == null) {
                return;
            }
            for (int i = 0, n = this.children.size; i < n; ++i) {
                this.children.get(i).addToTree(tree);
            }
        }
        
        public TreeElementNode getParent() {
            return this.parent;
        }
        
        public Object getObject() {
            return this.object;
        }
        
        public void setObject(final Object object) {
            this.object = object;
        }
        
        public Drawable getIcon() {
            return this.icon;
        }
        
        public void setIcon(final Drawable icon) {
            this.icon = icon;
        }
        
        public int getLevel() {
            int level = 0;
            TreeElementNode current = this;
            do {
                ++level;
                current = current.getParent();
            } while (current != null);
            return level;
        }
        
        public TreeElementNode findNode(final Object object) {
            if (object == null) {
                throw new IllegalArgumentException("object cannot be null.");
            }
            if (object.equals(this.object)) {
                return this;
            }
            return TreeElement.findNode(this.children, object);
        }
        
        public void collapseAll() {
            this.setExpanded(false);
            TreeElement.collapseAll(this.children);
        }
        
        public void expandAll() {
            this.setExpanded(true);
            if (this.children.size > 0) {
                TreeElement.expandAll(this.children);
            }
        }
        
        public void expandTo() {
            for (TreeElementNode node = this.parent; node != null; node = node.parent) {
                node.setExpanded(true);
            }
        }
        
        public boolean isSelectable() {
            return this.selectable;
        }
        
        public void setSelectable(final boolean selectable) {
            this.selectable = selectable;
        }
        
        public void findExpandedObjects(final Seq<Object> objects) {
            if (this.expanded && !TreeElement.findExpandedObjects(this.children, objects)) {
                objects.add(this.object);
            }
        }
        
        public void restoreExpandedObjects(final Seq objects) {
            for (int i = 0, n = objects.size; i < n; ++i) {
                final TreeElementNode node = this.findNode(objects.get(i));
                if (node != null) {
                    node.setExpanded(true);
                    node.expandTo();
                }
            }
        }
        
        public float getHeight() {
            return this.height;
        }
    }
    
    public static class TreeStyle
    {
        public Drawable plus;
        public Drawable minus;
        public Drawable over;
        public Drawable selection;
        public Drawable background;
        
        public TreeStyle() {
        }
        
        public TreeStyle(final Drawable plus, final Drawable minus, final Drawable selection) {
            this.plus = plus;
            this.minus = minus;
            this.selection = selection;
        }
        
        public TreeStyle(final TreeStyle style) {
            this.plus = style.plus;
            this.minus = style.minus;
            this.selection = style.selection;
        }
    }
}
