// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import arc.util.OS;
import arc.scene.event.ClickListener;
import arc.scene.event.InputEvent;
import arc.input.KeyCode;
import arc.util.Timer;
import arc.scene.style.Style;
import arc.scene.event.SceneEvent;
import arc.util.pooling.Pools;
import arc.scene.event.ChangeListener;
import arc.func.Cons;
import arc.scene.Group;
import arc.struct.Seq;
import arc.util.Time;
import arc.graphics.Color;
import arc.graphics.g2d.Font;
import arc.graphics.g2d.Draw;
import arc.scene.Scene;
import arc.math.Mathf;
import arc.Input;
import arc.scene.style.Drawable;
import arc.scene.event.IbeamCursorListener;
import arc.scene.event.EventListener;
import arc.Core;
import arc.scene.event.InputListener;
import arc.struct.FloatSeq;
import arc.graphics.g2d.GlyphLayout;
import arc.math.geom.Vec2;
import arc.scene.utils.Disableable;
import arc.scene.Element;

public class TextField extends Element implements Disableable
{
    protected static final char BACKSPACE = '\b';
    protected static final char TAB = '\t';
    protected static final char DELETE = '\u007f';
    protected static final char BULLET = '\u0095';
    private static final Vec2 tmp1;
    private static final Vec2 tmp2;
    private static final Vec2 tmp3;
    public static float keyRepeatInitialTime;
    public static float keyRepeatTime;
    protected final GlyphLayout layout;
    protected final FloatSeq glyphPositions;
    protected String text;
    protected int cursor;
    protected int selectionStart;
    protected boolean hasSelection;
    protected boolean writeEnters;
    protected CharSequence displayText;
    protected float fontOffset;
    protected float textHeight;
    protected float textOffset;
    TextFieldStyle style;
    InputListener inputListener;
    TextFieldListener listener;
    TextFieldValidator validator;
    TextFieldFilter filter;
    OnscreenKeyboard keyboard;
    boolean focusTraversal;
    boolean onlyFontChars;
    boolean disabled;
    String undoText;
    long lastChangeTime;
    boolean passwordMode;
    float renderOffset;
    boolean cursorOn;
    long lastBlink;
    KeyRepeatTask keyRepeatTask;
    boolean programmaticChangeEvents;
    private String messageText;
    private int textHAlign;
    private float selectionX;
    private float selectionWidth;
    private StringBuilder passwordBuffer;
    private char passwordCharacter;
    private int visibleTextStart;
    private int visibleTextEnd;
    private int maxLength;
    private float blinkTime;
    
    public TextField() {
        this("");
    }
    
    public TextField(final String text) {
        this(text, Core.scene.getStyle(TextFieldStyle.class));
    }
    
    public TextField(final String text, final TextFieldStyle style) {
        this.layout = new GlyphLayout();
        this.glyphPositions = new FloatSeq();
        this.keyboard = new DefaultOnscreenKeyboard();
        this.focusTraversal = true;
        this.onlyFontChars = true;
        this.undoText = "";
        this.cursorOn = true;
        this.keyRepeatTask = new KeyRepeatTask();
        this.textHAlign = 8;
        this.passwordCharacter = '\u0095';
        this.maxLength = 0;
        this.blinkTime = 0.32f;
        this.setStyle(style);
        this.initialize();
        this.setText(text);
        this.setSize(this.getPrefWidth(), this.getPrefHeight());
    }
    
    protected void initialize() {
        this.addListener(this.inputListener = this.createInputListener());
        this.addListener(new IbeamCursorListener());
    }
    
    protected InputListener createInputListener() {
        return new TextFieldClickListener();
    }
    
    protected int letterUnderCursor(float x) {
        x -= this.textOffset + this.fontOffset - this.style.font.getData().cursorX - this.glyphPositions.get(this.visibleTextStart);
        final Drawable background = this.getBackgroundDrawable();
        if (background != null) {
            x -= this.style.background.getLeftWidth();
        }
        final int n = this.glyphPositions.size;
        final float[] glyphPositions = this.glyphPositions.items;
        int i = 1;
        while (i < n) {
            if (glyphPositions[i] > x) {
                if (glyphPositions[i] - x <= x - glyphPositions[i - 1]) {
                    return i;
                }
                return i - 1;
            }
            else {
                ++i;
            }
        }
        return n - 1;
    }
    
    protected boolean isWordCharacter(final char c) {
        return Character.isLetterOrDigit(c);
    }
    
    protected int[] wordUnderCursor(final int at) {
        final String text = this.text;
        int right = text.length();
        int left = 0;
        int index = at;
        if (at >= text.length()) {
            left = text.length();
            right = 0;
        }
        else {
            while (index < right) {
                if (!this.isWordCharacter(text.charAt(index))) {
                    right = index;
                    break;
                }
                ++index;
            }
            for (index = at - 1; index > -1; --index) {
                if (!this.isWordCharacter(text.charAt(index))) {
                    left = index + 1;
                    break;
                }
            }
        }
        return new int[] { left, right };
    }
    
    int[] wordUnderCursor(final float x) {
        return this.wordUnderCursor(this.letterUnderCursor(x));
    }
    
    boolean withinMaxLength(final int size) {
        return this.maxLength <= 0 || size < this.maxLength;
    }
    
    public void addInputDialog() {
        if (!Core.app.isMobile()) {
            return;
        }
        final Input.TextInput input;
        this.tapped(() -> {
            input = new Input.TextInput();
            input.text = this.getText();
            if (this.maxLength > 0) {
                input.maxLength = this.maxLength;
            }
            input.accepted = (text -> {
                this.clearText();
                this.appendText(text);
                this.change();
                Core.input.setOnscreenKeyboardVisible(false);
                return;
            });
            input.canceled = (() -> {
                if (this.hasKeyboard()) {
                    Core.scene.setKeyboardFocus(null);
                }
                Core.input.setOnscreenKeyboardVisible(false);
                return;
            });
            Core.input.getTextInput(input);
        });
    }
    
    public int getMaxLength() {
        return this.maxLength;
    }
    
    public void setMaxLength(final int maxLength) {
        this.maxLength = maxLength;
    }
    
    public void clearText() {
        this.setText("");
    }
    
    public void setOnlyFontChars(final boolean onlyFontChars) {
        this.onlyFontChars = onlyFontChars;
    }
    
    public TextFieldStyle getStyle() {
        return this.style;
    }
    
    public void setStyle(final TextFieldStyle style) {
        if (style == null) {
            throw new IllegalArgumentException("style cannot be null.");
        }
        this.style = style;
        this.textHeight = style.font.getCapHeight() - style.font.getDescent() * 2.0f;
        this.invalidateHierarchy();
    }
    
    protected void calculateOffsets() {
        float visibleWidth = this.getWidth();
        final Drawable background = this.getBackgroundDrawable();
        if (background != null) {
            visibleWidth -= background.getLeftWidth() + background.getRightWidth();
        }
        final int glyphCount = this.glyphPositions.size;
        final float[] glyphPositions = this.glyphPositions.items;
        this.cursor = Mathf.clamp(this.cursor, 0, glyphPositions.length - 1);
        final float distance = glyphPositions[Math.max(0, this.cursor - 1)] + this.renderOffset;
        if (distance <= 0.0f) {
            this.renderOffset -= distance;
        }
        else {
            final int index = Math.min(glyphCount - 1, this.cursor + 1);
            final float minX = glyphPositions[index] - visibleWidth;
            if (-this.renderOffset < minX) {
                this.renderOffset = -minX;
            }
        }
        float maxOffset = 0.0f;
        final float width = glyphPositions[Mathf.clamp(glyphCount - 1, 0, glyphPositions.length - 1)];
        for (int i = glyphCount - 2; i >= 0; --i) {
            final float x = glyphPositions[i];
            if (width - x > visibleWidth) {
                break;
            }
            maxOffset = x;
        }
        if (-this.renderOffset > maxOffset) {
            this.renderOffset = -maxOffset;
        }
        this.visibleTextStart = 0;
        float startX = 0.0f;
        for (int j = 0; j < glyphCount; ++j) {
            if (glyphPositions[j] >= -this.renderOffset) {
                this.visibleTextStart = Math.max(0, j);
                startX = glyphPositions[j];
                break;
            }
        }
        final int length = Math.min(this.displayText.length(), glyphPositions.length - 1);
        this.visibleTextEnd = Math.min(length, this.cursor + 1);
        while (this.visibleTextEnd <= length && glyphPositions[this.visibleTextEnd] <= startX + visibleWidth) {
            ++this.visibleTextEnd;
        }
        this.visibleTextEnd = Math.max(0, this.visibleTextEnd - 1);
        if ((this.textHAlign & 0x8) == 0x0) {
            this.textOffset = visibleWidth - (glyphPositions[this.visibleTextEnd] - startX);
            if ((this.textHAlign & 0x1) != 0x0) {
                this.textOffset = (float)Math.round(this.textOffset * 0.5f);
            }
        }
        else {
            this.textOffset = startX + this.renderOffset;
        }
        if (this.hasSelection) {
            final int minIndex = Math.min(this.cursor, this.selectionStart);
            final int maxIndex = Math.max(this.cursor, this.selectionStart);
            final float minX2 = Math.max(glyphPositions[minIndex] - glyphPositions[this.visibleTextStart], -this.textOffset);
            final float maxX = Math.min(glyphPositions[maxIndex] - glyphPositions[this.visibleTextStart], visibleWidth - this.textOffset);
            this.selectionX = minX2;
            this.selectionWidth = maxX - minX2 - this.style.font.getData().cursorX;
        }
    }
    
    private Drawable getBackgroundDrawable() {
        final Scene stage = this.getScene();
        final boolean focused = stage != null && stage.getKeyboardFocus() == this;
        return (this.disabled && this.style.disabledBackground != null) ? this.style.disabledBackground : ((!this.isValid() && this.style.invalidBackground != null) ? this.style.invalidBackground : ((focused && this.style.focusedBackground != null) ? this.style.focusedBackground : this.style.background));
    }
    
    @Override
    public void draw() {
        final Scene stage = this.getScene();
        final boolean focused = stage != null && stage.getKeyboardFocus() == this;
        if (!focused) {
            this.keyRepeatTask.cancel();
        }
        final Font font = this.style.font;
        final Color fontColor = (this.disabled && this.style.disabledFontColor != null) ? this.style.disabledFontColor : ((focused && this.style.focusedFontColor != null) ? this.style.focusedFontColor : this.style.fontColor);
        final Drawable selection = this.style.selection;
        final Drawable cursorPatch = this.style.cursor;
        final Drawable background = this.getBackgroundDrawable();
        final Color color = this.color;
        final float x = this.x;
        final float y = this.y;
        final float width = this.getWidth();
        final float height = this.getHeight();
        Draw.color(color.r, color.g, color.b, color.a * this.parentAlpha);
        float bgLeftWidth = 0.0f;
        float bgRightWidth = 0.0f;
        if (background != null) {
            background.draw(x, y, width, height);
            bgLeftWidth = background.getLeftWidth();
            bgRightWidth = background.getRightWidth();
        }
        final float textY = this.getTextY(font, background);
        this.calculateOffsets();
        if (focused && this.hasSelection && selection != null) {
            this.drawSelection(selection, font, x + bgLeftWidth, y + textY);
        }
        final float yOffset = font.isFlipped() ? (-this.textHeight) : 0.0f;
        if (this.displayText.length() == 0) {
            if (!focused && this.messageText != null) {
                final Font messageFont = (this.style.messageFont != null) ? this.style.messageFont : font;
                if (this.style.messageFontColor != null) {
                    messageFont.setColor(this.style.messageFontColor.r, this.style.messageFontColor.g, this.style.messageFontColor.b, this.style.messageFontColor.a * color.a * this.parentAlpha);
                }
                else {
                    messageFont.setColor(0.7f, 0.7f, 0.7f, color.a * this.parentAlpha);
                }
                messageFont.draw(this.messageText, x + bgLeftWidth, y + textY + yOffset, 0, this.messageText.length(), width - bgLeftWidth - bgRightWidth, this.textHAlign, false, "...");
            }
        }
        else {
            font.setColor(fontColor.r, fontColor.g, fontColor.b, fontColor.a * color.a * this.parentAlpha);
            this.drawText(font, x + bgLeftWidth, y + textY + yOffset);
        }
        if (focused && !this.disabled) {
            this.blink();
            if (this.cursorOn && cursorPatch != null) {
                this.drawCursor(cursorPatch, font, x + bgLeftWidth, y + textY);
            }
        }
    }
    
    public boolean isValid() {
        return this.validator == null || this.validator.valid(this.text);
    }
    
    protected float getTextY(final Font font, final Drawable background) {
        final float height = this.getHeight();
        float textY = this.textHeight / 2.0f + font.getDescent();
        if (background != null) {
            final float bottom = background.getBottomHeight();
            textY = textY + (height - background.getTopHeight() - bottom) / 2.0f + bottom;
        }
        else {
            textY += height / 2.0f;
        }
        if (font.usesIntegerPositions()) {
            textY = (float)(int)textY;
        }
        return textY;
    }
    
    protected void drawSelection(final Drawable selection, final Font font, final float x, final float y) {
        selection.draw(x + this.textOffset + this.selectionX + this.fontOffset, y - this.textHeight - font.getDescent(), this.selectionWidth, this.textHeight);
    }
    
    protected void drawText(final Font font, final float x, final float y) {
        font.draw(this.displayText, x + this.textOffset, y, this.visibleTextStart, this.visibleTextEnd, 0.0f, 8, false);
    }
    
    protected void drawCursor(final Drawable cursorPatch, final Font font, final float x, final float y) {
        cursorPatch.draw(x + this.textOffset + this.glyphPositions.get(this.cursor) - this.glyphPositions.get(this.visibleTextStart) + this.fontOffset + font.getData().cursorX, y - this.textHeight - font.getDescent(), cursorPatch.getMinWidth(), this.textHeight);
    }
    
    protected void updateDisplayText() {
        final Font font = this.style.font;
        final Font.FontData data = font.getData();
        final String text = this.text;
        final int textLength = text.length();
        final StringBuilder buffer = new StringBuilder();
        for (int i = 0; i < textLength; ++i) {
            final char c = text.charAt(i);
            buffer.append(data.hasGlyph(c) ? c : ' ');
        }
        final String newDisplayText = buffer.toString();
        if (this.passwordMode && data.hasGlyph(this.passwordCharacter)) {
            if (this.passwordBuffer == null) {
                this.passwordBuffer = new StringBuilder(newDisplayText.length());
            }
            if (this.passwordBuffer.length() > textLength) {
                this.passwordBuffer.setLength(textLength);
            }
            else {
                for (int j = this.passwordBuffer.length(); j < textLength; ++j) {
                    this.passwordBuffer.append(this.passwordCharacter);
                }
            }
            this.displayText = this.passwordBuffer;
        }
        else {
            this.displayText = newDisplayText;
        }
        this.layout.setText(font, this.displayText);
        this.glyphPositions.clear();
        float x = 0.0f;
        if (this.layout.runs.size > 0) {
            final GlyphLayout.GlyphRun run = this.layout.runs.first();
            final FloatSeq xAdvances = run.xAdvances;
            this.fontOffset = xAdvances.first();
            for (int k = 1, n = xAdvances.size; k < n; ++k) {
                this.glyphPositions.add(x);
                x += xAdvances.get(k);
            }
        }
        else {
            this.fontOffset = 0.0f;
        }
        this.glyphPositions.add(x);
        this.visibleTextStart = Math.min(this.visibleTextStart, this.glyphPositions.size);
        this.visibleTextEnd = Mathf.clamp(this.visibleTextEnd, this.visibleTextStart, this.glyphPositions.size);
        if (this.selectionStart > newDisplayText.length()) {
            this.selectionStart = textLength;
        }
    }
    
    private void blink() {
        if (!Core.graphics.isContinuousRendering()) {
            this.cursorOn = true;
            return;
        }
        final long time = Time.nanos();
        if ((time - this.lastBlink) / 1.0E9f > this.blinkTime) {
            this.cursorOn = !this.cursorOn;
            this.lastBlink = time;
        }
    }
    
    public void copy() {
        if (this.hasSelection && !this.passwordMode) {
            Core.app.setClipboardText(this.text.substring(Math.min(this.cursor, this.selectionStart), Math.max(this.cursor, this.selectionStart)));
        }
    }
    
    public void cut() {
        this.cut(this.programmaticChangeEvents);
    }
    
    void cut(final boolean fireChangeEvent) {
        if (this.hasSelection && !this.passwordMode) {
            this.copy();
            this.cursor = this.delete(fireChangeEvent);
            this.updateDisplayText();
        }
    }
    
    public void paste(String content, final boolean fireChangeEvent) {
        if (content == null) {
            return;
        }
        final StringBuilder buffer = new StringBuilder();
        int textLength = this.text.length();
        if (this.hasSelection) {
            textLength -= Math.abs(this.cursor - this.selectionStart);
        }
        final Font.FontData data = this.style.font.getData();
        for (int i = 0, n = content.length(); i < n && this.withinMaxLength(textLength + buffer.length()); ++i) {
            final char c = content.charAt(i);
            if (c != '\r') {
                if (!this.writeEnters || c != '\n') {
                    if (c == '\n') {
                        continue;
                    }
                    if (this.onlyFontChars && !data.hasGlyph(c)) {
                        continue;
                    }
                    if (this.filter != null && !this.filter.acceptChar(this, c)) {
                        continue;
                    }
                }
                buffer.append(c);
            }
        }
        content = buffer.toString();
        if (this.hasSelection) {
            this.cursor = this.delete(fireChangeEvent);
        }
        if (fireChangeEvent) {
            this.changeText(this.text, this.insert(this.cursor, content, this.text));
        }
        else {
            this.text = this.insert(this.cursor, content, this.text);
        }
        this.updateDisplayText();
        this.cursor += content.length();
    }
    
    String insert(final int position, final CharSequence text, final String to) {
        if (to.length() == 0) {
            return text.toString();
        }
        return to.substring(0, position) + (Object)text + to.substring(position);
    }
    
    int delete(final boolean fireChangeEvent) {
        final int from = this.selectionStart;
        final int to = this.cursor;
        final int minIndex = Math.min(from, to);
        final int maxIndex = Math.max(from, to);
        final String newText = ((minIndex > 0) ? this.text.substring(0, minIndex) : "") + ((maxIndex < this.text.length()) ? this.text.substring(maxIndex) : "");
        if (fireChangeEvent) {
            this.changeText(this.text, newText);
        }
        else {
            this.text = newText;
        }
        this.clearSelection();
        return minIndex;
    }
    
    public void next(final boolean up) {
        final Scene stage = this.getScene();
        if (stage == null) {
            return;
        }
        TextField current = this;
        while (true) {
            current.parent.localToStageCoordinates(TextField.tmp1.set(this.x, this.y));
            TextField textField = current.findNextTextField(stage.getElements(), null, TextField.tmp2, TextField.tmp1, up);
            if (textField == null) {
                if (up) {
                    TextField.tmp1.set(Float.MIN_VALUE, Float.MIN_VALUE);
                }
                else {
                    TextField.tmp1.set(Float.MAX_VALUE, Float.MAX_VALUE);
                }
                textField = current.findNextTextField(this.getScene().getElements(), null, TextField.tmp2, TextField.tmp1, up);
            }
            if (textField == null) {
                Core.input.setOnscreenKeyboardVisible(false);
                break;
            }
            if (stage.setKeyboardFocus(textField)) {
                break;
            }
            current = textField;
        }
    }
    
    private TextField findNextTextField(final Seq<Element> elements, TextField best, final Vec2 bestCoords, final Vec2 currentCoords, final boolean up) {
        for (int i = 0, n = elements.size; i < n; ++i) {
            final Element element = elements.get(i);
            if (element != this) {
                if (element.visible) {
                    if (element instanceof TextField) {
                        final TextField textField = (TextField)element;
                        if (!textField.isDisabled()) {
                            if (textField.focusTraversal) {
                                final Vec2 elementCoords = element.parent.localToStageCoordinates(TextField.tmp3.set(element.x, element.y));
                                if (((elementCoords.y < currentCoords.y || (elementCoords.y == currentCoords.y && elementCoords.x > currentCoords.x)) ^ up) && (best == null || ((elementCoords.y > bestCoords.y || (elementCoords.y == bestCoords.y && elementCoords.x < bestCoords.x)) ^ up))) {
                                    best = (TextField)element;
                                    bestCoords.set(elementCoords);
                                }
                            }
                        }
                    }
                    else if (element instanceof Group) {
                        best = this.findNextTextField(((Group)element).getChildren(), best, bestCoords, currentCoords, up);
                    }
                }
            }
        }
        return best;
    }
    
    public InputListener getDefaultInputListener() {
        return this.inputListener;
    }
    
    public void setTextFieldListener(final TextFieldListener listener) {
        this.listener = listener;
    }
    
    public void typed(final char ch, final Runnable run) {
        this.setTextFieldListener((textField, c) -> {
            if (c == ch) {
                run.run();
            }
        });
    }
    
    public void typed(final Cons<Character> cons) {
        this.setTextFieldListener((textField, c) -> cons.get(c));
    }
    
    public TextFieldFilter getFilter() {
        return this.filter;
    }
    
    public void setFilter(final TextFieldFilter filter) {
        this.filter = filter;
    }
    
    public void setValidator(final TextFieldValidator validator) {
        this.validator = validator;
    }
    
    public TextFieldValidator getValidator() {
        return this.validator;
    }
    
    public void setFocusTraversal(final boolean focusTraversal) {
        this.focusTraversal = focusTraversal;
    }
    
    public String getMessageText() {
        return this.messageText;
    }
    
    public void setMessageText(final String messageText) {
        if (messageText != null && (messageText.startsWith("$") || messageText.startsWith("@")) && Core.bundle != null && Core.bundle.has(messageText.substring(1))) {
            this.messageText = Core.bundle.get(messageText.substring(1));
        }
        else {
            this.messageText = messageText;
        }
    }
    
    public void appendText(String str) {
        if (str == null) {
            str = "";
        }
        this.clearSelection();
        this.cursor = this.text.length();
        this.paste(str, this.programmaticChangeEvents);
    }
    
    public String getText() {
        return this.text;
    }
    
    public void setText(String str) {
        if (str == null) {
            str = "";
        }
        if (str.equals(this.text)) {
            return;
        }
        this.clearSelection();
        final String oldText = this.text;
        this.text = "";
        this.paste(str, false);
        if (this.programmaticChangeEvents) {
            this.changeText(oldText, this.text);
        }
        this.cursor = 0;
    }
    
    boolean changeText(final String oldText, final String newText) {
        if (newText.equals(oldText)) {
            return false;
        }
        this.text = newText;
        final ChangeListener.ChangeEvent changeEvent = Pools.obtain(ChangeListener.ChangeEvent.class, ChangeListener.ChangeEvent::new);
        final boolean cancelled = this.fire(changeEvent);
        this.text = (cancelled ? oldText : newText);
        Pools.free(changeEvent);
        return !cancelled;
    }
    
    public boolean getProgrammaticChangeEvents() {
        return this.programmaticChangeEvents;
    }
    
    public void setProgrammaticChangeEvents(final boolean programmaticChangeEvents) {
        this.programmaticChangeEvents = programmaticChangeEvents;
    }
    
    public int getSelectionStart() {
        return this.selectionStart;
    }
    
    public String getSelection() {
        return this.hasSelection ? this.text.substring(Math.min(this.selectionStart, this.cursor), Math.max(this.selectionStart, this.cursor)) : "";
    }
    
    public void setSelection(int selectionStart, int selectionEnd) {
        if (selectionStart < 0) {
            throw new IllegalArgumentException("selectionStart must be >= 0");
        }
        if (selectionEnd < 0) {
            throw new IllegalArgumentException("selectionEnd must be >= 0");
        }
        selectionStart = Math.min(this.text.length(), selectionStart);
        selectionEnd = Math.min(this.text.length(), selectionEnd);
        if (selectionEnd == selectionStart) {
            this.clearSelection();
            return;
        }
        if (selectionEnd < selectionStart) {
            final int temp = selectionEnd;
            selectionEnd = selectionStart;
            selectionStart = temp;
        }
        this.hasSelection = true;
        this.selectionStart = selectionStart;
        this.cursor = selectionEnd;
    }
    
    public void selectAll() {
        this.setSelection(0, this.text.length());
    }
    
    public void clearSelection() {
        this.hasSelection = false;
    }
    
    public int getCursorPosition() {
        return this.cursor;
    }
    
    public void setCursorPosition(final int cursorPosition) {
        if (cursorPosition < 0) {
            throw new IllegalArgumentException("cursorPosition must be >= 0");
        }
        this.clearSelection();
        this.cursor = Math.min(cursorPosition, this.text.length());
    }
    
    public OnscreenKeyboard getOnscreenKeyboard() {
        return this.keyboard;
    }
    
    public void setOnscreenKeyboard(final OnscreenKeyboard keyboard) {
        this.keyboard = keyboard;
    }
    
    @Override
    public float getPrefWidth() {
        return 150.0f;
    }
    
    @Override
    public float getPrefHeight() {
        float topAndBottom = 0.0f;
        float minHeight = 0.0f;
        if (this.style.background != null) {
            topAndBottom = Math.max(topAndBottom, this.style.background.getBottomHeight() + this.style.background.getTopHeight());
            minHeight = Math.max(minHeight, this.style.background.getMinHeight());
        }
        if (this.style.focusedBackground != null) {
            topAndBottom = Math.max(topAndBottom, this.style.focusedBackground.getBottomHeight() + this.style.focusedBackground.getTopHeight());
            minHeight = Math.max(minHeight, this.style.focusedBackground.getMinHeight());
        }
        if (this.style.disabledBackground != null) {
            topAndBottom = Math.max(topAndBottom, this.style.disabledBackground.getBottomHeight() + this.style.disabledBackground.getTopHeight());
            minHeight = Math.max(minHeight, this.style.disabledBackground.getMinHeight());
        }
        return Math.max(topAndBottom + this.textHeight, minHeight);
    }
    
    public void setAlignment(final int alignment) {
        this.textHAlign = alignment;
    }
    
    public boolean isPasswordMode() {
        return this.passwordMode;
    }
    
    public void setPasswordMode(final boolean passwordMode) {
        this.passwordMode = passwordMode;
        this.updateDisplayText();
    }
    
    public void setPasswordCharacter(final char passwordCharacter) {
        this.passwordCharacter = passwordCharacter;
        if (this.passwordMode) {
            this.updateDisplayText();
        }
    }
    
    public void setBlinkTime(final float blinkTime) {
        this.blinkTime = blinkTime;
    }
    
    @Override
    public boolean isDisabled() {
        return this.disabled;
    }
    
    @Override
    public void setDisabled(final boolean disabled) {
        this.disabled = disabled;
    }
    
    protected void moveCursor(final boolean forward, final boolean jump) {
        final int limit = forward ? this.text.length() : 0;
        final int charOffset = forward ? 0 : -1;
        do {
            if (forward) {
                if (++this.cursor < limit) {
                    continue;
                }
                break;
            }
            else {
                if (--this.cursor > limit) {
                    continue;
                }
                break;
            }
        } while (jump && this.continueCursor(this.cursor, charOffset));
    }
    
    protected boolean continueCursor(final int index, final int offset) {
        final char c = this.text.charAt(index + offset);
        return this.isWordCharacter(c);
    }
    
    static {
        tmp1 = new Vec2();
        tmp2 = new Vec2();
        tmp3 = new Vec2();
        TextField.keyRepeatInitialTime = 0.4f;
        TextField.keyRepeatTime = 0.1f;
    }
    
    public interface TextFieldFilter
    {
        public static final TextFieldFilter digitsOnly = (field, c) -> Character.isDigit(c);
        public static final TextFieldFilter floatsOnly = (field, c) -> Character.isDigit(c) || (!field.getText().contains(".") && c == '.');
        
        boolean acceptChar(final TextField p0, final char p1);
    }
    
    public static class DefaultOnscreenKeyboard implements OnscreenKeyboard
    {
        @Override
        public void show(final boolean visible) {
            Core.input.setOnscreenKeyboardVisible(visible);
        }
    }
    
    public static class TextFieldStyle extends Style
    {
        public Font font;
        public Color fontColor;
        public Color focusedFontColor;
        public Color disabledFontColor;
        public Drawable background;
        public Drawable focusedBackground;
        public Drawable disabledBackground;
        public Drawable invalidBackground;
        public Drawable cursor;
        public Drawable selection;
        public Font messageFont;
        public Color messageFontColor;
        
        public TextFieldStyle() {
        }
        
        public TextFieldStyle(final TextFieldStyle style) {
            this.messageFont = style.messageFont;
            if (style.messageFontColor != null) {
                this.messageFontColor = new Color(style.messageFontColor);
            }
            this.background = style.background;
            this.focusedBackground = style.focusedBackground;
            this.disabledBackground = style.disabledBackground;
            this.cursor = style.cursor;
            this.font = style.font;
            if (style.fontColor != null) {
                this.fontColor = new Color(style.fontColor);
            }
            if (style.focusedFontColor != null) {
                this.focusedFontColor = new Color(style.focusedFontColor);
            }
            if (style.disabledFontColor != null) {
                this.disabledFontColor = new Color(style.disabledFontColor);
            }
            this.selection = style.selection;
        }
    }
    
    class KeyRepeatTask extends Timer.Task
    {
        KeyCode keycode;
        
        @Override
        public void run() {
            TextField.this.inputListener.keyDown(null, this.keycode);
        }
    }
    
    public class TextFieldClickListener extends ClickListener
    {
        @Override
        public void clicked(final InputEvent event, final float x, final float y) {
            final int count = this.getTapCount() % 4;
            if (count == 0) {
                TextField.this.clearSelection();
            }
            if (count == 2) {
                final int[] array = TextField.this.wordUnderCursor(x);
                TextField.this.setSelection(array[0], array[1]);
            }
            if (count == 3) {
                TextField.this.selectAll();
            }
        }
        
        @Override
        public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
            if (!super.touchDown(event, x, y, pointer, button)) {
                return false;
            }
            if (pointer == 0 && button != KeyCode.mouseLeft) {
                return false;
            }
            if (TextField.this.disabled) {
                return true;
            }
            this.setCursorPosition(x, y);
            TextField.this.selectionStart = TextField.this.cursor;
            final Scene stage = TextField.this.getScene();
            if (stage != null) {
                stage.setKeyboardFocus(TextField.this);
            }
            TextField.this.keyboard.show(true);
            return TextField.this.hasSelection = true;
        }
        
        @Override
        public void touchDragged(final InputEvent event, final float x, final float y, final int pointer) {
            super.touchDragged(event, x, y, pointer);
            this.setCursorPosition(x, y);
        }
        
        @Override
        public void touchUp(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
            if (TextField.this.selectionStart == TextField.this.cursor) {
                TextField.this.hasSelection = false;
            }
            super.touchUp(event, x, y, pointer, button);
        }
        
        protected void setCursorPosition(final float x, final float y) {
            TextField.this.lastBlink = 0L;
            TextField.this.cursorOn = false;
            TextField.this.cursor = TextField.this.letterUnderCursor(x);
        }
        
        protected void goHome(final boolean jump) {
            TextField.this.cursor = 0;
        }
        
        protected void goEnd(final boolean jump) {
            TextField.this.cursor = TextField.this.text.length();
        }
        
        @Override
        public boolean keyDown(final InputEvent event, final KeyCode keycode) {
            if (TextField.this.disabled) {
                return false;
            }
            TextField.this.lastBlink = 0L;
            TextField.this.cursorOn = false;
            final Scene stage = TextField.this.getScene();
            if (stage == null || stage.getKeyboardFocus() != TextField.this) {
                return false;
            }
            boolean repeat = false;
            final boolean ctrl = Core.input.ctrl() && !Core.input.alt();
            final boolean jump = ctrl && !TextField.this.passwordMode;
            if (ctrl) {
                if (keycode == KeyCode.v) {
                    TextField.this.paste(Core.app.getClipboardText(), true);
                    repeat = true;
                }
                if (keycode == KeyCode.c || keycode == KeyCode.insert) {
                    TextField.this.copy();
                    return true;
                }
                if (keycode == KeyCode.x) {
                    TextField.this.cut(true);
                    return true;
                }
                if (keycode == KeyCode.a) {
                    TextField.this.selectAll();
                    return true;
                }
                if (keycode == KeyCode.z) {
                    final String oldText = TextField.this.text;
                    TextField.this.setText(TextField.this.undoText);
                    TextField.this.undoText = oldText;
                    TextField.this.updateDisplayText();
                    return true;
                }
            }
            Label_0493: {
                if (Core.input.shift()) {
                    if (keycode == KeyCode.insert) {
                        TextField.this.paste(Core.app.getClipboardText(), true);
                    }
                    if (keycode == KeyCode.forwardDel) {
                        TextField.this.cut(true);
                    }
                    final int temp = TextField.this.cursor;
                    if (keycode == KeyCode.left) {
                        TextField.this.moveCursor(false, jump);
                        repeat = true;
                    }
                    else if (keycode == KeyCode.right) {
                        TextField.this.moveCursor(true, jump);
                        repeat = true;
                    }
                    else if (keycode == KeyCode.home) {
                        this.goHome(jump);
                    }
                    else {
                        if (keycode != KeyCode.end) {
                            break Label_0493;
                        }
                        this.goEnd(jump);
                    }
                    if (!TextField.this.hasSelection) {
                        TextField.this.selectionStart = temp;
                        TextField.this.hasSelection = true;
                    }
                }
                else {
                    if (keycode == KeyCode.left) {
                        TextField.this.moveCursor(false, jump);
                        TextField.this.clearSelection();
                        repeat = true;
                    }
                    if (keycode == KeyCode.right) {
                        TextField.this.moveCursor(true, jump);
                        TextField.this.clearSelection();
                        repeat = true;
                    }
                    if (keycode == KeyCode.home) {
                        this.goHome(jump);
                        TextField.this.clearSelection();
                    }
                    if (keycode == KeyCode.end) {
                        this.goEnd(jump);
                        TextField.this.clearSelection();
                    }
                }
            }
            TextField.this.cursor = Mathf.clamp(TextField.this.cursor, 0, TextField.this.text.length());
            if (repeat) {
                this.scheduleKeyRepeatTask(keycode);
            }
            return true;
        }
        
        protected void scheduleKeyRepeatTask(final KeyCode keycode) {
            if (!TextField.this.keyRepeatTask.isScheduled() || TextField.this.keyRepeatTask.keycode != keycode) {
                TextField.this.keyRepeatTask.keycode = keycode;
                TextField.this.keyRepeatTask.cancel();
                Timer.schedule(TextField.this.keyRepeatTask, TextField.keyRepeatInitialTime, TextField.keyRepeatTime);
            }
        }
        
        @Override
        public boolean keyUp(final InputEvent event, final KeyCode keycode) {
            if (TextField.this.disabled) {
                return false;
            }
            TextField.this.keyRepeatTask.cancel();
            return true;
        }
        
        protected boolean checkFocusTraverse(final char character) {
            return TextField.this.focusTraversal && (character == '\t' || ((character == '\r' || character == '\n') && Core.app.isMobile()));
        }
        
        @Override
        public boolean keyTyped(final InputEvent event, final char character) {
            if (TextField.this.disabled) {
                return false;
            }
            switch (character) {
                case '\b':
                case '\t':
                case '\n':
                case '\r': {
                    break;
                }
                default: {
                    if (character < ' ') {
                        return false;
                    }
                    break;
                }
            }
            final Scene stage = TextField.this.getScene();
            if (stage == null || stage.getKeyboardFocus() != TextField.this) {
                return false;
            }
            if (OS.isMac && Core.input.keyDown(KeyCode.sym)) {
                return true;
            }
            if (this.checkFocusTraverse(character)) {
                TextField.this.next(Core.input.shift());
            }
            else {
                final boolean delete = character == '\u007f';
                final boolean backspace = character == '\b';
                final boolean enter = character == '\n' || character == '\r';
                final boolean add = enter ? TextField.this.writeEnters : (!TextField.this.onlyFontChars || TextField.this.style.font.getData().hasGlyph(character));
                final boolean remove = backspace || delete;
                if (add || remove) {
                    final String oldText = TextField.this.text;
                    final int oldCursor = TextField.this.cursor;
                    if (TextField.this.hasSelection) {
                        TextField.this.cursor = TextField.this.delete(false);
                    }
                    else {
                        if (backspace && TextField.this.cursor > 0) {
                            TextField.this.text = TextField.this.text.substring(0, TextField.this.cursor - 1) + TextField.this.text.substring(TextField.this.cursor--);
                            TextField.this.renderOffset = 0.0f;
                        }
                        if (delete && TextField.this.cursor < TextField.this.text.length()) {
                            TextField.this.text = TextField.this.text.substring(0, TextField.this.cursor) + TextField.this.text.substring(TextField.this.cursor + 1);
                        }
                    }
                    if (add && !remove) {
                        if (TextField.this.filter != null && !TextField.this.filter.acceptChar(TextField.this, character)) {
                            return true;
                        }
                        if (!TextField.this.withinMaxLength(TextField.this.text.length())) {
                            return true;
                        }
                        final String insertion = enter ? "\n" : String.valueOf(character);
                        TextField.this.text = TextField.this.insert(TextField.this.cursor++, insertion, TextField.this.text);
                    }
                    if (TextField.this.changeText(oldText, TextField.this.text)) {
                        final long time = System.currentTimeMillis();
                        if (time - 750L > TextField.this.lastChangeTime) {
                            TextField.this.undoText = oldText;
                        }
                        TextField.this.lastChangeTime = time;
                    }
                    else {
                        TextField.this.cursor = oldCursor;
                    }
                    TextField.this.updateDisplayText();
                }
            }
            if (TextField.this.listener != null) {
                TextField.this.listener.keyTyped(TextField.this, character);
            }
            return true;
        }
    }
    
    public interface TextFieldListener
    {
        void keyTyped(final TextField p0, final char p1);
    }
    
    public interface OnscreenKeyboard
    {
        void show(final boolean p0);
    }
    
    public interface TextFieldValidator
    {
        boolean valid(final String p0);
    }
}
