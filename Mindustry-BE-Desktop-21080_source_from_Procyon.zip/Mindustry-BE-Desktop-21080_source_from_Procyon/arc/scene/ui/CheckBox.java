// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import arc.scene.style.Drawable;
import arc.util.Scaling;
import arc.Core;
import arc.scene.ui.layout.Cell;

public class CheckBox extends TextButton
{
    private Image image;
    private Cell imageCell;
    private CheckBoxStyle style;
    
    public CheckBox(final String text) {
        this(text, Core.scene.getStyle(CheckBoxStyle.class));
    }
    
    public CheckBox(final String text, final CheckBoxStyle style) {
        super(text, style);
        this.clearChildren();
        final Label label = this.getLabel();
        final Image image = new Image(style.checkboxOff, Scaling.stretch);
        this.image = image;
        this.imageCell = this.add(image);
        this.add(label).padLeft(4.0f).get().setWrap(false);
        label.setAlignment(8);
        this.setSize(this.getPrefWidth(), this.getPrefHeight());
    }
    
    @Override
    public CheckBoxStyle getStyle() {
        return this.style;
    }
    
    @Override
    public void setStyle(final ButtonStyle style) {
        if (!(style instanceof CheckBoxStyle)) {
            throw new IllegalArgumentException("style must be a CheckBoxStyle.");
        }
        super.setStyle(style);
        this.style = (CheckBoxStyle)style;
    }
    
    @Override
    public void draw() {
        Drawable checkbox = null;
        if (this.isDisabled()) {
            if (this.isChecked && this.style.checkboxOnDisabled != null) {
                checkbox = this.style.checkboxOnDisabled;
            }
            else {
                checkbox = this.style.checkboxOffDisabled;
            }
        }
        if (checkbox == null) {
            if (this.isChecked && this.isOver() && this.style.checkboxOnOver != null) {
                checkbox = this.style.checkboxOnOver;
            }
            else if (this.isChecked && this.style.checkboxOn != null) {
                checkbox = this.style.checkboxOn;
            }
            else if (this.isOver() && this.style.checkboxOver != null && !this.isDisabled()) {
                checkbox = this.style.checkboxOver;
            }
            else {
                checkbox = this.style.checkboxOff;
            }
        }
        this.image.setDrawable(checkbox);
        super.draw();
    }
    
    public Image getImage() {
        return this.image;
    }
    
    public Cell getImageCell() {
        return this.imageCell;
    }
    
    public static class CheckBoxStyle extends TextButtonStyle
    {
        public Drawable checkboxOn;
        public Drawable checkboxOff;
        public Drawable checkboxOver;
        public Drawable checkboxOnDisabled;
        public Drawable checkboxOffDisabled;
        public Drawable checkboxOnOver;
    }
}
