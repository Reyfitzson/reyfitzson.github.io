// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui.layout;

import arc.struct.SnapshotSeq;
import arc.scene.Element;
import arc.scene.Group;

public class WidgetGroup extends Group
{
    private boolean needsLayout;
    private boolean layoutEnabled;
    
    public WidgetGroup() {
        this.needsLayout = true;
        this.layoutEnabled = true;
    }
    
    public WidgetGroup(final Element... actors) {
        this.needsLayout = true;
        this.layoutEnabled = true;
        for (final Element actor : actors) {
            this.addChild(actor);
        }
    }
    
    @Override
    public float getMinWidth() {
        return this.getPrefWidth();
    }
    
    @Override
    public float getMinHeight() {
        return this.getPrefHeight();
    }
    
    @Override
    public float getPrefWidth() {
        return 0.0f;
    }
    
    @Override
    public float getPrefHeight() {
        return 0.0f;
    }
    
    @Override
    public void setLayoutEnabled(final boolean enabled) {
        if (this.layoutEnabled == enabled) {
            return;
        }
        this.setLayoutEnabled(this, this.layoutEnabled = enabled);
    }
    
    private void setLayoutEnabled(final Group parent, final boolean enabled) {
        final SnapshotSeq<Element> children = parent.getChildren();
        for (int i = 0, n = children.size; i < n; ++i) {
            children.get(i).setLayoutEnabled(enabled);
        }
    }
    
    @Override
    public void validate() {
        if (!this.layoutEnabled) {
            return;
        }
        final Group parent = this.parent;
        if (this.fillParent && parent != null) {
            final float parentWidth = parent.getWidth();
            final float parentHeight = parent.getHeight();
            if (this.getWidth() != parentWidth || this.getHeight() != parentHeight) {
                this.setWidth(parentWidth);
                this.setHeight(parentHeight);
                this.invalidate();
            }
        }
        if (!this.needsLayout) {
            return;
        }
        this.needsLayout = false;
        this.layout();
    }
    
    @Override
    public boolean needsLayout() {
        return this.needsLayout;
    }
    
    @Override
    public void invalidate() {
        this.needsLayout = true;
    }
    
    @Override
    public void invalidateHierarchy() {
        this.invalidate();
        final Group parent = this.parent;
        if (parent != null) {
            parent.invalidateHierarchy();
        }
    }
    
    @Override
    protected void childrenChanged() {
        this.invalidateHierarchy();
    }
    
    @Override
    protected void sizeChanged() {
        this.invalidate();
    }
    
    @Override
    public void pack() {
        this.setSize(this.getPrefWidth(), this.getPrefHeight());
        this.validate();
        if (this.needsLayout) {
            this.setSize(this.getPrefWidth(), this.getPrefHeight());
            this.validate();
        }
    }
    
    @Override
    public void setFillParent(final boolean fillParent) {
        this.fillParent = fillParent;
    }
    
    @Override
    public void layout() {
    }
    
    @Override
    public void draw() {
        this.validate();
        super.draw();
    }
}
