// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui.layout;

import arc.Core;

public class Scl
{
    private static float scl;
    private static float addition;
    private static float product;
    private static final float debugScale = 1.0f;
    
    public static void setProduct(final float product) {
        Scl.product = product;
        Scl.scl = -1.0f;
    }
    
    public static void setAddition(final float addition) {
        Scl.addition = addition;
        Scl.scl = -1.0f;
    }
    
    public static float scl() {
        return scl(1.0f);
    }
    
    public static float scl(final float amount) {
        if (Scl.scl < 0.0f) {
            if (Core.app.isDesktop() || Core.app.isWeb()) {
                Scl.scl = Scl.product;
            }
            else {
                Scl.scl = Math.max(Math.round((Core.graphics.getDensity() / 1.5f + Scl.addition) / 0.5) * 0.5f, 1.0f) * Scl.product;
            }
        }
        return amount * Scl.scl * 1.0f;
    }
    
    static {
        Scl.scl = -1.0f;
        Scl.addition = 0.0f;
        Scl.product = 1.0f;
    }
}
