// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui.layout;

import arc.util.pooling.Pools;
import arc.scene.ui.Slider;
import arc.func.Floatc;
import arc.scene.ui.TextArea;
import arc.scene.ui.TextField;
import arc.scene.ui.ImageButton;
import arc.scene.ui.TextButton;
import arc.scene.ui.Button;
import arc.scene.utils.Elem;
import arc.scene.ui.CheckBox;
import arc.func.Boolc;
import arc.scene.style.TextureRegionDrawable;
import arc.scene.ui.Image;
import arc.graphics.g2d.TextureRegion;
import arc.Core;
import arc.scene.ui.ScrollPane;
import arc.scene.ui.Label;
import arc.func.Prov;
import arc.func.Boolp;
import arc.scene.Element;
import arc.graphics.Color;
import arc.graphics.g2d.Draw;
import arc.func.Cons;
import arc.scene.event.Touchable;
import arc.scene.style.Drawable;
import arc.struct.Seq;
import arc.util.pooling.Pool;

public class Table extends WidgetGroup
{
    private static float[] columnWeightedWidth;
    private static float[] rowWeightedHeight;
    private static Pool<Cell> cellPool;
    private final Seq<Cell> cells;
    private final Cell cellDefaults;
    float marginTop;
    float marginLeft;
    float marginBot;
    float marginRight;
    int align;
    Drawable background;
    boolean round;
    private int columns;
    private int rows;
    private boolean implicitEndRow;
    private Cell rowDefaults;
    private boolean sizeInvalid;
    private float[] columnMinWidth;
    private float[] rowMinHeight;
    private float[] columnPrefWidth;
    private float[] rowPrefHeight;
    private float tableMinWidth;
    private float tableMinHeight;
    private float tablePrefWidth;
    private float tablePrefHeight;
    private float[] columnWidth;
    private float[] rowHeight;
    private float[] expandWidth;
    private float[] expandHeight;
    private boolean clip;
    
    public Table() {
        this.cells = new Seq<Cell>(4);
        this.marginTop = Float.NEGATIVE_INFINITY;
        this.marginLeft = Float.NEGATIVE_INFINITY;
        this.marginBot = Float.NEGATIVE_INFINITY;
        this.marginRight = Float.NEGATIVE_INFINITY;
        this.align = 1;
        this.round = true;
        this.sizeInvalid = true;
        this.cellDefaults = this.obtainCell();
        this.setTransform(false);
        this.touchable = Touchable.childrenOnly;
    }
    
    public Table(final Drawable background) {
        this();
        this.background(background);
    }
    
    public Table(final Drawable background, final Cons<Table> cons) {
        this(background);
        cons.get(this);
    }
    
    public Table(final Cons<Table> cons) {
        this();
        cons.get(this);
    }
    
    private Cell obtainCell() {
        final Cell cell = Table.cellPool.obtain();
        cell.setLayout(this);
        return cell;
    }
    
    public Table fill() {
        final Table table = new Table();
        table.setFillParent(true);
        this.add(table);
        return table;
    }
    
    @Override
    public void draw() {
        this.validate();
        if (this.isTransform()) {
            this.applyTransform(this.computeTransform());
            this.drawBackground(0.0f, 0.0f);
            if (this.clip) {
                Draw.flush();
                final float padLeft = this.getMarginLeft();
                final float padBottom = this.getMarginBottom();
                if (this.clipBegin(padLeft, padBottom, this.getWidth() - padLeft - this.getMarginRight(), this.getHeight() - padBottom - this.getMarginTop())) {
                    this.drawChildren();
                    Draw.flush();
                    this.clipEnd();
                }
            }
            else {
                this.drawChildren();
            }
            this.resetTransform();
        }
        else {
            this.drawBackground(this.x, this.y);
            super.draw();
        }
    }
    
    protected void drawBackground(final float x, final float y) {
        if (this.background == null) {
            return;
        }
        final Color color = this.color;
        Draw.color(color.r, color.g, color.b, color.a * this.parentAlpha);
        this.background.draw(x, y, this.width, this.height);
    }
    
    public Table background(final Drawable background) {
        this.setBackground(background);
        return this;
    }
    
    public Drawable getBackground() {
        return this.background;
    }
    
    public void setBackground(final Drawable background) {
        if (this.background == background) {
            return;
        }
        final float padTopOld = this.getMarginTop();
        final float padLeftOld = this.getMarginLeft();
        final float padBottomOld = this.getMarginBottom();
        final float padRightOld = this.getMarginRight();
        this.background = background;
        final float padTopNew = this.getMarginTop();
        final float padLeftNew = this.getMarginLeft();
        final float padBottomNew = this.getMarginBottom();
        final float padRightNew = this.getMarginRight();
        if (padTopOld + padBottomOld != padTopNew + padBottomNew || padLeftOld + padRightOld != padLeftNew + padRightNew) {
            this.invalidateHierarchy();
        }
        else if (padTopOld != padTopNew || padLeftOld != padLeftNew || padBottomOld != padBottomNew || padRightOld != padRightNew) {
            this.invalidate();
        }
    }
    
    @Override
    public Element hit(final float x, final float y, final boolean touchable) {
        if (this.clip) {
            if (touchable && this.touchable == Touchable.disabled) {
                return null;
            }
            if (x < 0.0f || x >= this.getWidth() || y < 0.0f || y >= this.getHeight()) {
                return null;
            }
        }
        return super.hit(x, y, touchable);
    }
    
    public boolean getClip() {
        return this.clip;
    }
    
    public void setClip(final boolean enabled) {
        this.setTransform(this.clip = enabled);
        this.invalidate();
    }
    
    @Override
    public void invalidate() {
        this.sizeInvalid = true;
        super.invalidate();
    }
    
    public <T extends Element> Cell<T> add(final T element) {
        final Cell<T> cell = (Cell<T>)this.obtainCell();
        cell.element = element;
        if (this.implicitEndRow) {
            this.implicitEndRow = false;
            --this.rows;
            this.cells.peek().endRow = false;
        }
        final Seq<Cell> cells = this.cells;
        final int cellCount = cells.size;
        if (cellCount > 0) {
            final Cell lastCell = cells.peek();
            if (!lastCell.endRow) {
                cell.column = lastCell.column + lastCell.colspan;
                cell.row = lastCell.row;
            }
            else {
                cell.column = 0;
                cell.row = lastCell.row + 1;
            }
            Label_0205: {
                if (cell.row > 0) {
                    for (int i = cellCount - 1; i >= 0; --i) {
                        final Cell other = cells.get(i);
                        for (int column = other.column, nn = column + other.colspan; column < nn; ++column) {
                            if (column == cell.column) {
                                cell.cellAboveIndex = i;
                                break Label_0205;
                            }
                        }
                    }
                }
            }
        }
        else {
            cell.column = 0;
            cell.row = 0;
        }
        cells.add(cell);
        cell.set(this.cellDefaults);
        if (element != null) {
            this.addChild(element);
        }
        return cell;
    }
    
    public void add(final Element... elements) {
        for (final Element element : elements) {
            this.add(element);
        }
    }
    
    public Cell<Collapser> collapser(final Cons<Table> cons, final Boolp shown) {
        return this.collapser(cons, false, shown);
    }
    
    public Cell<Collapser> collapser(final Table table, final Boolp shown) {
        return this.collapser(table, false, shown);
    }
    
    public Cell<Collapser> collapser(final Cons<Table> cons, final boolean animate, final Boolp shown) {
        final Collapser col = new Collapser(cons, !shown.get());
        col.setCollapsed(animate, () -> !shown.get());
        return this.add(col);
    }
    
    public Cell<Collapser> collapser(final Table table, final boolean animate, final Boolp shown) {
        final Collapser col = new Collapser(table, !shown.get());
        col.setCollapsed(animate, () -> !shown.get());
        return this.add(col);
    }
    
    public Cell<Table> table() {
        return this.table((Drawable)null);
    }
    
    public Cell<Table> table(final Drawable background) {
        final Table table = new Table(background);
        return this.add(table);
    }
    
    public Cell<Table> table(final Cons<Table> cons) {
        final Table table = new Table();
        cons.get(table);
        return this.add(table);
    }
    
    public Cell<Table> table(final Drawable background, final Cons<Table> cons) {
        return this.table(background, 1, cons);
    }
    
    public Cell<Table> table(final Drawable background, final int align, final Cons<Table> cons) {
        final Table table = new Table(background);
        table.align(align);
        cons.get(table);
        return this.add(table);
    }
    
    public Cell<Label> label(final Prov<CharSequence> text) {
        return this.add(new Label(text));
    }
    
    public Cell<Label> labelWrap(final Prov<CharSequence> text) {
        final Label label = new Label(text);
        label.setWrap(true);
        return this.add(label);
    }
    
    public Cell<Label> labelWrap(final String text) {
        final Label label = new Label(text);
        label.setWrap(true);
        return this.add(label);
    }
    
    public Cell<ScrollPane> pane(final Cons<Table> consumer) {
        return this.pane(Core.scene.getStyle(ScrollPane.ScrollPaneStyle.class), consumer);
    }
    
    public Cell<ScrollPane> pane(final ScrollPane.ScrollPaneStyle style, final Cons<Table> consumer) {
        final Table table = new Table();
        consumer.get(table);
        final ScrollPane pane = new ScrollPane(table, style);
        return this.add(pane);
    }
    
    public Cell<ScrollPane> pane(final ScrollPane.ScrollPaneStyle style, final Element element) {
        final ScrollPane pane = new ScrollPane(element, style);
        return this.add(pane);
    }
    
    public Cell<ScrollPane> pane(final Element element) {
        return this.pane(Core.scene.getStyle(ScrollPane.ScrollPaneStyle.class), element);
    }
    
    public Cell<Label> add(final CharSequence text) {
        return this.add(new Label(text));
    }
    
    public Cell<Label> add(final CharSequence text, final float scl) {
        final Label l = new Label(text);
        l.setFontScale(scl);
        return this.add(l);
    }
    
    public Cell<Label> add(final CharSequence text, final Label.LabelStyle labelStyle, final float scl) {
        final Label l = new Label(text, labelStyle);
        l.setFontScale(scl);
        return this.add(l);
    }
    
    public Cell<Label> add(final CharSequence text, final Color color, final float scl) {
        final Label l = new Label(text);
        l.setColor(color);
        l.setFontScale(scl);
        return this.add(l);
    }
    
    public Cell<Label> add(final CharSequence text, final Label.LabelStyle labelStyle) {
        return this.add(new Label(text, labelStyle));
    }
    
    public Cell<Label> add(final CharSequence text, final Color color) {
        return this.add(new Label(text, new Label.LabelStyle(Core.scene.getStyle(Label.LabelStyle.class).font, color)));
    }
    
    public Cell add() {
        return this.add((Element)null);
    }
    
    public Cell<Stack> stack(final Element... elements) {
        final Stack stack = new Stack();
        if (elements != null) {
            for (int i = 0, n = elements.length; i < n; ++i) {
                stack.addChild(elements[i]);
            }
        }
        return this.add(stack);
    }
    
    public Cell<Image> image(final Prov<TextureRegion> reg) {
        return this.add(new Image(reg.get())).update(i -> {
            ((TextureRegionDrawable)i.getDrawable()).setRegion(reg.get());
            i.layout();
        });
    }
    
    public Cell<Image> image() {
        return this.add(new Image());
    }
    
    public Cell<Image> image(final Drawable name) {
        return this.add(new Image(name));
    }
    
    public Cell<Image> image(final Drawable name, final Color color) {
        final Image image = new Image(name);
        image.setColor(color);
        return this.add(image);
    }
    
    public Cell<Image> image(final TextureRegion region) {
        return this.add(new Image(region));
    }
    
    public Cell<CheckBox> check(final String text, final Boolc listener) {
        final CheckBox button = Elem.newCheck(text, listener);
        return this.add(button);
    }
    
    public Cell<CheckBox> check(final String text, final boolean checked, final Boolc listener) {
        final CheckBox button = Elem.newCheck(text, listener);
        button.setChecked(checked);
        return this.add(button);
    }
    
    public Cell<CheckBox> check(final String text, final float imagesize, final boolean checked, final Boolc listener) {
        final CheckBox button = Elem.newCheck(text, listener);
        button.getImageCell().size(imagesize);
        button.setChecked(checked);
        return this.add(button);
    }
    
    public Cell<Button> button(final Cons<Button> cons, final Runnable listener) {
        final Button button = new Button();
        button.clearChildren();
        button.clicked(listener);
        cons.get(button);
        return this.add(button);
    }
    
    public Cell<Button> button(final Cons<Button> cons, final Button.ButtonStyle style, final Runnable listener) {
        final Button button = new Button(style);
        button.clearChildren();
        button.clicked(listener);
        cons.get(button);
        return this.add(button);
    }
    
    public Cell<TextButton> button(final String text, final Runnable listener) {
        final TextButton button = Elem.newButton(text, listener);
        return this.add(button);
    }
    
    public Cell<TextButton> button(final String text, final TextButton.TextButtonStyle style, final Runnable listener) {
        final TextButton button = Elem.newButton(text, style, listener);
        return this.add(button);
    }
    
    public Cell<ImageButton> button(final Drawable icon, final Runnable listener) {
        final ImageButton button = Elem.newImageButton(icon, listener);
        return this.add(button);
    }
    
    public Cell<ImageButton> button(final Drawable icon, final float isize, final Runnable listener) {
        final ImageButton button = Elem.newImageButton(icon, listener);
        button.resizeImage(isize);
        return this.add(button);
    }
    
    public Cell<ImageButton> button(final Drawable icon, final ImageButton.ImageButtonStyle style, final float isize, final Runnable listener) {
        final ImageButton button = new ImageButton(icon, style);
        button.clicked(listener);
        button.resizeImage(isize);
        return this.add(button);
    }
    
    public Cell<ImageButton> button(final Drawable icon, final ImageButton.ImageButtonStyle style, final Runnable listener) {
        final ImageButton button = new ImageButton(icon, style);
        button.clicked(listener);
        button.resizeImage(icon.imageSize());
        return this.add(button);
    }
    
    public Cell<TextField> field(final String text, final Cons<String> listener) {
        final TextField field = Elem.newField(text, listener);
        return this.add(field);
    }
    
    public Cell<TextArea> area(final String text, final Cons<String> listener) {
        final TextArea area = new TextArea(text);
        area.changed(() -> listener.get(area.getText()));
        return this.add(area);
    }
    
    public Cell<TextArea> area(final String text, final TextField.TextFieldStyle style, final Cons<String> listener) {
        final TextArea area = new TextArea(text, style);
        area.changed(() -> listener.get(area.getText()));
        return this.add(area);
    }
    
    public Cell<TextField> field(final String text, final TextField.TextFieldFilter filter, final Cons<String> listener) {
        final TextField field = Elem.newField(text, listener);
        field.setFilter(filter);
        return this.add(field);
    }
    
    public Cell<TextField> field(final String text, final TextField.TextFieldStyle style, final Cons<String> listener) {
        final TextField field = Elem.newField(text, listener);
        field.setStyle(style);
        return this.add(field);
    }
    
    public Cell rect(final DrawRect draw) {
        return this.add(new Element() {
            @Override
            public void draw() {
                draw.draw(this.x, this.y, this.getWidth(), this.getHeight());
            }
        });
    }
    
    public Cell<TextButton> buttonRow(final String text, final Drawable image, final Runnable clicked) {
        final TextButton button = new TextButton(text);
        button.clearChildren();
        button.add(new Image(image)).update(i -> i.setColor(button.isDisabled() ? Color.gray : Color.white));
        button.row();
        button.add(button.getLabel()).padTop(4.0f).padLeft(4.0f).padRight(4.0f).wrap().growX();
        button.clicked(clicked);
        return this.add(button);
    }
    
    public Cell<TextButton> button(final String text, final Drawable image, final Runnable clicked) {
        return this.button(text, image, image.imageSize(), clicked);
    }
    
    public Cell<TextButton> button(final String text, final Drawable image, final float imagesize, final Runnable clicked) {
        final TextButton button = new TextButton(text);
        button.add(new Image(image)).size(imagesize);
        button.getCells().reverse();
        button.clicked(clicked);
        return this.add(button);
    }
    
    public Cell<TextButton> button(final String text, final Drawable image, final TextButton.TextButtonStyle style, final float imagesize, final Runnable clicked) {
        final TextButton button = new TextButton(text, style);
        button.add(new Image(image)).size(imagesize);
        button.getCells().reverse();
        button.clicked(clicked);
        return this.add(button);
    }
    
    public Cell<TextButton> button(final String text, final Drawable image, final TextButton.TextButtonStyle style, final Runnable clicked) {
        final TextButton button = new TextButton(text, style);
        button.add(new Image(image)).size(image.imageSize());
        button.getCells().reverse();
        button.clicked(clicked);
        return this.add(button);
    }
    
    public Cell<TextButton> buttonCenter(final String text, final Drawable image, final float imagesize, final Runnable clicked) {
        final TextButton button = new TextButton(text);
        button.add(new Image(image)).size(imagesize);
        button.getCells().reverse();
        button.clicked(clicked);
        button.getLabelCell().padLeft(-imagesize);
        return this.add(button);
    }
    
    public Cell<TextButton> buttonCenter(final String text, final Drawable image, final Runnable clicked) {
        final TextButton button = new TextButton(text);
        button.add(new Image(image));
        button.getCells().reverse();
        button.clicked(clicked);
        button.getLabelCell().padLeft(-image.imageSize());
        return this.add(button);
    }
    
    public Cell<TextButton> buttonCenter(final String text, final Drawable image, final TextButton.TextButtonStyle style, final float imagesize, final Runnable clicked) {
        final TextButton button = new TextButton(text, style);
        button.add(new Image(image)).size(imagesize);
        button.getCells().reverse();
        button.clicked(clicked);
        button.getLabelCell().padLeft(-imagesize);
        return this.add(button);
    }
    
    public Cell<Slider> slider(final float min, final float max, final float step, final Floatc listener) {
        return this.slider(min, max, step, 0.0f, listener);
    }
    
    public Cell<Slider> slider(final float min, final float max, final float step, final float defvalue, final Floatc listener) {
        final Slider slider = new Slider(min, max, step, false);
        slider.setValue(defvalue);
        if (listener != null) {
            slider.moved(listener);
        }
        return this.add(slider);
    }
    
    public Cell<Slider> slider(final float min, final float max, final float step, final float defvalue, final boolean onUp, final Floatc listener) {
        final Slider slider = new Slider(min, max, step, false);
        slider.setValue(defvalue);
        if (listener != null) {
            if (!onUp) {
                slider.moved(listener);
            }
            else {
                slider.released(() -> listener.get(slider.getValue()));
            }
        }
        return this.add(slider);
    }
    
    @Override
    public boolean removeChild(final Element element) {
        return this.removeChild(element, true);
    }
    
    @Override
    public boolean removeChild(final Element element, final boolean unfocus) {
        if (!super.removeChild(element, unfocus)) {
            return false;
        }
        final Cell cell = this.getCell(element);
        if (cell != null) {
            cell.element = null;
        }
        return true;
    }
    
    @Override
    public void clearChildren() {
        final Seq<Cell> cells = this.cells;
        for (int i = cells.size - 1; i >= 0; --i) {
            final Cell cell = cells.get(i);
            final Element actor = cell.element;
            if (actor != null) {
                actor.remove();
            }
        }
        Table.cellPool.freeAll(cells);
        cells.clear();
        this.rows = 0;
        this.columns = 0;
        if (this.rowDefaults != null) {
            Table.cellPool.free(this.rowDefaults);
        }
        this.rowDefaults = null;
        this.implicitEndRow = false;
        super.clearChildren();
    }
    
    public void reset() {
        this.clearChildren();
        this.marginTop = Float.NEGATIVE_INFINITY;
        this.marginLeft = Float.NEGATIVE_INFINITY;
        this.marginBot = Float.NEGATIVE_INFINITY;
        this.marginRight = Float.NEGATIVE_INFINITY;
        this.align = 1;
        this.cellDefaults.reset();
    }
    
    public Table row() {
        if (this.cells.size > 0) {
            if (!this.implicitEndRow) {
                this.endRow();
            }
            this.invalidate();
        }
        this.implicitEndRow = false;
        if (this.rowDefaults != null) {
            Table.cellPool.free(this.rowDefaults);
        }
        (this.rowDefaults = this.obtainCell()).clear();
        return this;
    }
    
    private void endRow() {
        final Seq<Cell> cells = this.cells;
        int rowColumns = 0;
        for (int i = cells.size - 1; i >= 0; --i) {
            final Cell cell = cells.get(i);
            if (cell.endRow) {
                break;
            }
            rowColumns += cell.colspan;
        }
        this.columns = Math.max(this.columns, rowColumns);
        ++this.rows;
        cells.peek().endRow = true;
    }
    
    public <T extends Element> Cell getCell(final T actor) {
        final Seq<Cell> cells = this.cells;
        for (int i = 0, n = cells.size; i < n; ++i) {
            final Cell c = cells.get(i);
            if (c.element == actor) {
                return c;
            }
        }
        return null;
    }
    
    public Seq<Cell> getCells() {
        return this.cells;
    }
    
    @Override
    public float getPrefWidth() {
        if (this.sizeInvalid) {
            this.computeSize();
        }
        final float width = this.tablePrefWidth;
        if (this.background != null) {
            return Math.max(width, this.background.getMinWidth());
        }
        return width;
    }
    
    @Override
    public float getPrefHeight() {
        if (this.sizeInvalid) {
            this.computeSize();
        }
        final float height = this.tablePrefHeight;
        if (this.background != null) {
            return Math.max(height, this.background.getMinHeight());
        }
        return height;
    }
    
    @Override
    public float getMinWidth() {
        if (this.sizeInvalid) {
            this.computeSize();
        }
        return this.tableMinWidth;
    }
    
    @Override
    public float getMinHeight() {
        if (this.sizeInvalid) {
            this.computeSize();
        }
        return this.tableMinHeight;
    }
    
    public Cell defaults() {
        return this.cellDefaults;
    }
    
    public Table margin(final float pad) {
        this.margin(pad, pad, pad, pad);
        return this;
    }
    
    public Table margin(final float top, final float left, final float bottom, final float right) {
        this.marginTop = Scl.scl(top);
        this.marginLeft = Scl.scl(left);
        this.marginBot = Scl.scl(bottom);
        this.marginRight = Scl.scl(right);
        this.sizeInvalid = true;
        return this;
    }
    
    public Table marginTop(final float padTop) {
        this.marginTop = Scl.scl(padTop);
        this.sizeInvalid = true;
        return this;
    }
    
    public Table marginLeft(final float padLeft) {
        this.marginLeft = Scl.scl(padLeft);
        this.sizeInvalid = true;
        return this;
    }
    
    public Table marginBottom(final float padBottom) {
        this.marginBot = Scl.scl(padBottom);
        this.sizeInvalid = true;
        return this;
    }
    
    public Table marginRight(final float padRight) {
        this.marginRight = Scl.scl(padRight);
        this.sizeInvalid = true;
        return this;
    }
    
    public Table align(final int align) {
        this.align = align;
        return this;
    }
    
    public Table center() {
        this.align = 1;
        return this;
    }
    
    public Table top() {
        this.align |= 0x2;
        this.align &= 0xFFFFFFFB;
        return this;
    }
    
    public Table left() {
        this.align |= 0x8;
        this.align &= 0xFFFFFFEF;
        return this;
    }
    
    public Table bottom() {
        this.align |= 0x4;
        this.align &= 0xFFFFFFFD;
        return this;
    }
    
    public Table right() {
        this.align |= 0x10;
        this.align &= 0xFFFFFFF7;
        return this;
    }
    
    public float getMarginTop() {
        return (this.marginTop != Float.NEGATIVE_INFINITY) ? this.marginTop : ((this.background == null) ? 0.0f : this.background.getTopHeight());
    }
    
    public float getMarginLeft() {
        return (this.marginLeft != Float.NEGATIVE_INFINITY) ? this.marginLeft : ((this.background == null) ? 0.0f : this.background.getLeftWidth());
    }
    
    public float getMarginBottom() {
        return (this.marginBot != Float.NEGATIVE_INFINITY) ? this.marginBot : ((this.background == null) ? 0.0f : this.background.getBottomHeight());
    }
    
    public float getMarginRight() {
        return (this.marginRight != Float.NEGATIVE_INFINITY) ? this.marginRight : ((this.background == null) ? 0.0f : this.background.getRightWidth());
    }
    
    public int getAlign() {
        return this.align;
    }
    
    public int getRow(float y) {
        final Seq<Cell> cells = this.cells;
        int row = 0;
        y += this.getMarginTop();
        int i = 0;
        final int n = cells.size;
        if (n == 0) {
            return -1;
        }
        if (n == 1) {
            return 0;
        }
        while (i < n) {
            final Cell c = cells.get(i++);
            if (c.elementY + c.computedPadTop < y) {
                break;
            }
            if (!c.endRow) {
                continue;
            }
            ++row;
        }
        return row;
    }
    
    public void setRound(final boolean round) {
        this.round = round;
    }
    
    public int getRows() {
        return this.rows;
    }
    
    public int getColumns() {
        return this.columns;
    }
    
    public float getRowHeight(final int rowIndex) {
        return this.rowHeight[rowIndex];
    }
    
    public float getColumnWidth(final int columnIndex) {
        return this.columnWidth[columnIndex];
    }
    
    private float[] ensureSize(final float[] array, final int size) {
        if (array == null || array.length < size) {
            return new float[size];
        }
        for (int i = 0, n = array.length; i < n; ++i) {
            array[i] = 0.0f;
        }
        return array;
    }
    
    @Override
    public void layout() {
        final float width = this.getWidth();
        final float height = this.getHeight();
        this.layout(0.0f, 0.0f, width, height);
        final Seq<Cell> cells = this.cells;
        if (this.round) {
            for (int i = 0, n = cells.size; i < n; ++i) {
                final Cell c = cells.get(i);
                final float actorWidth = (float)Math.round(c.elementWidth);
                final float actorHeight = (float)Math.round(c.elementHeight);
                final float actorX = (float)Math.round(c.elementX);
                final float actorY = height - Math.round(c.elementY) - actorHeight;
                c.setBounds(actorX, actorY, actorWidth, actorHeight);
                final Element actor = c.element;
                if (actor != null) {
                    actor.setBounds(actorX, actorY, actorWidth, actorHeight);
                }
            }
        }
        else {
            for (int i = 0, n = cells.size; i < n; ++i) {
                final Cell c = cells.get(i);
                final float actorHeight2 = c.elementHeight;
                final float actorY2 = height - c.elementY - actorHeight2;
                c.elementY = actorY2;
                final Element actor2 = c.element;
                if (actor2 != null) {
                    actor2.setBounds(c.elementX, actorY2, c.elementWidth, actorHeight2);
                }
            }
        }
        final Seq<Element> children = this.getChildren();
        for (int j = 0, n2 = children.size; j < n2; ++j) {
            final Element child = children.get(j);
            child.validate();
        }
    }
    
    private void computeSize() {
        this.sizeInvalid = false;
        final Seq<Cell> cells = this.cells;
        final int cellCount = cells.size;
        if (cellCount > 0 && !cells.peek().endRow) {
            this.endRow();
            this.implicitEndRow = true;
        }
        final int columns = this.columns;
        final int rows = this.rows;
        this.columnMinWidth = this.ensureSize(this.columnMinWidth, columns);
        this.rowMinHeight = this.ensureSize(this.rowMinHeight, rows);
        this.columnPrefWidth = this.ensureSize(this.columnPrefWidth, columns);
        this.rowPrefHeight = this.ensureSize(this.rowPrefHeight, rows);
        this.columnWidth = this.ensureSize(this.columnWidth, columns);
        this.rowHeight = this.ensureSize(this.rowHeight, rows);
        this.expandWidth = this.ensureSize(this.expandWidth, columns);
        this.expandHeight = this.ensureSize(this.expandHeight, rows);
        for (int i = 0; i < cellCount; ++i) {
            final Cell c = cells.get(i);
            final int column = c.column;
            final int row = c.row;
            final int colspan = c.colspan;
            if (c.expandY != 0 && this.expandHeight[row] == 0.0f) {
                this.expandHeight[row] = (float)c.expandY;
            }
            if (colspan == 1 && c.expandX != 0 && this.expandWidth[column] == 0.0f) {
                this.expandWidth[column] = (float)c.expandX;
            }
            c.computedPadLeft = c.padLeft;
            c.computedPadTop = c.padTop;
            c.computedPadRight = c.padRight;
            c.computedPadBottom = c.padBottom;
            float prefWidth = c.prefWidth();
            float prefHeight = c.prefHeight();
            final float minWidth = c.minWidth();
            final float minHeight = c.minHeight();
            final float maxWidth = c.maxWidth();
            final float maxHeight = c.maxHeight();
            if (prefWidth < minWidth) {
                prefWidth = minWidth;
            }
            if (prefHeight < minHeight) {
                prefHeight = minHeight;
            }
            if (maxWidth > 0.0f && prefWidth > maxWidth) {
                prefWidth = maxWidth;
            }
            if (maxHeight > 0.0f && prefHeight > maxHeight) {
                prefHeight = maxHeight;
            }
            if (colspan == 1) {
                final float hpadding = c.computedPadLeft + c.computedPadRight;
                this.columnPrefWidth[column] = Math.max(this.columnPrefWidth[column], prefWidth + hpadding);
                this.columnMinWidth[column] = Math.max(this.columnMinWidth[column], minWidth + hpadding);
            }
            final float vpadding = c.computedPadTop + c.computedPadBottom;
            this.rowPrefHeight[row] = Math.max(this.rowPrefHeight[row], prefHeight + vpadding);
            this.rowMinHeight[row] = Math.max(this.rowMinHeight[row], minHeight + vpadding);
        }
        float uniformMinWidth = 0.0f;
        float uniformMinHeight = 0.0f;
        float uniformPrefWidth = 0.0f;
        float uniformPrefHeight = 0.0f;
        for (int j = 0; j < cellCount; ++j) {
            final Cell c2 = cells.get(j);
            final int column2 = c2.column;
            final int expandX = c2.expandX;
            Label_0663: {
                if (expandX != 0) {
                    final int nn = column2 + c2.colspan;
                    for (int ii = column2; ii < nn; ++ii) {
                        if (this.expandWidth[ii] != 0.0f) {
                            break Label_0663;
                        }
                    }
                    for (int ii = column2; ii < nn; ++ii) {
                        this.expandWidth[ii] = (float)expandX;
                    }
                }
            }
            if (c2.uniformX && c2.colspan == 1) {
                final float hpadding2 = c2.computedPadLeft + c2.computedPadRight;
                uniformMinWidth = Math.max(uniformMinWidth, this.columnMinWidth[column2] - hpadding2);
                uniformPrefWidth = Math.max(uniformPrefWidth, this.columnPrefWidth[column2] - hpadding2);
            }
            if (c2.uniformY) {
                final float vpadding2 = c2.computedPadTop + c2.computedPadBottom;
                uniformMinHeight = Math.max(uniformMinHeight, this.rowMinHeight[c2.row] - vpadding2);
                uniformPrefHeight = Math.max(uniformPrefHeight, this.rowPrefHeight[c2.row] - vpadding2);
            }
        }
        if (uniformPrefWidth > 0.0f || uniformPrefHeight > 0.0f) {
            for (int j = 0; j < cellCount; ++j) {
                final Cell c2 = cells.get(j);
                if (uniformPrefWidth > 0.0f && c2.uniformX && c2.colspan == 1) {
                    final float hpadding3 = c2.computedPadLeft + c2.computedPadRight;
                    this.columnMinWidth[c2.column] = uniformMinWidth + hpadding3;
                    this.columnPrefWidth[c2.column] = uniformPrefWidth + hpadding3;
                }
                if (uniformPrefHeight > 0.0f && c2.uniformY) {
                    final float vpadding3 = c2.computedPadTop + c2.computedPadBottom;
                    this.rowMinHeight[c2.row] = uniformMinHeight + vpadding3;
                    this.rowPrefHeight[c2.row] = uniformPrefHeight + vpadding3;
                }
            }
        }
        for (int j = 0; j < cellCount; ++j) {
            final Cell c2 = cells.get(j);
            final int colspan2 = c2.colspan;
            if (colspan2 != 1) {
                final int column3 = c2.column;
                final Element a = c2.element;
                final float minWidth2 = c2.minWidth();
                float prefWidth2 = c2.prefWidth();
                final float maxWidth2 = c2.maxWidth();
                if (prefWidth2 < minWidth2) {
                    prefWidth2 = minWidth2;
                }
                if (maxWidth2 > 0.0f && prefWidth2 > maxWidth2) {
                    prefWidth2 = maxWidth2;
                }
                float spannedPrefWidth;
                float spannedMinWidth = spannedPrefWidth = -(c2.computedPadLeft + c2.computedPadRight);
                float totalExpandWidth = 0.0f;
                for (int ii2 = column3, nn2 = ii2 + colspan2; ii2 < nn2; ++ii2) {
                    spannedMinWidth += this.columnMinWidth[ii2];
                    spannedPrefWidth += this.columnPrefWidth[ii2];
                    totalExpandWidth += this.expandWidth[ii2];
                }
                final float extraMinWidth = Math.max(0.0f, minWidth2 - spannedMinWidth);
                final float extraPrefWidth = Math.max(0.0f, prefWidth2 - spannedPrefWidth);
                for (int ii3 = column3, nn3 = ii3 + colspan2; ii3 < nn3; ++ii3) {
                    final float ratio = (totalExpandWidth == 0.0f) ? (1.0f / colspan2) : (this.expandWidth[ii3] / totalExpandWidth);
                    final float[] columnMinWidth = this.columnMinWidth;
                    final int n = ii3;
                    columnMinWidth[n] += extraMinWidth * ratio;
                    final float[] columnPrefWidth = this.columnPrefWidth;
                    final int n2 = ii3;
                    columnPrefWidth[n2] += extraPrefWidth * ratio;
                }
            }
        }
        this.tableMinWidth = 0.0f;
        this.tableMinHeight = 0.0f;
        this.tablePrefWidth = 0.0f;
        this.tablePrefHeight = 0.0f;
        for (int j = 0; j < columns; ++j) {
            this.tableMinWidth += this.columnMinWidth[j];
            this.tablePrefWidth += this.columnPrefWidth[j];
        }
        for (int j = 0; j < rows; ++j) {
            this.tableMinHeight += this.rowMinHeight[j];
            this.tablePrefHeight += Math.max(this.rowMinHeight[j], this.rowPrefHeight[j]);
        }
        final float hpadding4 = this.getMarginLeft() + this.getMarginRight();
        final float vpadding4 = this.getMarginTop() + this.getMarginBottom();
        this.tableMinWidth += hpadding4;
        this.tableMinHeight += vpadding4;
        this.tablePrefWidth = Math.max(this.tablePrefWidth + hpadding4, this.tableMinWidth);
        this.tablePrefHeight = Math.max(this.tablePrefHeight + vpadding4, this.tableMinHeight);
    }
    
    private void layout(final float layoutX, final float layoutY, final float layoutWidth, final float layoutHeight) {
        final Seq<Cell> cells = this.cells;
        final int cellCount = cells.size;
        if (this.sizeInvalid) {
            this.computeSize();
        }
        final float padLeft = this.getMarginLeft();
        final float hpadding = padLeft + this.getMarginRight();
        final float padTop = this.getMarginTop();
        final float vpadding = padTop + this.getMarginBottom();
        final int columns = this.columns;
        final int rows = this.rows;
        final float[] expandWidth = this.expandWidth;
        final float[] expandHeight = this.expandHeight;
        final float[] columnWidth = this.columnWidth;
        final float[] rowHeight = this.rowHeight;
        float totalExpandWidth = 0.0f;
        float totalExpandHeight = 0.0f;
        for (int i = 0; i < columns; ++i) {
            totalExpandWidth += expandWidth[i];
        }
        for (int i = 0; i < rows; ++i) {
            totalExpandHeight += expandHeight[i];
        }
        final float totalGrowWidth = this.tablePrefWidth - this.tableMinWidth;
        float[] columnWeightedWidth;
        if (totalGrowWidth == 0.0f) {
            columnWeightedWidth = this.columnMinWidth;
        }
        else {
            final float extraWidth = Math.min(totalGrowWidth, Math.max(0.0f, layoutWidth - this.tableMinWidth));
            columnWeightedWidth = (Table.columnWeightedWidth = this.ensureSize(Table.columnWeightedWidth, columns));
            final float[] columnMinWidth = this.columnMinWidth;
            final float[] columnPrefWidth = this.columnPrefWidth;
            for (int j = 0; j < columns; ++j) {
                final float growWidth = columnPrefWidth[j] - columnMinWidth[j];
                final float growRatio = growWidth / totalGrowWidth;
                columnWeightedWidth[j] = columnMinWidth[j] + extraWidth * growRatio;
            }
        }
        final float totalGrowHeight = this.tablePrefHeight - this.tableMinHeight;
        float[] rowWeightedHeight;
        if (totalGrowHeight == 0.0f) {
            rowWeightedHeight = this.rowMinHeight;
        }
        else {
            rowWeightedHeight = (Table.rowWeightedHeight = this.ensureSize(Table.rowWeightedHeight, rows));
            final float extraHeight = Math.min(totalGrowHeight, Math.max(0.0f, layoutHeight - this.tableMinHeight));
            final float[] rowMinHeight = this.rowMinHeight;
            final float[] rowPrefHeight = this.rowPrefHeight;
            for (int k = 0; k < rows; ++k) {
                final float growHeight = rowPrefHeight[k] - rowMinHeight[k];
                final float growRatio2 = growHeight / totalGrowHeight;
                rowWeightedHeight[k] = rowMinHeight[k] + extraHeight * growRatio2;
            }
        }
        for (int l = 0; l < cellCount; ++l) {
            final Cell c = cells.get(l);
            final int column = c.column;
            final int row = c.row;
            float spannedWeightedWidth = 0.0f;
            final int colspan = c.colspan;
            for (int ii = column, nn = ii + colspan; ii < nn; ++ii) {
                spannedWeightedWidth += columnWeightedWidth[ii];
            }
            final float weightedHeight = rowWeightedHeight[row];
            float prefWidth = c.prefWidth();
            float prefHeight = c.prefHeight();
            final float minWidth = c.minWidth();
            final float minHeight = c.minHeight();
            final float maxWidth = c.maxWidth();
            final float maxHeight = c.maxHeight();
            if (prefWidth < minWidth) {
                prefWidth = minWidth;
            }
            if (prefHeight < minHeight) {
                prefHeight = minHeight;
            }
            if (maxWidth > 0.0f && prefWidth > maxWidth) {
                prefWidth = maxWidth;
            }
            if (maxHeight > 0.0f && prefHeight > maxHeight) {
                prefHeight = maxHeight;
            }
            c.elementWidth = Math.min(spannedWeightedWidth - c.computedPadLeft - c.computedPadRight, prefWidth);
            c.elementHeight = Math.min(weightedHeight - c.computedPadTop - c.computedPadBottom, prefHeight);
            if (colspan == 1) {
                columnWidth[column] = Math.max(columnWidth[column], spannedWeightedWidth);
            }
            rowHeight[row] = Math.max(rowHeight[row], weightedHeight);
        }
        if (totalExpandWidth > 0.0f) {
            float extra = layoutWidth - hpadding;
            for (int j = 0; j < columns; ++j) {
                extra -= columnWidth[j];
            }
            float used = 0.0f;
            int lastIndex = 0;
            for (int k = 0; k < columns; ++k) {
                if (expandWidth[k] != 0.0f) {
                    final float amount = extra * expandWidth[k] / totalExpandWidth;
                    final float[] array = columnWidth;
                    final int n = k;
                    array[n] += amount;
                    used += amount;
                    lastIndex = k;
                }
            }
            final float[] array2 = columnWidth;
            final int n2 = lastIndex;
            array2[n2] += extra - used;
        }
        if (totalExpandHeight > 0.0f) {
            float extra = layoutHeight - vpadding;
            for (int j = 0; j < rows; ++j) {
                extra -= rowHeight[j];
            }
            float used = 0.0f;
            int lastIndex = 0;
            for (int k = 0; k < rows; ++k) {
                if (expandHeight[k] != 0.0f) {
                    final float amount = extra * expandHeight[k] / totalExpandHeight;
                    final float[] array3 = rowHeight;
                    final int n3 = k;
                    array3[n3] += amount;
                    used += amount;
                    lastIndex = k;
                }
            }
            final float[] array4 = rowHeight;
            final int n4 = lastIndex;
            array4[n4] += extra - used;
        }
        for (int l = 0; l < cellCount; ++l) {
            final Cell c = cells.get(l);
            final int colspan2 = c.colspan;
            if (colspan2 != 1) {
                float extraWidth2 = 0.0f;
                for (int column2 = c.column, nn2 = column2 + colspan2; column2 < nn2; ++column2) {
                    extraWidth2 += columnWeightedWidth[column2] - columnWidth[column2];
                }
                extraWidth2 -= Math.max(0.0f, c.computedPadLeft + c.computedPadRight);
                extraWidth2 /= colspan2;
                if (extraWidth2 > 0.0f) {
                    for (int column2 = c.column, nn2 = column2 + colspan2; column2 < nn2; ++column2) {
                        final float[] array5 = columnWidth;
                        final int n5 = column2;
                        array5[n5] += extraWidth2;
                    }
                }
            }
        }
        float tableWidth = hpadding;
        float tableHeight = vpadding;
        for (int m = 0; m < columns; ++m) {
            tableWidth += columnWidth[m];
        }
        for (int m = 0; m < rows; ++m) {
            tableHeight += rowHeight[m];
        }
        int align = this.align;
        float x = layoutX + padLeft;
        if ((align & 0x10) != 0x0) {
            x += layoutWidth - tableWidth;
        }
        else if ((align & 0x8) == 0x0) {
            x += (layoutWidth - tableWidth) / 2.0f;
        }
        float y = layoutY + padTop;
        if ((align & 0x4) != 0x0) {
            y += layoutHeight - tableHeight;
        }
        else if ((align & 0x2) == 0x0) {
            y += (layoutHeight - tableHeight) / 2.0f;
        }
        float currentX = x;
        float currentY = y;
        for (int i2 = 0; i2 < cellCount; ++i2) {
            final Cell c2 = cells.get(i2);
            float spannedCellWidth = 0.0f;
            for (int column3 = c2.column, nn3 = column3 + c2.colspan; column3 < nn3; ++column3) {
                spannedCellWidth += columnWidth[column3];
            }
            spannedCellWidth -= c2.computedPadLeft + c2.computedPadRight;
            currentX += c2.computedPadLeft;
            final float fillX = c2.fillX;
            final float fillY = c2.fillY;
            if (fillX > 0.0f) {
                c2.elementWidth = Math.max(spannedCellWidth * fillX, c2.minWidth());
                final float maxWidth2 = c2.maxWidth;
                if (maxWidth2 > 0.0f) {
                    c2.elementWidth = Math.min(c2.elementWidth, maxWidth2);
                }
            }
            if (fillY > 0.0f) {
                c2.elementHeight = Math.max(rowHeight[c2.row] * fillY - c2.computedPadTop - c2.computedPadBottom, c2.minHeight());
                final float maxHeight = c2.maxHeight();
                if (maxHeight > 0.0f) {
                    c2.elementHeight = Math.min(c2.elementHeight, maxHeight);
                }
            }
            align = c2.align;
            if ((align & 0x8) != 0x0) {
                c2.elementX = currentX;
            }
            else if ((align & 0x10) != 0x0) {
                c2.elementX = currentX + spannedCellWidth - c2.elementWidth;
            }
            else {
                c2.elementX = currentX + (spannedCellWidth - c2.elementWidth) / 2.0f;
            }
            if ((align & 0x2) != 0x0) {
                c2.elementY = currentY + c2.computedPadTop;
            }
            else if ((align & 0x4) != 0x0) {
                c2.elementY = currentY + rowHeight[c2.row] - c2.elementHeight - c2.computedPadBottom;
            }
            else {
                c2.elementY = currentY + (rowHeight[c2.row] - c2.elementHeight + c2.computedPadTop - c2.computedPadBottom) / 2.0f;
            }
            if (c2.endRow) {
                currentX = x;
                currentY += rowHeight[c2.row];
            }
            else {
                currentX += spannedCellWidth + c2.computedPadRight;
            }
        }
    }
    
    static {
        Table.cellPool = (Pool<Cell>)Pools.get(Cell.class, Cell::new);
    }
    
    public interface DrawRect
    {
        void draw(final float p0, final float p1, final float p2, final float p3);
    }
}
