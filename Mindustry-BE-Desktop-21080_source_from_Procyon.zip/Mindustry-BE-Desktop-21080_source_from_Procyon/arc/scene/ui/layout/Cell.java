// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui.layout;

import arc.scene.ui.ScrollPane;
import arc.scene.style.Style;
import arc.graphics.Color;
import arc.scene.ui.ButtonGroup;
import arc.scene.ui.TextButton;
import arc.scene.ui.Label;
import arc.scene.ui.TextField;
import arc.scene.ui.Image;
import arc.util.Scaling;
import arc.func.Boolp;
import arc.func.Prov;
import arc.scene.event.Touchable;
import arc.scene.utils.Disableable;
import arc.scene.ui.Button;
import arc.func.Boolf;
import arc.scene.event.EventListener;
import arc.scene.ui.Tooltip;
import arc.func.Cons;
import arc.util.pooling.Pool;
import arc.scene.Element;

public class Cell<T extends Element> implements Pool.Poolable
{
    private static boolean dset;
    private static Cell defaults;
    static final float unset = Float.NEGATIVE_INFINITY;
    float minWidth;
    float minHeight;
    float maxWidth;
    float maxHeight;
    float padTop;
    float padLeft;
    float padBottom;
    float padRight;
    float fillX;
    float fillY;
    int align;
    int expandX;
    int expandY;
    int colspan;
    boolean uniformX;
    boolean uniformY;
    Element element;
    float elementX;
    float elementY;
    float elementWidth;
    float elementHeight;
    boolean endRow;
    int column;
    int row;
    int cellAboveIndex;
    float computedPadTop;
    float computedPadLeft;
    float computedPadBottom;
    float computedPadRight;
    private Table table;
    
    public Cell() {
        this.reset();
    }
    
    public static Cell defaults() {
        if (!Cell.dset) {
            Cell.dset = true;
            Cell.defaults = new Cell();
            Cell.defaults.minWidth = Float.NEGATIVE_INFINITY;
            Cell.defaults.minHeight = Float.NEGATIVE_INFINITY;
            Cell.defaults.maxWidth = Float.NEGATIVE_INFINITY;
            Cell.defaults.maxHeight = Float.NEGATIVE_INFINITY;
            Cell.defaults.padTop = 0.0f;
            Cell.defaults.padLeft = 0.0f;
            Cell.defaults.padBottom = 0.0f;
            Cell.defaults.padRight = 0.0f;
            Cell.defaults.fillX = 0.0f;
            Cell.defaults.fillY = 0.0f;
            Cell.defaults.align = 0;
            Cell.defaults.expandX = 0;
            Cell.defaults.expandY = 0;
            Cell.defaults.colspan = 1;
            Cell.defaults.uniformX = false;
            Cell.defaults.uniformY = false;
        }
        return Cell.defaults;
    }
    
    public void setLayout(final Table table) {
        this.table = table;
    }
    
    public <A extends Element> Cell<A> setElement(final A newElement) {
        if (this.element != newElement) {
            if (this.element != null) {
                this.element.remove();
            }
            if ((this.element = newElement) != null) {
                this.table.addChild(newElement);
            }
        }
        return (Cell<A>)this;
    }
    
    public Cell<T> clearElement() {
        this.setElement((Element)null);
        return this;
    }
    
    public Cell<T> with(final Cons<T> c) {
        c.get((T)this.element);
        return this;
    }
    
    public Cell<T> self(final Cons<Cell<T>> c) {
        c.get(this);
        return this;
    }
    
    public T get() {
        return (T)this.element;
    }
    
    public boolean hasElement() {
        return this.element != null;
    }
    
    public float prefWidth() {
        return (this.element == null) ? 0.0f : this.element.getPrefWidth();
    }
    
    public float prefHeight() {
        return (this.element == null) ? 0.0f : this.element.getPrefHeight();
    }
    
    public float maxWidth() {
        return (this.maxWidth == Float.NEGATIVE_INFINITY) ? ((this.element == null) ? 0.0f : this.element.getMaxWidth()) : this.maxWidth;
    }
    
    public float maxHeight() {
        return (this.maxHeight == Float.NEGATIVE_INFINITY) ? ((this.element == null) ? 0.0f : this.element.getMaxHeight()) : this.maxHeight;
    }
    
    public float minWidth() {
        return (this.minWidth == Float.NEGATIVE_INFINITY) ? ((this.element == null) ? 0.0f : this.element.getMinWidth()) : this.minWidth;
    }
    
    public float minHeight() {
        return (this.minHeight == Float.NEGATIVE_INFINITY) ? ((this.element == null) ? 0.0f : this.element.getMinHeight()) : this.minHeight;
    }
    
    public Cell<T> tooltip(final String text) {
        this.element.addListener(Tooltip.Tooltips.getInstance().create(text));
        return this;
    }
    
    public Cell<T> size(final float size) {
        final float scl = this.scl(size);
        this.maxHeight = scl;
        this.maxWidth = scl;
        this.minHeight = scl;
        this.minWidth = scl;
        return this;
    }
    
    public Cell<T> size(final float width, final float height) {
        final float scl = this.scl(width);
        this.maxWidth = scl;
        this.minWidth = scl;
        final float scl2 = this.scl(height);
        this.maxHeight = scl2;
        this.minHeight = scl2;
        return this;
    }
    
    public Cell<T> name(final String name) {
        this.get().name = name;
        return this;
    }
    
    public Cell<T> update(final Cons<T> updater) {
        final T t = this.get();
        t.update(() -> updater.get(t));
        return this;
    }
    
    public Cell<T> disabled(final Boolf<T> vis) {
        if (this.element instanceof Button) {
            final T t = this.get();
            ((Button)this.element).setDisabled(() -> vis.get(t));
        }
        else if (this.element instanceof Disableable) {
            final T t = this.get();
            final T t2;
            this.element.update(() -> ((Disableable)this.element).setDisabled(vis.get(t2)));
        }
        return this;
    }
    
    public Cell<T> disabled(final boolean disabled) {
        if (this.get() instanceof Disableable) {
            this.get().setDisabled(disabled);
        }
        return this;
    }
    
    public Cell<T> touchable(final Touchable touchable) {
        this.get().touchable = touchable;
        return this;
    }
    
    public Cell<T> touchable(final Prov<Touchable> touchable) {
        this.get().touchable(touchable);
        return this;
    }
    
    public Cell<T> visible(final Boolp prov) {
        this.get().visible(prov);
        return this;
    }
    
    public Cell<T> visible(final boolean visible) {
        this.get().visible = visible;
        return this;
    }
    
    public Cell<T> scaling(final Scaling scaling) {
        if (this.element instanceof Image) {
            ((Image)this.element).setScaling(scaling);
        }
        return this;
    }
    
    public Cell<T> valid(final TextField.TextFieldValidator val) {
        if (this.element instanceof TextField) {
            ((TextField)this.element).setValidator(val);
        }
        return this;
    }
    
    public Cell<T> maxTextLength(final int length) {
        if (this.element instanceof TextField) {
            ((TextField)this.element).setMaxLength(length);
        }
        return this;
    }
    
    public Cell<T> addInputDialog() {
        if (this.element instanceof TextField) {
            ((TextField)this.element).addInputDialog();
        }
        return this;
    }
    
    public Cell<T> addInputDialog(final int maxLength) {
        if (this.element instanceof TextField) {
            ((TextField)this.element).setMaxLength(maxLength);
            ((TextField)this.element).addInputDialog();
        }
        return this;
    }
    
    public Cell<T> wrap() {
        if (this.get() instanceof Label) {
            this.get().setWrap(true);
        }
        else if (this.get() instanceof TextButton) {
            this.get().getLabel().setWrap(true);
        }
        return this;
    }
    
    public Cell<T> labelAlign(final int label, final int line) {
        if (this.get() instanceof Label) {
            this.get().setAlignment(label, line);
        }
        return this;
    }
    
    public Cell<T> labelAlign(final int label) {
        return this.labelAlign(label, label);
    }
    
    public <N extends Button> Cell<T> group(final ButtonGroup<N> group) {
        if (this.get() instanceof Button) {
            group.add(this.get());
        }
        return this;
    }
    
    public Cell<T> checked(final boolean toggle) {
        if (this.get() instanceof Button) {
            this.get().setChecked(toggle);
        }
        return this;
    }
    
    public Cell<T> checked(final Boolf<T> toggle) {
        final T t = this.get();
        if (t instanceof Button) {
            final Element element;
            t.update(() -> ((Button)element).setChecked(toggle.get((T)element)));
        }
        return this;
    }
    
    public Cell<T> fontScale(final float scale) {
        if (this.element instanceof Label) {
            ((Label)this.element).setFontScale(scale);
        }
        return this;
    }
    
    public Cell<T> color(final Color color) {
        this.get().setColor(color);
        return this;
    }
    
    public Cell<T> margin(final float margin) {
        if (this.get() instanceof Table) {
            this.get().margin(margin);
        }
        return this;
    }
    
    public Cell<T> marginTop(final float margin) {
        if (this.get() instanceof Table) {
            this.get().marginTop(margin);
        }
        return this;
    }
    
    public Cell<T> marginBottom(final float margin) {
        if (this.get() instanceof Table) {
            this.get().marginBottom(margin);
        }
        return this;
    }
    
    public Cell<T> marginLeft(final float margin) {
        if (this.get() instanceof Table) {
            this.get().marginLeft(margin);
        }
        return this;
    }
    
    public Cell<T> marginRight(final float margin) {
        if (this.get() instanceof Table) {
            this.get().marginRight(margin);
        }
        return this;
    }
    
    public Cell<T> width(final float width) {
        final float scl = this.scl(width);
        this.maxWidth = scl;
        this.minWidth = scl;
        return this;
    }
    
    public Cell<T> style(final Style style) {
        if (style == null) {
            return this;
        }
        if (this.element instanceof Label) {
            ((Label)this.element).setStyle((Label.LabelStyle)style);
        }
        else if (this.element instanceof Button) {
            ((Button)this.element).setStyle((Button.ButtonStyle)style);
        }
        else if (this.element instanceof ScrollPane) {
            ((ScrollPane)this.element).setStyle((ScrollPane.ScrollPaneStyle)style);
        }
        return this;
    }
    
    public Cell<T> height(final float height) {
        final float scl = this.scl(height);
        this.maxHeight = scl;
        this.minHeight = scl;
        return this;
    }
    
    public Cell<T> minSize(final float size) {
        final float scl = this.scl(size);
        this.minHeight = scl;
        this.minWidth = scl;
        return this;
    }
    
    public Cell<T> minSize(final float width, final float height) {
        this.minWidth = this.scl(width);
        this.minHeight = this.scl(height);
        return this;
    }
    
    public Cell<T> minWidth(final float minWidth) {
        this.minWidth = this.scl(minWidth);
        return this;
    }
    
    public Cell<T> minHeight(final float minHeight) {
        this.minHeight = this.scl(minHeight);
        return this;
    }
    
    public Cell<T> maxSize(final float size) {
        final float scl = this.scl(size);
        this.maxHeight = scl;
        this.maxWidth = scl;
        return this;
    }
    
    public Cell<T> maxSize(final float width, final float height) {
        this.maxWidth = this.scl(width);
        this.maxHeight = this.scl(height);
        return this;
    }
    
    public Cell<T> maxWidth(final float maxWidth) {
        this.maxWidth = this.scl(maxWidth);
        return this;
    }
    
    public Cell<T> maxHeight(final float maxHeight) {
        this.maxHeight = this.scl(maxHeight);
        return this;
    }
    
    public Cell<T> pad(final float pad) {
        final float scl = this.scl(pad);
        this.padRight = scl;
        this.padBottom = scl;
        this.padLeft = scl;
        this.padTop = scl;
        return this;
    }
    
    public Cell<T> pad(final float top, final float left, final float bottom, final float right) {
        this.padTop = this.scl(top);
        this.padLeft = this.scl(left);
        this.padBottom = this.scl(bottom);
        this.padRight = this.scl(right);
        return this;
    }
    
    public Cell<T> padTop(final float padTop) {
        this.padTop = this.scl(padTop);
        return this;
    }
    
    public Cell<T> padLeft(final float padLeft) {
        this.padLeft = this.scl(padLeft);
        return this;
    }
    
    public Cell<T> padBottom(final float padBottom) {
        this.padBottom = this.scl(padBottom);
        return this;
    }
    
    public Cell<T> padRight(final float padRight) {
        this.padRight = this.scl(padRight);
        return this;
    }
    
    public Cell<T> fill() {
        this.fillX = 1.0f;
        this.fillY = 1.0f;
        return this;
    }
    
    public Cell<T> fillX() {
        this.fillX = 1.0f;
        return this;
    }
    
    public Cell<T> fillY() {
        this.fillY = 1.0f;
        return this;
    }
    
    public Cell<T> fill(final float x, final float y) {
        this.fillX = x;
        this.fillY = y;
        return this;
    }
    
    public Cell<T> fill(final boolean x, final boolean y) {
        this.fillX = (x ? 1.0f : 0.0f);
        this.fillY = (y ? 1.0f : 0.0f);
        return this;
    }
    
    public Cell<T> fill(final boolean fill) {
        this.fillX = (fill ? 1.0f : 0.0f);
        this.fillY = (fill ? 1.0f : 0.0f);
        return this;
    }
    
    public Cell<T> align(final int align) {
        this.align = align;
        return this;
    }
    
    public Cell<T> center() {
        this.align = 1;
        return this;
    }
    
    public Cell<T> top() {
        this.align = ((this.align | 0x2) & 0xFFFFFFFB);
        return this;
    }
    
    public Cell<T> left() {
        this.align = ((this.align | 0x8) & 0xFFFFFFEF);
        return this;
    }
    
    public Cell<T> bottom() {
        this.align = ((this.align | 0x4) & 0xFFFFFFFD);
        return this;
    }
    
    public Cell<T> right() {
        this.align = ((this.align | 0x10) & 0xFFFFFFF7);
        return this;
    }
    
    public Cell<T> grow() {
        this.expandX = 1;
        this.expandY = 1;
        this.fillX = 1.0f;
        this.fillY = 1.0f;
        return this;
    }
    
    public Cell<T> growX() {
        this.expandX = 1;
        this.fillX = 1.0f;
        return this;
    }
    
    public Cell<T> growY() {
        this.expandY = 1;
        this.fillY = 1.0f;
        return this;
    }
    
    public Cell<T> expand() {
        this.expandX = 1;
        this.expandY = 1;
        return this;
    }
    
    public Cell<T> expandX() {
        this.expandX = 1;
        return this;
    }
    
    public Cell<T> expandY() {
        this.expandY = 1;
        return this;
    }
    
    public Cell<T> expand(final int x, final int y) {
        this.expandX = x;
        this.expandY = y;
        return this;
    }
    
    public Cell<T> expand(final boolean x, final boolean y) {
        this.expandX = (x ? 1 : 0);
        this.expandY = (y ? 1 : 0);
        return this;
    }
    
    public Cell<T> colspan(final int colspan) {
        this.colspan = colspan;
        return this;
    }
    
    public Cell<T> uniform() {
        this.uniformX = true;
        this.uniformY = true;
        return this;
    }
    
    public Cell<T> uniformX() {
        this.uniformX = true;
        return this;
    }
    
    public Cell<T> uniformY() {
        this.uniformY = true;
        return this;
    }
    
    public Cell<T> uniform(final boolean x, final boolean y) {
        this.uniformX = x;
        this.uniformY = y;
        return this;
    }
    
    public void setBounds(final float x, final float y, final float width, final float height) {
        this.elementX = x;
        this.elementY = y;
        this.elementWidth = width;
        this.elementHeight = height;
    }
    
    public boolean isEndRow() {
        return this.endRow;
    }
    
    public void row() {
        this.table.row();
    }
    
    public Table getTable() {
        return this.table;
    }
    
    void clear() {
        this.minWidth = Float.NEGATIVE_INFINITY;
        this.minHeight = Float.NEGATIVE_INFINITY;
        this.maxWidth = Float.NEGATIVE_INFINITY;
        this.maxHeight = Float.NEGATIVE_INFINITY;
        this.padTop = 0.0f;
        this.padLeft = 0.0f;
        this.padBottom = 0.0f;
        this.padRight = 0.0f;
        this.fillX = 0.0f;
        this.fillY = 0.0f;
        this.align = 0;
        this.expandX = 0;
        this.expandY = 0;
        this.colspan = 1;
        this.uniformX = false;
        this.uniformY = false;
    }
    
    float scl(final float value) {
        return Scl.scl(value);
    }
    
    @Override
    public void reset() {
        this.element = null;
        this.table = null;
        this.endRow = false;
        this.cellAboveIndex = -1;
        final Cell defaults = defaults();
        if (defaults != null) {
            this.set(defaults);
        }
    }
    
    public Cell<T> set(final Cell cell) {
        this.minWidth = cell.minWidth;
        this.minHeight = cell.minHeight;
        this.maxWidth = cell.maxWidth;
        this.maxHeight = cell.maxHeight;
        this.padTop = cell.padTop;
        this.padLeft = cell.padLeft;
        this.padBottom = cell.padBottom;
        this.padRight = cell.padRight;
        this.fillX = cell.fillX;
        this.fillY = cell.fillY;
        this.align = cell.align;
        this.expandX = cell.expandX;
        this.expandY = cell.expandY;
        this.colspan = cell.colspan;
        this.uniformX = cell.uniformX;
        this.uniformY = cell.uniformY;
        return this;
    }
    
    @Override
    public String toString() {
        return (this.element != null) ? this.element.toString() : super.toString();
    }
}
