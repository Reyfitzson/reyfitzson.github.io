// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import java.util.Iterator;
import arc.scene.Action;
import arc.scene.actions.Actions;
import arc.math.Interp;
import arc.util.Timer;
import arc.func.Func;
import arc.struct.Seq;
import arc.Core;
import arc.scene.Scene;
import arc.input.KeyCode;
import arc.scene.event.InputEvent;
import arc.scene.event.Touchable;
import arc.func.Cons;
import arc.scene.Element;
import arc.scene.ui.layout.Table;
import arc.math.geom.Vec2;
import arc.scene.event.InputListener;

public class Tooltip extends InputListener
{
    static Vec2 tmp;
    public final Tooltips manager;
    public final Table container;
    boolean instant;
    boolean always;
    Element targetActor;
    Runnable show;
    
    public Tooltip(final Cons<Table> contents) {
        this(contents, Tooltips.getInstance());
    }
    
    public Tooltip(final Cons<Table> contents, final Runnable show) {
        this(contents, Tooltips.getInstance());
        this.show = show;
    }
    
    public Tooltip(final Cons<Table> contents, final Tooltips manager) {
        this.instant = true;
        this.manager = manager;
        contents.get(this.container = new Table() {
            @Override
            public void act(final float delta) {
                super.act(delta);
                if (Tooltip.this.targetActor != null && Tooltip.this.targetActor.getScene() == null) {
                    this.remove();
                }
            }
        });
        this.container.touchable = Touchable.disabled;
    }
    
    public Tooltips getManager() {
        return this.manager;
    }
    
    public Table getContainer() {
        return this.container;
    }
    
    public void setInstant(final boolean instant) {
        this.instant = instant;
    }
    
    public void setAlways(final boolean always) {
        this.always = always;
    }
    
    @Override
    public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
        if (this.instant) {
            this.container.toFront();
            return false;
        }
        this.manager.touchDown(this);
        return false;
    }
    
    @Override
    public boolean mouseMoved(final InputEvent event, final float x, final float y) {
        if (this.container.hasParent()) {
            return false;
        }
        this.setContainerPosition(event.listenerActor, x, y);
        return true;
    }
    
    protected void setContainerPosition(final Element element, final float x, final float y) {
        this.targetActor = element;
        final Scene stage = element.getScene();
        if (stage == null) {
            return;
        }
        this.container.pack();
        final float offsetX = this.manager.offsetX;
        final float offsetY = this.manager.offsetY;
        final float dist = this.manager.edgeDistance;
        Vec2 point = element.localToStageCoordinates(Tooltip.tmp.set(x + offsetX, y - offsetY - this.container.getHeight()));
        if (point.y < dist) {
            point = element.localToStageCoordinates(Tooltip.tmp.set(x + offsetX, y + offsetY));
        }
        if (point.x < dist) {
            point.x = dist;
        }
        if (point.x + this.container.getWidth() > stage.getWidth() - dist) {
            point.x = stage.getWidth() - dist - this.container.getWidth();
        }
        if (point.y + this.container.getHeight() > stage.getHeight() - dist) {
            point.y = stage.getHeight() - dist - this.container.getHeight();
        }
        this.container.setPosition(point.x, point.y);
        point = element.localToStageCoordinates(Tooltip.tmp.set(element.getWidth() / 2.0f, element.getHeight() / 2.0f));
        point.sub(this.container.x, this.container.y);
        this.container.setOrigin(point.x, point.y);
    }
    
    @Override
    public void enter(final InputEvent event, final float x, final float y, final int pointer, final Element fromActor) {
        if (pointer != -1) {
            return;
        }
        if (Core.input.isTouched()) {
            return;
        }
        final Element element = event.listenerActor;
        if (fromActor != null && fromActor.isDescendantOf(element)) {
            return;
        }
        this.show(element, x, y);
    }
    
    @Override
    public void exit(final InputEvent event, final float x, final float y, final int pointer, final Element toActor) {
        if (toActor != null && toActor.isDescendantOf(event.listenerActor)) {
            return;
        }
        this.hide();
    }
    
    public void show(final Element element, final float x, final float y) {
        this.setContainerPosition(element, x, y);
        this.manager.enter(this);
        this.container.pack();
        if (this.show != null) {
            this.show.run();
        }
    }
    
    public void hide() {
        this.manager.hide(this);
    }
    
    static {
        Tooltip.tmp = new Vec2();
    }
    
    public static class Tooltips
    {
        private static Tooltips instance;
        final Seq<Tooltip> shown;
        public Func<String, Tooltip> textProvider;
        public float initialTime;
        public float subsequentTime;
        public float resetTime;
        public boolean enabled;
        public boolean animations;
        public float maxWidth;
        public float offsetX;
        public float offsetY;
        public float edgeDistance;
        float time;
        final Timer.Task resetTask;
        Tooltip showTooltip;
        final Timer.Task showTask;
        
        public Tooltips() {
            this.shown = new Seq<Tooltip>();
            this.textProvider = (Func<String, Tooltip>)(text -> new Tooltip(t -> t.add((CharSequence)text)));
            this.initialTime = 2.0f;
            this.subsequentTime = 0.0f;
            this.resetTime = 1.5f;
            this.enabled = true;
            this.animations = false;
            this.maxWidth = 2.14748365E9f;
            this.offsetX = 15.0f;
            this.offsetY = 19.0f;
            this.edgeDistance = 7.0f;
            this.time = this.initialTime;
            this.resetTask = new Timer.Task() {
                @Override
                public void run() {
                    Tooltips.this.time = Tooltips.this.initialTime;
                }
            };
            this.showTask = new Timer.Task() {
                @Override
                public void run() {
                    if (Tooltips.this.showTooltip == null) {
                        return;
                    }
                    final Scene stage = Tooltips.this.showTooltip.targetActor.getScene();
                    if (stage == null) {
                        return;
                    }
                    stage.add(Tooltips.this.showTooltip.container);
                    Tooltips.this.showTooltip.container.toFront();
                    Tooltips.this.shown.add(Tooltips.this.showTooltip);
                    Tooltips.this.showTooltip.container.clearActions();
                    Tooltips.this.showAction(Tooltips.this.showTooltip);
                    if (!Tooltips.this.showTooltip.instant) {
                        Tooltips.this.time = Tooltips.this.subsequentTime;
                        Tooltips.this.resetTask.cancel();
                    }
                }
            };
        }
        
        public static Tooltips getInstance() {
            if (Tooltips.instance == null) {
                Tooltips.instance = new Tooltips();
            }
            return Tooltips.instance;
        }
        
        public Tooltip create(final String text) {
            return this.textProvider.get(text);
        }
        
        public void touchDown(final Tooltip tooltip) {
            this.showTask.cancel();
            if (tooltip.container.remove()) {
                this.resetTask.cancel();
            }
            this.resetTask.run();
            if (this.enabled || tooltip.always) {
                this.showTooltip = tooltip;
                Timer.schedule(this.showTask, this.time);
            }
        }
        
        public void enter(final Tooltip tooltip) {
            this.showTooltip = tooltip;
            this.showTask.cancel();
            if (this.enabled || tooltip.always) {
                if (this.time == 0.0f || tooltip.instant) {
                    this.showTask.run();
                }
                else {
                    Timer.schedule(this.showTask, this.time);
                }
            }
        }
        
        public void hide(final Tooltip tooltip) {
            this.showTooltip = null;
            this.showTask.cancel();
            if (tooltip.container.hasParent()) {
                this.shown.remove(tooltip, true);
                this.hideAction(tooltip);
                this.resetTask.cancel();
                Timer.schedule(this.resetTask, this.resetTime);
            }
        }
        
        protected void showAction(final Tooltip tooltip) {
            final float actionTime = this.animations ? ((this.time > 0.0f) ? 0.5f : 0.15f) : 0.1f;
            tooltip.container.setTransform(true);
            tooltip.container.color.a = 0.2f;
            tooltip.container.setScale(0.05f);
            tooltip.container.addAction(Actions.parallel(Actions.fadeIn(actionTime, Interp.fade), Actions.scaleTo(1.0f, 1.0f, actionTime, Interp.fade)));
        }
        
        protected void hideAction(final Tooltip tooltip) {
            tooltip.container.addAction(Actions.sequence(Actions.parallel(Actions.alpha(0.2f, 0.2f, Interp.fade), Actions.scaleTo(0.05f, 0.05f, 0.2f, Interp.fade)), Actions.remove()));
        }
        
        public void hideAll() {
            this.resetTask.cancel();
            this.showTask.cancel();
            this.time = this.initialTime;
            this.showTooltip = null;
            for (final Tooltip tooltip : this.shown) {
                tooltip.hide();
            }
            this.shown.clear();
        }
        
        public void instant() {
            this.time = 0.0f;
            this.showTask.run();
            this.showTask.cancel();
        }
    }
}
