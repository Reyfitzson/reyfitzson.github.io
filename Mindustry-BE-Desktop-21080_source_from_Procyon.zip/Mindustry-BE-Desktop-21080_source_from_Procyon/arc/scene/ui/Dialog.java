// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import arc.graphics.g2d.Font;
import arc.scene.style.Drawable;
import arc.scene.style.Style;
import arc.math.Interp;
import arc.scene.actions.Actions;
import arc.scene.event.SceneEvent;
import arc.scene.event.VisibilityEvent;
import arc.scene.event.VisibilityListener;
import arc.graphics.Color;
import arc.graphics.g2d.Draw;
import arc.scene.Scene;
import arc.scene.event.EventListener;
import arc.scene.event.Touchable;
import arc.input.KeyCode;
import arc.scene.event.InputEvent;
import arc.Core;
import arc.scene.event.FocusListener;
import arc.scene.Element;
import arc.math.geom.Vec2;
import arc.scene.event.InputListener;
import arc.scene.Action;
import arc.func.Prov;
import arc.scene.ui.layout.Table;

public class Dialog extends Table
{
    private static Prov<Action> defaultShowAction;
    private static Prov<Action> defaultHideAction;
    protected InputListener ignoreTouchDown;
    private static final Vec2 tmpPosition;
    private static final Vec2 tmpSize;
    private static final int MOVE = 32;
    protected int edge;
    protected boolean dragging;
    boolean isMovable;
    boolean isModal;
    boolean isResizable;
    boolean center;
    int resizeBorder;
    boolean keepWithinStage;
    private DialogStyle style;
    Element previousKeyboardFocus;
    Element previousScrollFocus;
    FocusListener focusListener;
    public final Table cont;
    public final Table buttons;
    public final Label title;
    public final Table titleTable;
    
    public Dialog(final String title) {
        this(title, Core.scene.getStyle(DialogStyle.class));
    }
    
    public Dialog(final String title, final DialogStyle style) {
        this.ignoreTouchDown = new InputListener() {
            @Override
            public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                event.cancel();
                return false;
            }
        };
        this.isMovable = false;
        this.isModal = true;
        this.isResizable = false;
        this.center = true;
        this.resizeBorder = 8;
        this.keepWithinStage = true;
        if (title == null) {
            throw new IllegalArgumentException("title cannot be null.");
        }
        this.touchable = Touchable.enabled;
        this.setClip(true);
        (this.title = new Label(title, new Label.LabelStyle(style.titleFont, style.titleFontColor))).setEllipsis(true);
        this.titleTable = new Table();
        this.titleTable.add(this.title).expandX().fillX().minWidth(0.0f);
        this.add(this.titleTable).growX().row();
        this.setStyle(style);
        this.setWidth(150.0f);
        this.setHeight(150.0f);
        this.addCaptureListener(new InputListener() {
            @Override
            public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                Dialog.this.toFront();
                return false;
            }
        });
        this.addListener(new InputListener() {
            float startX;
            float startY;
            float lastX;
            float lastY;
            
            private void updateEdge(final float x, final float y) {
                float border = Dialog.this.resizeBorder / 2.0f;
                final float width = Dialog.this.getWidth();
                final float height = Dialog.this.getHeight();
                final float padTop = Dialog.this.getMarginTop();
                final float padRight = Dialog.this.getMarginRight();
                final float right = width - padRight;
                Dialog.this.edge = 0;
                if (Dialog.this.isResizable && x >= Dialog.this.getMarginLeft() - border && x <= right + border && y >= Dialog.this.getMarginBottom() - border) {
                    if (x < Dialog.this.getMarginLeft() + border) {
                        final Dialog this$0 = Dialog.this;
                        this$0.edge |= 0x8;
                    }
                    if (x > right - border) {
                        final Dialog this$2 = Dialog.this;
                        this$2.edge |= 0x10;
                    }
                    if (y < Dialog.this.getMarginBottom() + border) {
                        final Dialog this$3 = Dialog.this;
                        this$3.edge |= 0x4;
                    }
                    if (Dialog.this.edge != 0) {
                        border += 25.0f;
                    }
                    if (x < Dialog.this.getMarginLeft() + border) {
                        final Dialog this$4 = Dialog.this;
                        this$4.edge |= 0x8;
                    }
                    if (x > right - border) {
                        final Dialog this$5 = Dialog.this;
                        this$5.edge |= 0x10;
                    }
                    if (y < Dialog.this.getMarginBottom() + border) {
                        final Dialog this$6 = Dialog.this;
                        this$6.edge |= 0x4;
                    }
                }
                if (Dialog.this.isMovable && Dialog.this.edge == 0 && y <= height && y >= height - padTop && x >= Dialog.this.getMarginLeft() && x <= right) {
                    Dialog.this.edge = 32;
                }
            }
            
            @Override
            public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                if (button == KeyCode.mouseLeft) {
                    this.updateEdge(x, y);
                    Dialog.this.dragging = (Dialog.this.edge != 0);
                    this.startX = x;
                    this.startY = y;
                    this.lastX = x - Dialog.this.getWidth();
                    this.lastY = y - Dialog.this.getHeight();
                }
                return Dialog.this.edge != 0 || Dialog.this.isModal;
            }
            
            @Override
            public void touchUp(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                Dialog.this.dragging = false;
            }
            
            @Override
            public void touchDragged(final InputEvent event, final float x, final float y, final int pointer) {
                if (!Dialog.this.dragging) {
                    return;
                }
                float width = Dialog.this.getWidth();
                float height = Dialog.this.getHeight();
                float windowX = Dialog.this.x;
                float windowY = Dialog.this.y;
                final float minWidth = Dialog.this.getMinWidth();
                final float minHeight = Dialog.this.getMinHeight();
                final Scene stage = Dialog.this.getScene();
                final boolean clampPosition = Dialog.this.keepWithinStage && Dialog.this.parent == stage.root;
                if ((Dialog.this.edge & 0x20) != 0x0) {
                    final float amountX = x - this.startX;
                    final float amountY = y - this.startY;
                    windowX += amountX;
                    windowY += amountY;
                }
                if ((Dialog.this.edge & 0x8) != 0x0) {
                    float amountX = x - this.startX;
                    if (width - amountX < minWidth) {
                        amountX = -(minWidth - width);
                    }
                    if (clampPosition && windowX + amountX < 0.0f) {
                        amountX = -windowX;
                    }
                    width -= amountX;
                    windowX += amountX;
                }
                if ((Dialog.this.edge & 0x4) != 0x0) {
                    float amountY2 = y - this.startY;
                    if (height - amountY2 < minHeight) {
                        amountY2 = -(minHeight - height);
                    }
                    if (clampPosition && windowY + amountY2 < 0.0f) {
                        amountY2 = -windowY;
                    }
                    height -= amountY2;
                    windowY += amountY2;
                }
                if ((Dialog.this.edge & 0x10) != 0x0) {
                    float amountX = x - this.lastX - width;
                    if (width + amountX < minWidth) {
                        amountX = minWidth - width;
                    }
                    if (clampPosition && windowX + width + amountX > stage.getWidth()) {
                        amountX = stage.getWidth() - windowX - width;
                    }
                    width += amountX;
                }
                if ((Dialog.this.edge & 0x2) != 0x0) {
                    float amountY2 = y - this.lastY - height;
                    if (height + amountY2 < minHeight) {
                        amountY2 = minHeight - height;
                    }
                    if (clampPosition && windowY + height + amountY2 > stage.getHeight()) {
                        amountY2 = stage.getHeight() - windowY - height;
                    }
                    height += amountY2;
                }
                Dialog.this.setBounds((float)Math.round(windowX), (float)Math.round(windowY), (float)Math.round(width), (float)Math.round(height));
            }
            
            @Override
            public boolean mouseMoved(final InputEvent event, final float x, final float y) {
                this.updateEdge(x, y);
                return Dialog.this.isModal;
            }
            
            @Override
            public boolean scrolled(final InputEvent event, final float x, final float y, final float amountX, final float amountY) {
                return Dialog.this.isModal;
            }
            
            @Override
            public boolean keyDown(final InputEvent event, final KeyCode keycode) {
                return Dialog.this.isModal;
            }
            
            @Override
            public boolean keyUp(final InputEvent event, final KeyCode keycode) {
                return Dialog.this.isModal;
            }
            
            @Override
            public boolean keyTyped(final InputEvent event, final char character) {
                return Dialog.this.isModal;
            }
        });
        this.setOrigin(1);
        this.defaults().pad(3.0f);
        final Table table = new Table();
        this.cont = table;
        this.add(table).expand().fill();
        this.row();
        final Table table2 = new Table();
        this.buttons = table2;
        this.add(table2).fillX();
        this.cont.defaults().pad(3.0f);
        this.buttons.defaults().pad(3.0f);
        this.focusListener = new FocusListener() {
            @Override
            public void keyboardFocusChanged(final FocusEvent event, final Element actor, final boolean focused) {
                if (!focused) {
                    this.focusChanged(event);
                }
            }
            
            @Override
            public void scrollFocusChanged(final FocusEvent event, final Element actor, final boolean focused) {
                if (!focused) {
                    this.focusChanged(event);
                }
            }
            
            private void focusChanged(final FocusEvent event) {
                final Scene stage = Dialog.this.getScene();
                if (Dialog.this.isModal && stage != null && stage.root.getChildren().size > 0 && stage.root.getChildren().peek() == Dialog.this) {
                    final Element newFocusedActor = event.relatedActor;
                    if (newFocusedActor != null && !newFocusedActor.isDescendantOf(Dialog.this) && !newFocusedActor.equals(Dialog.this.previousKeyboardFocus) && !newFocusedActor.equals(Dialog.this.previousScrollFocus)) {
                        event.cancel();
                    }
                }
            }
        };
        this.shown(this::updateScrollFocus);
    }
    
    public DialogStyle getStyle() {
        return this.style;
    }
    
    public void setStyle(final DialogStyle style) {
        if (style == null) {
            throw new IllegalArgumentException("style cannot be null.");
        }
        this.style = style;
        this.setBackground(style.background);
        this.invalidateHierarchy();
    }
    
    void keepWithinStage() {
        if (!this.keepWithinStage) {
            return;
        }
        this.keepInStage();
    }
    
    @Override
    public void act(final float delta) {
        super.act(delta);
        if (this.getScene() != null) {
            this.keepWithinStage();
            if (this.center && !this.isMovable && this.getActions().size == 0) {
                this.centerWindow();
            }
        }
    }
    
    @Override
    public void draw() {
        final Scene stage = this.getScene();
        if (stage.getKeyboardFocus() == null) {
            stage.setKeyboardFocus(this);
        }
        if (this.style.stageBackground != null) {
            this.stageToLocalCoordinates(Dialog.tmpPosition.set(0.0f, 0.0f));
            this.stageToLocalCoordinates(Dialog.tmpSize.set(stage.getWidth(), stage.getHeight()));
            this.drawStageBackground(this.x + Dialog.tmpPosition.x, this.y + Dialog.tmpPosition.y, this.x + Dialog.tmpSize.x, this.y + Dialog.tmpSize.y);
        }
        super.draw();
    }
    
    protected void drawStageBackground(final float x, final float y, final float width, final float height) {
        final Color color = this.color;
        Draw.color(color.r, color.g, color.b, color.a * this.parentAlpha);
        this.style.stageBackground.draw(x, y, width, height);
    }
    
    @Override
    public Element hit(final float x, final float y, final boolean touchable) {
        final Element hit = super.hit(x, y, touchable);
        if (hit == null && this.isModal && (!touchable || this.touchable == Touchable.enabled)) {
            return this;
        }
        return hit;
    }
    
    public void centerWindow() {
        this.setPosition((float)Math.round((Core.scene.getWidth() - Core.scene.marginLeft - Core.scene.marginRight - this.getWidth()) / 2.0f), (float)Math.round((Core.scene.getHeight() - Core.scene.marginTop - Core.scene.marginBottom - this.getHeight()) / 2.0f));
    }
    
    public boolean isMovable() {
        return this.isMovable;
    }
    
    public void setMovable(final boolean isMovable) {
        this.isMovable = isMovable;
    }
    
    public boolean isModal() {
        return this.isModal;
    }
    
    public void setModal(final boolean isModal) {
        this.isModal = isModal;
    }
    
    public void setKeepWithinStage(final boolean keepWithinStage) {
        this.keepWithinStage = keepWithinStage;
    }
    
    public boolean isCentered() {
        return this.center;
    }
    
    public void setCentered(final boolean center) {
        this.center = center;
    }
    
    public boolean isResizable() {
        return this.isResizable;
    }
    
    public void setResizable(final boolean isResizable) {
        this.isResizable = isResizable;
    }
    
    public void setResizeBorder(final int resizeBorder) {
        this.resizeBorder = resizeBorder;
    }
    
    public boolean isDragging() {
        return this.dragging;
    }
    
    public void updateScrollFocus() {
        final boolean[] done = { false };
        final Object o;
        Core.app.post(() -> this.forEach(child -> {
            if (!o[0]) {
                if (child instanceof ScrollPane) {
                    Core.scene.setScrollFocus(child);
                    o[0] = true;
                }
            }
        }));
    }
    
    public static void setHideAction(final Prov<Action> prov) {
        Dialog.defaultHideAction = prov;
    }
    
    public static void setShowAction(final Prov<Action> prov) {
        Dialog.defaultShowAction = prov;
    }
    
    @Override
    protected void setScene(final Scene stage) {
        if (stage == null) {
            this.addListener(this.focusListener);
        }
        else {
            this.removeListener(this.focusListener);
        }
        super.setScene(stage);
    }
    
    public void shown(final Runnable run) {
        this.addListener(new VisibilityListener() {
            @Override
            public boolean shown() {
                run.run();
                return false;
            }
        });
    }
    
    public void hidden(final Runnable run) {
        this.addListener(new VisibilityListener() {
            @Override
            public boolean hidden() {
                run.run();
                return false;
            }
        });
    }
    
    public void addCloseButton() {
    }
    
    public void closeOnBack() {
        this.keyDown(key -> {
            if (key == KeyCode.escape || key == KeyCode.back) {
                Core.app.post(this::hide);
            }
        });
    }
    
    public boolean isShown() {
        return this.getScene() != null;
    }
    
    public Dialog show(final Scene stage, final Action action) {
        this.setOrigin(1);
        this.setClip(false);
        this.setTransform(true);
        this.fire(new VisibilityEvent(false));
        this.clearActions();
        this.removeCaptureListener(this.ignoreTouchDown);
        this.previousKeyboardFocus = null;
        Element actor = stage.getKeyboardFocus();
        if (actor != null && !actor.isDescendantOf(this)) {
            this.previousKeyboardFocus = actor;
        }
        this.previousScrollFocus = null;
        actor = stage.getScrollFocus();
        if (actor != null && !actor.isDescendantOf(this)) {
            this.previousScrollFocus = actor;
        }
        this.pack();
        stage.add(this);
        stage.setKeyboardFocus(this);
        stage.setScrollFocus(this);
        if (action != null) {
            this.addAction(action);
        }
        this.pack();
        return this;
    }
    
    public void toggle() {
        if (this.isShown()) {
            this.hide();
        }
        else {
            this.show();
        }
    }
    
    public Dialog show() {
        return this.show(Core.scene);
    }
    
    public Dialog show(final Scene stage) {
        this.show(stage, Dialog.defaultShowAction.get());
        this.centerWindow();
        return this;
    }
    
    public void hide(final Action action) {
        this.fire(new VisibilityEvent(true));
        final Scene stage = this.getScene();
        if (stage != null) {
            this.removeListener(this.focusListener);
            if (this.previousKeyboardFocus != null && this.previousKeyboardFocus.getScene() == null) {
                this.previousKeyboardFocus = null;
            }
            Element actor = stage.getKeyboardFocus();
            if (actor == null || actor.isDescendantOf(this)) {
                stage.setKeyboardFocus(this.previousKeyboardFocus);
            }
            if (this.previousScrollFocus != null && this.previousScrollFocus.getScene() == null) {
                this.previousScrollFocus = null;
            }
            actor = stage.getScrollFocus();
            if (actor == null || actor.isDescendantOf(this)) {
                stage.setScrollFocus(this.previousScrollFocus);
            }
        }
        if (action != null) {
            this.addCaptureListener(this.ignoreTouchDown);
            this.addAction(Actions.sequence(action, Actions.removeListener(this.ignoreTouchDown, true), Actions.remove()));
        }
        else {
            this.remove();
        }
    }
    
    public void hide() {
        if (!this.isShown()) {
            return;
        }
        this.setOrigin(1);
        this.setClip(false);
        this.setTransform(true);
        this.hide(Dialog.defaultHideAction.get());
    }
    
    static {
        Dialog.defaultShowAction = (Prov<Action>)(() -> Actions.sequence(Actions.alpha(0.0f), Actions.fadeIn(0.4f, Interp.fade)));
        Dialog.defaultHideAction = (Prov<Action>)(() -> Actions.fadeOut(0.4f, Interp.fade));
        tmpPosition = new Vec2();
        tmpSize = new Vec2();
    }
    
    public static class DialogStyle extends Style
    {
        public Drawable background;
        public Font titleFont;
        public Color titleFontColor;
        public Drawable stageBackground;
        
        public DialogStyle() {
            this.titleFontColor = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        }
    }
}
