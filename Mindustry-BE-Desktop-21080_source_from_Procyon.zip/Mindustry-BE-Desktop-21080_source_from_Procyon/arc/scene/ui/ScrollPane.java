// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import arc.scene.style.Style;
import arc.graphics.g2d.Draw;
import arc.math.Interp;
import arc.graphics.g2d.ScissorStack;
import arc.scene.utils.Cullable;
import arc.scene.style.Drawable;
import arc.math.Mathf;
import arc.scene.Scene;
import arc.scene.event.SceneEvent;
import arc.scene.event.EventListener;
import arc.input.KeyCode;
import arc.scene.event.InputEvent;
import arc.scene.event.InputListener;
import arc.Core;
import arc.scene.event.ElementGestureListener;
import arc.scene.Element;
import arc.math.geom.Vec2;
import arc.math.geom.Rect;
import arc.scene.ui.layout.WidgetGroup;

public class ScrollPane extends WidgetGroup
{
    final Rect hScrollBounds;
    final Rect vScrollBounds;
    final Rect hKnobBounds;
    final Rect vKnobBounds;
    final Vec2 lastPoint;
    private final Rect widgetAreaBounds;
    private final Rect widgetCullingArea;
    private final Rect scissorBounds;
    protected boolean disableX;
    protected boolean disableY;
    boolean scrollX;
    boolean scrollY;
    boolean vScrollOnRight;
    boolean hScrollOnBottom;
    float amountX;
    float amountY;
    float visualAmountX;
    float visualAmountY;
    float maxX;
    float maxY;
    boolean touchScrollH;
    boolean touchScrollV;
    float areaWidth;
    float areaHeight;
    float fadeAlpha;
    float fadeAlphaSeconds;
    float fadeDelay;
    float fadeDelaySeconds;
    boolean cancelTouchFocus;
    boolean flickScroll;
    float velocityX;
    float velocityY;
    float flingTimer;
    float flingTime;
    int draggingPointer;
    private ScrollPaneStyle style;
    private Element widget;
    private ElementGestureListener flickScrollListener;
    private boolean fadeScrollBars;
    private boolean smoothScrolling;
    private boolean overscrollX;
    private boolean overscrollY;
    private float overscrollDistance;
    private float overscrollSpeedMin;
    private float overscrollSpeedMax;
    private boolean forceScrollX;
    private boolean forceScrollY;
    private boolean clamp;
    private boolean scrollbarsOnTop;
    private boolean variableSizeKnobs;
    private boolean clip;
    
    public ScrollPane(final Element widget) {
        this(widget, Core.scene.getStyle(ScrollPaneStyle.class));
    }
    
    public ScrollPane(final Element widget, final ScrollPaneStyle style) {
        this.hScrollBounds = new Rect();
        this.vScrollBounds = new Rect();
        this.hKnobBounds = new Rect();
        this.vKnobBounds = new Rect();
        this.lastPoint = new Vec2();
        this.widgetAreaBounds = new Rect();
        this.widgetCullingArea = new Rect();
        this.scissorBounds = new Rect();
        this.vScrollOnRight = true;
        this.hScrollOnBottom = true;
        this.fadeAlpha = 1.0f;
        this.fadeAlphaSeconds = 1.0f;
        this.fadeDelaySeconds = 1.0f;
        this.cancelTouchFocus = true;
        this.flickScroll = true;
        this.flingTime = 1.0f;
        this.draggingPointer = -1;
        this.fadeScrollBars = false;
        this.smoothScrolling = true;
        this.overscrollX = true;
        this.overscrollY = true;
        this.overscrollDistance = 50.0f;
        this.overscrollSpeedMin = 30.0f;
        this.overscrollSpeedMax = 200.0f;
        this.clamp = true;
        this.variableSizeKnobs = true;
        this.clip = true;
        if (style == null) {
            throw new IllegalArgumentException("style cannot be null.");
        }
        this.style = style;
        this.setWidget(widget);
        this.setSize(150.0f, 150.0f);
        this.setTransform(true);
        this.addCaptureListener(new InputListener() {
            private float handlePosition;
            
            @Override
            public void enter(final InputEvent event, final float x, final float y, final int pointer, final Element fromActor) {
                ScrollPane.this.requestScroll();
            }
            
            @Override
            public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                if (ScrollPane.this.draggingPointer != -1) {
                    return false;
                }
                if (pointer == 0 && button != KeyCode.mouseLeft) {
                    return false;
                }
                ScrollPane.this.requestScroll();
                if (!ScrollPane.this.flickScroll) {
                    ScrollPane.this.resetFade();
                }
                if (ScrollPane.this.fadeAlpha == 0.0f) {
                    return false;
                }
                if (ScrollPane.this.scrollX && ScrollPane.this.hScrollBounds.contains(x, y)) {
                    event.stop();
                    ScrollPane.this.resetFade();
                    if (ScrollPane.this.hKnobBounds.contains(x, y)) {
                        ScrollPane.this.lastPoint.set(x, y);
                        this.handlePosition = ScrollPane.this.hKnobBounds.x;
                        ScrollPane.this.touchScrollH = true;
                        ScrollPane.this.draggingPointer = pointer;
                        return true;
                    }
                    ScrollPane.this.setScrollX(ScrollPane.this.amountX + ScrollPane.this.areaWidth * ((x < ScrollPane.this.hKnobBounds.x) ? -1 : 1));
                    return true;
                }
                else {
                    if (!ScrollPane.this.scrollY || !ScrollPane.this.vScrollBounds.contains(x, y)) {
                        return false;
                    }
                    event.stop();
                    ScrollPane.this.resetFade();
                    if (ScrollPane.this.vKnobBounds.contains(x, y)) {
                        ScrollPane.this.lastPoint.set(x, y);
                        this.handlePosition = ScrollPane.this.vKnobBounds.y;
                        ScrollPane.this.touchScrollV = true;
                        ScrollPane.this.draggingPointer = pointer;
                        return true;
                    }
                    ScrollPane.this.setScrollY(ScrollPane.this.amountY + ScrollPane.this.areaHeight * ((y < ScrollPane.this.vKnobBounds.y) ? 1 : -1));
                    return true;
                }
            }
            
            @Override
            public void touchUp(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                if (pointer != ScrollPane.this.draggingPointer) {
                    return;
                }
                ScrollPane.this.cancel();
            }
            
            @Override
            public void touchDragged(final InputEvent event, final float x, final float y, final int pointer) {
                if (pointer != ScrollPane.this.draggingPointer) {
                    return;
                }
                if (ScrollPane.this.touchScrollH) {
                    final float delta = x - ScrollPane.this.lastPoint.x;
                    float scrollH = this.handlePosition + delta;
                    this.handlePosition = scrollH;
                    scrollH = Math.max(ScrollPane.this.hScrollBounds.x, scrollH);
                    scrollH = Math.min(ScrollPane.this.hScrollBounds.x + ScrollPane.this.hScrollBounds.width - ScrollPane.this.hKnobBounds.width, scrollH);
                    final float total = ScrollPane.this.hScrollBounds.width - ScrollPane.this.hKnobBounds.width;
                    if (total != 0.0f) {
                        ScrollPane.this.setScrollPercentX((scrollH - ScrollPane.this.hScrollBounds.x) / total);
                    }
                    ScrollPane.this.lastPoint.set(x, y);
                }
                else if (ScrollPane.this.touchScrollV) {
                    final float delta = y - ScrollPane.this.lastPoint.y;
                    float scrollV = this.handlePosition + delta;
                    this.handlePosition = scrollV;
                    scrollV = Math.max(ScrollPane.this.vScrollBounds.y, scrollV);
                    scrollV = Math.min(ScrollPane.this.vScrollBounds.y + ScrollPane.this.vScrollBounds.height - ScrollPane.this.vKnobBounds.height, scrollV);
                    final float total = ScrollPane.this.vScrollBounds.height - ScrollPane.this.vKnobBounds.height;
                    if (total != 0.0f) {
                        ScrollPane.this.setScrollPercentY(1.0f - (scrollV - ScrollPane.this.vScrollBounds.y) / total);
                    }
                    ScrollPane.this.lastPoint.set(x, y);
                }
            }
            
            @Override
            public boolean mouseMoved(final InputEvent event, final float x, final float y) {
                if (!ScrollPane.this.flickScroll) {
                    ScrollPane.this.resetFade();
                }
                ScrollPane.this.requestScroll();
                return false;
            }
        });
        this.addListener(this.flickScrollListener = new ElementGestureListener() {
            @Override
            public void pan(final InputEvent event, final float x, final float y, final float deltaX, final float deltaY) {
                ScrollPane.this.resetFade();
                final ScrollPane this$0 = ScrollPane.this;
                this$0.amountX -= deltaX;
                final ScrollPane this$2 = ScrollPane.this;
                this$2.amountY += deltaY;
                ScrollPane.this.clamp();
                if (ScrollPane.this.cancelTouchFocus && ((ScrollPane.this.scrollX && deltaX != 0.0f) || (ScrollPane.this.scrollY && deltaY != 0.0f))) {
                    ScrollPane.this.cancelTouchFocus();
                }
            }
            
            @Override
            public void fling(final InputEvent event, final float x, final float y, final KeyCode button) {
                if (Math.abs(x) > 150.0f && ScrollPane.this.scrollX) {
                    ScrollPane.this.flingTimer = ScrollPane.this.flingTime;
                    ScrollPane.this.velocityX = x;
                    if (ScrollPane.this.cancelTouchFocus) {
                        ScrollPane.this.cancelTouchFocus();
                    }
                }
                if (Math.abs(y) > 150.0f && ScrollPane.this.scrollY) {
                    ScrollPane.this.flingTimer = ScrollPane.this.flingTime;
                    ScrollPane.this.velocityY = -y;
                    if (ScrollPane.this.cancelTouchFocus) {
                        ScrollPane.this.cancelTouchFocus();
                    }
                }
            }
            
            @Override
            public boolean handle(final SceneEvent event) {
                if (super.handle(event)) {
                    if (((InputEvent)event).type == InputEvent.InputEventType.touchDown) {
                        ScrollPane.this.flingTimer = 0.0f;
                    }
                    return true;
                }
                return false;
            }
        });
        this.addListener(new InputListener() {
            @Override
            public boolean scrolled(final InputEvent event, final float x, final float y, final float sx, final float sy) {
                ScrollPane.this.resetFade();
                if (ScrollPane.this.scrollY) {
                    ScrollPane.this.setScrollY(ScrollPane.this.amountY + ScrollPane.this.getMouseWheelY() * sy);
                }
                if (ScrollPane.this.scrollX) {
                    ScrollPane.this.setScrollX(ScrollPane.this.amountX + ScrollPane.this.getMouseWheelX() * sx);
                }
                return ScrollPane.this.scrollX || ScrollPane.this.scrollY;
            }
        });
        this.addCaptureListener(new InputListener() {
            boolean on = false;
            
            @Override
            public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                final Element actor = ScrollPane.this.hit(x, y, true);
                this.on = ScrollPane.this.flickScroll;
                if (actor instanceof Slider && this.on) {
                    ScrollPane.this.setFlickScroll(false);
                    return true;
                }
                return super.touchDown(event, x, y, pointer, button);
            }
            
            @Override
            public void touchUp(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                if (this.on) {
                    ScrollPane.this.setFlickScroll(true);
                }
                super.touchUp(event, x, y, pointer, button);
            }
        });
    }
    
    void resetFade() {
        this.fadeAlpha = this.fadeAlphaSeconds;
        this.fadeDelay = this.fadeDelaySeconds;
    }
    
    public void cancelTouchFocus() {
        final Scene stage = this.getScene();
        if (stage != null) {
            stage.cancelTouchFocusExcept(this.flickScrollListener, this);
        }
    }
    
    public void cancel() {
        this.draggingPointer = -1;
        this.touchScrollH = false;
        this.touchScrollV = false;
        this.flickScrollListener.getGestureDetector().cancel();
    }
    
    void clamp() {
        if (!this.clamp) {
            return;
        }
        this.scrollX(this.overscrollX ? Mathf.clamp(this.amountX, -this.overscrollDistance, this.maxX + this.overscrollDistance) : Mathf.clamp(this.amountX, 0.0f, this.maxX));
        this.scrollY(this.overscrollY ? Mathf.clamp(this.amountY, -this.overscrollDistance, this.maxY + this.overscrollDistance) : Mathf.clamp(this.amountY, 0.0f, this.maxY));
    }
    
    public ScrollPaneStyle getStyle() {
        return this.style;
    }
    
    public void setStyle(final ScrollPaneStyle style) {
        if (style == null) {
            throw new IllegalArgumentException("style cannot be null.");
        }
        this.style = style;
        this.invalidateHierarchy();
    }
    
    @Override
    public void act(final float delta) {
        super.act(delta);
        final boolean panning = this.flickScrollListener.getGestureDetector().isPanning();
        boolean animating = false;
        if (this.fadeAlpha > 0.0f && this.fadeScrollBars && !panning && !this.touchScrollH && !this.touchScrollV) {
            this.fadeDelay -= delta;
            if (this.fadeDelay <= 0.0f) {
                this.fadeAlpha = Math.max(0.0f, this.fadeAlpha - delta);
            }
            animating = true;
        }
        if (this.flingTimer > 0.0f) {
            this.resetFade();
            final float alpha = this.flingTimer / this.flingTime;
            this.amountX -= this.velocityX * alpha * delta;
            this.amountY -= this.velocityY * alpha * delta;
            this.clamp();
            if (this.amountX == -this.overscrollDistance) {
                this.velocityX = 0.0f;
            }
            if (this.amountX >= this.maxX + this.overscrollDistance) {
                this.velocityX = 0.0f;
            }
            if (this.amountY == -this.overscrollDistance) {
                this.velocityY = 0.0f;
            }
            if (this.amountY >= this.maxY + this.overscrollDistance) {
                this.velocityY = 0.0f;
            }
            this.flingTimer -= delta;
            if (this.flingTimer <= 0.0f) {
                this.velocityX = 0.0f;
                this.velocityY = 0.0f;
            }
            animating = true;
        }
        if (this.smoothScrolling && this.flingTimer <= 0.0f && !panning && (!this.touchScrollH || (this.scrollX && this.maxX / (this.hScrollBounds.width - this.hKnobBounds.width) > this.areaWidth * 0.1f)) && (!this.touchScrollV || (this.scrollY && this.maxY / (this.vScrollBounds.height - this.vKnobBounds.height) > this.areaHeight * 0.1f))) {
            if (this.visualAmountX != this.amountX) {
                if (this.visualAmountX < this.amountX) {
                    this.visualScrollX(Math.min(this.amountX, this.visualAmountX + Math.max(200.0f * delta, (this.amountX - this.visualAmountX) * 7.0f * delta)));
                }
                else {
                    this.visualScrollX(Math.max(this.amountX, this.visualAmountX - Math.max(200.0f * delta, (this.visualAmountX - this.amountX) * 7.0f * delta)));
                }
                animating = true;
            }
            if (this.visualAmountY != this.amountY) {
                if (this.visualAmountY < this.amountY) {
                    this.visualScrollY(Math.min(this.amountY, this.visualAmountY + Math.max(200.0f * delta, (this.amountY - this.visualAmountY) * 7.0f * delta)));
                }
                else {
                    this.visualScrollY(Math.max(this.amountY, this.visualAmountY - Math.max(200.0f * delta, (this.visualAmountY - this.amountY) * 7.0f * delta)));
                }
                animating = true;
            }
        }
        else {
            if (this.visualAmountX != this.amountX) {
                this.visualScrollX(this.amountX);
            }
            if (this.visualAmountY != this.amountY) {
                this.visualScrollY(this.amountY);
            }
        }
        if (!panning) {
            if (this.overscrollX && this.scrollX) {
                if (this.amountX < 0.0f) {
                    this.resetFade();
                    this.amountX += (this.overscrollSpeedMin + (this.overscrollSpeedMax - this.overscrollSpeedMin) * -this.amountX / this.overscrollDistance) * delta;
                    if (this.amountX > 0.0f) {
                        this.scrollX(0.0f);
                    }
                    animating = true;
                }
                else if (this.amountX > this.maxX) {
                    this.resetFade();
                    this.amountX -= (this.overscrollSpeedMin + (this.overscrollSpeedMax - this.overscrollSpeedMin) * -(this.maxX - this.amountX) / this.overscrollDistance) * delta;
                    if (this.amountX < this.maxX) {
                        this.scrollX(this.maxX);
                    }
                    animating = true;
                }
            }
            if (this.overscrollY && this.scrollY) {
                if (this.amountY < 0.0f) {
                    this.resetFade();
                    this.amountY += (this.overscrollSpeedMin + (this.overscrollSpeedMax - this.overscrollSpeedMin) * -this.amountY / this.overscrollDistance) * delta;
                    if (this.amountY > 0.0f) {
                        this.scrollY(0.0f);
                    }
                    animating = true;
                }
                else if (this.amountY > this.maxY) {
                    this.resetFade();
                    this.amountY -= (this.overscrollSpeedMin + (this.overscrollSpeedMax - this.overscrollSpeedMin) * -(this.maxY - this.amountY) / this.overscrollDistance) * delta;
                    if (this.amountY < this.maxY) {
                        this.scrollY(this.maxY);
                    }
                    animating = true;
                }
            }
        }
        if (animating) {
            final Scene stage = this.getScene();
            if (stage != null && stage.getActionsRequestRendering()) {
                Core.graphics.requestRendering();
            }
        }
    }
    
    public void setClip(final boolean clip) {
        this.clip = clip;
    }
    
    @Override
    public void layout() {
        final Drawable bg = this.style.background;
        final Drawable hScrollKnob = this.style.hScrollKnob;
        final Drawable vScrollKnob = this.style.vScrollKnob;
        float bgLeftWidth = 0.0f;
        float bgRightWidth = 0.0f;
        float bgTopHeight = 0.0f;
        float bgBottomHeight = 0.0f;
        if (bg != null) {
            bgLeftWidth = bg.getLeftWidth();
            bgRightWidth = bg.getRightWidth();
            bgTopHeight = bg.getTopHeight();
            bgBottomHeight = bg.getBottomHeight();
        }
        final float width = this.getWidth();
        final float height = this.getHeight();
        float scrollbarHeight = 0.0f;
        if (hScrollKnob != null) {
            scrollbarHeight = hScrollKnob.getMinHeight();
        }
        if (this.style.hScroll != null) {
            scrollbarHeight = Math.max(scrollbarHeight, this.style.hScroll.getMinHeight());
        }
        float scrollbarWidth = 0.0f;
        if (vScrollKnob != null) {
            scrollbarWidth = vScrollKnob.getMinWidth();
        }
        if (this.style.vScroll != null) {
            scrollbarWidth = Math.max(scrollbarWidth, this.style.vScroll.getMinWidth());
        }
        this.areaWidth = width - bgLeftWidth - bgRightWidth;
        this.areaHeight = height - bgTopHeight - bgBottomHeight;
        if (this.widget == null) {
            return;
        }
        float widgetWidth = this.widget.getPrefWidth();
        float widgetHeight = this.widget.getPrefHeight();
        this.scrollX = (this.forceScrollX || (widgetWidth > this.areaWidth && !this.disableX));
        this.scrollY = (this.forceScrollY || (widgetHeight > this.areaHeight && !this.disableY));
        final boolean fade = this.fadeScrollBars;
        if (!fade) {
            if (this.scrollY) {
                this.areaWidth -= scrollbarWidth;
                if (!this.scrollX && widgetWidth > this.areaWidth && !this.disableX) {
                    this.scrollX = true;
                }
            }
            if (this.scrollX) {
                this.areaHeight -= scrollbarHeight;
                if (!this.scrollY && widgetHeight > this.areaHeight && !this.disableY) {
                    this.scrollY = true;
                    this.areaWidth -= scrollbarWidth;
                }
            }
        }
        this.widgetAreaBounds.set(bgLeftWidth, bgBottomHeight, this.areaWidth, this.areaHeight);
        if (fade) {
            if (this.scrollX && this.scrollY) {
                this.areaHeight -= scrollbarHeight;
                this.areaWidth -= scrollbarWidth;
            }
        }
        else if (this.scrollbarsOnTop) {
            if (this.scrollX) {
                final Rect widgetAreaBounds = this.widgetAreaBounds;
                widgetAreaBounds.height += scrollbarHeight;
            }
            if (this.scrollY) {
                final Rect widgetAreaBounds2 = this.widgetAreaBounds;
                widgetAreaBounds2.width += scrollbarWidth;
            }
        }
        else {
            if (this.scrollX && this.hScrollOnBottom) {
                final Rect widgetAreaBounds3 = this.widgetAreaBounds;
                widgetAreaBounds3.y += scrollbarHeight;
            }
            if (this.scrollY && !this.vScrollOnRight) {
                final Rect widgetAreaBounds4 = this.widgetAreaBounds;
                widgetAreaBounds4.x += scrollbarWidth;
            }
        }
        widgetWidth = (this.disableX ? this.areaWidth : Math.max(this.areaWidth, widgetWidth));
        widgetHeight = (this.disableY ? this.areaHeight : Math.max(this.areaHeight, widgetHeight));
        this.maxX = widgetWidth - this.areaWidth;
        this.maxY = widgetHeight - this.areaHeight;
        if (fade && this.scrollX && this.scrollY) {
            this.maxY -= scrollbarHeight;
            this.maxX -= scrollbarWidth;
        }
        this.scrollX(Mathf.clamp(this.amountX, 0.0f, this.maxX));
        if (this.scrollX) {
            if (hScrollKnob != null) {
                final float hScrollHeight = hScrollKnob.getMinHeight();
                final float boundsX = this.vScrollOnRight ? bgLeftWidth : (bgLeftWidth + scrollbarWidth);
                final float boundsY = this.hScrollOnBottom ? bgBottomHeight : (height - bgTopHeight - hScrollHeight);
                this.hScrollBounds.set(boundsX, boundsY, this.areaWidth, hScrollHeight);
                if (this.variableSizeKnobs) {
                    this.hKnobBounds.width = Math.max(hScrollKnob.getMinWidth(), (float)(int)(this.hScrollBounds.width * this.areaWidth / widgetWidth));
                }
                else {
                    this.hKnobBounds.width = hScrollKnob.getMinWidth();
                }
                this.hKnobBounds.height = hScrollKnob.getMinHeight();
                this.hKnobBounds.x = this.hScrollBounds.x + (int)((this.hScrollBounds.width - this.hKnobBounds.width) * this.getScrollPercentX());
                this.hKnobBounds.y = this.hScrollBounds.y;
            }
            else {
                this.hScrollBounds.set(0.0f, 0.0f, 0.0f, 0.0f);
                this.hKnobBounds.set(0.0f, 0.0f, 0.0f, 0.0f);
            }
        }
        if (this.scrollY) {
            if (vScrollKnob != null) {
                final float vScrollWidth = vScrollKnob.getMinWidth();
                float boundsY;
                if (this.hScrollOnBottom) {
                    boundsY = height - bgTopHeight - this.areaHeight;
                }
                else {
                    boundsY = bgBottomHeight;
                }
                float boundsX;
                if (this.vScrollOnRight) {
                    boundsX = width - bgRightWidth - vScrollWidth;
                }
                else {
                    boundsX = bgLeftWidth;
                }
                this.vScrollBounds.set(boundsX, boundsY, vScrollWidth, this.areaHeight);
                this.vKnobBounds.width = vScrollKnob.getMinWidth();
                if (this.variableSizeKnobs) {
                    this.vKnobBounds.height = Math.max(vScrollKnob.getMinHeight(), (float)(int)(this.vScrollBounds.height * this.areaHeight / widgetHeight));
                }
                else {
                    this.vKnobBounds.height = vScrollKnob.getMinHeight();
                }
                if (this.vScrollOnRight) {
                    this.vKnobBounds.x = width - bgRightWidth - vScrollKnob.getMinWidth();
                }
                else {
                    this.vKnobBounds.x = bgLeftWidth;
                }
                this.vKnobBounds.y = this.vScrollBounds.y + (int)((this.vScrollBounds.height - this.vKnobBounds.height) * (1.0f - this.getScrollPercentY()));
            }
            else {
                this.vScrollBounds.set(0.0f, 0.0f, 0.0f, 0.0f);
                this.vKnobBounds.set(0.0f, 0.0f, 0.0f, 0.0f);
            }
        }
        this.widget.setSize(widgetWidth, widgetHeight);
        this.widget.validate();
    }
    
    @Override
    public void draw() {
        if (this.widget == null) {
            return;
        }
        this.validate();
        this.applyTransform(this.computeTransform());
        if (this.scrollX) {
            this.hKnobBounds.x = this.hScrollBounds.x + (int)((this.hScrollBounds.width - this.hKnobBounds.width) * this.getVisualScrollPercentX());
        }
        if (this.scrollY) {
            this.vKnobBounds.y = this.vScrollBounds.y + (int)((this.vScrollBounds.height - this.vKnobBounds.height) * (1.0f - this.getVisualScrollPercentY()));
        }
        float y = this.widgetAreaBounds.y;
        if (!this.scrollY) {
            y -= (int)this.maxY;
        }
        else {
            y -= (int)(this.maxY - this.visualAmountY);
        }
        float x = this.widgetAreaBounds.x;
        if (this.scrollX) {
            x -= (int)this.visualAmountX;
        }
        if (!this.fadeScrollBars && this.scrollbarsOnTop) {
            if (this.scrollX && this.hScrollOnBottom) {
                float scrollbarHeight = 0.0f;
                if (this.style.hScrollKnob != null) {
                    scrollbarHeight = this.style.hScrollKnob.getMinHeight();
                }
                if (this.style.hScroll != null) {
                    scrollbarHeight = Math.max(scrollbarHeight, this.style.hScroll.getMinHeight());
                }
                y += scrollbarHeight;
            }
            if (this.scrollY && !this.vScrollOnRight) {
                float scrollbarWidth = 0.0f;
                if (this.style.hScrollKnob != null) {
                    scrollbarWidth = this.style.hScrollKnob.getMinWidth();
                }
                if (this.style.hScroll != null) {
                    scrollbarWidth = Math.max(scrollbarWidth, this.style.hScroll.getMinWidth());
                }
                x += scrollbarWidth;
            }
        }
        this.widget.setPosition(x, y);
        if (this.widget instanceof Cullable) {
            this.widgetCullingArea.x = -this.widget.x + this.widgetAreaBounds.x;
            this.widgetCullingArea.y = -this.widget.y + this.widgetAreaBounds.y;
            this.widgetCullingArea.width = this.widgetAreaBounds.width;
            this.widgetCullingArea.height = this.widgetAreaBounds.height;
            ((Cullable)this.widget).setCullingArea(this.widgetCullingArea);
        }
        if (this.style.background != null) {
            this.style.background.draw(0.0f, 0.0f, this.getWidth(), this.getHeight());
        }
        Core.scene.calculateScissors(this.widgetAreaBounds, this.scissorBounds);
        if (this.clip) {
            if (ScissorStack.push(this.scissorBounds)) {
                this.drawChildren();
                ScissorStack.pop();
            }
        }
        else {
            this.drawChildren();
        }
        Draw.color(this.color.r, this.color.g, this.color.b, this.color.a * this.parentAlpha * Interp.fade.apply(this.fadeAlpha / this.fadeAlphaSeconds));
        if (this.scrollX && this.scrollY && this.style.corner != null) {
            this.style.corner.draw(this.hScrollBounds.x + this.hScrollBounds.width, this.hScrollBounds.y, this.vScrollBounds.width, this.vScrollBounds.y);
        }
        if (this.scrollX) {
            if (this.style.hScroll != null) {
                this.style.hScroll.draw(this.hScrollBounds.x, this.hScrollBounds.y, this.hScrollBounds.width, this.hScrollBounds.height);
            }
            if (this.style.hScrollKnob != null) {
                this.style.hScrollKnob.draw(this.hKnobBounds.x, this.hKnobBounds.y, this.hKnobBounds.width, this.hKnobBounds.height);
            }
        }
        if (this.scrollY) {
            if (this.style.vScroll != null) {
                this.style.vScroll.draw(this.vScrollBounds.x, this.vScrollBounds.y, this.vScrollBounds.width, this.vScrollBounds.height);
            }
            if (this.style.vScrollKnob != null) {
                this.style.vScrollKnob.draw(this.vKnobBounds.x, this.vKnobBounds.y, this.vKnobBounds.width, this.vKnobBounds.height);
            }
        }
        this.resetTransform();
    }
    
    public void fling(final float flingTime, final float velocityX, final float velocityY) {
        this.flingTimer = flingTime;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
    }
    
    @Override
    public float getPrefWidth() {
        float width = 0.0f;
        if (this.widget != null) {
            this.validate();
            width = this.widget.getPrefWidth();
        }
        if (this.style.background != null) {
            width += this.style.background.getLeftWidth() + this.style.background.getRightWidth();
        }
        if (this.scrollY) {
            float scrollbarWidth = 0.0f;
            if (this.style.vScrollKnob != null) {
                scrollbarWidth = this.style.vScrollKnob.getMinWidth();
            }
            if (this.style.vScroll != null) {
                scrollbarWidth = Math.max(scrollbarWidth, this.style.vScroll.getMinWidth());
            }
            width += scrollbarWidth;
        }
        return width;
    }
    
    @Override
    public float getPrefHeight() {
        float height = 0.0f;
        if (this.widget != null) {
            this.validate();
            height = this.widget.getPrefHeight();
        }
        if (this.style.background != null) {
            height += this.style.background.getTopHeight() + this.style.background.getBottomHeight();
        }
        if (this.scrollX) {
            float scrollbarHeight = 0.0f;
            if (this.style.hScrollKnob != null) {
                scrollbarHeight = this.style.hScrollKnob.getMinHeight();
            }
            if (this.style.hScroll != null) {
                scrollbarHeight = Math.max(scrollbarHeight, this.style.hScroll.getMinHeight());
            }
            height += scrollbarHeight;
        }
        return height;
    }
    
    @Override
    public float getMinWidth() {
        return 0.0f;
    }
    
    @Override
    public float getMinHeight() {
        return 0.0f;
    }
    
    public Element getWidget() {
        return this.widget;
    }
    
    public void setWidget(final Element widget) {
        if (widget == this) {
            throw new IllegalArgumentException("widget cannot be the ScrollPane.");
        }
        if (this.widget != null) {
            super.removeChild(this.widget);
        }
        if ((this.widget = widget) != null) {
            super.addChild(widget);
        }
    }
    
    @Override
    public boolean removeChild(final Element actor) {
        if (actor == null) {
            throw new IllegalArgumentException("actor cannot be null.");
        }
        if (actor != this.widget) {
            return false;
        }
        this.setWidget(null);
        return true;
    }
    
    @Override
    public boolean removeChild(final Element actor, final boolean unfocus) {
        if (actor == null) {
            throw new IllegalArgumentException("actor cannot be null.");
        }
        if (actor != this.widget) {
            return false;
        }
        this.widget = null;
        return super.removeChild(actor, unfocus);
    }
    
    @Override
    public Element hit(final float x, final float y, final boolean touchable) {
        if (x < 0.0f || x >= this.getWidth() || y < 0.0f || y >= this.getHeight()) {
            return null;
        }
        if (this.scrollX && this.hScrollBounds.contains(x, y)) {
            return this;
        }
        if (this.scrollY && this.vScrollBounds.contains(x, y)) {
            return this;
        }
        return super.hit(x, y, touchable);
    }
    
    protected void scrollX(final float pixelsX) {
        this.amountX = pixelsX;
    }
    
    protected void scrollY(final float pixelsY) {
        this.amountY = pixelsY;
    }
    
    protected void visualScrollX(final float pixelsX) {
        this.visualAmountX = pixelsX;
    }
    
    protected void visualScrollY(final float pixelsY) {
        this.visualAmountY = pixelsY;
    }
    
    protected float getMouseWheelX() {
        return Math.min(this.areaWidth, Math.max(this.areaWidth * 0.9f, this.maxX * 0.1f) / 4.0f);
    }
    
    protected float getMouseWheelY() {
        return Math.min(this.areaHeight, Math.max(this.areaHeight * 0.9f, this.maxY * 0.1f) / 4.0f);
    }
    
    public void setScrollXForce(final float pixels) {
        this.visualAmountX = pixels;
        this.amountX = pixels;
        this.scrollX = true;
    }
    
    public float getScrollX() {
        return this.amountX;
    }
    
    public void setScrollYForce(final float pixels) {
        this.visualAmountY = pixels;
        this.amountY = pixels;
        this.scrollY = true;
    }
    
    public float getScrollY() {
        return this.amountY;
    }
    
    public void updateVisualScroll() {
        this.visualAmountX = this.amountX;
        this.visualAmountY = this.amountY;
    }
    
    public float getVisualScrollX() {
        return this.scrollX ? this.visualAmountX : 0.0f;
    }
    
    public float getVisualScrollY() {
        return this.scrollY ? this.visualAmountY : 0.0f;
    }
    
    public float getVisualScrollPercentX() {
        return Mathf.clamp(this.visualAmountX / this.maxX, 0.0f, 1.0f);
    }
    
    public float getVisualScrollPercentY() {
        return Mathf.clamp(this.visualAmountY / this.maxY, 0.0f, 1.0f);
    }
    
    public float getScrollPercentX() {
        if (Float.isNaN(this.amountX / this.maxX)) {
            return 1.0f;
        }
        return Mathf.clamp(this.amountX / this.maxX, 0.0f, 1.0f);
    }
    
    public void setScrollPercentX(final float percentX) {
        this.scrollX(this.maxX * Mathf.clamp(percentX, 0.0f, 1.0f));
    }
    
    public float getScrollPercentY() {
        if (Float.isNaN(this.amountY / this.maxY)) {
            return 1.0f;
        }
        return Mathf.clamp(this.amountY / this.maxY, 0.0f, 1.0f);
    }
    
    public void setScrollPercentY(final float percentY) {
        this.scrollY(this.maxY * Mathf.clamp(percentY, 0.0f, 1.0f));
    }
    
    public void setFlickScroll(final boolean flickScroll) {
        if (this.flickScroll == flickScroll) {
            return;
        }
        this.flickScroll = flickScroll;
        if (flickScroll) {
            this.addListener(this.flickScrollListener);
        }
        else {
            this.removeListener(this.flickScrollListener);
        }
        this.invalidate();
    }
    
    public void setFlickScrollTapSquareSize(final float halfTapSquareSize) {
        this.flickScrollListener.getGestureDetector().setTapSquareSize(halfTapSquareSize);
    }
    
    public void scrollTo(final float x, final float y, final float width, final float height) {
        this.scrollTo(x, y, width, height, false, false);
    }
    
    public void scrollTo(final float x, final float y, final float width, final float height, final boolean centerHorizontal, final boolean centerVertical) {
        float amountX = this.amountX;
        if (centerHorizontal) {
            amountX = x - this.areaWidth / 2.0f + width / 2.0f;
        }
        else {
            if (x + width > amountX + this.areaWidth) {
                amountX = x + width - this.areaWidth;
            }
            if (x < amountX) {
                amountX = x;
            }
        }
        this.scrollX(Mathf.clamp(amountX, 0.0f, this.maxX));
        float amountY = this.amountY;
        if (centerVertical) {
            amountY = this.maxY - y + this.areaHeight / 2.0f - height / 2.0f;
        }
        else {
            if (amountY > this.maxY - y - height + this.areaHeight) {
                amountY = this.maxY - y - height + this.areaHeight;
            }
            if (amountY < this.maxY - y) {
                amountY = this.maxY - y;
            }
        }
        this.scrollY(Mathf.clamp(amountY, 0.0f, this.maxY));
    }
    
    public float getMaxX() {
        return this.maxX;
    }
    
    public float getMaxY() {
        return this.maxY;
    }
    
    public float getScrollBarHeight() {
        if (!this.scrollX) {
            return 0.0f;
        }
        float height = 0.0f;
        if (this.style.hScrollKnob != null) {
            height = this.style.hScrollKnob.getMinHeight();
        }
        if (this.style.hScroll != null) {
            height = Math.max(height, this.style.hScroll.getMinHeight());
        }
        return height;
    }
    
    public float getScrollBarWidth() {
        if (!this.scrollY) {
            return 0.0f;
        }
        float width = 0.0f;
        if (this.style.vScrollKnob != null) {
            width = this.style.vScrollKnob.getMinWidth();
        }
        if (this.style.vScroll != null) {
            width = Math.max(width, this.style.vScroll.getMinWidth());
        }
        return width;
    }
    
    public float getScrollWidth() {
        return this.areaWidth;
    }
    
    public float getScrollHeight() {
        return this.areaHeight;
    }
    
    public boolean isScrollX() {
        return this.scrollX;
    }
    
    public void setScrollX(final float pixels) {
        this.scrollX(Mathf.clamp(pixels, 0.0f, this.maxX));
    }
    
    public boolean isScrollY() {
        return this.scrollY;
    }
    
    public void setScrollY(final float pixels) {
        this.scrollY(Mathf.clamp(pixels, 0.0f, this.maxY));
    }
    
    public void setScrollingDisabled(final boolean x, final boolean y) {
        this.disableX = x;
        this.disableY = y;
    }
    
    public boolean isScrollingDisabledX() {
        return this.disableX;
    }
    
    public boolean isScrollingDisabledY() {
        return this.disableY;
    }
    
    public boolean isLeftEdge() {
        return !this.scrollX || this.amountX <= 0.0f;
    }
    
    public boolean isRightEdge() {
        return !this.scrollX || this.amountX >= this.maxX;
    }
    
    public boolean isTopEdge() {
        return !this.scrollY || this.amountY <= 0.0f;
    }
    
    public boolean isBottomEdge() {
        return !this.scrollY || this.amountY >= this.maxY;
    }
    
    public boolean isDragging() {
        return this.draggingPointer != -1;
    }
    
    public boolean isPanning() {
        return this.flickScrollListener.getGestureDetector().isPanning();
    }
    
    public boolean isFlinging() {
        return this.flingTimer > 0.0f;
    }
    
    public float getVelocityX() {
        return this.velocityX;
    }
    
    public void setVelocityX(final float velocityX) {
        this.velocityX = velocityX;
    }
    
    public float getVelocityY() {
        return this.velocityY;
    }
    
    public void setVelocityY(final float velocityY) {
        this.velocityY = velocityY;
    }
    
    public void setOverscroll(final boolean overscrollX, final boolean overscrollY) {
        this.overscrollX = overscrollX;
        this.overscrollY = overscrollY;
    }
    
    public void setupOverscroll(final float distance, final float speedMin, final float speedMax) {
        this.overscrollDistance = distance;
        this.overscrollSpeedMin = speedMin;
        this.overscrollSpeedMax = speedMax;
    }
    
    public void setForceScroll(final boolean x, final boolean y) {
        this.forceScrollX = x;
        this.forceScrollY = y;
    }
    
    public boolean isForceScrollX() {
        return this.forceScrollX;
    }
    
    public boolean isForceScrollY() {
        return this.forceScrollY;
    }
    
    public void setFlingTime(final float flingTime) {
        this.flingTime = flingTime;
    }
    
    public void setClamp(final boolean clamp) {
        this.clamp = clamp;
    }
    
    public void setScrollBarPositions(final boolean bottom, final boolean right) {
        this.hScrollOnBottom = bottom;
        this.vScrollOnRight = right;
    }
    
    public void setFadeScrollBars(final boolean fadeScrollBars) {
        if (this.fadeScrollBars == fadeScrollBars) {
            return;
        }
        if (!(this.fadeScrollBars = fadeScrollBars)) {
            this.fadeAlpha = this.fadeAlphaSeconds;
        }
        this.invalidate();
    }
    
    public void setupFadeScrollBars(final float fadeAlphaSeconds, final float fadeDelaySeconds) {
        this.fadeAlphaSeconds = fadeAlphaSeconds;
        this.fadeDelaySeconds = fadeDelaySeconds;
    }
    
    public void setSmoothScrolling(final boolean smoothScrolling) {
        this.smoothScrolling = smoothScrolling;
    }
    
    public void setScrollbarsOnTop(final boolean scrollbarsOnTop) {
        this.scrollbarsOnTop = scrollbarsOnTop;
        this.invalidate();
    }
    
    public boolean getVariableSizeKnobs() {
        return this.variableSizeKnobs;
    }
    
    public void setVariableSizeKnobs(final boolean variableSizeKnobs) {
        this.variableSizeKnobs = variableSizeKnobs;
    }
    
    public void setCancelTouchFocus(final boolean cancelTouchFocus) {
        this.cancelTouchFocus = cancelTouchFocus;
    }
    
    public static class ScrollPaneStyle extends Style
    {
        public Drawable background;
        public Drawable corner;
        public Drawable hScroll;
        public Drawable hScrollKnob;
        public Drawable vScroll;
        public Drawable vScrollKnob;
        
        public ScrollPaneStyle() {
        }
        
        public ScrollPaneStyle(final ScrollPaneStyle style) {
            this.background = style.background;
            this.hScroll = style.hScroll;
            this.hScrollKnob = style.hScrollKnob;
            this.vScroll = style.vScroll;
            this.vScrollKnob = style.vScrollKnob;
        }
    }
}
