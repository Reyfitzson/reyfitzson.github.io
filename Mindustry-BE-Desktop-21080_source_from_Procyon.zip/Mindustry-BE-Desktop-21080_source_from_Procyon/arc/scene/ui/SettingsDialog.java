// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import arc.scene.ui.layout.Scl;
import java.util.Iterator;
import arc.func.Boolc;
import arc.func.Cons;
import arc.struct.Seq;
import arc.scene.ui.layout.Table;
import arc.Core;

public class SettingsDialog extends Dialog
{
    public SettingsTable main;
    
    public SettingsDialog() {
        super(Core.bundle.get("settings", "Settings"));
        this.addCloseButton();
        this.main = new SettingsTable();
        this.cont.add(this.main);
    }
    
    public static class SettingsTable extends Table
    {
        protected Seq<Setting> list;
        protected Cons<SettingsTable> rebuilt;
        
        public SettingsTable() {
            this.list = new Seq<Setting>();
            this.left();
        }
        
        public SettingsTable(final Cons<SettingsTable> rebuilt) {
            this.list = new Seq<Setting>();
            this.rebuilt = rebuilt;
            this.left();
        }
        
        public Seq<Setting> getSettings() {
            return this.list;
        }
        
        public void pref(final Setting setting) {
            this.list.add(setting);
            this.rebuild();
        }
        
        public void screenshakePref() {
            this.sliderPref("screenshake", Core.bundle.get("setting.screenshake.name", "Screen Shake"), 4, 0, 8, i -> i / 4.0f + "x");
        }
        
        public SliderSetting sliderPref(final String name, final String title, final int def, final int min, final int max, final StringProcessor s) {
            return this.sliderPref(name, title, def, min, max, 1, s);
        }
        
        public SliderSetting sliderPref(final String name, final String title, final int def, final int min, final int max, final int step, final StringProcessor s) {
            final SliderSetting res;
            this.list.add(res = new SliderSetting(name, title, def, min, max, step, s));
            Core.settings.defaults(name, def);
            this.rebuild();
            return res;
        }
        
        public SliderSetting sliderPref(final String name, final int def, final int min, final int max, final StringProcessor s) {
            return this.sliderPref(name, def, min, max, 1, s);
        }
        
        public SliderSetting sliderPref(final String name, final int def, final int min, final int max, final int step, final StringProcessor s) {
            final SliderSetting res;
            this.list.add(res = new SliderSetting(name, Core.bundle.get("setting." + name + ".name"), def, min, max, step, s));
            Core.settings.defaults(name, def);
            this.rebuild();
            return res;
        }
        
        public void checkPref(final String name, final String title, final boolean def) {
            this.list.add(new CheckSetting(name, title, def, null));
            Core.settings.defaults(name, def);
            this.rebuild();
        }
        
        public void checkPref(final String name, final String title, final boolean def, final Boolc changed) {
            this.list.add(new CheckSetting(name, title, def, changed));
            Core.settings.defaults(name, def);
            this.rebuild();
        }
        
        public void checkPref(final String name, final boolean def) {
            this.list.add(new CheckSetting(name, Core.bundle.get("setting." + name + ".name"), def, null));
            Core.settings.defaults(name, def);
            this.rebuild();
        }
        
        public void checkPref(final String name, final boolean def, final Boolc changed) {
            this.list.add(new CheckSetting(name, Core.bundle.get("setting." + name + ".name"), def, changed));
            Core.settings.defaults(name, def);
            this.rebuild();
        }
        
        void rebuild() {
            this.clearChildren();
            for (final Setting setting : this.list) {
                setting.add(this);
            }
            final Iterator<Setting> iterator2;
            Setting setting2;
            this.button(Core.bundle.get("settings.reset", "Reset to Defaults"), () -> {
                this.list.iterator();
                while (iterator2.hasNext()) {
                    setting2 = iterator2.next();
                    if (setting2.name != null) {
                        if (setting2.title == null) {
                            continue;
                        }
                        else {
                            Core.settings.put(setting2.name, Core.settings.getDefault(setting2.name));
                        }
                    }
                }
                this.rebuild();
                return;
            }).margin(14.0f).width(240.0f).pad(6.0f);
            if (this.rebuilt != null) {
                this.rebuilt.get(this);
            }
        }
        
        public abstract static class Setting
        {
            public String name;
            public String title;
            
            public abstract void add(final SettingsTable p0);
        }
        
        public static class CheckSetting extends Setting
        {
            boolean def;
            Boolc changed;
            
            CheckSetting(final String name, final String title, final boolean def, final Boolc changed) {
                this.name = name;
                this.title = title;
                this.def = def;
                this.changed = changed;
            }
            
            @Override
            public void add(final SettingsTable table) {
                final CheckBox box = new CheckBox(this.title);
                box.update(() -> box.setChecked(Core.settings.getBool(this.name)));
                final CheckBox checkBox;
                box.changed(() -> {
                    Core.settings.put(this.name, checkBox.isChecked);
                    if (this.changed != null) {
                        this.changed.get(checkBox.isChecked);
                    }
                    return;
                });
                box.left();
                table.add(box).left().padTop(3.0f);
                table.row();
            }
        }
        
        public static class SliderSetting extends Setting
        {
            int def;
            int min;
            int max;
            int step;
            StringProcessor sp;
            float[] values;
            
            SliderSetting(final String name, final String title, final int def, final int min, final int max, final int step, final StringProcessor s) {
                this.values = null;
                this.name = name;
                this.title = title;
                this.def = def;
                this.min = min;
                this.max = max;
                this.step = step;
                this.sp = s;
            }
            
            @Override
            public void add(final SettingsTable table) {
                final Slider slider = new Slider((float)this.min, (float)this.max, (float)this.step, false);
                slider.setValue((float)Core.settings.getInt(this.name));
                if (this.values != null) {
                    slider.setSnapToValues(this.values, 1.0f);
                }
                final Label label = new Label(this.title);
                final ProgressBar progressBar;
                final Label label2;
                slider.changed(() -> {
                    Core.settings.put(this.name, (int)progressBar.getValue());
                    label2.setText(this.title + ": " + this.sp.get((int)progressBar.getValue()));
                    return;
                });
                slider.change();
                final Label element;
                final Slider element2;
                table.table(t -> {
                    t.left().defaults().left();
                    t.add(element).minWidth(element.getPrefWidth() / Scl.scl(1.0f) + 50.0f);
                    t.add(element2).width(180.0f);
                    return;
                }).left().padTop(3.0f);
                table.row();
            }
        }
    }
    
    public interface StringProcessor
    {
        String get(final int p0);
    }
}
