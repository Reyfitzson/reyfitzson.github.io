// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import arc.scene.style.Drawable;
import arc.graphics.g2d.Font;
import arc.scene.ui.layout.Cell;
import arc.graphics.Color;
import arc.Core;

public class TextButton extends Button
{
    protected final Label label;
    private TextButtonStyle style;
    
    public TextButton(final String text) {
        this(text, Core.scene.getStyle(TextButtonStyle.class));
    }
    
    public TextButton(final String text, final TextButtonStyle style) {
        this.setStyle(style);
        this.style = style;
        (this.label = new Label(text, new Label.LabelStyle(style.font, style.fontColor))).setAlignment(1);
        this.add(this.label).expand().fill().wrap().minWidth(this.getMinWidth());
        this.setSize(this.getPrefWidth(), this.getPrefHeight());
    }
    
    @Override
    public TextButtonStyle getStyle() {
        return this.style;
    }
    
    @Override
    public void setStyle(final ButtonStyle style) {
        if (style == null) {
            throw new NullPointerException("style cannot be null");
        }
        if (!(style instanceof TextButtonStyle)) {
            throw new IllegalArgumentException("style must be a TextButtonStyle.");
        }
        super.setStyle(style);
        this.style = (TextButtonStyle)style;
        if (this.label != null) {
            final TextButtonStyle textButtonStyle = (TextButtonStyle)style;
            final Label.LabelStyle labelStyle = this.label.getStyle();
            labelStyle.font = textButtonStyle.font;
            labelStyle.fontColor = textButtonStyle.fontColor;
            this.label.setStyle(labelStyle);
        }
    }
    
    @Override
    public void draw() {
        Color fontColor;
        if (this.isDisabled() && this.style.disabledFontColor != null) {
            fontColor = this.style.disabledFontColor;
        }
        else if (this.isPressed() && this.style.downFontColor != null) {
            fontColor = this.style.downFontColor;
        }
        else if (this.isChecked && this.style.checkedFontColor != null) {
            fontColor = ((this.isOver() && this.style.checkedOverFontColor != null) ? this.style.checkedOverFontColor : this.style.checkedFontColor);
        }
        else if (this.isOver() && this.style.overFontColor != null) {
            fontColor = this.style.overFontColor;
        }
        else {
            fontColor = this.style.fontColor;
        }
        if (fontColor != null) {
            this.label.getStyle().fontColor = fontColor;
        }
        super.draw();
    }
    
    public Label getLabel() {
        return this.label;
    }
    
    public Cell<Label> getLabelCell() {
        return (Cell<Label>)this.getCell(this.label);
    }
    
    public CharSequence getText() {
        return this.label.getText();
    }
    
    public void setText(final String text) {
        this.label.setText(text);
    }
    
    public static class TextButtonStyle extends ButtonStyle
    {
        public Font font;
        public Color fontColor;
        public Color downFontColor;
        public Color overFontColor;
        public Color checkedFontColor;
        public Color checkedOverFontColor;
        public Color disabledFontColor;
        
        public TextButtonStyle() {
        }
        
        public TextButtonStyle(final Drawable up, final Drawable down, final Drawable checked, final Font font) {
            super(up, down, checked);
            this.font = font;
        }
        
        public TextButtonStyle(final TextButtonStyle style) {
            super(style);
            this.font = style.font;
            if (style.fontColor != null) {
                this.fontColor = new Color(style.fontColor);
            }
            if (style.downFontColor != null) {
                this.downFontColor = new Color(style.downFontColor);
            }
            if (style.overFontColor != null) {
                this.overFontColor = new Color(style.overFontColor);
            }
            if (style.checkedFontColor != null) {
                this.checkedFontColor = new Color(style.checkedFontColor);
            }
            if (style.checkedOverFontColor != null) {
                this.checkedFontColor = new Color(style.checkedOverFontColor);
            }
            if (style.disabledFontColor != null) {
                this.disabledFontColor = new Color(style.disabledFontColor);
            }
        }
    }
}
