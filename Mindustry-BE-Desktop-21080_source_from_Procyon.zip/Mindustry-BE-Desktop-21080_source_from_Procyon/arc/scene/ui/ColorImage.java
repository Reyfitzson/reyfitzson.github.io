// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import arc.graphics.Color;

public class ColorImage extends Image
{
    private Color set;
    
    public ColorImage(final Color set) {
        this.set = new Color(set);
    }
    
    @Override
    public void draw() {
        this.setColor(this.set);
        super.draw();
    }
}
