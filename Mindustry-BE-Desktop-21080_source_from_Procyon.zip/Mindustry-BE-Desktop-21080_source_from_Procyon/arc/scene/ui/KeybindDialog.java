// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import arc.scene.style.Style;
import arc.util.Time;
import arc.scene.event.EventListener;
import arc.scene.event.InputEvent;
import arc.scene.event.InputListener;
import arc.scene.ui.layout.Cell;
import arc.struct.OrderedMap;
import arc.struct.Seq;
import arc.graphics.Color;
import arc.scene.ui.layout.Table;
import arc.util.Strings;
import arc.input.InputDevice;
import arc.scene.Element;
import arc.scene.ui.layout.Stack;
import arc.Core;
import arc.struct.ObjectIntMap;
import arc.input.KeyCode;
import arc.KeyBinds;

public class KeybindDialog extends Dialog
{
    protected KeybindDialogStyle style;
    protected KeyBinds.Section section;
    protected KeyBinds.KeyBind rebindKey;
    protected boolean rebindAxis;
    protected boolean rebindMin;
    protected KeyCode minKey;
    protected Dialog rebindDialog;
    protected ObjectIntMap<KeyBinds.Section> sectionControls;
    
    public KeybindDialog() {
        super(Core.bundle.get("keybind.title", "Rebind Keys"));
        this.rebindKey = null;
        this.rebindAxis = false;
        this.rebindMin = true;
        this.minKey = null;
        this.sectionControls = new ObjectIntMap<KeyBinds.Section>();
        this.style = Core.scene.getStyle(KeybindDialogStyle.class);
        this.setup();
        this.addCloseButton();
    }
    
    public void setStyle(final KeybindDialogStyle style) {
        this.style = style;
        this.setup();
    }
    
    private void setup() {
        this.cont.clear();
        final KeyBinds.Section[] sections = Core.keybinds.getSections();
        final Stack stack = new Stack();
        final ButtonGroup<TextButton> group = new ButtonGroup<TextButton>();
        final ScrollPane pane = new ScrollPane(stack);
        pane.setFadeScrollBars(false);
        this.section = sections[0];
        for (final KeyBinds.Section section : sections) {
            if (!this.sectionControls.containsKey(section)) {
                this.sectionControls.put(section, Core.input.getDevices().indexOf(section.device, true));
            }
            if (this.sectionControls.get(section, 0) >= Core.input.getDevices().size) {
                this.sectionControls.put(section, 0);
                section.device = Core.input.getDevices().get(0);
            }
            if (sections.length != 1) {
                final TextButton button = new TextButton(Core.bundle.get("section." + section.name + ".name", Strings.capitalize(section.name)));
                if (section.equals(this.section)) {
                    button.toggle();
                }
                button.clicked(() -> this.section = section);
                group.add(button);
                this.cont.add(button).fill();
            }
            final Table table = new Table();
            final Label device = new Label("Keyboard");
            device.setAlignment(1);
            final Seq<InputDevice> devices = Core.input.getDevices();
            final Table stable = new Table();
            final KeyBinds.Section section2;
            final int i;
            final Seq<InputDevice> seq;
            stable.button("<", () -> {
                i = this.sectionControls.get(section2, 0);
                if (i - 1 >= 0) {
                    this.sectionControls.put(section2, i - 1);
                    section2.device = seq.get(i - 1);
                    this.setup();
                }
                return;
            }).disabled(this.sectionControls.get(section, 0) - 1 < 0).size(40.0f);
            stable.add(device).minWidth(device.getMinWidth() + 60.0f);
            device.setText(Core.input.getDevices().get(this.sectionControls.get(section, 0)).name());
            final KeyBinds.Section section3;
            final int j;
            final Seq<InputDevice> seq2;
            stable.button(">", () -> {
                j = this.sectionControls.get(section3, 0);
                if (j + 1 < seq2.size) {
                    this.sectionControls.put(section3, j + 1);
                    section3.device = seq2.get(j + 1);
                    this.setup();
                }
                return;
            }).disabled(this.sectionControls.get(section, 0) + 1 >= devices.size).size(40.0f);
            table.add(stable).colspan(4);
            table.row();
            table.add().height(10.0f);
            table.row();
            if (section.device.type() == InputDevice.DeviceType.controller) {
                table.table(info -> info.add((CharSequence)("Controller Type: [#" + this.style.controllerColor.toString().toUpperCase() + "]" + Strings.capitalize(section.device.name()))).left());
            }
            table.row();
            String lastCategory = null;
            for (final KeyBinds.KeyBind keybind : Core.keybinds.getKeybinds()) {
                if (lastCategory != keybind.category() && keybind.category() != null) {
                    table.add((CharSequence)Core.bundle.get("category." + keybind.category() + ".name", Strings.capitalize(keybind.category()))).color(Color.gray).colspan(4).pad(10.0f).padBottom(4.0f).row();
                    table.image().color(Color.gray).fillX().height(3.0f).pad(6.0f).colspan(4).padTop(0.0f).padBottom(10.0f).row();
                    lastCategory = keybind.category();
                }
                final KeyBinds.Axis axis = Core.keybinds.get(section, keybind);
                if (keybind.defaultValue(section.device.type()) instanceof KeyBinds.Axis) {
                    table.add(Core.bundle.get("keybind." + keybind.name() + ".name", Strings.capitalize(keybind.name())), this.style.keyNameColor).left().padRight(40.0f).padLeft(8.0f);
                    if (axis.key != null) {
                        table.add(axis.key.toString(), this.style.keyColor).left().minWidth(90.0f).padRight(20.0f);
                    }
                    else {
                        final Table axt = new Table();
                        axt.left();
                        axt.labelWrap(axis.min.toString() + " [red]/[] " + axis.max.toString()).color(this.style.keyColor).width(140.0f).padRight(5.0f);
                        table.add(axt).left().minWidth(90.0f).padRight(20.0f);
                    }
                    final KeyBinds.Section section4;
                    final KeyBinds.KeyBind name;
                    table.button(Core.bundle.get("settings.rebind", "Rebind"), () -> {
                        this.rebindAxis = true;
                        this.rebindMin = true;
                        this.openDialog(section4, name);
                        return;
                    }).width(130.0f);
                }
                else {
                    table.add(Core.bundle.get("keybind." + keybind.name() + ".name", Strings.capitalize(keybind.name())), this.style.keyNameColor).left().padRight(40.0f).padLeft(8.0f);
                    table.add(Core.keybinds.get(section, keybind).key.toString(), this.style.keyColor).left().minWidth(90.0f).padRight(20.0f);
                    final KeyBinds.Section section5;
                    final KeyBinds.KeyBind name2;
                    table.button(Core.bundle.get("settings.rebind", "Rebind"), () -> {
                        this.rebindAxis = false;
                        this.rebindMin = false;
                        this.openDialog(section5, name2);
                        return;
                    }).width(130.0f);
                }
                table.button(Core.bundle.get("settings.resetKey", "Reset"), () -> {
                    Core.keybinds.resetToDefault(section, keybind);
                    this.setup();
                    return;
                }).width(130.0f);
                table.row();
            }
            table.visible(() -> this.section.equals(section));
            table.button(Core.bundle.get("settings.reset", "Reset to Defaults"), () -> {
                Core.keybinds.resetToDefaults();
                this.setup();
                return;
            }).colspan(4).padTop(4.0f).fill();
            stack.add(table);
        }
        this.cont.row();
        this.cont.add(pane).growX().colspan(sections.length);
    }
    
    void rebind(final KeyBinds.Section section, final KeyBinds.KeyBind bind, final KeyCode newKey) {
        if (this.rebindKey == null) {
            return;
        }
        this.rebindDialog.hide();
        final boolean isAxis = bind.defaultValue(section.device.type()) instanceof KeyBinds.Axis;
        if (isAxis) {
            if (newKey.axis || !this.rebindMin) {
                section.binds.get(section.device.type(), OrderedMap::new).put(this.rebindKey, newKey.axis ? new KeyBinds.Axis(newKey) : new KeyBinds.Axis(this.minKey, newKey));
            }
        }
        else {
            section.binds.get(section.device.type(), OrderedMap::new).put(this.rebindKey, new KeyBinds.Axis(newKey));
        }
        if (this.rebindAxis && isAxis && this.rebindMin && !newKey.axis) {
            this.rebindMin = false;
            this.minKey = newKey;
            this.openDialog(section, this.rebindKey);
        }
        else {
            this.rebindKey = null;
            this.rebindAxis = false;
            this.setup();
        }
    }
    
    private void openDialog(final KeyBinds.Section section, final KeyBinds.KeyBind name) {
        this.rebindDialog = new Dialog(this.rebindAxis ? Core.bundle.get("keybind.press.axis", "Press an axis or key...") : Core.bundle.get("keybind.press", "Press a key..."));
        this.rebindKey = name;
        this.rebindDialog.titleTable.getCells().first().pad(4.0f);
        if (section.device.type() == InputDevice.DeviceType.keyboard) {
            this.rebindDialog.keyDown(i -> this.setup());
            this.rebindDialog.addListener(new InputListener() {
                @Override
                public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                    if (Core.app.isAndroid()) {
                        return false;
                    }
                    KeybindDialog.this.rebind(section, name, button);
                    return false;
                }
                
                @Override
                public boolean keyDown(final InputEvent event, final KeyCode keycode) {
                    KeybindDialog.this.rebindDialog.hide();
                    if (keycode == KeyCode.escape) {
                        return false;
                    }
                    KeybindDialog.this.rebind(section, name, keycode);
                    return false;
                }
                
                @Override
                public boolean scrolled(final InputEvent event, final float x, final float y, final float amountX, final float amountY) {
                    if (!KeybindDialog.this.rebindAxis) {
                        return false;
                    }
                    KeybindDialog.this.rebindDialog.hide();
                    KeybindDialog.this.rebind(section, name, KeyCode.scroll);
                    return false;
                }
            });
        }
        this.rebindDialog.show();
        Time.runTask(1.0f, () -> this.getScene().setScrollFocus(this.rebindDialog));
    }
    
    public static class KeybindDialogStyle extends Style
    {
        public Color keyColor;
        public Color keyNameColor;
        public Color controllerColor;
        
        public KeybindDialogStyle() {
            this.keyColor = Color.white;
            this.keyNameColor = Color.white;
            this.controllerColor = Color.white;
        }
    }
}
