// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import arc.scene.style.TransformDrawable;
import arc.graphics.g2d.Draw;
import arc.math.geom.Vec2;
import arc.graphics.Texture;
import arc.scene.style.TextureRegionDrawable;
import arc.scene.style.NinePatchDrawable;
import arc.graphics.g2d.NinePatch;
import arc.graphics.Color;
import arc.graphics.g2d.TextureRegion;
import arc.Core;
import arc.scene.style.Drawable;
import arc.util.Scaling;
import arc.scene.Element;

public class Image extends Element
{
    protected float imageX;
    protected float imageY;
    protected float imageWidth;
    protected float imageHeight;
    private Scaling scaling;
    private int align;
    private Drawable drawable;
    
    public Image() {
        this(Core.atlas.has("whiteui") ? Core.atlas.find("whiteui") : Core.atlas.find("white"));
    }
    
    public Image(final Drawable name, final Color color) {
        this(name);
        this.setColor(color);
    }
    
    public Image(final NinePatch patch) {
        this(new NinePatchDrawable(patch), Scaling.stretch, 1);
    }
    
    public Image(final TextureRegion region) {
        this(new TextureRegionDrawable(region), Scaling.stretch, 1);
    }
    
    public Image(final Texture texture) {
        this(new TextureRegionDrawable(new TextureRegion(texture)));
    }
    
    public Image(final Drawable drawable) {
        this(drawable, Scaling.stretch, 1);
    }
    
    public Image(final Drawable drawable, final Scaling scaling) {
        this(drawable, scaling, 1);
    }
    
    public Image(final Drawable drawable, final Scaling scaling, final int align) {
        this.setDrawable(drawable);
        this.scaling = scaling;
        this.align = align;
        this.setSize(this.getPrefWidth(), this.getPrefHeight());
    }
    
    @Override
    public void layout() {
        if (this.drawable == null) {
            return;
        }
        final float regionWidth = this.drawable.getMinWidth();
        final float regionHeight = this.drawable.getMinHeight();
        final float width = this.getWidth();
        final float height = this.getHeight();
        final Vec2 size = this.scaling.apply(regionWidth, regionHeight, width, height);
        this.imageWidth = size.x;
        this.imageHeight = size.y;
        if ((this.align & 0x8) != 0x0) {
            this.imageX = 0.0f;
        }
        else if ((this.align & 0x10) != 0x0) {
            this.imageX = (float)(int)(width - this.imageWidth);
        }
        else {
            this.imageX = (float)(int)(width / 2.0f - this.imageWidth / 2.0f);
        }
        if ((this.align & 0x2) != 0x0) {
            this.imageY = (float)(int)(height - this.imageHeight);
        }
        else if ((this.align & 0x4) != 0x0) {
            this.imageY = 0.0f;
        }
        else {
            this.imageY = (float)(int)(height / 2.0f - this.imageHeight / 2.0f);
        }
    }
    
    @Override
    public void draw() {
        this.validate();
        final float x = this.x;
        final float y = this.y;
        final float scaleX = this.scaleX;
        final float scaleY = this.scaleY;
        Draw.color(this.color);
        Draw.alpha(this.parentAlpha * this.color.a);
        if (this.drawable instanceof TransformDrawable) {
            final float rotation = this.getRotation();
            if (scaleX != 1.0f || scaleY != 1.0f || rotation != 0.0f) {
                this.drawable.draw(x + this.imageX, y + this.imageY, this.originX - this.imageX, this.originY - this.imageY, this.imageWidth, this.imageHeight, scaleX, scaleY, rotation);
                return;
            }
        }
        if (this.drawable != null) {
            this.drawable.draw(x + this.imageX, y + this.imageY, this.imageWidth * scaleX, this.imageHeight * scaleY);
        }
    }
    
    public TextureRegion getRegion() {
        return ((TextureRegionDrawable)this.drawable).getRegion();
    }
    
    public Drawable getDrawable() {
        return this.drawable;
    }
    
    public void setDrawable(final TextureRegion region) {
        this.setDrawable(new TextureRegionDrawable(region));
    }
    
    public void setDrawable(final Drawable drawable) {
        if (this.drawable == drawable) {
            return;
        }
        if (drawable != null) {
            if (this.getPrefWidth() != drawable.getMinWidth() || this.getPrefHeight() != drawable.getMinHeight()) {
                this.invalidateHierarchy();
            }
        }
        else {
            this.invalidateHierarchy();
        }
        this.drawable = drawable;
    }
    
    public Image setScaling(final Scaling scaling) {
        if (scaling == null) {
            throw new IllegalArgumentException("scaling cannot be null.");
        }
        this.scaling = scaling;
        this.invalidate();
        return this;
    }
    
    public void setAlign(final int align) {
        this.align = align;
        this.invalidate();
    }
    
    @Override
    public float getMinWidth() {
        return 0.0f;
    }
    
    @Override
    public float getMinHeight() {
        return 0.0f;
    }
    
    @Override
    public float getPrefWidth() {
        if (this.drawable != null) {
            return this.drawable.getMinWidth();
        }
        return 0.0f;
    }
    
    @Override
    public float getPrefHeight() {
        if (this.drawable != null) {
            return this.drawable.getMinHeight();
        }
        return 0.0f;
    }
    
    public float getImageX() {
        return this.imageX;
    }
    
    public float getImageY() {
        return this.imageY;
    }
    
    public float getImageWidth() {
        return this.imageWidth;
    }
    
    public float getImageHeight() {
        return this.imageHeight;
    }
}
