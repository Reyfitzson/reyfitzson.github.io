// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.ui;

import arc.func.Floatc;
import arc.scene.style.Drawable;
import arc.scene.Element;
import arc.scene.event.SceneEvent;
import arc.util.pooling.Pools;
import arc.scene.event.ChangeListener;
import arc.input.KeyCode;
import arc.scene.event.InputEvent;
import arc.scene.event.InputListener;
import arc.scene.event.EventListener;
import arc.scene.event.HandCursorListener;
import arc.Core;
import arc.math.Interp;

public class Slider extends ProgressBar
{
    int draggingPointer;
    boolean mouseOver;
    private Interp visualInterpolationInverse;
    private float[] snapValues;
    private float threshold;
    
    public Slider(final float min, final float max, final float stepSize, final boolean vertical) {
        this(min, max, stepSize, vertical, Core.scene.getStyle(SliderStyle.class));
    }
    
    public Slider(final float min, final float max, final float stepSize, final boolean vertical, final SliderStyle style) {
        super(min, max, stepSize, vertical, style);
        this.draggingPointer = -1;
        this.visualInterpolationInverse = Interp.linear;
        this.addListener(new HandCursorListener());
        this.addListener(new InputListener() {
            @Override
            public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                if (Slider.this.disabled) {
                    return false;
                }
                if (Slider.this.draggingPointer != -1) {
                    return false;
                }
                Slider.this.draggingPointer = pointer;
                Slider.this.calculatePositionAndValue(x, y);
                return true;
            }
            
            @Override
            public void touchUp(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                if (pointer != Slider.this.draggingPointer) {
                    return;
                }
                Slider.this.draggingPointer = -1;
                if (!Slider.this.calculatePositionAndValue(x, y)) {
                    final ChangeListener.ChangeEvent changeEvent = Pools.obtain(ChangeListener.ChangeEvent.class, ChangeListener.ChangeEvent::new);
                    Slider.this.fire(changeEvent);
                    Pools.free(changeEvent);
                }
            }
            
            @Override
            public void touchDragged(final InputEvent event, final float x, final float y, final int pointer) {
                Slider.this.calculatePositionAndValue(x, y);
            }
            
            @Override
            public void enter(final InputEvent event, final float x, final float y, final int pointer, final Element fromActor) {
                if (pointer == -1) {
                    Slider.this.mouseOver = true;
                }
            }
            
            @Override
            public void exit(final InputEvent event, final float x, final float y, final int pointer, final Element toActor) {
                if (pointer == -1) {
                    Slider.this.mouseOver = false;
                }
            }
        });
    }
    
    @Override
    public SliderStyle getStyle() {
        return (SliderStyle)super.getStyle();
    }
    
    public void setStyle(final SliderStyle style) {
        if (style == null) {
            throw new NullPointerException("style cannot be null");
        }
        if (!(style instanceof SliderStyle)) {
            throw new IllegalArgumentException("style must be a SliderStyle.");
        }
        super.setStyle(style);
    }
    
    @Override
    protected Drawable getKnobDrawable() {
        final SliderStyle style = this.getStyle();
        return (this.disabled && style.disabledKnob != null) ? style.disabledKnob : ((this.isDragging() && style.knobDown != null) ? style.knobDown : ((this.mouseOver && style.knobOver != null) ? style.knobOver : style.knob));
    }
    
    boolean calculatePositionAndValue(final float x, final float y) {
        final SliderStyle style = this.getStyle();
        final Drawable knob = this.getKnobDrawable();
        final Drawable bg = (this.disabled && style.disabledBackground != null) ? style.disabledBackground : style.background;
        final float oldPosition = this.position;
        final float min = this.getMinValue();
        final float max = this.getMaxValue();
        float value;
        if (this.vertical) {
            final float height = this.getHeight() - bg.getTopHeight() - bg.getBottomHeight();
            final float knobHeight = (knob == null) ? 0.0f : knob.getMinHeight();
            this.position = y - bg.getBottomHeight() - knobHeight * 0.5f;
            value = min + (max - min) * this.visualInterpolationInverse.apply(this.position / (height - knobHeight));
            this.position = Math.max(0.0f, this.position);
            this.position = Math.min(height - knobHeight, this.position);
        }
        else {
            final float width = this.getWidth() - bg.getLeftWidth() - bg.getRightWidth();
            final float knobWidth = (knob == null) ? 0.0f : knob.getMinWidth();
            this.position = x - bg.getLeftWidth() - knobWidth * 0.5f;
            value = min + (max - min) * this.visualInterpolationInverse.apply(this.position / (width - knobWidth));
            this.position = Math.max(0.0f, this.position);
            this.position = Math.min(width - knobWidth, this.position);
        }
        final float oldValue = value;
        if (!Core.input.keyDown(KeyCode.shiftLeft) && !Core.input.keyDown(KeyCode.shiftRight)) {
            value = this.snap(value);
        }
        final boolean valueSet = this.setValue(value);
        if (value == oldValue) {
            this.position = oldPosition;
        }
        return valueSet;
    }
    
    public void moved(final Floatc listener) {
        this.changed(() -> listener.get(this.getValue()));
    }
    
    protected float snap(final float value) {
        if (this.snapValues == null) {
            return value;
        }
        for (int i = 0; i < this.snapValues.length; ++i) {
            if (Math.abs(value - this.snapValues[i]) <= this.threshold) {
                return this.snapValues[i];
            }
        }
        return value;
    }
    
    public void setSnapToValues(final float[] values, final float threshold) {
        this.snapValues = values;
        this.threshold = threshold;
    }
    
    public boolean isDragging() {
        return this.draggingPointer != -1;
    }
    
    public void setVisualInterpolationInverse(final Interp interpolation) {
        this.visualInterpolationInverse = interpolation;
    }
    
    public static class SliderStyle extends ProgressBarStyle
    {
        public Drawable knobOver;
        public Drawable knobDown;
    }
}
