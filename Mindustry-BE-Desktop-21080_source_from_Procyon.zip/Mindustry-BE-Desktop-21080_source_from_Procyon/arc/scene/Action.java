// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene;

import arc.util.pooling.Pool;

public abstract class Action implements Pool.Poolable
{
    protected Element actor;
    protected Element target;
    private Pool<Action> pool;
    
    public abstract boolean act(final float p0);
    
    public void restart() {
    }
    
    public Element getActor() {
        return this.actor;
    }
    
    public void setActor(final Element actor) {
        this.actor = actor;
        if (this.target == null) {
            this.setTarget(actor);
        }
        if (actor == null && this.pool != null) {
            this.pool.free(this);
            this.pool = null;
        }
    }
    
    public Element getTarget() {
        return this.target;
    }
    
    public void setTarget(final Element target) {
        this.target = target;
    }
    
    @Override
    public void reset() {
        this.actor = null;
        this.target = null;
        this.pool = null;
        this.restart();
    }
    
    public Pool<Action> getPool() {
        return this.pool;
    }
    
    public void setPool(final Pool pool) {
        this.pool = (Pool<Action>)pool;
    }
    
    @Override
    public String toString() {
        String name = super.toString().split("@")[0];
        final int dotIndex = name.lastIndexOf(46);
        if (dotIndex != -1) {
            name = name.substring(dotIndex + 1);
        }
        if (name.endsWith("Action")) {
            name = name.substring(0, name.length() - 6);
        }
        return name;
    }
}
