// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene;

import arc.scene.event.ChangeListener;
import arc.scene.utils.Disableable;
import java.util.Iterator;
import arc.scene.event.ClickListener;
import arc.func.Cons;
import arc.graphics.Camera;
import arc.graphics.g2d.ScissorStack;
import arc.math.geom.Rect;
import arc.func.Boolf;
import arc.scene.actions.Actions;
import arc.func.Floatc;
import arc.input.KeyCode;
import arc.scene.event.InputListener;
import arc.func.Floatc2;
import arc.scene.event.InputEvent;
import arc.util.pooling.Pools;
import arc.scene.event.SceneEvent;
import arc.Core;
import arc.struct.Seq;
import arc.scene.event.EventListener;
import arc.struct.DelayedRemovalSeq;
import arc.func.Prov;
import arc.func.Boolp;
import arc.scene.event.Touchable;
import arc.math.geom.Vec2;
import arc.graphics.Color;

public class Element
{
    public final Color color;
    public float originX;
    public float originY;
    public float scaleX;
    public float scaleY;
    public float rotation;
    public String name;
    public boolean fillParent;
    public Vec2 translation;
    public boolean visible;
    public Object userObject;
    public Touchable touchable;
    public Group parent;
    public Boolp visibility;
    public Prov<Touchable> touchablility;
    public boolean cullable;
    private final DelayedRemovalSeq<EventListener> listeners;
    private final DelayedRemovalSeq<EventListener> captureListeners;
    private final Seq<Action> actions;
    public float x;
    public float y;
    protected float width;
    protected float height;
    protected float parentAlpha;
    private Scene stage;
    private boolean needsLayout;
    private boolean layoutEnabled;
    private Runnable update;
    
    public Element() {
        this.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        this.scaleX = 1.0f;
        this.scaleY = 1.0f;
        this.translation = new Vec2(0.0f, 0.0f);
        this.visible = true;
        this.touchable = Touchable.enabled;
        this.cullable = true;
        this.listeners = new DelayedRemovalSeq<EventListener>(0);
        this.captureListeners = new DelayedRemovalSeq<EventListener>(0);
        this.actions = new Seq<Action>(0);
        this.parentAlpha = 1.0f;
        this.needsLayout = true;
        this.layoutEnabled = true;
    }
    
    public void draw() {
        this.validate();
    }
    
    public void act(final float delta) {
        final Seq<Action> actions = this.actions;
        if (actions.size > 0) {
            if (this.stage != null && this.stage.getActionsRequestRendering()) {
                Core.graphics.requestRendering();
            }
            for (int i = 0; i < actions.size; ++i) {
                final Action action = actions.get(i);
                if (action.act(delta) && i < actions.size) {
                    final Action current = actions.get(i);
                    final int actionIndex = (current == action) ? i : actions.indexOf(action, true);
                    if (actionIndex != -1) {
                        actions.remove(actionIndex);
                        action.setActor(null);
                        --i;
                    }
                }
            }
        }
        if (this.touchablility != null) {
            this.touchable = this.touchablility.get();
        }
        if (this.update != null) {
            this.update.run();
        }
    }
    
    public void updateVisibility() {
        if (this.visibility != null) {
            this.visible = this.visibility.get();
        }
    }
    
    public boolean hasMouse() {
        final Element e = Core.scene.hit((float)Core.input.mouseX(), (float)Core.input.mouseY(), true);
        return e == this || (e != null && e.isDescendantOf(this));
    }
    
    public boolean hasKeyboard() {
        return Core.scene.getKeyboardFocus() == this;
    }
    
    public boolean hasScroll() {
        return Core.scene.getScrollFocus() == this;
    }
    
    public void requestKeyboard() {
        Core.scene.setKeyboardFocus(this);
    }
    
    public void requestScroll() {
        Core.scene.setScrollFocus(this);
    }
    
    public boolean fire(final SceneEvent event) {
        event.targetActor = this;
        final Seq<Group> ancestors = Pools.obtain((Class<Seq<Group>>)Seq.class, Seq::new);
        for (Group parent = this.parent; parent != null; parent = parent.parent) {
            ancestors.add(parent);
        }
        try {
            final Object[] ancestorsArray = ancestors.items;
            for (int i = ancestors.size - 1; i >= 0; --i) {
                final Group currentTarget = (Group)ancestorsArray[i];
                currentTarget.notify(event, true);
                if (event.stopped) {
                    return event.cancelled;
                }
            }
            this.notify(event, true);
            if (event.stopped) {
                return event.cancelled;
            }
            this.notify(event, false);
            if (!event.bubbles) {
                return event.cancelled;
            }
            if (event.stopped) {
                return event.cancelled;
            }
            for (int i = 0, n = ancestors.size; i < n; ++i) {
                ((Group)ancestorsArray[i]).notify(event, false);
                if (event.stopped) {
                    return event.cancelled;
                }
            }
            return event.cancelled;
        }
        finally {
            ancestors.clear();
            Pools.free(ancestors);
        }
    }
    
    public boolean notify(final SceneEvent event, final boolean capture) {
        if (event.targetActor == null) {
            throw new IllegalArgumentException("The event target cannot be null.");
        }
        final DelayedRemovalSeq<EventListener> listeners = capture ? this.captureListeners : this.listeners;
        if (listeners.size == 0) {
            return event.cancelled;
        }
        event.listenerActor = this;
        event.capture = capture;
        listeners.begin();
        for (int i = 0, n = listeners.size; i < n; ++i) {
            final EventListener listener = listeners.get(i);
            if (listener.handle(event)) {
                event.handle();
                if (event instanceof InputEvent) {
                    final InputEvent inputEvent = (InputEvent)event;
                    if (inputEvent.type == InputEvent.InputEventType.touchDown) {
                        this.getScene().addTouchFocus(listener, this, inputEvent.targetActor, inputEvent.pointer, inputEvent.keyCode);
                    }
                }
            }
        }
        listeners.end();
        return event.cancelled;
    }
    
    public Element hit(final float x, final float y, final boolean touchable) {
        if (touchable && this.touchable != Touchable.enabled) {
            return null;
        }
        final Element e = this;
        return (x >= e.translation.x && x < this.width + e.translation.x && y >= e.translation.y && y < this.height + e.translation.y) ? this : null;
    }
    
    public boolean remove() {
        return this.parent != null && this.parent.removeChild(this, true);
    }
    
    public void dragged(final Floatc2 cons) {
        this.addListener(new InputListener() {
            float lastX;
            float lastY;
            
            @Override
            public void touchDragged(final InputEvent event, final float mx, final float my, final int pointer) {
                if (Core.app.isMobile() && pointer != 0) {
                    return;
                }
                cons.get(mx - this.lastX, my - this.lastY);
                this.lastX = mx;
                this.lastY = my;
            }
            
            @Override
            public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                if (Core.app.isMobile() && pointer != 0) {
                    return false;
                }
                this.lastX = x;
                this.lastY = y;
                return true;
            }
        });
    }
    
    public void scrolled(final Floatc cons) {
        this.addListener(new InputListener() {
            @Override
            public boolean scrolled(final InputEvent event, final float x, final float y, final float amountX, final float amountY) {
                cons.get(amountY);
                return true;
            }
        });
    }
    
    public boolean addListener(final EventListener listener) {
        if (listener == null) {
            throw new IllegalArgumentException("listener cannot be null.");
        }
        if (!this.listeners.contains(listener, true)) {
            this.listeners.add(listener);
            return true;
        }
        return false;
    }
    
    public boolean removeListener(final EventListener listener) {
        if (listener == null) {
            throw new IllegalArgumentException("listener cannot be null.");
        }
        return this.listeners.remove(listener, true);
    }
    
    public Seq<EventListener> getListeners() {
        return this.listeners;
    }
    
    public boolean addCaptureListener(final EventListener listener) {
        if (listener == null) {
            throw new IllegalArgumentException("listener cannot be null.");
        }
        if (!this.captureListeners.contains(listener, true)) {
            this.captureListeners.add(listener);
        }
        return true;
    }
    
    public boolean removeCaptureListener(final EventListener listener) {
        if (listener == null) {
            throw new IllegalArgumentException("listener cannot be null.");
        }
        return this.captureListeners.remove(listener, true);
    }
    
    public Seq<EventListener> getCaptureListeners() {
        return this.captureListeners;
    }
    
    public void addAction(final Action action) {
        action.setActor(this);
        this.actions.add(action);
        if (this.stage != null && this.stage.getActionsRequestRendering()) {
            Core.graphics.requestRendering();
        }
    }
    
    public void actions(final Action... actions) {
        this.addAction(Actions.sequence(actions));
    }
    
    public void removeAction(final Action action) {
        if (this.actions.remove(action, true)) {
            action.setActor(null);
        }
    }
    
    public Seq<Action> getActions() {
        return this.actions;
    }
    
    public boolean hasActions() {
        return this.actions.size > 0;
    }
    
    public void clearActions() {
        for (int i = this.actions.size - 1; i >= 0; --i) {
            this.actions.get(i).setActor(null);
        }
        this.actions.clear();
    }
    
    public void clearListeners() {
        this.listeners.clear();
        this.captureListeners.clear();
    }
    
    public void clear() {
        this.clearActions();
        this.clearListeners();
    }
    
    public Scene getScene() {
        return this.stage;
    }
    
    protected void setScene(final Scene stage) {
        this.stage = stage;
    }
    
    public boolean isDescendantOf(final Boolf<Element> actor) {
        for (Element parent = this; parent != null; parent = parent.parent) {
            if (actor.get(parent)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean isDescendantOf(final Element actor) {
        if (actor == null) {
            throw new IllegalArgumentException("actor cannot be null.");
        }
        for (Element parent = this; parent != null; parent = parent.parent) {
            if (parent == actor) {
                return true;
            }
        }
        return false;
    }
    
    public boolean isAscendantOf(Element actor) {
        if (actor == null) {
            throw new IllegalArgumentException("actor cannot be null.");
        }
        while (actor != null) {
            if (actor == this) {
                return true;
            }
            actor = actor.parent;
        }
        return false;
    }
    
    public boolean hasParent() {
        return this.parent != null;
    }
    
    public boolean isTouchable() {
        return this.touchable == Touchable.enabled;
    }
    
    public float getX(final int alignment) {
        float x = this.x;
        if ((alignment & 0x10) != 0x0) {
            x += this.width;
        }
        else if ((alignment & 0x8) == 0x0) {
            x += this.width / 2.0f;
        }
        return x;
    }
    
    public float getY(final int alignment) {
        float y = this.y;
        if ((alignment & 0x2) != 0x0) {
            y += this.height;
        }
        else if ((alignment & 0x4) == 0x0) {
            y += this.height / 2.0f;
        }
        return y;
    }
    
    public void setPosition(final float x, final float y) {
        if (this.x != x || this.y != y) {
            this.x = x;
            this.y = y;
        }
    }
    
    public void setPosition(float x, float y, final int alignment) {
        if ((alignment & 0x10) != 0x0) {
            x -= this.width;
        }
        else if ((alignment & 0x8) == 0x0) {
            x -= this.width / 2.0f;
        }
        if ((alignment & 0x2) != 0x0) {
            y -= this.height;
        }
        else if ((alignment & 0x4) == 0x0) {
            y -= this.height / 2.0f;
        }
        if (this.x != x || this.y != y) {
            this.x = x;
            this.y = y;
        }
    }
    
    public void moveBy(final float x, final float y) {
        if (x != 0.0f || y != 0.0f) {
            this.x += x;
            this.y += y;
        }
    }
    
    public float getWidth() {
        return this.width;
    }
    
    public void setWidth(final float width) {
        if (this.width != width) {
            this.width = width;
            this.sizeChanged();
        }
    }
    
    public float getHeight() {
        return this.height;
    }
    
    public void setHeight(final float height) {
        if (this.height != height) {
            this.height = height;
            this.sizeChanged();
        }
    }
    
    public float getTop() {
        return this.y + this.height;
    }
    
    public float getRight() {
        return this.x + this.width;
    }
    
    protected void sizeChanged() {
        this.invalidate();
    }
    
    protected void rotationChanged() {
    }
    
    public void setSize(final float size) {
        this.setSize(size, size);
    }
    
    public void setSize(final float width, final float height) {
        if (this.width != width || this.height != height) {
            this.width = width;
            this.height = height;
            this.sizeChanged();
        }
    }
    
    public void sizeBy(final float size) {
        if (size != 0.0f) {
            this.width += size;
            this.height += size;
            this.sizeChanged();
        }
    }
    
    public void sizeBy(final float width, final float height) {
        if (width != 0.0f || height != 0.0f) {
            this.width += width;
            this.height += height;
            this.sizeChanged();
        }
    }
    
    public void setBounds(final float x, final float y, final float width, final float height) {
        if (this.x != x || this.y != y) {
            this.x = x;
            this.y = y;
        }
        if (this.width != width || this.height != height) {
            this.width = width;
            this.height = height;
            this.sizeChanged();
        }
    }
    
    public void setOrigin(final float originX, final float originY) {
        this.originX = originX;
        this.originY = originY;
    }
    
    public void setOrigin(final int alignment) {
        if ((alignment & 0x8) != 0x0) {
            this.originX = 0.0f;
        }
        else if ((alignment & 0x10) != 0x0) {
            this.originX = this.width;
        }
        else {
            this.originX = this.width / 2.0f;
        }
        if ((alignment & 0x4) != 0x0) {
            this.originY = 0.0f;
        }
        else if ((alignment & 0x2) != 0x0) {
            this.originY = this.height;
        }
        else {
            this.originY = this.height / 2.0f;
        }
    }
    
    public void setScale(final float scaleXY) {
        this.scaleX = scaleXY;
        this.scaleY = scaleXY;
    }
    
    public void setScale(final float scaleX, final float scaleY) {
        this.scaleX = scaleX;
        this.scaleY = scaleY;
    }
    
    public void scaleBy(final float scale) {
        this.scaleX += scale;
        this.scaleY += scale;
    }
    
    public void scaleBy(final float scaleX, final float scaleY) {
        this.scaleX += scaleX;
        this.scaleY += scaleY;
    }
    
    public float getRotation() {
        return this.rotation;
    }
    
    public void setRotation(final float degrees) {
        if (this.rotation != degrees) {
            this.rotation = degrees;
            this.rotationChanged();
        }
    }
    
    public void setRotationOrigin(final float degrees, final int align) {
        this.setOrigin(align);
        if (this.rotation != degrees) {
            this.rotation = degrees;
            this.rotationChanged();
        }
    }
    
    public void rotateBy(final float amountInDegrees) {
        if (amountInDegrees != 0.0f) {
            this.rotation += amountInDegrees;
            this.rotationChanged();
        }
    }
    
    public void setColor(final float r, final float g, final float b, final float a) {
        this.color.set(r, g, b, a);
    }
    
    public void setColor(final Color color) {
        this.color.set(color);
    }
    
    public void toFront() {
        this.setZIndex(Integer.MAX_VALUE);
    }
    
    public void toBack() {
        this.setZIndex(0);
    }
    
    public int getZIndex() {
        final Group parent = this.parent;
        if (parent == null) {
            return -1;
        }
        return parent.children.indexOf(this, true);
    }
    
    public void setZIndex(int index) {
        if (index < 0) {
            throw new IllegalArgumentException("ZIndex cannot be < 0.");
        }
        final Group parent = this.parent;
        if (parent == null) {
            return;
        }
        final Seq<Element> children = parent.children;
        if (children.size == 1) {
            return;
        }
        index = Math.min(index, children.size - 1);
        if (children.get(index) == this) {
            return;
        }
        if (!children.remove(this, true)) {
            return;
        }
        children.insert(index, this);
    }
    
    public boolean clipBegin() {
        return this.clipBegin(this.x, this.y, this.width, this.height);
    }
    
    public boolean clipBegin(final float x, final float y, final float width, final float height) {
        if (width <= 0.0f || height <= 0.0f) {
            return false;
        }
        final Rect tableBounds = Rect.tmp;
        tableBounds.x = x;
        tableBounds.y = y;
        tableBounds.width = width;
        tableBounds.height = height;
        final Scene stage = this.stage;
        final Rect scissorBounds = Pools.obtain(Rect.class, Rect::new);
        stage.calculateScissors(tableBounds, scissorBounds);
        if (ScissorStack.push(scissorBounds)) {
            return true;
        }
        Pools.free(scissorBounds);
        return false;
    }
    
    public void clipEnd() {
        Pools.free(ScissorStack.pop());
    }
    
    public Vec2 screenToLocalCoordinates(final Vec2 screenCoords) {
        final Scene stage = this.stage;
        if (stage == null) {
            return screenCoords;
        }
        return this.stageToLocalCoordinates(stage.screenToStageCoordinates(screenCoords));
    }
    
    public Vec2 stageToLocalCoordinates(final Vec2 stageCoords) {
        if (this.parent != null) {
            this.parent.stageToLocalCoordinates(stageCoords);
        }
        this.parentToLocalCoordinates(stageCoords);
        return stageCoords;
    }
    
    public Vec2 localToStageCoordinates(final Vec2 localCoords) {
        return this.localToAscendantCoordinates(null, localCoords);
    }
    
    public Vec2 localToParentCoordinates(final Vec2 localCoords) {
        final float rotation = -this.rotation;
        final float scaleX = this.scaleX;
        final float scaleY = this.scaleY;
        final float x = this.x + this.translation.x;
        final float y = this.y + this.translation.y;
        if (rotation == 0.0f) {
            if (scaleX == 1.0f && scaleY == 1.0f) {
                localCoords.x += x;
                localCoords.y += y;
            }
            else {
                final float originX = this.originX;
                final float originY = this.originY;
                localCoords.x = (localCoords.x - originX) * scaleX + originX + x;
                localCoords.y = (localCoords.y - originY) * scaleY + originY + y;
            }
        }
        else {
            final float cos = (float)Math.cos(rotation * 0.017453292f);
            final float sin = (float)Math.sin(rotation * 0.017453292f);
            final float originX2 = this.originX;
            final float originY2 = this.originY;
            final float tox = (localCoords.x - originX2) * scaleX;
            final float toy = (localCoords.y - originY2) * scaleY;
            localCoords.x = tox * cos + toy * sin + originX2 + x;
            localCoords.y = tox * -sin + toy * cos + originY2 + y;
        }
        return localCoords;
    }
    
    public Vec2 localToAscendantCoordinates(final Element ascendant, final Vec2 localCoords) {
        Element actor = this;
        while (actor != null) {
            actor.localToParentCoordinates(localCoords);
            actor = actor.parent;
            if (actor == ascendant) {
                break;
            }
        }
        return localCoords;
    }
    
    public Vec2 parentToLocalCoordinates(final Vec2 parentCoords) {
        final float rotation = this.rotation;
        final float scaleX = this.scaleX;
        final float scaleY = this.scaleY;
        final float childX = this.x + this.translation.x;
        final float childY = this.y + this.translation.y;
        if (rotation == 0.0f) {
            if (scaleX == 1.0f && scaleY == 1.0f) {
                parentCoords.x -= childX;
                parentCoords.y -= childY;
            }
            else {
                final float originX = this.originX;
                final float originY = this.originY;
                parentCoords.x = (parentCoords.x - childX - originX) / scaleX + originX;
                parentCoords.y = (parentCoords.y - childY - originY) / scaleY + originY;
            }
        }
        else {
            final float cos = (float)Math.cos(rotation * 0.017453292f);
            final float sin = (float)Math.sin(rotation * 0.017453292f);
            final float originX2 = this.originX;
            final float originY2 = this.originY;
            final float tox = parentCoords.x - childX - originX2;
            final float toy = parentCoords.y - childY - originY2;
            parentCoords.x = (tox * cos + toy * sin) / scaleX + originX2;
            parentCoords.y = (tox * -sin + toy * cos) / scaleY + originY2;
        }
        return parentCoords;
    }
    
    public float getMinWidth() {
        return this.getPrefWidth();
    }
    
    public float getMinHeight() {
        return this.getPrefHeight();
    }
    
    public float getPrefWidth() {
        return 0.0f;
    }
    
    public float getPrefHeight() {
        return 0.0f;
    }
    
    public float getMaxWidth() {
        return 0.0f;
    }
    
    public float getMaxHeight() {
        return 0.0f;
    }
    
    public void setLayoutEnabled(final boolean enabled) {
        this.layoutEnabled = enabled;
        if (enabled) {
            this.invalidateHierarchy();
        }
    }
    
    public void validate() {
        if (!this.layoutEnabled) {
            return;
        }
        final Group parent = this.parent;
        if (this.fillParent && parent != null) {
            this.setSize(parent.getWidth(), parent.getHeight());
        }
        if (!this.needsLayout) {
            return;
        }
        this.needsLayout = false;
        this.layout();
    }
    
    public boolean needsLayout() {
        return this.needsLayout;
    }
    
    public void invalidate() {
        this.needsLayout = true;
    }
    
    public void invalidateHierarchy() {
        if (!this.layoutEnabled) {
            return;
        }
        this.invalidate();
        final Group parent = this.parent;
        if (parent != null) {
            parent.invalidateHierarchy();
        }
    }
    
    public void pack() {
        this.setSize(this.getPrefWidth(), this.getPrefHeight());
        this.validate();
    }
    
    public void setFillParent(final boolean fillParent) {
        this.fillParent = fillParent;
    }
    
    public void layout() {
    }
    
    public void keepInStage() {
        if (this.stage == null) {
            return;
        }
        final Camera camera = this.stage.getCamera();
        final float parentWidth = this.stage.getWidth();
        final float parentHeight = this.stage.getHeight();
        if (this.getX(16) - camera.position.x > parentWidth / 2.0f) {
            this.setPosition(camera.position.x + parentWidth / 2.0f, this.getY(16), 16);
        }
        if (this.getX(8) - camera.position.x < -parentWidth / 2.0f) {
            this.setPosition(camera.position.x - parentWidth / 2.0f, this.getY(8), 8);
        }
        if (this.getY(2) - camera.position.y > parentHeight / 2.0f) {
            this.setPosition(this.getX(2), camera.position.y + parentHeight / 2.0f, 2);
        }
        if (this.getY(4) - camera.position.y < -parentHeight / 2.0f) {
            this.setPosition(this.getX(4), camera.position.y - parentHeight / 2.0f, 4);
        }
    }
    
    public void setTranslation(final float x, final float y) {
        this.translation.x = x;
        this.translation.y = y;
    }
    
    public void keyDown(final KeyCode key, final Runnable l) {
        this.keyDown(k -> {
            if (k == key) {
                l.run();
            }
        });
    }
    
    public void keyDown(final Cons<KeyCode> cons) {
        this.addListener(new InputListener() {
            @Override
            public boolean keyDown(final InputEvent event, final KeyCode keycode) {
                cons.get(keycode);
                return true;
            }
        });
    }
    
    public void fireClick() {
        for (final EventListener listener : this.getListeners()) {
            if (listener instanceof ClickListener) {
                ((ClickListener)listener).clicked(new InputEvent(), -1.0f, -1.0f);
            }
        }
    }
    
    public ClickListener clicked(final Runnable r) {
        return this.clicked(KeyCode.mouseLeft, r);
    }
    
    public ClickListener clicked(final KeyCode button, final Runnable r) {
        return this.clicked(l -> l.setButton(button), r);
    }
    
    public ClickListener clicked(final Cons<ClickListener> tweaker, final Runnable r) {
        return this.clicked(tweaker, e -> r.run());
    }
    
    public ClickListener clicked(final Cons<ClickListener> tweaker, final Cons<ClickListener> runner) {
        final Element elem = this;
        final ClickListener click;
        this.addListener(click = new ClickListener() {
            @Override
            public void clicked(final InputEvent event, final float x, final float y) {
                if (runner != null && (!(elem instanceof Disableable) || !((Disableable)elem).isDisabled())) {
                    runner.get(this);
                }
            }
        });
        tweaker.get(click);
        return click;
    }
    
    public void tapped(final Runnable r) {
        this.addListener(new InputListener() {
            @Override
            public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                r.run();
                event.stop();
                return true;
            }
        });
    }
    
    public void hovered(final Runnable r) {
        this.addListener(new InputListener() {
            @Override
            public void enter(final InputEvent event, final float x, final float y, final int pointer, final Element fromActor) {
                r.run();
            }
        });
    }
    
    public void exited(final Runnable r) {
        this.addListener(new InputListener() {
            @Override
            public void exit(final InputEvent event, final float x, final float y, final int pointer, final Element fromActor) {
                r.run();
            }
        });
    }
    
    public void released(final Runnable r) {
        this.addListener(new InputListener() {
            @Override
            public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                return true;
            }
            
            @Override
            public void touchUp(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
                r.run();
            }
        });
    }
    
    public void change() {
        this.fire(new ChangeListener.ChangeEvent());
    }
    
    public void changed(final Runnable r) {
        final Element elem = this;
        this.addListener(new ChangeListener() {
            @Override
            public void changed(final ChangeEvent event, final Element actor) {
                if (!(elem instanceof Disableable) || !((Disableable)elem).isDisabled()) {
                    r.run();
                }
            }
        });
    }
    
    public Element update(final Runnable r) {
        this.update = r;
        return this;
    }
    
    public Element visible(final Boolp vis) {
        this.visibility = vis;
        return this;
    }
    
    public void touchable(final Prov<Touchable> touch) {
        this.touchablility = touch;
    }
    
    @Override
    public String toString() {
        String name = this.name;
        if (name == null) {
            name = super.toString().split("@")[0];
            final int dotIndex = name.lastIndexOf(46);
            if (dotIndex != -1) {
                name = name.substring(dotIndex + 1);
            }
        }
        return name;
    }
}
