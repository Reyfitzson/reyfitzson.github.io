// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.actions;

import arc.scene.Action;

public class OriginAction extends Action
{
    @Override
    public boolean act(final float delta) {
        this.actor.setOrigin(1);
        return true;
    }
}
