// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.actions;

import arc.scene.Action;

public class LayoutAction extends Action
{
    private boolean enabled;
    
    @Override
    public boolean act(final float delta) {
        this.target.setLayoutEnabled(this.enabled);
        return true;
    }
    
    public boolean isEnabled() {
        return this.enabled;
    }
    
    public void setLayoutEnabled(final boolean enabled) {
        this.enabled = enabled;
    }
}
