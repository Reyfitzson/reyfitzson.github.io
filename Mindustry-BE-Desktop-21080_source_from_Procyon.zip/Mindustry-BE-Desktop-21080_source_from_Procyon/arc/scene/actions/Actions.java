// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.actions;

import arc.scene.event.EventListener;
import arc.scene.event.Touchable;
import arc.graphics.Color;
import arc.math.Interp;
import arc.scene.Element;
import arc.util.pooling.Pool;
import arc.util.pooling.Pools;
import arc.scene.Action;
import arc.func.Prov;

public class Actions
{
    public static <T extends Action> T action(final Class<T> type, final Prov<T> sup) {
        final T action = Pools.obtain(type, sup);
        action.setPool(Pools.get(type, sup));
        return action;
    }
    
    public static AddAction addAction(final Action action) {
        final AddAction addAction = action(AddAction.class, AddAction::new);
        addAction.setAction(action);
        return addAction;
    }
    
    public static AddAction addAction(final Action action, final Element targetActor) {
        final AddAction addAction = action(AddAction.class, AddAction::new);
        addAction.setTarget(targetActor);
        addAction.setAction(action);
        return addAction;
    }
    
    public static RemoveAction removeAction(final Action action) {
        final RemoveAction removeAction = action(RemoveAction.class, RemoveAction::new);
        removeAction.setAction(action);
        return removeAction;
    }
    
    public static RemoveAction removeAction(final Action action, final Element targetActor) {
        final RemoveAction removeAction = action(RemoveAction.class, RemoveAction::new);
        removeAction.setTarget(targetActor);
        removeAction.setAction(action);
        return removeAction;
    }
    
    public static Action originCenter() {
        return new OriginAction();
    }
    
    public static MoveToAction moveTo(final float x, final float y) {
        return moveTo(x, y, 0.0f, null);
    }
    
    public static MoveToAction moveTo(final float x, final float y, final float duration) {
        return moveTo(x, y, duration, null);
    }
    
    public static MoveToAction moveTo(final float x, final float y, final float duration, final Interp interpolation) {
        final MoveToAction action = action(MoveToAction.class, MoveToAction::new);
        action.setPosition(x, y);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static MoveToAction moveToAligned(final float x, final float y, final int alignment) {
        return moveToAligned(x, y, alignment, 0.0f, null);
    }
    
    public static MoveToAction moveToAligned(final float x, final float y, final int alignment, final float duration) {
        return moveToAligned(x, y, alignment, duration, null);
    }
    
    public static MoveToAction moveToAligned(final float x, final float y, final int alignment, final float duration, final Interp interpolation) {
        final MoveToAction action = action(MoveToAction.class, MoveToAction::new);
        action.setPosition(x, y, alignment);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static MoveByAction moveBy(final float amountX, final float amountY) {
        return moveBy(amountX, amountY, 0.0f, null);
    }
    
    public static MoveByAction moveBy(final float amountX, final float amountY, final float duration) {
        return moveBy(amountX, amountY, duration, null);
    }
    
    public static RunnableAction translateTo(final float amountX, final float amountY) {
        final RunnableAction action = action(RunnableAction.class, RunnableAction::new);
        action.setRunnable(() -> action.getActor().setTranslation(amountX, amountY));
        return action;
    }
    
    public static TranslateByAction translateBy(final float amountX, final float amountY, final float duration, final Interp interpolation) {
        final TranslateByAction action = action(TranslateByAction.class, TranslateByAction::new);
        action.setAmount(amountX, amountY);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static TranslateByAction translateBy(final float amountX, final float amountY) {
        return translateBy(amountX, amountY, 0.0f, null);
    }
    
    public static TranslateByAction translateBy(final float amountX, final float amountY, final float duration) {
        return translateBy(amountX, amountY, duration, null);
    }
    
    public static MoveByAction moveBy(final float amountX, final float amountY, final float duration, final Interp interpolation) {
        final MoveByAction action = action(MoveByAction.class, MoveByAction::new);
        action.setAmount(amountX, amountY);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static SizeToAction sizeTo(final float x, final float y) {
        return sizeTo(x, y, 0.0f, null);
    }
    
    public static SizeToAction sizeTo(final float x, final float y, final float duration) {
        return sizeTo(x, y, duration, null);
    }
    
    public static SizeToAction sizeTo(final float x, final float y, final float duration, final Interp interpolation) {
        final SizeToAction action = action(SizeToAction.class, SizeToAction::new);
        action.setSize(x, y);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static SizeByAction sizeBy(final float amountX, final float amountY) {
        return sizeBy(amountX, amountY, 0.0f, null);
    }
    
    public static SizeByAction sizeBy(final float amountX, final float amountY, final float duration) {
        return sizeBy(amountX, amountY, duration, null);
    }
    
    public static SizeByAction sizeBy(final float amountX, final float amountY, final float duration, final Interp interpolation) {
        final SizeByAction action = action(SizeByAction.class, SizeByAction::new);
        action.setAmount(amountX, amountY);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static ScaleToAction scaleTo(final float x, final float y) {
        return scaleTo(x, y, 0.0f, null);
    }
    
    public static ScaleToAction scaleTo(final float x, final float y, final float duration) {
        return scaleTo(x, y, duration, null);
    }
    
    public static ScaleToAction scaleTo(final float x, final float y, final float duration, final Interp interpolation) {
        final ScaleToAction action = action(ScaleToAction.class, ScaleToAction::new);
        action.setScale(x, y);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static ScaleByAction scaleBy(final float amountX, final float amountY) {
        return scaleBy(amountX, amountY, 0.0f, null);
    }
    
    public static ScaleByAction scaleBy(final float amountX, final float amountY, final float duration) {
        return scaleBy(amountX, amountY, duration, null);
    }
    
    public static ScaleByAction scaleBy(final float amountX, final float amountY, final float duration, final Interp interpolation) {
        final ScaleByAction action = action(ScaleByAction.class, ScaleByAction::new);
        action.setAmount(amountX, amountY);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static RotateToAction rotateTo(final float rotation) {
        return rotateTo(rotation, 0.0f, null);
    }
    
    public static RotateToAction rotateTo(final float rotation, final float duration) {
        return rotateTo(rotation, duration, null);
    }
    
    public static RotateToAction rotateTo(final float rotation, final float duration, final Interp interpolation) {
        final RotateToAction action = action(RotateToAction.class, RotateToAction::new);
        action.setRotation(rotation);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static RotateByAction rotateBy(final float rotationAmount) {
        return rotateBy(rotationAmount, 0.0f, null);
    }
    
    public static RotateByAction rotateBy(final float rotationAmount, final float duration) {
        return rotateBy(rotationAmount, duration, null);
    }
    
    public static RotateByAction rotateBy(final float rotationAmount, final float duration, final Interp interpolation) {
        final RotateByAction action = action(RotateByAction.class, RotateByAction::new);
        action.setAmount(rotationAmount);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static ColorAction color(final Color color) {
        return color(color, 0.0f, null);
    }
    
    public static ColorAction color(final Color color, final float duration) {
        return color(color, duration, null);
    }
    
    public static ColorAction color(final Color color, final float duration, final Interp interpolation) {
        final ColorAction action = action(ColorAction.class, ColorAction::new);
        action.setEndColor(color);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static AlphaAction alpha(final float a) {
        return alpha(a, 0.0f, null);
    }
    
    public static AlphaAction alpha(final float a, final float duration) {
        return alpha(a, duration, null);
    }
    
    public static AlphaAction alpha(final float a, final float duration, final Interp interpolation) {
        final AlphaAction action = action(AlphaAction.class, AlphaAction::new);
        action.setAlpha(a);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static AlphaAction fadeOut(final float duration) {
        return alpha(0.0f, duration, null);
    }
    
    public static AlphaAction fadeOut(final float duration, final Interp interpolation) {
        final AlphaAction action = action(AlphaAction.class, AlphaAction::new);
        action.setAlpha(0.0f);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static AlphaAction fadeIn(final float duration) {
        return alpha(1.0f, duration, null);
    }
    
    public static AlphaAction fadeIn(final float duration, final Interp interpolation) {
        final AlphaAction action = action(AlphaAction.class, AlphaAction::new);
        action.setAlpha(1.0f);
        action.setDuration(duration);
        action.setInterpolation(interpolation);
        return action;
    }
    
    public static VisibleAction show() {
        return visible(true);
    }
    
    public static VisibleAction hide() {
        return visible(false);
    }
    
    public static VisibleAction visible(final boolean visible) {
        final VisibleAction action = action(VisibleAction.class, VisibleAction::new);
        action.setVisible(visible);
        return action;
    }
    
    public static TouchableAction touchable(final Touchable touchable) {
        final TouchableAction action = action(TouchableAction.class, TouchableAction::new);
        action.touchable(touchable);
        return action;
    }
    
    public static RemoveActorAction remove() {
        return action(RemoveActorAction.class, RemoveActorAction::new);
    }
    
    public static RemoveActorAction remove(final Element removeActor) {
        final RemoveActorAction action = action(RemoveActorAction.class, RemoveActorAction::new);
        action.setTarget(removeActor);
        return action;
    }
    
    public static DelayAction delay(final float duration) {
        final DelayAction action = action(DelayAction.class, DelayAction::new);
        action.setDuration(duration);
        return action;
    }
    
    public static DelayAction delay(final float duration, final Action delayedAction) {
        final DelayAction action = action(DelayAction.class, DelayAction::new);
        action.setDuration(duration);
        action.setAction(delayedAction);
        return action;
    }
    
    public static TimeScaleAction timeScale(final float scale, final Action scaledAction) {
        final TimeScaleAction action = action(TimeScaleAction.class, TimeScaleAction::new);
        action.setScale(scale);
        action.setAction(scaledAction);
        return action;
    }
    
    public static SequenceAction sequence(final Action action1) {
        final SequenceAction action2 = action(SequenceAction.class, SequenceAction::new);
        action2.addAction(action1);
        return action2;
    }
    
    public static SequenceAction sequence(final Action action1, final Action action2) {
        final SequenceAction action3 = action(SequenceAction.class, SequenceAction::new);
        action3.addAction(action1);
        action3.addAction(action2);
        return action3;
    }
    
    public static SequenceAction sequence(final Action action1, final Action action2, final Action action3) {
        final SequenceAction action4 = action(SequenceAction.class, SequenceAction::new);
        action4.addAction(action1);
        action4.addAction(action2);
        action4.addAction(action3);
        return action4;
    }
    
    public static SequenceAction sequence(final Action action1, final Action action2, final Action action3, final Action action4) {
        final SequenceAction action5 = action(SequenceAction.class, SequenceAction::new);
        action5.addAction(action1);
        action5.addAction(action2);
        action5.addAction(action3);
        action5.addAction(action4);
        return action5;
    }
    
    public static SequenceAction sequence(final Action action1, final Action action2, final Action action3, final Action action4, final Action action5) {
        final SequenceAction action6 = action(SequenceAction.class, SequenceAction::new);
        action6.addAction(action1);
        action6.addAction(action2);
        action6.addAction(action3);
        action6.addAction(action4);
        action6.addAction(action5);
        return action6;
    }
    
    public static SequenceAction sequence(final Action... actions) {
        final SequenceAction action = action(SequenceAction.class, SequenceAction::new);
        for (int i = 0, n = actions.length; i < n; ++i) {
            action.addAction(actions[i]);
        }
        return action;
    }
    
    public static SequenceAction sequence() {
        return action(SequenceAction.class, SequenceAction::new);
    }
    
    public static ParallelAction parallel(final Action action1) {
        final ParallelAction action2 = action(ParallelAction.class, ParallelAction::new);
        action2.addAction(action1);
        return action2;
    }
    
    public static ParallelAction parallel(final Action action1, final Action action2) {
        final ParallelAction action3 = action(ParallelAction.class, ParallelAction::new);
        action3.addAction(action1);
        action3.addAction(action2);
        return action3;
    }
    
    public static ParallelAction parallel(final Action action1, final Action action2, final Action action3) {
        final ParallelAction action4 = action(ParallelAction.class, ParallelAction::new);
        action4.addAction(action1);
        action4.addAction(action2);
        action4.addAction(action3);
        return action4;
    }
    
    public static ParallelAction parallel(final Action action1, final Action action2, final Action action3, final Action action4) {
        final ParallelAction action5 = action(ParallelAction.class, ParallelAction::new);
        action5.addAction(action1);
        action5.addAction(action2);
        action5.addAction(action3);
        action5.addAction(action4);
        return action5;
    }
    
    public static ParallelAction parallel(final Action action1, final Action action2, final Action action3, final Action action4, final Action action5) {
        final ParallelAction action6 = action(ParallelAction.class, ParallelAction::new);
        action6.addAction(action1);
        action6.addAction(action2);
        action6.addAction(action3);
        action6.addAction(action4);
        action6.addAction(action5);
        return action6;
    }
    
    public static ParallelAction parallel(final Action... actions) {
        final ParallelAction action = action(ParallelAction.class, ParallelAction::new);
        for (int i = 0, n = actions.length; i < n; ++i) {
            action.addAction(actions[i]);
        }
        return action;
    }
    
    public static ParallelAction parallel() {
        return action(ParallelAction.class, ParallelAction::new);
    }
    
    public static RepeatAction repeat(final int count, final Action repeatedAction) {
        final RepeatAction action = action(RepeatAction.class, RepeatAction::new);
        action.setCount(count);
        action.setAction(repeatedAction);
        return action;
    }
    
    public static RepeatAction forever(final Action repeatedAction) {
        final RepeatAction action = action(RepeatAction.class, RepeatAction::new);
        action.setCount(-1);
        action.setAction(repeatedAction);
        return action;
    }
    
    public static RunnableAction run(final Runnable runnable) {
        final RunnableAction action = action(RunnableAction.class, RunnableAction::new);
        action.setRunnable(runnable);
        return action;
    }
    
    public static LayoutAction layout(final boolean enabled) {
        final LayoutAction action = action(LayoutAction.class, LayoutAction::new);
        action.setLayoutEnabled(enabled);
        return action;
    }
    
    public static AfterAction after(final Action action) {
        final AfterAction afterAction = action(AfterAction.class, AfterAction::new);
        afterAction.setAction(action);
        return afterAction;
    }
    
    public static AddListenerAction addListener(final EventListener listener, final boolean capture) {
        final AddListenerAction addAction = action(AddListenerAction.class, AddListenerAction::new);
        addAction.setListener(listener);
        addAction.setCapture(capture);
        return addAction;
    }
    
    public static AddListenerAction addListener(final EventListener listener, final boolean capture, final Element targetActor) {
        final AddListenerAction addAction = action(AddListenerAction.class, AddListenerAction::new);
        addAction.setTarget(targetActor);
        addAction.setListener(listener);
        addAction.setCapture(capture);
        return addAction;
    }
    
    public static RemoveListenerAction removeListener(final EventListener listener, final boolean capture) {
        final RemoveListenerAction addAction = action(RemoveListenerAction.class, RemoveListenerAction::new);
        addAction.setListener(listener);
        addAction.setCapture(capture);
        return addAction;
    }
    
    public static RemoveListenerAction removeListener(final EventListener listener, final boolean capture, final Element targetActor) {
        final RemoveListenerAction addAction = action(RemoveListenerAction.class, RemoveListenerAction::new);
        addAction.setTarget(targetActor);
        addAction.setListener(listener);
        addAction.setCapture(capture);
        return addAction;
    }
}
