// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.actions;

import arc.scene.Element;
import arc.util.pooling.Pool;
import arc.scene.Action;

public abstract class DelegateAction extends Action
{
    protected Action action;
    
    public Action getAction() {
        return this.action;
    }
    
    public void setAction(final Action action) {
        this.action = action;
    }
    
    protected abstract boolean delegate(final float p0);
    
    @Override
    public final boolean act(final float delta) {
        final Pool pool = this.getPool();
        this.setPool(null);
        try {
            return this.delegate(delta);
        }
        finally {
            this.setPool(pool);
        }
    }
    
    @Override
    public void restart() {
        if (this.action != null) {
            this.action.restart();
        }
    }
    
    @Override
    public void reset() {
        super.reset();
        this.action = null;
    }
    
    @Override
    public void setActor(final Element actor) {
        if (this.action != null) {
            this.action.setActor(actor);
        }
        super.setActor(actor);
    }
    
    @Override
    public void setTarget(final Element target) {
        if (this.action != null) {
            this.action.setTarget(target);
        }
        super.setTarget(target);
    }
    
    @Override
    public String toString() {
        return super.toString() + ((this.action == null) ? "" : ("(" + this.action + ")"));
    }
}
