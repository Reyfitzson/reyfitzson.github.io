// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.actions;

import arc.scene.Action;

public class RemoveActorAction extends Action
{
    private boolean removed;
    
    @Override
    public boolean act(final float delta) {
        if (!this.removed) {
            this.removed = true;
            this.target.remove();
        }
        return true;
    }
    
    @Override
    public void restart() {
        this.removed = false;
    }
}
