// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.actions;

import arc.scene.event.EventListener;
import arc.scene.Action;

public class AddListenerAction extends Action
{
    private EventListener listener;
    private boolean capture;
    
    @Override
    public boolean act(final float delta) {
        if (this.capture) {
            this.target.addCaptureListener(this.listener);
        }
        else {
            this.target.addListener(this.listener);
        }
        return true;
    }
    
    public EventListener getListener() {
        return this.listener;
    }
    
    public void setListener(final EventListener listener) {
        this.listener = listener;
    }
    
    public boolean getCapture() {
        return this.capture;
    }
    
    public void setCapture(final boolean capture) {
        this.capture = capture;
    }
    
    @Override
    public void reset() {
        super.reset();
        this.listener = null;
    }
}
