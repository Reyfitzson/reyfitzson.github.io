// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.utils;

import arc.math.geom.Rect;

public interface Cullable
{
    void setCullingArea(final Rect p0);
}
