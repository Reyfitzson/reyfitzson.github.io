// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.utils;

import java.util.Iterator;
import arc.scene.event.SceneEvent;
import arc.util.pooling.Pools;
import arc.scene.event.ChangeListener;
import arc.struct.Seq;
import arc.struct.ObjectSet;
import arc.Core;
import arc.scene.Element;
import arc.struct.OrderedSet;

public class Selection<T> implements Disableable, Iterable<T>
{
    final OrderedSet<T> selected;
    private final OrderedSet<T> old;
    boolean isDisabled;
    boolean multiple;
    boolean required;
    T lastSelected;
    private Element element;
    private boolean toggle;
    private boolean programmaticChangeEvents;
    
    public Selection() {
        this.selected = new OrderedSet<T>();
        this.old = new OrderedSet<T>();
        this.programmaticChangeEvents = true;
    }
    
    public void setActor(final Element element) {
        this.element = element;
    }
    
    public void choose(final T item) {
        if (item == null) {
            throw new IllegalArgumentException("item cannot be null.");
        }
        if (this.isDisabled) {
            return;
        }
        this.snapshot();
        try {
            if ((this.toggle || (!this.required && this.selected.size == 1) || Core.input.ctrl()) && this.selected.contains(item)) {
                if (this.required && this.selected.size == 1) {
                    return;
                }
                this.selected.remove(item);
                this.lastSelected = null;
            }
            else {
                boolean modified = false;
                if (!this.multiple || (!this.toggle && !Core.input.ctrl())) {
                    if (this.selected.size == 1 && this.selected.contains(item)) {
                        return;
                    }
                    modified = (this.selected.size > 0);
                    this.selected.clear();
                }
                if (!this.selected.add(item) && !modified) {
                    return;
                }
                this.lastSelected = item;
            }
            if (this.fireChangeEvent()) {
                this.revert();
            }
            else {
                this.changed();
            }
        }
        finally {
            this.cleanup();
        }
    }
    
    public boolean hasItems() {
        return this.selected.size > 0;
    }
    
    public boolean isEmpty() {
        return this.selected.size == 0;
    }
    
    public int size() {
        return this.selected.size;
    }
    
    public OrderedSet<T> items() {
        return this.selected;
    }
    
    public T first() {
        return (this.selected.size == 0) ? null : this.selected.first();
    }
    
    void snapshot() {
        this.old.clear();
        this.old.addAll(this.selected);
    }
    
    void revert() {
        this.selected.clear();
        this.selected.addAll(this.old);
    }
    
    void cleanup() {
        this.old.clear(32);
    }
    
    public void set(final T item) {
        if (item == null) {
            throw new IllegalArgumentException("item cannot be null.");
        }
        if (this.selected.size == 1 && this.selected.first() == item) {
            return;
        }
        this.snapshot();
        this.selected.clear();
        this.selected.add(item);
        if (this.programmaticChangeEvents && this.fireChangeEvent()) {
            this.revert();
        }
        else {
            this.lastSelected = item;
            this.changed();
        }
        this.cleanup();
    }
    
    public void setAll(final Seq<T> items) {
        boolean added = false;
        this.snapshot();
        this.lastSelected = null;
        this.selected.clear();
        for (int i = 0, n = items.size; i < n; ++i) {
            final T item = items.get(i);
            if (item == null) {
                throw new IllegalArgumentException("item cannot be null.");
            }
            if (this.selected.add(item)) {
                added = true;
            }
        }
        if (added) {
            if (this.programmaticChangeEvents && this.fireChangeEvent()) {
                this.revert();
            }
            else if (items.size > 0) {
                this.lastSelected = items.peek();
                this.changed();
            }
        }
        this.cleanup();
    }
    
    public void add(final T item) {
        if (item == null) {
            throw new IllegalArgumentException("item cannot be null.");
        }
        if (!this.selected.add(item)) {
            return;
        }
        if (this.programmaticChangeEvents && this.fireChangeEvent()) {
            this.selected.remove(item);
        }
        else {
            this.lastSelected = item;
            this.changed();
        }
    }
    
    public void addAll(final Seq<T> items) {
        boolean added = false;
        this.snapshot();
        for (int i = 0, n = items.size; i < n; ++i) {
            final T item = items.get(i);
            if (item == null) {
                throw new IllegalArgumentException("item cannot be null.");
            }
            if (this.selected.add(item)) {
                added = true;
            }
        }
        if (added) {
            if (this.programmaticChangeEvents && this.fireChangeEvent()) {
                this.revert();
            }
            else {
                this.lastSelected = items.peek();
                this.changed();
            }
        }
        this.cleanup();
    }
    
    public void remove(final T item) {
        if (item == null) {
            throw new IllegalArgumentException("item cannot be null.");
        }
        if (!this.selected.remove(item)) {
            return;
        }
        if (this.programmaticChangeEvents && this.fireChangeEvent()) {
            this.selected.add(item);
        }
        else {
            this.lastSelected = null;
            this.changed();
        }
    }
    
    public void removeAll(final Seq<T> items) {
        boolean removed = false;
        this.snapshot();
        for (int i = 0, n = items.size; i < n; ++i) {
            final T item = items.get(i);
            if (item == null) {
                throw new IllegalArgumentException("item cannot be null.");
            }
            if (this.selected.remove(item)) {
                removed = true;
            }
        }
        if (removed) {
            if (this.programmaticChangeEvents && this.fireChangeEvent()) {
                this.revert();
            }
            else {
                this.lastSelected = null;
                this.changed();
            }
        }
        this.cleanup();
    }
    
    public void clear() {
        if (this.selected.size == 0) {
            return;
        }
        this.snapshot();
        this.selected.clear();
        if (this.programmaticChangeEvents && this.fireChangeEvent()) {
            this.revert();
        }
        else {
            this.lastSelected = null;
            this.changed();
        }
        this.cleanup();
    }
    
    protected void changed() {
    }
    
    public boolean fireChangeEvent() {
        if (this.element == null) {
            return false;
        }
        final ChangeListener.ChangeEvent changeEvent = Pools.obtain(ChangeListener.ChangeEvent.class, ChangeListener.ChangeEvent::new);
        try {
            return this.element.fire(changeEvent);
        }
        finally {
            Pools.free(changeEvent);
        }
    }
    
    public boolean contains(final T item) {
        return item != null && this.selected.contains(item);
    }
    
    public T getLastSelected() {
        if (this.lastSelected != null) {
            return this.lastSelected;
        }
        if (this.selected.size > 0) {
            return this.selected.first();
        }
        return null;
    }
    
    @Override
    public Iterator<T> iterator() {
        return (Iterator<T>)this.selected.iterator();
    }
    
    public Seq<T> toArray() {
        return this.selected.iterator().toSeq();
    }
    
    public Seq<T> toArray(final Seq<T> array) {
        return this.selected.iterator().toSeq(array);
    }
    
    @Override
    public boolean isDisabled() {
        return this.isDisabled;
    }
    
    @Override
    public void setDisabled(final boolean isDisabled) {
        this.isDisabled = isDisabled;
    }
    
    public boolean getToggle() {
        return this.toggle;
    }
    
    public void setToggle(final boolean toggle) {
        this.toggle = toggle;
    }
    
    public boolean getMultiple() {
        return this.multiple;
    }
    
    public void setMultiple(final boolean multiple) {
        this.multiple = multiple;
    }
    
    public boolean getRequired() {
        return this.required;
    }
    
    public void setRequired(final boolean required) {
        this.required = required;
    }
    
    public void setProgrammaticChangeEvents(final boolean programmaticChangeEvents) {
        this.programmaticChangeEvents = programmaticChangeEvents;
    }
    
    @Override
    public String toString() {
        return this.selected.toString();
    }
}
