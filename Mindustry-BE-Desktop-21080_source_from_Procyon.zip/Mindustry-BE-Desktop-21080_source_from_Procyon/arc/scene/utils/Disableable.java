// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.utils;

public interface Disableable
{
    boolean isDisabled();
    
    void setDisabled(final boolean p0);
}
