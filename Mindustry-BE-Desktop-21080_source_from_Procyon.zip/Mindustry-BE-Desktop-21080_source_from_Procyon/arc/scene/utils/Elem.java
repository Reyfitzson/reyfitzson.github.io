// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.utils;

import arc.scene.ui.TextField;
import arc.func.Cons;
import arc.graphics.Color;
import arc.scene.ui.ImageButton;
import arc.scene.style.Drawable;
import arc.scene.ui.TextButton;
import arc.scene.ui.CheckBox;
import arc.func.Boolc;

public class Elem
{
    public static CheckBox newCheck(final String text, final Boolc listener) {
        final CheckBox button = new CheckBox(text);
        if (listener != null) {
            button.changed(() -> listener.get(button.isChecked()));
        }
        return button;
    }
    
    public static TextButton newButton(final String text, final Runnable listener) {
        final TextButton button = new TextButton(text);
        if (listener != null) {
            button.changed(listener);
        }
        return button;
    }
    
    public static TextButton newButton(final String text, final TextButton.TextButtonStyle style, final Runnable listener) {
        final TextButton button = new TextButton(text, style);
        if (listener != null) {
            button.changed(listener);
        }
        return button;
    }
    
    public static ImageButton newImageButton(final Drawable icon, final Runnable listener) {
        final ImageButton button = new ImageButton(icon);
        if (listener != null) {
            button.changed(listener);
        }
        return button;
    }
    
    public static ImageButton newImageButton(final Drawable icon, final float size, final Runnable listener) {
        final ImageButton button = new ImageButton(icon);
        button.resizeImage(size);
        if (listener != null) {
            button.changed(listener);
        }
        return button;
    }
    
    public static ImageButton newImageButton(final ImageButton.ImageButtonStyle style, final Drawable icon, final float size, final Runnable listener) {
        final ImageButton button = new ImageButton(icon, style);
        button.resizeImage(size);
        if (listener != null) {
            button.changed(listener);
        }
        return button;
    }
    
    public static ImageButton newImageButton(final Drawable icon, final float size, final Color color, final Runnable listener) {
        final ImageButton button = new ImageButton(icon);
        button.resizeImage(size);
        button.getImage().setColor(color);
        if (listener != null) {
            button.changed(listener);
        }
        return button;
    }
    
    public static TextField newField(final String text, final Cons<String> listener) {
        final TextField field = new TextField(text);
        if (listener != null) {
            final TextField textField;
            field.changed(() -> {
                if (textField.isValid()) {
                    listener.get(textField.getText());
                }
                return;
            });
        }
        return field;
    }
}
