// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene;

import arc.util.pooling.Pool;
import java.lang.reflect.Field;
import arc.scene.event.FocusListener;
import arc.scene.event.EventListener;
import arc.input.KeyCode;
import arc.scene.style.Drawable;
import arc.func.Cons;
import arc.scene.ui.layout.Table;
import arc.func.Boolf;
import arc.scene.event.SceneEvent;
import arc.util.pooling.Pools;
import arc.scene.event.InputEvent;
import arc.graphics.Camera;
import arc.graphics.g2d.Draw;
import arc.scene.ui.Dialog;
import arc.scene.ui.TextField;
import arc.util.Reflect;
import arc.struct.Seq;
import arc.Core;
import arc.scene.event.Touchable;
import arc.graphics.g2d.ScissorStack;
import arc.math.geom.Rect;
import arc.math.Mat;
import arc.util.viewport.ScreenViewport;
import arc.util.viewport.Viewport;
import arc.struct.SnapshotSeq;
import arc.math.geom.Vec2;
import arc.struct.ObjectMap;
import arc.input.InputProcessor;

public class Scene implements InputProcessor
{
    public final Group root;
    public float marginLeft;
    public float marginRight;
    public float marginTop;
    public float marginBottom;
    private final ObjectMap<Class, Object> styleDefaults;
    private final Vec2 tempCoords;
    private final Element[] pointerOverActors;
    private final boolean[] pointerTouched;
    private final int[] pointerScreenX;
    private final int[] pointerScreenY;
    private final SnapshotSeq<TouchFocus> touchFocuses;
    private Viewport viewport;
    private int mouseScreenX;
    private int mouseScreenY;
    private Element mouseOverElement;
    private Element keyboardFocus;
    private Element scrollFocus;
    private boolean actionsRequestRendering;
    
    public Scene() {
        this.styleDefaults = new ObjectMap<Class, Object>();
        this.tempCoords = new Vec2();
        this.pointerOverActors = new Element[20];
        this.pointerTouched = new boolean[20];
        this.pointerScreenX = new int[20];
        this.pointerScreenY = new int[20];
        this.touchFocuses = new SnapshotSeq<TouchFocus>(true, 4, TouchFocus.class);
        this.actionsRequestRendering = true;
        this.viewport = new ScreenViewport() {
            @Override
            public void calculateScissors(final Mat batchTransform, final Rect area, final Rect scissor) {
                ScissorStack.calculateScissors(this.getCamera(), (float)this.getScreenX(), (float)this.getScreenY(), (float)this.getScreenWidth(), (float)this.getScreenHeight(), batchTransform, area, scissor);
            }
        };
        this.root = new Group() {
            @Override
            public float getHeight() {
                return Scene.this.getHeight() - Scene.this.marginTop - Scene.this.marginBottom;
            }
            
            @Override
            public float getWidth() {
                return Scene.this.getWidth() - Scene.this.marginLeft - Scene.this.marginRight;
            }
        };
        this.root.touchable = Touchable.childrenOnly;
        this.root.setScene(this);
        this.viewport.update(Core.graphics.getWidth(), Core.graphics.getHeight(), true);
    }
    
    public Scene(final Viewport viewport) {
        this();
        this.viewport = viewport;
    }
    
    public <T> T getStyle(final Class<T> type) {
        final IllegalArgumentException ex;
        return (T)this.styleDefaults.getThrow((Class<Object>)type, () -> {
            new IllegalArgumentException("No default style for type: " + type.getSimpleName());
            return ex;
        });
    }
    
    public <T> void addStyle(final Class<T> type, final T style) {
        this.styleDefaults.put(type, style);
    }
    
    public void registerStyles(final Class<?> type) {
        Seq.with(type.getFields()).each(f -> f.getName().startsWith("default"), f -> this.addStyle(f.getType(), Reflect.get(f)));
    }
    
    public boolean hasField() {
        return this.getKeyboardFocus() instanceof TextField;
    }
    
    public boolean hasMouse() {
        return this.hit((float)Core.input.mouseX(), (float)Core.input.mouseY(), true) != null;
    }
    
    public boolean hasMouse(final float mousex, final float mousey) {
        return this.hit(mousex, mousey, true) != null;
    }
    
    public boolean hasDialog() {
        return this.getScrollFocus() instanceof Dialog || (this.getKeyboardFocus() != null && this.getKeyboardFocus().isDescendantOf(e -> e instanceof Dialog));
    }
    
    public boolean hasKeyboard() {
        return this.getKeyboardFocus() != null;
    }
    
    public boolean hasScroll() {
        return this.getScrollFocus() != null;
    }
    
    public Dialog getDialog() {
        if (this.getKeyboardFocus() instanceof Dialog) {
            return (Dialog)this.getKeyboardFocus();
        }
        if (this.getScrollFocus() instanceof Dialog) {
            return (Dialog)this.getScrollFocus();
        }
        return null;
    }
    
    public void draw() {
        final Camera camera = this.viewport.getCamera();
        camera.update();
        if (!this.root.visible) {
            return;
        }
        Draw.proj(camera);
        this.root.draw();
        Draw.flush();
    }
    
    public void act() {
        this.act(Core.graphics.getDeltaTime());
    }
    
    public void act(final float delta) {
        this.root.y = this.marginBottom;
        this.root.x = this.marginLeft;
        this.root.height = this.getHeight() - this.marginBottom - this.marginTop;
        this.root.width = this.getWidth() - this.marginLeft - this.marginRight;
        for (int pointer = 0, n = this.pointerOverActors.length; pointer < n; ++pointer) {
            final Element overLast = this.pointerOverActors[pointer];
            if (!this.pointerTouched[pointer]) {
                if (overLast != null) {
                    this.pointerOverActors[pointer] = null;
                    this.screenToStageCoordinates(this.tempCoords.set((float)this.pointerScreenX[pointer], (float)this.pointerScreenY[pointer]));
                    final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
                    event.type = InputEvent.InputEventType.exit;
                    event.stageX = this.tempCoords.x;
                    event.stageY = this.tempCoords.y;
                    event.relatedActor = overLast;
                    event.pointer = pointer;
                    overLast.fire(event);
                    Pools.free(event);
                }
            }
            else {
                this.pointerOverActors[pointer] = this.fireEnterAndExit(overLast, this.pointerScreenX[pointer], this.pointerScreenY[pointer], pointer);
            }
        }
        if (Core.app.isDesktop() || Core.app.isWeb()) {
            this.mouseOverElement = this.fireEnterAndExit(this.mouseOverElement, this.mouseScreenX, this.mouseScreenY, -1);
        }
        if (this.scrollFocus != null && (!this.scrollFocus.visible || this.scrollFocus.getScene() == null)) {
            this.scrollFocus = null;
        }
        if (this.keyboardFocus != null && (!this.keyboardFocus.visible || this.keyboardFocus.getScene() == null)) {
            this.keyboardFocus = null;
        }
        if (this.scrollFocus != null) {
            for (Element curr = this.scrollFocus; curr.parent != null; curr = curr.parent) {
                if (!curr.visible) {
                    this.scrollFocus = null;
                    break;
                }
            }
        }
        this.root.act(delta);
    }
    
    public Element find(final String name) {
        return this.root.find(name);
    }
    
    public Element findVisible(final String name) {
        return this.root.findVisible(name);
    }
    
    public Element find(final Boolf<Element> pred) {
        return this.root.find(pred);
    }
    
    public Table table() {
        final Table table = new Table();
        table.setFillParent(true);
        this.add(table);
        return table;
    }
    
    public Table table(final Cons<Table> cons) {
        final Table table = new Table();
        table.setFillParent(true);
        this.add(table);
        cons.get(table);
        return table;
    }
    
    public Table table(final Drawable style, final Cons<Table> cons) {
        final Table table = new Table(style);
        table.setFillParent(true);
        this.add(table);
        cons.get(table);
        return table;
    }
    
    private Element fireEnterAndExit(final Element overLast, final int screenX, final int screenY, final int pointer) {
        this.screenToStageCoordinates(this.tempCoords.set((float)screenX, (float)screenY));
        final Element over = this.hit(this.tempCoords.x, this.tempCoords.y, true);
        if (over == overLast) {
            return overLast;
        }
        if (overLast != null) {
            final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
            event.stageX = this.tempCoords.x;
            event.stageY = this.tempCoords.y;
            event.pointer = pointer;
            event.type = InputEvent.InputEventType.exit;
            event.relatedActor = over;
            overLast.fire(event);
            Pools.free(event);
        }
        if (over != null) {
            final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
            event.stageX = this.tempCoords.x;
            event.stageY = this.tempCoords.y;
            event.pointer = pointer;
            event.type = InputEvent.InputEventType.enter;
            event.relatedActor = overLast;
            over.fire(event);
            Pools.free(event);
        }
        return over;
    }
    
    @Override
    public boolean touchDown(final int screenX, final int screenY, final int pointer, final KeyCode button) {
        if (!this.isInsideViewport(screenX, screenY)) {
            return false;
        }
        this.pointerTouched[pointer] = true;
        this.pointerScreenX[pointer] = screenX;
        this.pointerScreenY[pointer] = screenY;
        this.screenToStageCoordinates(this.tempCoords.set((float)screenX, (float)screenY));
        final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
        event.type = InputEvent.InputEventType.touchDown;
        event.stageX = this.tempCoords.x;
        event.stageY = this.tempCoords.y;
        event.pointer = pointer;
        event.keyCode = button;
        final Element target = this.hit(this.tempCoords.x, this.tempCoords.y, true);
        if (target == null) {
            if (this.root.touchable == Touchable.enabled) {
                this.root.fire(event);
            }
        }
        else {
            target.fire(event);
        }
        final boolean handled = event.handled;
        Pools.free(event);
        return handled;
    }
    
    @Override
    public boolean touchDragged(final int screenX, final int screenY, final int pointer) {
        this.pointerScreenX[pointer] = screenX;
        this.pointerScreenY[pointer] = screenY;
        this.mouseScreenX = screenX;
        this.mouseScreenY = screenY;
        if (this.touchFocuses.size == 0) {
            return false;
        }
        this.screenToStageCoordinates(this.tempCoords.set((float)screenX, (float)screenY));
        final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
        event.type = InputEvent.InputEventType.touchDragged;
        event.stageX = this.tempCoords.x;
        event.stageY = this.tempCoords.y;
        event.pointer = pointer;
        final SnapshotSeq<TouchFocus> touchFocuses = this.touchFocuses;
        final TouchFocus[] focuses = touchFocuses.begin();
        for (int i = 0, n = touchFocuses.size; i < n; ++i) {
            final TouchFocus focus = focuses[i];
            if (focus.pointer == pointer) {
                if (touchFocuses.contains(focus, true)) {
                    event.targetActor = focus.target;
                    event.listenerActor = focus.listenerActor;
                    if (focus.listener.handle(event)) {
                        event.handle();
                    }
                }
            }
        }
        touchFocuses.end();
        final boolean handled = event.handled;
        Pools.free(event);
        return handled;
    }
    
    @Override
    public boolean touchUp(final int screenX, final int screenY, final int pointer, final KeyCode button) {
        this.pointerTouched[pointer] = false;
        this.pointerScreenX[pointer] = screenX;
        this.pointerScreenY[pointer] = screenY;
        if (this.touchFocuses.size == 0) {
            return false;
        }
        this.screenToStageCoordinates(this.tempCoords.set((float)screenX, (float)screenY));
        final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
        event.type = InputEvent.InputEventType.touchUp;
        event.stageX = this.tempCoords.x;
        event.stageY = this.tempCoords.y;
        event.pointer = pointer;
        event.keyCode = button;
        final SnapshotSeq<TouchFocus> touchFocuses = this.touchFocuses;
        final TouchFocus[] focuses = touchFocuses.begin();
        for (int i = 0, n = touchFocuses.size; i < n; ++i) {
            final TouchFocus focus = focuses[i];
            if (focus.pointer == pointer) {
                if (focus.button == button) {
                    if (touchFocuses.remove(focus, true)) {
                        event.targetActor = focus.target;
                        event.listenerActor = focus.listenerActor;
                        if (focus.listener.handle(event)) {
                            event.handle();
                        }
                        Pools.free(focus);
                    }
                }
            }
        }
        touchFocuses.end();
        final boolean handled = event.handled;
        Pools.free(event);
        return handled;
    }
    
    @Override
    public boolean mouseMoved(final int screenX, final int screenY) {
        if (!this.isInsideViewport(screenX, screenY)) {
            return false;
        }
        this.mouseScreenX = screenX;
        this.mouseScreenY = screenY;
        this.screenToStageCoordinates(this.tempCoords.set((float)screenX, (float)screenY));
        final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
        event.type = InputEvent.InputEventType.mouseMoved;
        event.stageX = this.tempCoords.x;
        event.stageY = this.tempCoords.y;
        Element target = this.hit(this.tempCoords.x, this.tempCoords.y, true);
        if (target == null) {
            target = this.root;
        }
        target.fire(event);
        final boolean handled = event.handled;
        Pools.free(event);
        return handled;
    }
    
    @Override
    public boolean scrolled(final float amountX, final float amountY) {
        final Element target = (this.scrollFocus == null) ? this.root : this.scrollFocus;
        this.screenToStageCoordinates(this.tempCoords.set((float)this.mouseScreenX, (float)this.mouseScreenY));
        final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
        event.type = InputEvent.InputEventType.scrolled;
        event.scrollAmountX = amountX;
        event.scrollAmountY = amountY;
        event.stageX = this.tempCoords.x;
        event.stageY = this.tempCoords.y;
        target.fire(event);
        final boolean handled = event.handled;
        Pools.free(event);
        return handled;
    }
    
    @Override
    public boolean keyDown(final KeyCode keyCode) {
        final Element target = (this.keyboardFocus == null) ? this.root : this.keyboardFocus;
        final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
        event.type = InputEvent.InputEventType.keyDown;
        event.keyCode = keyCode;
        target.fire(event);
        final boolean handled = event.handled;
        Pools.free(event);
        return handled;
    }
    
    @Override
    public boolean keyUp(final KeyCode keyCode) {
        final Element target = (this.keyboardFocus == null) ? this.root : this.keyboardFocus;
        final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
        event.type = InputEvent.InputEventType.keyUp;
        event.keyCode = keyCode;
        target.fire(event);
        final boolean handled = event.handled;
        Pools.free(event);
        return handled;
    }
    
    @Override
    public boolean keyTyped(final char character) {
        final Element target = (this.keyboardFocus == null) ? this.root : this.keyboardFocus;
        final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
        event.type = InputEvent.InputEventType.keyTyped;
        event.character = character;
        target.fire(event);
        final boolean handled = event.handled;
        Pools.free(event);
        return handled;
    }
    
    public void addTouchFocus(final EventListener listener, final Element listenerActor, final Element target, final int pointer, final KeyCode button) {
        final TouchFocus focus = Pools.obtain(TouchFocus.class, () -> new TouchFocus());
        focus.listenerActor = listenerActor;
        focus.target = target;
        focus.listener = listener;
        focus.pointer = pointer;
        focus.button = button;
        this.touchFocuses.add(focus);
    }
    
    public void removeTouchFocus(final EventListener listener, final Element listenerActor, final Element target, final int pointer, final KeyCode button) {
        final SnapshotSeq<TouchFocus> touchFocuses = this.touchFocuses;
        for (int i = touchFocuses.size - 1; i >= 0; --i) {
            final TouchFocus focus = touchFocuses.get(i);
            if (focus.listener == listener && focus.listenerActor == listenerActor && focus.target == target && focus.pointer == pointer && focus.button == button) {
                touchFocuses.remove(i);
                Pools.free(focus);
            }
        }
    }
    
    public void cancelTouchFocus(final Element actor) {
        final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
        event.type = InputEvent.InputEventType.touchUp;
        event.stageX = -2.14748365E9f;
        event.stageY = -2.14748365E9f;
        final SnapshotSeq<TouchFocus> touchFocuses = this.touchFocuses;
        final TouchFocus[] items = touchFocuses.begin();
        for (int i = 0, n = touchFocuses.size; i < n; ++i) {
            final TouchFocus focus = items[i];
            if (focus.listenerActor == actor) {
                if (touchFocuses.remove(focus, true)) {
                    event.targetActor = focus.target;
                    event.listenerActor = focus.listenerActor;
                    event.pointer = focus.pointer;
                    event.keyCode = focus.button;
                    focus.listener.handle(event);
                }
            }
        }
        touchFocuses.end();
        Pools.free(event);
    }
    
    public void cancelTouchFocus() {
        this.cancelTouchFocusExcept(null, null);
    }
    
    public void cancelTouchFocusExcept(final EventListener exceptListener, final Element exceptActor) {
        final InputEvent event = Pools.obtain(InputEvent.class, InputEvent::new);
        event.type = InputEvent.InputEventType.touchUp;
        event.stageX = -2.14748365E9f;
        event.stageY = -2.14748365E9f;
        final SnapshotSeq<TouchFocus> touchFocuses = this.touchFocuses;
        final TouchFocus[] items = touchFocuses.begin();
        for (int i = 0, n = touchFocuses.size; i < n; ++i) {
            final TouchFocus focus = items[i];
            if (focus.listener != exceptListener || focus.listenerActor != exceptActor) {
                if (touchFocuses.remove(focus, true)) {
                    event.targetActor = focus.target;
                    event.listenerActor = focus.listenerActor;
                    event.pointer = focus.pointer;
                    event.keyCode = focus.button;
                    focus.listener.handle(event);
                }
            }
        }
        touchFocuses.end();
        Pools.free(event);
    }
    
    public void add(final Element actor) {
        this.root.addChild(actor);
    }
    
    public void addAction(final Action action) {
        this.root.addAction(action);
    }
    
    public Seq<Element> getElements() {
        return this.root.children;
    }
    
    public boolean addListener(final EventListener listener) {
        return this.root.addListener(listener);
    }
    
    public boolean removeListener(final EventListener listener) {
        return this.root.removeListener(listener);
    }
    
    public boolean addCaptureListener(final EventListener listener) {
        return this.root.addCaptureListener(listener);
    }
    
    public boolean removeCaptureListener(final EventListener listener) {
        return this.root.removeCaptureListener(listener);
    }
    
    public void clear() {
        this.unfocusAll();
        this.root.clear();
    }
    
    public void unfocusAll() {
        this.setScrollFocus(null);
        this.setKeyboardFocus(null);
        this.cancelTouchFocus();
    }
    
    public void unfocus(final Element actor) {
        this.cancelTouchFocus(actor);
        if (this.scrollFocus != null && this.scrollFocus.isDescendantOf(actor)) {
            this.setScrollFocus(null);
        }
        if (this.keyboardFocus != null && this.keyboardFocus.isDescendantOf(actor)) {
            this.setKeyboardFocus(null);
        }
    }
    
    public boolean setKeyboardFocus(final Element actor) {
        if (this.keyboardFocus == actor) {
            return true;
        }
        final FocusListener.FocusEvent event = Pools.obtain(FocusListener.FocusEvent.class, FocusListener.FocusEvent::new);
        event.type = FocusListener.FocusEvent.Type.keyboard;
        final Element oldKeyboardFocus = this.keyboardFocus;
        if (oldKeyboardFocus != null) {
            event.focused = false;
            event.relatedActor = actor;
            oldKeyboardFocus.fire(event);
        }
        boolean success = !event.cancelled;
        if (success && (this.keyboardFocus = actor) != null) {
            event.focused = true;
            event.relatedActor = oldKeyboardFocus;
            actor.fire(event);
            success = !event.cancelled;
            if (!success) {
                this.setKeyboardFocus(oldKeyboardFocus);
            }
        }
        Pools.free(event);
        return success;
    }
    
    public Element getKeyboardFocus() {
        return this.keyboardFocus;
    }
    
    public boolean setScrollFocus(final Element actor) {
        if (this.scrollFocus == actor) {
            return true;
        }
        final FocusListener.FocusEvent event = Pools.obtain(FocusListener.FocusEvent.class, FocusListener.FocusEvent::new);
        event.type = FocusListener.FocusEvent.Type.scroll;
        final Element oldScrollFocus = this.scrollFocus;
        if (oldScrollFocus != null) {
            event.focused = false;
            event.relatedActor = actor;
            oldScrollFocus.fire(event);
        }
        boolean success = !event.cancelled;
        if (success && (this.scrollFocus = actor) != null) {
            event.focused = true;
            event.relatedActor = oldScrollFocus;
            actor.fire(event);
            success = !event.cancelled;
            if (!success) {
                this.setScrollFocus(oldScrollFocus);
            }
        }
        Pools.free(event);
        return success;
    }
    
    public Element getScrollFocus() {
        return this.scrollFocus;
    }
    
    public Viewport getViewport() {
        return this.viewport;
    }
    
    public void setViewport(final Viewport viewport) {
        this.viewport = viewport;
    }
    
    public float getWidth() {
        return this.viewport.getWorldWidth();
    }
    
    public float getHeight() {
        return this.viewport.getWorldHeight();
    }
    
    public Camera getCamera() {
        return this.viewport.getCamera();
    }
    
    public Element hit(final float stageX, final float stageY, final boolean touchable) {
        this.root.parentToLocalCoordinates(this.tempCoords.set(stageX, stageY));
        return this.root.hit(this.tempCoords.x, this.tempCoords.y, touchable);
    }
    
    public Vec2 screenToStageCoordinates(final Vec2 screenCoords) {
        this.viewport.unproject(screenCoords);
        return screenCoords;
    }
    
    public Vec2 stageToScreenCoordinates(final Vec2 stageCoords) {
        this.viewport.project(stageCoords);
        stageCoords.y = this.viewport.getScreenHeight() - stageCoords.y;
        return stageCoords;
    }
    
    public Vec2 toScreenCoordinates(final Vec2 coords, final Mat transformMatrix) {
        return this.viewport.toScreenCoordinates(coords, transformMatrix);
    }
    
    public void calculateScissors(final Rect localRect, final Rect scissorRect) {
        final Mat transformMatrix = Draw.trans();
        this.viewport.calculateScissors(transformMatrix, localRect, scissorRect);
    }
    
    public boolean getActionsRequestRendering() {
        return this.actionsRequestRendering;
    }
    
    public void setActionsRequestRendering(final boolean actionsRequestRendering) {
        this.actionsRequestRendering = actionsRequestRendering;
    }
    
    protected boolean isInsideViewport(final int screenX, int screenY) {
        final int x0 = this.viewport.getScreenX();
        final int x2 = x0 + this.viewport.getScreenWidth();
        final int y0 = this.viewport.getScreenY();
        final int y2 = y0 + this.viewport.getScreenHeight();
        screenY = Core.graphics.getHeight() - screenY;
        return screenX >= x0 && screenX < x2 && screenY >= y0 && screenY < y2;
    }
    
    public void resize(final int width, final int height) {
        this.viewport.update(width, height, true);
    }
    
    private static final class TouchFocus implements Pool.Poolable
    {
        EventListener listener;
        Element listenerActor;
        Element target;
        int pointer;
        KeyCode button;
        
        @Override
        public void reset() {
            this.listenerActor = null;
            this.listener = null;
            this.target = null;
        }
    }
}
