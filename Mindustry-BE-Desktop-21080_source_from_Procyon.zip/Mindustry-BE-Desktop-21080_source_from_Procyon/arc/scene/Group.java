// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene;

import arc.func.Boolf;
import arc.struct.Seq;
import arc.scene.style.Drawable;
import arc.scene.ui.layout.Table;
import java.util.Iterator;
import arc.func.Cons;
import arc.scene.event.Touchable;
import arc.graphics.g2d.Draw;
import arc.math.geom.Rect;
import arc.math.Mat;
import arc.math.Affine2;
import arc.struct.SnapshotSeq;
import arc.math.geom.Vec2;
import arc.scene.utils.Cullable;

public abstract class Group extends Element implements Cullable
{
    private static final Vec2 tmp;
    protected final SnapshotSeq<Element> children;
    private final Affine2 worldTransform;
    private final Mat computedTransform;
    private final Mat oldTransform;
    protected boolean transform;
    protected Rect cullingArea;
    
    public Group() {
        this.children = new SnapshotSeq<Element>(true, 4, Element.class);
        this.worldTransform = new Affine2();
        this.computedTransform = new Mat();
        this.oldTransform = new Mat();
        this.transform = false;
    }
    
    @Override
    public void act(final float delta) {
        super.act(delta);
        final Element[] actors = this.children.begin();
        for (int i = 0, n = this.children.size; i < n; ++i) {
            if (actors[i].visible) {
                actors[i].act(delta);
            }
            actors[i].updateVisibility();
        }
        this.children.end();
    }
    
    @Override
    public void draw() {
        if (this.transform) {
            this.applyTransform(this.computeTransform());
        }
        this.drawChildren();
        if (this.transform) {
            this.resetTransform();
        }
    }
    
    protected void drawChildren() {
        this.parentAlpha *= this.color.a;
        final SnapshotSeq<Element> children = this.children;
        final Element[] actors = children.begin();
        final Rect cullingArea = this.cullingArea;
        if (cullingArea != null) {
            final float cullLeft = cullingArea.x;
            final float cullRight = cullLeft + cullingArea.width;
            final float cullBottom = cullingArea.y;
            final float cullTop = cullBottom + cullingArea.height;
            if (this.transform) {
                for (int i = 0, n = children.size; i < n; ++i) {
                    final Element child = actors[i];
                    child.parentAlpha = this.parentAlpha;
                    if (child.visible) {
                        final float cx = child.x;
                        final float cy = child.y;
                        final Element element = child;
                        element.x += child.translation.x;
                        final Element element2 = child;
                        element2.y += child.translation.y;
                        if ((cx <= cullRight && cy <= cullTop && cx + child.width >= cullLeft && cy + child.height >= cullBottom) || !child.cullable) {
                            child.draw();
                        }
                        final Element element3 = child;
                        element3.x -= child.translation.x;
                        final Element element4 = child;
                        element4.y -= child.translation.y;
                    }
                }
            }
            else {
                final float offsetX = this.x;
                final float offsetY = this.y;
                this.x = 0.0f;
                this.y = 0.0f;
                for (int j = 0, n2 = children.size; j < n2; ++j) {
                    final Element child2 = actors[j];
                    child2.parentAlpha = this.parentAlpha;
                    if (child2.visible) {
                        final float cx2 = child2.x;
                        final float cy2 = child2.y;
                        if ((cx2 <= cullRight && cy2 <= cullTop && cx2 + child2.width >= cullLeft && cy2 + child2.height >= cullBottom) || !child2.cullable) {
                            child2.x = cx2 + offsetX + child2.translation.x;
                            child2.y = cy2 + offsetY + child2.translation.y;
                            child2.draw();
                            child2.x = cx2;
                            child2.y = cy2;
                        }
                    }
                }
                this.x = offsetX;
                this.y = offsetY;
            }
        }
        else if (this.transform) {
            for (int k = 0, n3 = children.size; k < n3; ++k) {
                final Element child3 = actors[k];
                child3.parentAlpha = this.parentAlpha;
                if (child3.visible) {
                    final Element element5 = child3;
                    element5.x += child3.translation.x;
                    final Element element6 = child3;
                    element6.y += child3.translation.y;
                    child3.draw();
                    final Element element7 = child3;
                    element7.x -= child3.translation.x;
                    final Element element8 = child3;
                    element8.y -= child3.translation.y;
                }
            }
        }
        else {
            final float offsetX2 = this.x;
            final float offsetY2 = this.y;
            this.x = 0.0f;
            this.y = 0.0f;
            for (int l = 0, n4 = children.size; l < n4; ++l) {
                final Element child4 = actors[l];
                child4.parentAlpha = this.parentAlpha;
                if (child4.visible) {
                    final float cx3 = child4.x;
                    final float cy3 = child4.y;
                    child4.x = cx3 + offsetX2 + child4.translation.x;
                    child4.y = cy3 + offsetY2 + child4.translation.y;
                    child4.draw();
                    child4.x = cx3;
                    child4.y = cy3;
                }
            }
            this.x = offsetX2;
            this.y = offsetY2;
        }
        children.end();
    }
    
    protected Mat computeTransform() {
        final Affine2 worldTransform = this.worldTransform;
        final float originX = this.originX;
        final float originY = this.originY;
        worldTransform.setToTrnRotScl(this.x + originX, this.y + originY, this.rotation, this.scaleX, this.scaleY);
        if (originX != 0.0f || originY != 0.0f) {
            worldTransform.translate(-originX, -originY);
        }
        Group parentGroup;
        for (parentGroup = this.parent; parentGroup != null && !parentGroup.transform; parentGroup = parentGroup.parent) {}
        if (parentGroup != null) {
            worldTransform.preMul(parentGroup.worldTransform);
        }
        this.computedTransform.set(worldTransform);
        return this.computedTransform;
    }
    
    protected void applyTransform(final Mat transform) {
        this.oldTransform.set(Draw.trans());
        Draw.trans(transform);
    }
    
    protected void resetTransform() {
        Draw.trans(this.oldTransform);
    }
    
    public Rect getCullingArea() {
        return this.cullingArea;
    }
    
    @Override
    public void setCullingArea(final Rect cullingArea) {
        this.cullingArea = cullingArea;
    }
    
    @Override
    public Element hit(final float x, final float y, final boolean touchable) {
        if (touchable && this.touchable == Touchable.disabled) {
            return null;
        }
        final Vec2 point = Group.tmp;
        final Element[] childrenArray = this.children.items;
        for (int i = this.children.size - 1; i >= 0; --i) {
            final Element child = childrenArray[i];
            if (child.visible) {
                child.parentToLocalCoordinates(point.set(x, y));
                final Element hit = child.hit(point.x, point.y, touchable);
                if (hit != null) {
                    return hit;
                }
            }
        }
        return super.hit(x, y, touchable);
    }
    
    protected void childrenChanged() {
    }
    
    public void forEach(final Cons<Element> cons) {
        for (final Element e : this.getChildren()) {
            cons.get(e);
            if (e instanceof Group) {
                ((Group)e).forEach(cons);
            }
        }
    }
    
    public Element fill(final Table.DrawRect rect) {
        final Element e = new Element() {
            @Override
            public void draw() {
                rect.draw(this.x, this.y, this.width, this.height);
            }
        };
        e.setFillParent(true);
        this.addChild(e);
        return e;
    }
    
    public void fill(final Cons<Table> cons) {
        this.fill(null, cons);
    }
    
    public void fill(final Drawable background, final Cons<Table> cons) {
        final Table table = (background == null) ? new Table() : new Table(background);
        table.setFillParent(true);
        this.addChild(table);
        cons.get(table);
    }
    
    public void addChild(final Element actor) {
        if (actor.parent != null) {
            if (actor.parent == this) {
                return;
            }
            actor.parent.removeChild(actor, false);
        }
        this.children.add(actor);
        actor.parent = this;
        actor.setScene(this.getScene());
        this.childrenChanged();
    }
    
    public void addChildAt(final int index, final Element actor) {
        if (actor.parent != null) {
            if (actor.parent == this) {
                return;
            }
            actor.parent.removeChild(actor, false);
        }
        if (index >= this.children.size) {
            this.children.add(actor);
        }
        else {
            this.children.insert(index, actor);
        }
        actor.parent = this;
        actor.setScene(this.getScene());
        this.childrenChanged();
    }
    
    public void addChildBefore(final Element actorBefore, final Element actor) {
        if (actor.parent != null) {
            if (actor.parent == this) {
                return;
            }
            actor.parent.removeChild(actor, false);
        }
        final int index = this.children.indexOf(actorBefore, true);
        this.children.insert(index, actor);
        actor.parent = this;
        actor.setScene(this.getScene());
        this.childrenChanged();
    }
    
    public void addChildAfter(final Element actorAfter, final Element actor) {
        if (actor.parent != null) {
            if (actor.parent == this) {
                return;
            }
            actor.parent.removeChild(actor, false);
        }
        final int index = this.children.indexOf(actorAfter, true);
        if (index == this.children.size) {
            this.children.add(actor);
        }
        else {
            this.children.insert(index + 1, actor);
        }
        actor.parent = this;
        actor.setScene(this.getScene());
        this.childrenChanged();
    }
    
    public boolean removeChild(final Element actor) {
        return this.removeChild(actor, true);
    }
    
    public boolean removeChild(final Element actor, final boolean unfocus) {
        if (!this.children.remove(actor, true)) {
            return false;
        }
        if (unfocus) {
            final Scene stage = this.getScene();
            if (stage != null) {
                stage.unfocus(actor);
            }
        }
        actor.parent = null;
        actor.setScene(null);
        this.childrenChanged();
        return true;
    }
    
    public void clearChildren() {
        final Element[] actors = this.children.begin();
        for (int i = 0, n = this.children.size; i < n; ++i) {
            final Element child = actors[i];
            child.setScene(null);
            child.parent = null;
        }
        this.children.end();
        this.children.clear();
        this.childrenChanged();
    }
    
    @Override
    public void clear() {
        super.clear();
        this.clearChildren();
    }
    
    public <T extends Element> T find(final String name) {
        final Seq<Element> children = this.children;
        for (int i = 0, n = children.size; i < n; ++i) {
            if (name.equals(children.get(i).name)) {
                return (T)children.get(i);
            }
        }
        for (int i = 0, n = children.size; i < n; ++i) {
            final Element child = children.get(i);
            if (child instanceof Group) {
                final Element actor = ((Group)child).find(name);
                if (actor != null) {
                    return (T)actor;
                }
            }
        }
        return null;
    }
    
    public <T extends Element> T findVisible(final String name) {
        final Seq<Element> children = this.children;
        for (int i = 0, n = children.size; i < n; ++i) {
            if (name.equals(children.get(i).name) && children.get(i).visible) {
                return (T)children.get(i);
            }
        }
        for (int i = 0, n = children.size; i < n; ++i) {
            final Element child = children.get(i);
            if (child instanceof Group && child.visible) {
                final Element actor = ((Group)child).findVisible(name);
                if (actor != null) {
                    return (T)actor;
                }
            }
        }
        return null;
    }
    
    public <T extends Element> T find(final Boolf<Element> pred) {
        final Seq<Element> children = this.children;
        for (int i = 0, n = children.size; i < n; ++i) {
            if (pred.get(children.get(i))) {
                return (T)children.get(i);
            }
        }
        for (int i = 0, n = children.size; i < n; ++i) {
            final Element child = children.get(i);
            if (child instanceof Group) {
                final Element actor = ((Group)child).find(pred);
                if (actor != null) {
                    return (T)actor;
                }
            }
        }
        return null;
    }
    
    @Override
    protected void setScene(final Scene stage) {
        super.setScene(stage);
        final Element[] childrenArray = this.children.items;
        for (int i = 0, n = this.children.size; i < n; ++i) {
            childrenArray[i].setScene(stage);
        }
    }
    
    public boolean swapActor(final int first, final int second) {
        final int maxIndex = this.children.size;
        if (first < 0 || first >= maxIndex) {
            return false;
        }
        if (second < 0 || second >= maxIndex) {
            return false;
        }
        this.children.swap(first, second);
        return true;
    }
    
    public boolean swapActor(final Element first, final Element second) {
        final int firstIndex = this.children.indexOf(first, true);
        final int secondIndex = this.children.indexOf(second, true);
        if (firstIndex == -1 || secondIndex == -1) {
            return false;
        }
        this.children.swap(firstIndex, secondIndex);
        return true;
    }
    
    public SnapshotSeq<Element> getChildren() {
        return this.children;
    }
    
    public boolean hasChildren() {
        return this.children.size > 0;
    }
    
    public boolean isTransform() {
        return this.transform;
    }
    
    public void setTransform(final boolean transform) {
        this.transform = transform;
    }
    
    public Vec2 localToDescendantCoordinates(final Element descendant, final Vec2 localCoords) {
        final Group parent = descendant.parent;
        if (parent == null) {
            throw new IllegalArgumentException("Child is not a descendant: " + descendant);
        }
        if (parent != this) {
            this.localToDescendantCoordinates(parent, localCoords);
        }
        descendant.parentToLocalCoordinates(localCoords);
        return localCoords;
    }
    
    @Override
    public String toString() {
        final StringBuilder buffer = new StringBuilder(128);
        this.toString(buffer, 1);
        buffer.setLength(buffer.length() - 1);
        return buffer.toString();
    }
    
    void toString(final StringBuilder buffer, final int indent) {
        buffer.append(super.toString());
        buffer.append('\n');
        final Element[] actors = this.children.begin();
        for (int i = 0, n = this.children.size; i < n; ++i) {
            for (int ii = 0; ii < indent; ++ii) {
                buffer.append("|  ");
            }
            final Element actor = actors[i];
            if (actor instanceof Group) {
                ((Group)actor).toString(buffer, indent + 1);
            }
            else {
                buffer.append(actor);
                buffer.append('\n');
            }
        }
        this.children.end();
    }
    
    static {
        tmp = new Vec2();
    }
}
