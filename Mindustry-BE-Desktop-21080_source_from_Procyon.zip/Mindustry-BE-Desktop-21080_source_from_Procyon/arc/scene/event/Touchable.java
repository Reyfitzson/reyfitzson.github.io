// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

public enum Touchable
{
    enabled, 
    disabled, 
    childrenOnly;
}
