// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

import arc.scene.utils.Disableable;
import arc.Graphics;
import arc.Core;
import arc.scene.Element;
import arc.func.Boolp;

public class HandCursorListener extends ClickListener
{
    public Boolp enabled;
    public boolean checkEnabled;
    
    public HandCursorListener(final Boolp enabled, final boolean check) {
        this.enabled = (() -> true);
        this.checkEnabled = true;
        this.enabled = enabled;
        this.checkEnabled = check;
    }
    
    public HandCursorListener() {
        this.enabled = (() -> true);
        this.checkEnabled = true;
    }
    
    @Override
    public void enter(final InputEvent event, final float x, final float y, final int pointer, final Element fromActor) {
        super.enter(event, x, y, pointer, fromActor);
        if (pointer != -1 || !this.enabled.get() || (this.checkEnabled && (isDisabled(event.targetActor) || isDisabled(fromActor)))) {
            return;
        }
        Core.graphics.cursor(Graphics.Cursor.SystemCursor.hand);
    }
    
    @Override
    public void exit(final InputEvent event, final float x, final float y, final int pointer, final Element toActor) {
        super.exit(event, x, y, pointer, toActor);
        if (pointer == -1) {
            Core.graphics.restoreCursor();
        }
    }
    
    static boolean isDisabled(final Element element) {
        return element != null && ((element instanceof Disableable && ((Disableable)element).isDisabled()) || !element.visible || isDisabled(element.parent));
    }
}
