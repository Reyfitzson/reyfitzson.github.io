// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

import arc.util.Timer;
import arc.scene.ui.ScrollPane;
import arc.math.Interp;

public class DragScrollListener extends DragListener
{
    Interp interpolation;
    float minSpeed;
    float maxSpeed;
    float tickSecs;
    long startTime;
    long rampTime;
    private ScrollPane scroll;
    private Timer.Task scrollUp;
    private Timer.Task scrollDown;
    
    public DragScrollListener(final ScrollPane scroll) {
        this.interpolation = Interp.exp5In;
        this.minSpeed = 15.0f;
        this.maxSpeed = 75.0f;
        this.tickSecs = 0.05f;
        this.rampTime = 1750L;
        this.scroll = scroll;
        this.scrollUp = new Timer.Task() {
            @Override
            public void run() {
                scroll.setScrollY(scroll.getScrollY() - DragScrollListener.this.getScrollPixels());
            }
        };
        this.scrollDown = new Timer.Task() {
            @Override
            public void run() {
                scroll.setScrollY(scroll.getScrollY() + DragScrollListener.this.getScrollPixels());
            }
        };
    }
    
    public void setup(final float minSpeedPixels, final float maxSpeedPixels, final float tickSecs, final float rampSecs) {
        this.minSpeed = minSpeedPixels;
        this.maxSpeed = maxSpeedPixels;
        this.tickSecs = tickSecs;
        this.rampTime = (long)(rampSecs * 1000.0f);
    }
    
    float getScrollPixels() {
        return this.interpolation.apply(this.minSpeed, this.maxSpeed, Math.min(1.0f, (System.currentTimeMillis() - this.startTime) / (float)this.rampTime));
    }
    
    @Override
    public void drag(final InputEvent event, final float x, final float y, final int pointer) {
        if (x >= 0.0f && x < this.scroll.getWidth()) {
            if (y >= this.scroll.getHeight()) {
                this.scrollDown.cancel();
                if (!this.scrollUp.isScheduled()) {
                    this.startTime = System.currentTimeMillis();
                    Timer.schedule(this.scrollUp, this.tickSecs, this.tickSecs);
                }
                return;
            }
            if (y < 0.0f) {
                this.scrollUp.cancel();
                if (!this.scrollDown.isScheduled()) {
                    this.startTime = System.currentTimeMillis();
                    Timer.schedule(this.scrollDown, this.tickSecs, this.tickSecs);
                }
                return;
            }
        }
        this.scrollUp.cancel();
        this.scrollDown.cancel();
    }
    
    @Override
    public void dragStop(final InputEvent event, final float x, final float y, final int pointer) {
        this.scrollUp.cancel();
        this.scrollDown.cancel();
    }
}
