// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

import arc.scene.Element;

public abstract class ChangeListener implements EventListener
{
    @Override
    public boolean handle(final SceneEvent event) {
        if (!(event instanceof ChangeEvent)) {
            return false;
        }
        this.changed((ChangeEvent)event, event.targetActor);
        return false;
    }
    
    public abstract void changed(final ChangeEvent p0, final Element p1);
    
    public static class ChangeEvent extends SceneEvent
    {
    }
}
