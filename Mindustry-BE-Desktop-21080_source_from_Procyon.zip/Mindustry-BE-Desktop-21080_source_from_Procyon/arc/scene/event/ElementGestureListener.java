// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

import arc.input.KeyCode;
import arc.scene.Element;
import arc.input.GestureDetector;
import arc.math.geom.Vec2;

public class ElementGestureListener implements EventListener
{
    static final Vec2 tmpCoords;
    static final Vec2 tmpCoords2;
    private final GestureDetector detector;
    InputEvent event;
    Element actor;
    Element touchDownTarget;
    
    public ElementGestureListener() {
        this(20.0f, 0.4f, 1.1f, 0.15f);
    }
    
    public ElementGestureListener(final float halfTapSquareSize, final float tapCountInterval, final float longPressDuration, final float maxFlingDelay) {
        this.detector = new GestureDetector(halfTapSquareSize, tapCountInterval, longPressDuration, maxFlingDelay, new GestureDetector.GestureListener() {
            private final Vec2 initialPointer1 = new Vec2();
            private final Vec2 initialPointer2 = new Vec2();
            private final Vec2 pointer1 = new Vec2();
            private final Vec2 pointer2 = new Vec2();
            
            @Override
            public boolean tap(final float stageX, final float stageY, final int count, final KeyCode button) {
                ElementGestureListener.this.actor.stageToLocalCoordinates(ElementGestureListener.tmpCoords.set(stageX, stageY));
                ElementGestureListener.this.tap(ElementGestureListener.this.event, ElementGestureListener.tmpCoords.x, ElementGestureListener.tmpCoords.y, count, button);
                return true;
            }
            
            @Override
            public boolean longPress(final float stageX, final float stageY) {
                ElementGestureListener.this.actor.stageToLocalCoordinates(ElementGestureListener.tmpCoords.set(stageX, stageY));
                return ElementGestureListener.this.longPress(ElementGestureListener.this.actor, ElementGestureListener.tmpCoords.x, ElementGestureListener.tmpCoords.y);
            }
            
            @Override
            public boolean fling(final float velocityX, final float velocityY, final KeyCode button) {
                this.stageToLocalAmount(ElementGestureListener.tmpCoords.set(velocityX, velocityY));
                ElementGestureListener.this.fling(ElementGestureListener.this.event, ElementGestureListener.tmpCoords.x, ElementGestureListener.tmpCoords.y, button);
                return true;
            }
            
            @Override
            public boolean pan(final float stageX, final float stageY, float deltaX, float deltaY) {
                this.stageToLocalAmount(ElementGestureListener.tmpCoords.set(deltaX, deltaY));
                deltaX = ElementGestureListener.tmpCoords.x;
                deltaY = ElementGestureListener.tmpCoords.y;
                ElementGestureListener.this.actor.stageToLocalCoordinates(ElementGestureListener.tmpCoords.set(stageX, stageY));
                ElementGestureListener.this.pan(ElementGestureListener.this.event, ElementGestureListener.tmpCoords.x, ElementGestureListener.tmpCoords.y, deltaX, deltaY);
                return true;
            }
            
            @Override
            public boolean zoom(final float initialDistance, final float distance) {
                ElementGestureListener.this.zoom(ElementGestureListener.this.event, initialDistance, distance);
                return true;
            }
            
            @Override
            public boolean pinch(final Vec2 stageInitialPointer1, final Vec2 stageInitialPointer2, final Vec2 stagePointer1, final Vec2 stagePointer2) {
                ElementGestureListener.this.actor.stageToLocalCoordinates(this.initialPointer1.set(stageInitialPointer1));
                ElementGestureListener.this.actor.stageToLocalCoordinates(this.initialPointer2.set(stageInitialPointer2));
                ElementGestureListener.this.actor.stageToLocalCoordinates(this.pointer1.set(stagePointer1));
                ElementGestureListener.this.actor.stageToLocalCoordinates(this.pointer2.set(stagePointer2));
                ElementGestureListener.this.pinch(ElementGestureListener.this.event, this.initialPointer1, this.initialPointer2, this.pointer1, this.pointer2);
                return true;
            }
            
            private void stageToLocalAmount(final Vec2 amount) {
                ElementGestureListener.this.actor.stageToLocalCoordinates(amount);
                amount.sub(ElementGestureListener.this.actor.stageToLocalCoordinates(ElementGestureListener.tmpCoords2.set(0.0f, 0.0f)));
            }
        });
    }
    
    @Override
    public boolean handle(final SceneEvent e) {
        if (!(e instanceof InputEvent)) {
            return false;
        }
        final InputEvent event = (InputEvent)e;
        switch (event.type) {
            case touchDown: {
                this.actor = event.listenerActor;
                this.touchDownTarget = event.targetActor;
                this.detector.touchDown(event.stageX, event.stageY, event.pointer, event.keyCode);
                this.actor.stageToLocalCoordinates(ElementGestureListener.tmpCoords.set(event.stageX, event.stageY));
                this.touchDown(event, ElementGestureListener.tmpCoords.x, ElementGestureListener.tmpCoords.y, event.pointer, event.keyCode);
                return true;
            }
            case touchUp: {
                if (event.isTouchFocusCancel()) {
                    return false;
                }
                this.event = event;
                this.actor = event.listenerActor;
                this.detector.touchUp(event.stageX, event.stageY, event.pointer, event.keyCode);
                this.actor.stageToLocalCoordinates(ElementGestureListener.tmpCoords.set(event.stageX, event.stageY));
                this.touchUp(event, ElementGestureListener.tmpCoords.x, ElementGestureListener.tmpCoords.y, event.pointer, event.keyCode);
                return true;
            }
            case touchDragged: {
                this.event = event;
                this.actor = event.listenerActor;
                this.detector.touchDragged(event.stageX, event.stageY, event.pointer);
                return true;
            }
            default: {
                return false;
            }
        }
    }
    
    public void touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
    }
    
    public void touchUp(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
    }
    
    public void tap(final InputEvent event, final float x, final float y, final int count, final KeyCode button) {
    }
    
    public boolean longPress(final Element actor, final float x, final float y) {
        return false;
    }
    
    public void fling(final InputEvent event, final float velocityX, final float velocityY, final KeyCode button) {
    }
    
    public void pan(final InputEvent event, final float x, final float y, final float deltaX, final float deltaY) {
    }
    
    public void zoom(final InputEvent event, final float initialDistance, final float distance) {
    }
    
    public void pinch(final InputEvent event, final Vec2 initialPointer1, final Vec2 initialPointer2, final Vec2 pointer1, final Vec2 pointer2) {
    }
    
    public GestureDetector getGestureDetector() {
        return this.detector;
    }
    
    public Element getTouchDownTarget() {
        return this.touchDownTarget;
    }
    
    static {
        tmpCoords = new Vec2();
        tmpCoords2 = new Vec2();
    }
}
