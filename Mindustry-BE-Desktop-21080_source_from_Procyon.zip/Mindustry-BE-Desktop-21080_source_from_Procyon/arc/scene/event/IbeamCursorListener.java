// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

import arc.Graphics;
import arc.Core;
import arc.scene.Element;

public class IbeamCursorListener extends ClickListener
{
    @Override
    public void enter(final InputEvent event, final float x, final float y, final int pointer, final Element fromActor) {
        super.enter(event, x, y, pointer, fromActor);
        if (pointer == -1 && event.targetActor.visible) {
            Core.graphics.cursor(Graphics.Cursor.SystemCursor.ibeam);
        }
    }
    
    @Override
    public void exit(final InputEvent event, final float x, final float y, final int pointer, final Element toActor) {
        super.exit(event, x, y, pointer, toActor);
        if (pointer == -1) {
            Core.graphics.restoreCursor();
        }
    }
}
