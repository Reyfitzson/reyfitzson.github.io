// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

import arc.util.Tmp;
import arc.scene.Element;
import arc.Core;
import arc.util.Time;
import arc.input.KeyCode;

public class ClickListener extends InputListener
{
    public static float visualPressedDuration;
    public static Runnable clicked;
    protected float tapSquareSize;
    protected float touchDownX;
    protected float touchDownY;
    protected int pressedPointer;
    protected KeyCode pressedButton;
    protected KeyCode button;
    protected boolean pressed;
    protected boolean over;
    protected boolean overAny;
    protected boolean cancelled;
    protected long visualPressedTime;
    protected long tapCountInterval;
    protected int tapCount;
    protected long lastTapTime;
    protected boolean stop;
    
    public ClickListener() {
        this.tapSquareSize = 14.0f;
        this.touchDownX = -1.0f;
        this.touchDownY = -1.0f;
        this.pressedPointer = -1;
        this.button = KeyCode.mouseLeft;
        this.tapCountInterval = 400000000L;
        this.stop = false;
    }
    
    public ClickListener(final KeyCode button) {
        this.tapSquareSize = 14.0f;
        this.touchDownX = -1.0f;
        this.touchDownY = -1.0f;
        this.pressedPointer = -1;
        this.button = KeyCode.mouseLeft;
        this.tapCountInterval = 400000000L;
        this.stop = false;
        this.button = button;
    }
    
    @Override
    public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
        if (this.pressed) {
            return false;
        }
        if (pointer == 0 && this.button != null && button != this.button) {
            return false;
        }
        this.pressed = true;
        this.pressedPointer = pointer;
        this.pressedButton = button;
        this.touchDownX = x;
        this.touchDownY = y;
        this.visualPressedTime = Time.millis() + (long)(ClickListener.visualPressedDuration * 1000.0f);
        return true;
    }
    
    @Override
    public void touchDragged(final InputEvent event, final float x, final float y, final int pointer) {
        if (pointer != this.pressedPointer || this.cancelled) {
            return;
        }
        this.pressed = this.isOver(event.listenerActor, x, y);
        if (this.pressed && pointer == 0 && this.button != null && !Core.input.keyDown(this.button)) {
            this.pressed = false;
        }
        if (!this.pressed) {
            this.invalidateTapSquare();
        }
    }
    
    @Override
    public void touchUp(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
        if (pointer == this.pressedPointer) {
            if (!this.cancelled) {
                boolean touchUpOver = this.isOver(event.listenerActor, x, y);
                if (touchUpOver && pointer == 0 && this.button != null && button != this.button) {
                    touchUpOver = false;
                }
                if (touchUpOver) {
                    final long time = Time.nanos();
                    if (time - this.lastTapTime > this.tapCountInterval) {
                        this.tapCount = 0;
                    }
                    ++this.tapCount;
                    this.lastTapTime = time;
                    ClickListener.clicked.run();
                    this.clicked(event, x, y);
                }
            }
            this.pressed = false;
            this.pressedPointer = -1;
            this.pressedButton = null;
            this.cancelled = false;
        }
    }
    
    @Override
    public void enter(final InputEvent event, final float x, final float y, final int pointer, final Element fromActor) {
        if (pointer == -1 && !this.cancelled) {
            this.over = true;
        }
        if (!this.cancelled) {
            this.overAny = true;
        }
    }
    
    @Override
    public void exit(final InputEvent event, final float x, final float y, final int pointer, final Element toActor) {
        if (pointer == -1 && !this.cancelled) {
            this.over = false;
        }
        if (!this.cancelled) {
            this.overAny = false;
        }
    }
    
    public void cancel() {
        if (this.pressedPointer == -1) {
            return;
        }
        this.cancelled = true;
        this.pressed = false;
    }
    
    public void clicked(final InputEvent event, final float x, final float y) {
    }
    
    public boolean isOver(final Element element, final float x, final float y) {
        element.localToStageCoordinates(Tmp.v1.set(x, y));
        final Element hit = Core.scene.hit(Tmp.v1.x, Tmp.v1.y, true);
        return hit != null && hit.isDescendantOf(element);
    }
    
    public boolean inTapSquare(final float x, final float y) {
        return (this.touchDownX != -1.0f || this.touchDownY != -1.0f) && Math.abs(x - this.touchDownX) < this.tapSquareSize && Math.abs(y - this.touchDownY) < this.tapSquareSize;
    }
    
    public boolean inTapSquare() {
        return this.touchDownX != -1.0f;
    }
    
    public void invalidateTapSquare() {
        this.touchDownX = -1.0f;
        this.touchDownY = -1.0f;
    }
    
    public boolean isPressed() {
        return this.pressed;
    }
    
    public boolean isVisualPressed() {
        if (this.pressed) {
            return true;
        }
        if (this.visualPressedTime <= 0L) {
            return false;
        }
        if (this.visualPressedTime > Time.millis()) {
            return true;
        }
        this.visualPressedTime = 0L;
        return false;
    }
    
    public boolean isOver() {
        return this.over || this.pressed;
    }
    
    public float getTapSquareSize() {
        return this.tapSquareSize;
    }
    
    public void setTapSquareSize(final float halfTapSquareSize) {
        this.tapSquareSize = halfTapSquareSize;
    }
    
    public void setTapCountInterval(final float tapCountInterval) {
        this.tapCountInterval = (long)(tapCountInterval * 1.0E9f);
    }
    
    public int getTapCount() {
        return this.tapCount;
    }
    
    public void setTapCount(final int tapCount) {
        this.tapCount = tapCount;
    }
    
    public float getTouchDownX() {
        return this.touchDownX;
    }
    
    public float getTouchDownY() {
        return this.touchDownY;
    }
    
    public KeyCode getPressedButton() {
        return this.pressedButton;
    }
    
    public int getPressedPointer() {
        return this.pressedPointer;
    }
    
    public KeyCode getButton() {
        return this.button;
    }
    
    public void setButton(final KeyCode button) {
        this.button = button;
    }
    
    static {
        ClickListener.visualPressedDuration = 0.1f;
        ClickListener.clicked = (() -> {});
    }
}
