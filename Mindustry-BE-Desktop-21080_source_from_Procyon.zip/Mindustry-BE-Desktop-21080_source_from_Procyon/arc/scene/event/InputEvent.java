// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

import arc.math.geom.Vec2;
import arc.scene.Element;
import arc.input.KeyCode;

public class InputEvent extends SceneEvent
{
    public InputEventType type;
    public float stageX;
    public float stageY;
    public int pointer;
    public float scrollAmountX;
    public float scrollAmountY;
    public KeyCode keyCode;
    public char character;
    public Element relatedActor;
    
    @Override
    public void reset() {
        super.reset();
        this.relatedActor = null;
    }
    
    public Vec2 toCoordinates(final Element actor, final Vec2 actorCoords) {
        actorCoords.set(this.stageX, this.stageY);
        actor.stageToLocalCoordinates(actorCoords);
        return actorCoords;
    }
    
    public boolean isTouchFocusCancel() {
        return this.stageX == -2.14748365E9f || this.stageY == -2.14748365E9f;
    }
    
    @Override
    public String toString() {
        return this.type.toString();
    }
    
    public enum InputEventType
    {
        touchDown, 
        touchUp, 
        touchDragged, 
        mouseMoved, 
        enter, 
        exit, 
        scrolled, 
        keyDown, 
        keyUp, 
        keyTyped;
    }
}
