// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

import arc.scene.Element;
import arc.input.KeyCode;
import arc.math.geom.Vec2;

public class InputListener implements EventListener
{
    private static final Vec2 tmpCoords;
    
    @Override
    public boolean handle(final SceneEvent e) {
        if (!(e instanceof InputEvent)) {
            return false;
        }
        final InputEvent event = (InputEvent)e;
        switch (event.type) {
            case keyDown: {
                return this.keyDown(event, event.keyCode);
            }
            case keyUp: {
                return this.keyUp(event, event.keyCode);
            }
            case keyTyped: {
                return this.keyTyped(event, event.character);
            }
            default: {
                event.toCoordinates(event.listenerActor, InputListener.tmpCoords);
                switch (event.type) {
                    case touchDown: {
                        return this.touchDown(event, InputListener.tmpCoords.x, InputListener.tmpCoords.y, event.pointer, event.keyCode);
                    }
                    case touchUp: {
                        this.touchUp(event, InputListener.tmpCoords.x, InputListener.tmpCoords.y, event.pointer, event.keyCode);
                        return true;
                    }
                    case touchDragged: {
                        this.touchDragged(event, InputListener.tmpCoords.x, InputListener.tmpCoords.y, event.pointer);
                        return true;
                    }
                    case mouseMoved: {
                        return this.mouseMoved(event, InputListener.tmpCoords.x, InputListener.tmpCoords.y);
                    }
                    case scrolled: {
                        return this.scrolled(event, InputListener.tmpCoords.x, InputListener.tmpCoords.y, event.scrollAmountX, event.scrollAmountY);
                    }
                    case enter: {
                        this.enter(event, InputListener.tmpCoords.x, InputListener.tmpCoords.y, event.pointer, event.relatedActor);
                        return false;
                    }
                    case exit: {
                        this.exit(event, InputListener.tmpCoords.x, InputListener.tmpCoords.y, event.pointer, event.relatedActor);
                        return false;
                    }
                    default: {
                        return false;
                    }
                }
                break;
            }
        }
    }
    
    public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
        return false;
    }
    
    public void touchUp(final InputEvent event, final float x, final float y, final int pointer, final KeyCode button) {
    }
    
    public void touchDragged(final InputEvent event, final float x, final float y, final int pointer) {
    }
    
    public boolean mouseMoved(final InputEvent event, final float x, final float y) {
        return false;
    }
    
    public void enter(final InputEvent event, final float x, final float y, final int pointer, final Element fromActor) {
    }
    
    public void exit(final InputEvent event, final float x, final float y, final int pointer, final Element toActor) {
    }
    
    public boolean scrolled(final InputEvent event, final float x, final float y, final float amountX, final float amountY) {
        return false;
    }
    
    public boolean keyDown(final InputEvent event, final KeyCode keycode) {
        return false;
    }
    
    public boolean keyUp(final InputEvent event, final KeyCode keycode) {
        return false;
    }
    
    public boolean keyTyped(final InputEvent event, final char character) {
        return false;
    }
    
    static {
        tmpCoords = new Vec2();
    }
}
