// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

public class DragListener extends InputListener
{
    private float tapSquareSize;
    private float touchDownX;
    private float touchDownY;
    private float stageTouchDownX;
    private float stageTouchDownY;
    private int pressedPointer;
    private int button;
    private boolean dragging;
    private float deltaX;
    private float deltaY;
    
    public DragListener() {
        this.tapSquareSize = 14.0f;
        this.touchDownX = -1.0f;
        this.touchDownY = -1.0f;
        this.stageTouchDownX = -1.0f;
        this.stageTouchDownY = -1.0f;
        this.pressedPointer = -1;
    }
    
    public boolean touchDown(final InputEvent event, final float x, final float y, final int pointer, final int button) {
        if (this.pressedPointer != -1) {
            return false;
        }
        if (pointer == 0 && this.button != -1 && button != this.button) {
            return false;
        }
        this.pressedPointer = pointer;
        this.touchDownX = x;
        this.touchDownY = y;
        this.stageTouchDownX = event.stageX;
        this.stageTouchDownY = event.stageY;
        return true;
    }
    
    @Override
    public void touchDragged(final InputEvent event, final float x, final float y, final int pointer) {
        if (pointer != this.pressedPointer) {
            return;
        }
        if (!this.dragging && (Math.abs(this.touchDownX - x) > this.tapSquareSize || Math.abs(this.touchDownY - y) > this.tapSquareSize)) {
            this.dragging = true;
            this.dragStart(event, x, y, pointer);
            this.deltaX = x;
            this.deltaY = y;
        }
        if (this.dragging) {
            this.deltaX -= x;
            this.deltaY -= y;
            this.drag(event, x, y, pointer);
            this.deltaX = x;
            this.deltaY = y;
        }
    }
    
    public void touchUp(final InputEvent event, final float x, final float y, final int pointer, final int button) {
        if (pointer == this.pressedPointer) {
            if (this.dragging) {
                this.dragStop(event, x, y, pointer);
            }
            this.cancel();
        }
    }
    
    public void dragStart(final InputEvent event, final float x, final float y, final int pointer) {
    }
    
    public void drag(final InputEvent event, final float x, final float y, final int pointer) {
    }
    
    public void dragStop(final InputEvent event, final float x, final float y, final int pointer) {
    }
    
    public void cancel() {
        this.dragging = false;
        this.pressedPointer = -1;
    }
    
    public boolean isDragging() {
        return this.dragging;
    }
    
    public float getTapSquareSize() {
        return this.tapSquareSize;
    }
    
    public void setTapSquareSize(final float halfTapSquareSize) {
        this.tapSquareSize = halfTapSquareSize;
    }
    
    public float getTouchDownX() {
        return this.touchDownX;
    }
    
    public float getTouchDownY() {
        return this.touchDownY;
    }
    
    public float getStageTouchDownX() {
        return this.stageTouchDownX;
    }
    
    public float getStageTouchDownY() {
        return this.stageTouchDownY;
    }
    
    public float getDeltaX() {
        return this.deltaX;
    }
    
    public float getDeltaY() {
        return this.deltaY;
    }
    
    public int getButton() {
        return this.button;
    }
    
    public void setButton(final int button) {
        this.button = button;
    }
}
