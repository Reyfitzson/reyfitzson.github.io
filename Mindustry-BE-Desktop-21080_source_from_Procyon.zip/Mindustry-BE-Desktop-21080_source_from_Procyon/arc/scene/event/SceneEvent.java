// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

import arc.scene.Element;
import arc.util.pooling.Pool;

public class SceneEvent implements Pool.Poolable
{
    public Element targetActor;
    public Element listenerActor;
    public boolean capture;
    public boolean bubbles;
    public boolean handled;
    public boolean stopped;
    public boolean cancelled;
    
    public SceneEvent() {
        this.bubbles = true;
    }
    
    public void handle() {
        this.handled = true;
    }
    
    public void cancel() {
        this.cancelled = true;
        this.stopped = true;
        this.handled = true;
    }
    
    public void stop() {
        this.stopped = true;
    }
    
    @Override
    public void reset() {
        this.targetActor = null;
        this.listenerActor = null;
        this.capture = false;
        this.bubbles = true;
        this.handled = false;
        this.stopped = false;
        this.cancelled = false;
    }
}
