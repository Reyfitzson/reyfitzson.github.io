// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

public class VisibilityEvent extends SceneEvent
{
    private boolean hide;
    
    public VisibilityEvent() {
    }
    
    public VisibilityEvent(final boolean hide) {
        this.hide = hide;
    }
    
    public boolean isHide() {
        return this.hide;
    }
}
