// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

public interface EventListener
{
    boolean handle(final SceneEvent p0);
}
