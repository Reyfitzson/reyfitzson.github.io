// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

public class VisibilityListener implements EventListener
{
    @Override
    public boolean handle(final SceneEvent event) {
        if (!(event instanceof VisibilityEvent)) {
            return false;
        }
        if (((VisibilityEvent)event).isHide()) {
            return this.hidden();
        }
        return this.shown();
    }
    
    public boolean shown() {
        return false;
    }
    
    public boolean hidden() {
        return false;
    }
}
