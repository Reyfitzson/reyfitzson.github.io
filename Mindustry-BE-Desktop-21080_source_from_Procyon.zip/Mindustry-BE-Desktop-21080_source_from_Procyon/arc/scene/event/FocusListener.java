// 
// Decompiled by Procyon v0.5.36
// 

package arc.scene.event;

import arc.scene.Element;

public abstract class FocusListener implements EventListener
{
    @Override
    public boolean handle(final SceneEvent event) {
        if (!(event instanceof FocusEvent)) {
            return false;
        }
        final FocusEvent focusEvent = (FocusEvent)event;
        switch (focusEvent.type) {
            case keyboard: {
                this.keyboardFocusChanged(focusEvent, event.targetActor, focusEvent.focused);
                break;
            }
            case scroll: {
                this.scrollFocusChanged(focusEvent, event.targetActor, focusEvent.focused);
                break;
            }
        }
        return false;
    }
    
    public void keyboardFocusChanged(final FocusEvent event, final Element element, final boolean focused) {
    }
    
    public void scrollFocusChanged(final FocusEvent event, final Element element, final boolean focused) {
    }
    
    public static class FocusEvent extends SceneEvent
    {
        public boolean focused;
        public Type type;
        public Element relatedActor;
        
        @Override
        public void reset() {
            super.reset();
            this.relatedActor = null;
        }
        
        public enum Type
        {
            keyboard, 
            scroll;
        }
    }
}
