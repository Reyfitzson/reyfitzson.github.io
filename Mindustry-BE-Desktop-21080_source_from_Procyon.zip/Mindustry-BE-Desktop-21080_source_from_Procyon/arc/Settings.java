// 
// Decompiled by Procyon v0.5.36
// 

package arc;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;
import arc.func.Prov;
import arc.util.serialization.BaseJsonWriter;
import java.io.OutputStream;
import arc.util.serialization.UBJsonWriter;
import arc.util.OS;
import java.util.Iterator;
import java.util.Map;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.DataInputStream;
import arc.util.Log;
import arc.util.Strings;
import arc.util.serialization.Json;
import arc.util.serialization.UBJsonReader;
import arc.util.io.ReusableByteInStream;
import java.io.ByteArrayOutputStream;
import arc.func.Cons;
import java.util.HashMap;
import arc.struct.ObjectMap;
import arc.files.Fi;

public class Settings
{
    protected static final byte typeBool = 0;
    protected static final byte typeInt = 1;
    protected static final byte typeLong = 2;
    protected static final byte typeFloat = 3;
    protected static final byte typeString = 4;
    protected static final byte typeBinary = 5;
    protected Fi dataDirectory;
    protected String appName;
    protected ObjectMap<String, Object> defaults;
    protected HashMap<String, Object> values;
    protected boolean modified;
    protected Cons<Throwable> errorHandler;
    protected boolean hasErrored;
    protected boolean shouldAutosave;
    protected boolean loaded;
    protected ByteArrayOutputStream byteStream;
    protected ReusableByteInStream byteInputStream;
    protected UBJsonReader ureader;
    protected Json json;
    
    public Settings() {
        this.appName = "app";
        this.defaults = new ObjectMap<String, Object>();
        this.values = new HashMap<String, Object>();
        this.shouldAutosave = true;
        this.loaded = false;
        this.byteStream = new ByteArrayOutputStream(32);
        this.byteInputStream = new ReusableByteInStream();
        this.ureader = new UBJsonReader();
        this.json = new Json();
    }
    
    public void setJson(final Json json) {
        this.json = json;
    }
    
    public String getAppName() {
        return this.appName;
    }
    
    public void setAppName(final String name) {
        this.appName = name;
    }
    
    public void setErrorHandler(final Cons<Throwable> handler) {
        this.errorHandler = handler;
    }
    
    public void setAutosave(final boolean autosave) {
        this.shouldAutosave = autosave;
    }
    
    public boolean modified() {
        return this.modified;
    }
    
    public synchronized void load() {
        try {
            this.loadValues();
            Core.keybinds.load();
        }
        catch (Throwable error) {
            this.writeLog("Error in load: " + Strings.getStackTrace(error));
            if (this.errorHandler == null) {
                throw error;
            }
            if (!this.hasErrored) {
                this.errorHandler.get(error);
            }
            this.hasErrored = true;
        }
        this.loaded = true;
    }
    
    public synchronized void forceSave() {
        if (!this.loaded) {
            return;
        }
        try {
            Core.keybinds.save();
            this.saveValues();
        }
        catch (Throwable error) {
            this.writeLog("Error in forceSave to " + this.getSettingsFile() + ":\n" + Strings.getStackTrace(error));
            if (this.errorHandler == null) {
                throw error;
            }
            if (!this.hasErrored) {
                this.errorHandler.get(error);
            }
            this.hasErrored = true;
        }
        this.modified = false;
    }
    
    public synchronized void manualSave() {
        if (this.loaded) {
            this.forceSave();
        }
    }
    
    public synchronized void autosave() {
        if (this.modified && this.shouldAutosave) {
            this.forceSave();
            this.modified = false;
        }
    }
    
    public synchronized void loadValues() {
        if (!this.getSettingsFile().exists() && !this.getBackupSettingsFile().exists()) {
            this.writeLog("No settings files found: " + this.getSettingsFile().absolutePath() + " and " + this.getBackupSettingsFile().absolutePath());
            return;
        }
        try {
            this.loadValues(this.getSettingsFile());
            this.writeLog("Loaded " + this.values.size() + " values");
            this.getSettingsFile().copyTo(this.getBackupSettingsFile());
            this.writeLog("Backed up " + this.getSettingsFile() + " to " + this.getBackupSettingsFile() + " (" + this.getSettingsFile().length() + " bytes)");
        }
        catch (Throwable e) {
            Log.err("Failed to load base settings file, attempting to load backup.", e);
            this.writeLog("Failed to load base file " + this.getSettingsFile() + ":\n" + Strings.getStackTrace(e));
            try {
                this.loadValues(this.getBackupSettingsFile());
                this.getBackupSettingsFile().copyTo(this.getSettingsFile());
                Log.info((Object)"Loaded backup settings file.");
                this.writeLog("Loaded backup settings file after load failure. Length: " + this.getBackupSettingsFile().length());
            }
            catch (Throwable e2) {
                this.writeLog("Failed to load backup file " + this.getSettingsFile() + ":\n" + Strings.getStackTrace(e2));
                Log.err("Failed to load backup settings file.", e2);
            }
        }
    }
    
    public synchronized void loadValues(final Fi file) throws IOException {
        try (final DataInputStream stream = new DataInputStream(file.read(8192))) {
            for (int amount = stream.readInt(), i = 0; i < amount; ++i) {
                final String key = stream.readUTF();
                final byte type = stream.readByte();
                switch (type) {
                    case 0: {
                        this.values.put(key, stream.readBoolean());
                        break;
                    }
                    case 1: {
                        this.values.put(key, stream.readInt());
                        break;
                    }
                    case 2: {
                        this.values.put(key, stream.readLong());
                        break;
                    }
                    case 3: {
                        this.values.put(key, stream.readFloat());
                        break;
                    }
                    case 4: {
                        this.values.put(key, stream.readUTF());
                        break;
                    }
                    case 5: {
                        final int length = stream.readInt();
                        final byte[] bytes = new byte[length];
                        stream.read(bytes);
                        this.values.put(key, bytes);
                        break;
                    }
                }
            }
        }
    }
    
    public synchronized void saveValues() {
        final Fi file = this.getSettingsFile();
        try (final DataOutputStream stream = new DataOutputStream(file.write(false, 8192))) {
            stream.writeInt(this.values.size());
            for (final Map.Entry<String, Object> entry : this.values.entrySet()) {
                stream.writeUTF(entry.getKey());
                final Object value = entry.getValue();
                if (value instanceof Boolean) {
                    stream.writeByte(0);
                    stream.writeBoolean((boolean)value);
                }
                else if (value instanceof Integer) {
                    stream.writeByte(1);
                    stream.writeInt((int)value);
                }
                else if (value instanceof Long) {
                    stream.writeByte(2);
                    stream.writeLong((long)value);
                }
                else if (value instanceof Float) {
                    stream.writeByte(3);
                    stream.writeFloat((float)value);
                }
                else if (value instanceof String) {
                    stream.writeByte(4);
                    stream.writeUTF((String)value);
                }
                else {
                    if (!(value instanceof byte[])) {
                        continue;
                    }
                    stream.writeByte(5);
                    stream.writeInt(((byte[])value).length);
                    stream.write((byte[])value);
                }
            }
        }
        catch (Throwable e) {
            file.delete();
            throw new RuntimeException("Error writing preferences: " + file, e);
        }
        this.writeLog("Saving " + this.values.size() + " values; " + file.length() + " bytes");
    }
    
    public Fi getSettingsFile() {
        return this.getDataDirectory().child("settings.bin");
    }
    
    public Fi getBackupSettingsFile() {
        return this.getDataDirectory().child("settings_backup.bin");
    }
    
    public Fi getDataDirectory() {
        return (this.dataDirectory == null) ? Core.files.absolute(OS.getAppDataDirectoryString(this.appName)) : this.dataDirectory;
    }
    
    public void setDataDirectory(final Fi file) {
        this.dataDirectory = file;
    }
    
    public synchronized void defaults(final Object... objects) {
        for (int i = 0; i < objects.length; i += 2) {
            this.defaults.put((String)objects[i], objects[i + 1]);
        }
    }
    
    public synchronized void clear() {
        this.values.clear();
    }
    
    public synchronized Object getDefault(final String name) {
        return this.defaults.get(name);
    }
    
    public synchronized boolean has(final String name) {
        return this.values.containsKey(name);
    }
    
    public synchronized Object get(final String name, final Object def) {
        return this.values.containsKey(name) ? this.values.get(name) : def;
    }
    
    public boolean isModified() {
        return this.modified;
    }
    
    public synchronized void putJson(final String name, final Object value) {
        this.putJson(name, null, value);
    }
    
    public synchronized void putJson(final String name, final Class<?> elementType, final Object value) {
        this.byteStream.reset();
        this.json.setWriter(new UBJsonWriter(this.byteStream));
        this.json.writeValue(value, (value == null) ? null : value.getClass(), elementType);
        this.put(name, this.byteStream.toByteArray());
        this.modified = true;
    }
    
    public synchronized <T> T getJson(final String name, final Class<T> type, final Class elementType, final Prov<T> def) {
        try {
            if (!this.has(name)) {
                return def.get();
            }
            this.byteInputStream.setBytes(this.getBytes(name));
            return this.json.readValue(type, elementType, this.ureader.parse(this.byteInputStream));
        }
        catch (Throwable e) {
            this.writeLog("Failed to write JSON key=" + name + " type=" + type + ":\n" + Strings.getStackTrace(e));
            return def.get();
        }
    }
    
    public <T> T getJson(final String name, final Class<T> type, final Prov<T> def) {
        return this.getJson(name, type, null, def);
    }
    
    public float getFloat(final String name, final float def) {
        return (float)this.get(name, def);
    }
    
    public long getLong(final String name, final long def) {
        return (long)this.get(name, def);
    }
    
    public Long getLong(final String name) {
        return this.getLong(name, 0L);
    }
    
    public int getInt(final String name, final int def) {
        return (int)this.get(name, def);
    }
    
    public boolean getBool(final String name, final boolean def) {
        return (boolean)this.get(name, def);
    }
    
    public byte[] getBytes(final String name, final byte[] def) {
        return (byte[])this.get(name, def);
    }
    
    public String getString(final String name, final String def) {
        return (String)this.get(name, def);
    }
    
    public float getFloat(final String name) {
        return this.getFloat(name, this.defaults.get(name, 0.0f));
    }
    
    public int getInt(final String name) {
        return this.getInt(name, this.defaults.get(name, 0));
    }
    
    public boolean getBool(final String name) {
        return this.getBool(name, this.defaults.get(name, false));
    }
    
    public void getBoolOnce(final String name, final Runnable run) {
        if (!this.getBool(name, false)) {
            run.run();
            this.put(name, true);
        }
    }
    
    public boolean getBoolOnce(final String name) {
        final boolean val = this.getBool(name, false);
        this.put(name, true);
        return val;
    }
    
    public byte[] getBytes(final String name) {
        return this.getBytes(name, this.defaults.get(name));
    }
    
    public String getString(final String name) {
        return this.getString(name, this.defaults.get(name));
    }
    
    public void putAll(final ObjectMap<String, Object> map) {
        for (final ObjectMap.Entry<String, Object> entry : map.entries()) {
            this.put(entry.key, entry.value);
        }
    }
    
    public synchronized void put(final String name, final Object object) {
        if (object instanceof Float || object instanceof Integer || object instanceof Boolean || object instanceof Long || object instanceof String || object instanceof byte[]) {
            this.values.put(name, object);
            this.modified = true;
            return;
        }
        throw new IllegalArgumentException("Invalid object stored: " + ((object == null) ? null : object.getClass()) + ". Use putObject() for serialization.");
    }
    
    public synchronized void remove(final String name) {
        this.values.remove(name);
        this.modified = true;
    }
    
    public synchronized Iterable<String> keys() {
        return this.values.keySet();
    }
    
    public synchronized int keySize() {
        return this.values.size();
    }
    
    void writeLog(final String text) {
        try {
            final Fi log = this.getDataDirectory().child("settings.log");
            log.writeString("[" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()) + "] " + text + "\n", true);
        }
        catch (Throwable t) {
            Log.err("Failed to write settings log", t);
        }
    }
}
