// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets;

public class AssetLoaderParameters<T>
{
    public LoadedCallback loadedCallback;
    
    public AssetLoaderParameters() {
    }
    
    public AssetLoaderParameters(final LoadedCallback loadedCallback) {
        this.loadedCallback = loadedCallback;
    }
    
    public interface LoadedCallback
    {
        void finishedLoading(final AssetManager p0, final String p1, final Class p2);
    }
}
