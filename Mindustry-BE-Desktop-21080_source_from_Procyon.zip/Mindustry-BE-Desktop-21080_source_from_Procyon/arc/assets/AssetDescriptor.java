// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets;

import arc.util.Nullable;
import arc.func.Cons;
import arc.files.Fi;

public class AssetDescriptor<T>
{
    public final String fileName;
    public final Class<T> type;
    public final AssetLoaderParameters params;
    public Fi file;
    public Cons<T> loaded;
    @Nullable
    public Cons<Throwable> errored;
    
    public AssetDescriptor(final Class<T> assetType) {
        this(assetType.getSimpleName(), assetType, null);
    }
    
    public AssetDescriptor(final String fileName, final Class<T> assetType) {
        this(fileName, assetType, null);
    }
    
    public AssetDescriptor(final Fi file, final Class<T> assetType) {
        this(file, assetType, null);
    }
    
    public AssetDescriptor(final String fileName, final Class<T> assetType, final AssetLoaderParameters<T> params) {
        this.loaded = (t -> {});
        this.errored = null;
        this.fileName = fileName.replaceAll("\\\\", "/");
        this.type = assetType;
        this.params = params;
    }
    
    public AssetDescriptor(final Fi file, final Class<T> assetType, final AssetLoaderParameters<T> params) {
        this.loaded = (t -> {});
        this.errored = null;
        this.fileName = file.path().replaceAll("\\\\", "/");
        this.file = file;
        this.type = assetType;
        this.params = params;
    }
    
    @Override
    public String toString() {
        return this.fileName + ", " + this.type.getName();
    }
}
