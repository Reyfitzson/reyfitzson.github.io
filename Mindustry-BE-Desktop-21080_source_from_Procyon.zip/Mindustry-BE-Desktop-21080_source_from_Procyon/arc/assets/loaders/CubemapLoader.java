// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets.loaders;

import arc.graphics.Texture;
import arc.graphics.CubemapData;
import arc.assets.AssetLoaderParameters;
import arc.assets.AssetDescriptor;
import arc.struct.Seq;
import arc.graphics.Pixmap;
import arc.files.Fi;
import arc.assets.AssetManager;
import arc.graphics.Cubemap;

public class CubemapLoader extends AsynchronousAssetLoader<Cubemap, CubemapParameter>
{
    CubemapLoaderInfo info;
    
    public CubemapLoader(final FileHandleResolver resolver) {
        super(resolver);
        this.info = new CubemapLoaderInfo();
    }
    
    @Override
    public void loadAsync(final AssetManager manager, final String fileName, final Fi file, final CubemapParameter parameter) {
        this.info.filename = fileName;
        if (parameter == null || parameter.cubemapData == null) {
            final Pixmap pixmap = null;
            Pixmap.Format format = null;
            final boolean genMipMaps = false;
            this.info.cubemap = null;
            if (parameter != null) {
                format = parameter.format;
                this.info.cubemap = parameter.cubemap;
            }
        }
        else {
            this.info.data = parameter.cubemapData;
            this.info.cubemap = parameter.cubemap;
        }
        if (!this.info.data.isPrepared()) {
            this.info.data.prepare();
        }
    }
    
    @Override
    public Cubemap loadSync(final AssetManager manager, final String fileName, final Fi file, final CubemapParameter parameter) {
        if (this.info == null) {
            return null;
        }
        Cubemap cubemap = this.info.cubemap;
        if (cubemap != null) {
            cubemap.load(this.info.data);
        }
        else {
            cubemap = new Cubemap(this.info.data);
        }
        if (parameter != null) {
            cubemap.setFilter(parameter.minFilter, parameter.magFilter);
            cubemap.setWrap(parameter.wrapU, parameter.wrapV);
        }
        return cubemap;
    }
    
    @Override
    public Seq<AssetDescriptor> getDependencies(final String fileName, final Fi file, final CubemapParameter parameter) {
        return null;
    }
    
    public static class CubemapLoaderInfo
    {
        String filename;
        CubemapData data;
        Cubemap cubemap;
    }
    
    public static class CubemapParameter extends AssetLoaderParameters<Cubemap>
    {
        public Pixmap.Format format;
        public Cubemap cubemap;
        public CubemapData cubemapData;
        public Texture.TextureFilter minFilter;
        public Texture.TextureFilter magFilter;
        public Texture.TextureWrap wrapU;
        public Texture.TextureWrap wrapV;
        
        public CubemapParameter() {
            this.format = null;
            this.cubemap = null;
            this.cubemapData = null;
            this.minFilter = Texture.TextureFilter.nearest;
            this.magFilter = Texture.TextureFilter.nearest;
            this.wrapU = Texture.TextureWrap.clampToEdge;
            this.wrapV = Texture.TextureWrap.clampToEdge;
        }
    }
}
