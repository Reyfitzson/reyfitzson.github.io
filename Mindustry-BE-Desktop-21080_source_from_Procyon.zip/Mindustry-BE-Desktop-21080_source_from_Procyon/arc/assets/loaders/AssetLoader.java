// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets.loaders;

import arc.assets.AssetDescriptor;
import arc.struct.Seq;
import arc.files.Fi;
import arc.assets.AssetLoaderParameters;

public abstract class AssetLoader<T, P extends AssetLoaderParameters<T>>
{
    private FileHandleResolver resolver;
    
    public AssetLoader(final FileHandleResolver resolver) {
        this.resolver = resolver;
    }
    
    public Fi resolve(final String fileName) {
        return this.resolver.resolve(fileName);
    }
    
    public abstract Seq<AssetDescriptor> getDependencies(final String p0, final Fi p1, final P p2);
}
