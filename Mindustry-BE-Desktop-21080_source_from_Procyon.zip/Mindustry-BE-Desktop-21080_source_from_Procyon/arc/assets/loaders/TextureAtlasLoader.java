// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets.loaders;

import arc.assets.AssetLoaderParameters;
import arc.assets.AssetDescriptor;
import arc.struct.Seq;
import java.util.Iterator;
import arc.graphics.Texture;
import arc.files.Fi;
import arc.assets.AssetManager;
import arc.graphics.g2d.TextureAtlas;

public class TextureAtlasLoader extends SynchronousAssetLoader<TextureAtlas, TextureAtlasParameter>
{
    TextureAtlas.TextureAtlasData data;
    
    public TextureAtlasLoader(final FileHandleResolver resolver) {
        super(resolver);
    }
    
    @Override
    public TextureAtlas load(final AssetManager assetManager, final String fileName, final Fi file, final TextureAtlasParameter parameter) {
        for (final TextureAtlas.TextureAtlasData.AtlasPage page : this.data.getPages()) {
            page.texture = assetManager.get(page.textureFile.path().replaceAll("\\\\", "/"), Texture.class);
        }
        final TextureAtlas atlas = new TextureAtlas(this.data);
        this.data = null;
        return atlas;
    }
    
    @Override
    public Seq<AssetDescriptor> getDependencies(final String fileName, final Fi atlasFile, final TextureAtlasParameter parameter) {
        final Fi imgDir = atlasFile.parent();
        if (parameter != null) {
            this.data = new TextureAtlas.TextureAtlasData(atlasFile, imgDir, parameter.flip);
        }
        else {
            this.data = new TextureAtlas.TextureAtlasData(atlasFile, imgDir, false);
        }
        final Seq<AssetDescriptor> dependencies = new Seq<AssetDescriptor>();
        for (final TextureAtlas.TextureAtlasData.AtlasPage page : this.data.getPages()) {
            final TextureLoader.TextureParameter params = new TextureLoader.TextureParameter();
            params.format = page.format;
            params.genMipMaps = page.useMipMaps;
            params.minFilter = page.minFilter;
            params.magFilter = page.magFilter;
            dependencies.add(new AssetDescriptor(page.textureFile, Texture.class, params));
        }
        return dependencies;
    }
    
    public static class TextureAtlasParameter extends AssetLoaderParameters<TextureAtlas>
    {
        public boolean flip;
        
        public TextureAtlasParameter() {
            this.flip = false;
        }
        
        public TextureAtlasParameter(final boolean flip) {
            this.flip = false;
            this.flip = flip;
        }
        
        public TextureAtlasParameter(final LoadedCallback loadedCallback) {
            super(loadedCallback);
            this.flip = false;
        }
    }
}
