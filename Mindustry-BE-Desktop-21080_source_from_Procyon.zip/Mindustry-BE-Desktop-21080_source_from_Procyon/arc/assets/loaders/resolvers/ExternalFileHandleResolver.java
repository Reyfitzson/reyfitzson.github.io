// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets.loaders.resolvers;

import arc.Core;
import arc.files.Fi;
import arc.assets.loaders.FileHandleResolver;

public class ExternalFileHandleResolver implements FileHandleResolver
{
    @Override
    public Fi resolve(final String fileName) {
        return Core.files.external(fileName);
    }
}
