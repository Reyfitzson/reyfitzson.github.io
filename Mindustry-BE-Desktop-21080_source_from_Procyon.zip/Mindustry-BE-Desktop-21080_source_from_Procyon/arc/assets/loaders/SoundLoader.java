// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets.loaders;

import arc.util.Nullable;
import arc.assets.AssetLoaderParameters;
import arc.assets.AssetDescriptor;
import arc.struct.Seq;
import arc.Core;
import arc.files.Fi;
import arc.assets.AssetManager;
import arc.audio.Sound;

public class SoundLoader extends AsynchronousAssetLoader<Sound, SoundParameter>
{
    private Sound sound;
    
    public SoundLoader(final FileHandleResolver resolver) {
        super(resolver);
    }
    
    protected Sound getLoadedSound() {
        return this.sound;
    }
    
    @Override
    public void loadAsync(final AssetManager manager, final String fileName, final Fi file, final SoundParameter parameter) {
        if (parameter != null && parameter.sound != null) {
            (this.sound = parameter.sound).load(file);
        }
        else {
            this.sound = Core.audio.newSound(file);
        }
    }
    
    @Override
    public Sound loadSync(final AssetManager manager, final String fileName, final Fi file, final SoundParameter parameter) {
        final Sound sound = this.sound;
        this.sound = null;
        return sound;
    }
    
    @Override
    public Seq<AssetDescriptor> getDependencies(final String fileName, final Fi file, final SoundParameter parameter) {
        return null;
    }
    
    public static class SoundParameter extends AssetLoaderParameters<Sound>
    {
        @Nullable
        public Sound sound;
        
        public SoundParameter() {
        }
        
        public SoundParameter(@Nullable final Sound sound) {
            this.sound = sound;
        }
        
        public SoundParameter(final LoadedCallback loadedCallback) {
            super(loadedCallback);
        }
    }
}
