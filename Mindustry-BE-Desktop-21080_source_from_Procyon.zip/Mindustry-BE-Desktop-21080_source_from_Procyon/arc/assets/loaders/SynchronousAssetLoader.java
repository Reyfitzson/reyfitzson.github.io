// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets.loaders;

import arc.files.Fi;
import arc.assets.AssetManager;
import arc.assets.AssetLoaderParameters;

public abstract class SynchronousAssetLoader<T, P extends AssetLoaderParameters<T>> extends AssetLoader<T, P>
{
    public SynchronousAssetLoader(final FileHandleResolver resolver) {
        super(resolver);
    }
    
    public abstract T load(final AssetManager p0, final String p1, final Fi p2, final P p3);
}
