// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets.loaders;

import arc.assets.AssetLoaderParameters;
import arc.util.Log;
import arc.assets.AssetManager;
import arc.assets.AssetDescriptor;
import arc.struct.Seq;
import arc.files.Fi;
import arc.graphics.gl.Shader;

public class ShaderProgramLoader extends AsynchronousAssetLoader<Shader, ShaderProgramParameter>
{
    private String vertexFileSuffix;
    private String fragmentFileSuffix;
    
    public ShaderProgramLoader(final FileHandleResolver resolver) {
        super(resolver);
        this.vertexFileSuffix = ".vert";
        this.fragmentFileSuffix = ".frag";
    }
    
    public ShaderProgramLoader(final FileHandleResolver resolver, final String vertexFileSuffix, final String fragmentFileSuffix) {
        super(resolver);
        this.vertexFileSuffix = ".vert";
        this.fragmentFileSuffix = ".frag";
        this.vertexFileSuffix = vertexFileSuffix;
        this.fragmentFileSuffix = fragmentFileSuffix;
    }
    
    @Override
    public Seq<AssetDescriptor> getDependencies(final String fileName, final Fi file, final ShaderProgramParameter parameter) {
        return null;
    }
    
    @Override
    public void loadAsync(final AssetManager manager, final String fileName, final Fi file, final ShaderProgramParameter parameter) {
    }
    
    @Override
    public Shader loadSync(final AssetManager manager, final String fileName, final Fi file, final ShaderProgramParameter parameter) {
        String vertFileName = null;
        String fragFileName = null;
        if (parameter != null) {
            if (parameter.vertexFile != null) {
                vertFileName = parameter.vertexFile;
            }
            if (parameter.fragmentFile != null) {
                fragFileName = parameter.fragmentFile;
            }
        }
        if (vertFileName == null && fileName.endsWith(this.fragmentFileSuffix)) {
            vertFileName = fileName.substring(0, fileName.length() - this.fragmentFileSuffix.length()) + this.vertexFileSuffix;
        }
        if (fragFileName == null && fileName.endsWith(this.vertexFileSuffix)) {
            fragFileName = fileName.substring(0, fileName.length() - this.vertexFileSuffix.length()) + this.fragmentFileSuffix;
        }
        final Fi vertexFile = (vertFileName == null) ? file : this.resolve(vertFileName);
        final Fi fragmentFile = (fragFileName == null) ? file : this.resolve(fragFileName);
        String vertexCode = vertexFile.readString();
        String fragmentCode = vertexFile.equals(fragmentFile) ? vertexCode : fragmentFile.readString();
        if (parameter != null) {
            if (parameter.prependVertexCode != null) {
                vertexCode = parameter.prependVertexCode + vertexCode;
            }
            if (parameter.prependFragmentCode != null) {
                fragmentCode = parameter.prependFragmentCode + fragmentCode;
            }
        }
        final Shader shader = new Shader(vertexCode, fragmentCode);
        if ((parameter == null || parameter.logOnCompileFailure) && !shader.isCompiled()) {
            Log.err("Shader " + fileName + " failed to compile:\n" + shader.getLog(), new Object[0]);
        }
        return shader;
    }
    
    public static class ShaderProgramParameter extends AssetLoaderParameters<Shader>
    {
        public String vertexFile;
        public String fragmentFile;
        public boolean logOnCompileFailure;
        public String prependVertexCode;
        public String prependFragmentCode;
        
        public ShaderProgramParameter() {
            this.logOnCompileFailure = true;
        }
    }
}
