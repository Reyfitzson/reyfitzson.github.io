// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets.loaders;

import arc.assets.AssetLoaderParameters;
import arc.assets.AssetDescriptor;
import arc.struct.Seq;
import arc.files.Fi;
import arc.assets.AssetManager;
import arc.graphics.Pixmap;

public class PixmapLoader extends AsynchronousAssetLoader<Pixmap, PixmapParameter>
{
    Pixmap pixmap;
    
    public PixmapLoader(final FileHandleResolver resolver) {
        super(resolver);
    }
    
    @Override
    public void loadAsync(final AssetManager manager, final String fileName, final Fi file, final PixmapParameter parameter) {
        this.pixmap = null;
        this.pixmap = new Pixmap(file);
    }
    
    @Override
    public Pixmap loadSync(final AssetManager manager, final String fileName, final Fi file, final PixmapParameter parameter) {
        final Pixmap pixmap = this.pixmap;
        this.pixmap = null;
        return pixmap;
    }
    
    @Override
    public Seq<AssetDescriptor> getDependencies(final String fileName, final Fi file, final PixmapParameter parameter) {
        return null;
    }
    
    public static class PixmapParameter extends AssetLoaderParameters<Pixmap>
    {
    }
}
