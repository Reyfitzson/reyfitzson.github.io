// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets.loaders;

import arc.util.Nullable;
import arc.assets.AssetLoaderParameters;
import arc.assets.AssetDescriptor;
import arc.struct.Seq;
import arc.Core;
import arc.util.Log;
import arc.files.Fi;
import arc.assets.AssetManager;
import arc.audio.Music;

public class MusicLoader extends AsynchronousAssetLoader<Music, MusicParameter>
{
    private Music music;
    
    public MusicLoader(final FileHandleResolver resolver) {
        super(resolver);
    }
    
    protected Music getLoadedMusic() {
        return this.music;
    }
    
    @Override
    public void loadAsync(final AssetManager manager, final String fileName, final Fi file, final MusicParameter parameter) {
        if (parameter != null && parameter.music != null) {
            try {
                (this.music = parameter.music).load(file);
            }
            catch (Exception e) {
                Log.err(e);
            }
        }
        else {
            this.music = Core.audio.newMusic(file);
        }
    }
    
    @Override
    public Music loadSync(final AssetManager manager, final String fileName, final Fi file, final MusicParameter parameter) {
        final Music music = this.music;
        this.music = null;
        return music;
    }
    
    @Override
    public Seq<AssetDescriptor> getDependencies(final String fileName, final Fi file, final MusicParameter parameter) {
        return null;
    }
    
    public static class MusicParameter extends AssetLoaderParameters<Music>
    {
        @Nullable
        public Music music;
        
        public MusicParameter() {
        }
        
        public MusicParameter(@Nullable final Music music) {
            this.music = music;
        }
        
        public MusicParameter(final LoadedCallback loadedCallback) {
            super(loadedCallback);
        }
    }
}
