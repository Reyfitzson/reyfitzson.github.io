// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets.loaders;

import arc.util.ArcRuntimeException;
import arc.graphics.g2d.TextureRegion;
import arc.assets.AssetManager;
import arc.assets.AssetLoaderParameters;
import arc.graphics.Texture;
import arc.graphics.g2d.TextureAtlas;
import arc.assets.AssetDescriptor;
import arc.struct.Seq;
import arc.files.Fi;
import arc.graphics.g2d.Font;

public class FontLoader extends AsynchronousAssetLoader<Font, FontParameter>
{
    Font.FontData data;
    
    public FontLoader(final FileHandleResolver resolver) {
        super(resolver);
    }
    
    @Override
    public Seq<AssetDescriptor> getDependencies(final String fileName, final Fi file, final FontParameter parameter) {
        final Seq<AssetDescriptor> deps = new Seq<AssetDescriptor>();
        if (parameter != null && parameter.fontData != null) {
            this.data = parameter.fontData;
            return deps;
        }
        this.data = new Font.FontData(file, parameter != null && parameter.flip);
        if (parameter != null && parameter.atlasName != null) {
            deps.add(new AssetDescriptor(parameter.atlasName, TextureAtlas.class));
        }
        else {
            for (int i = 0; i < this.data.getImagePaths().length; ++i) {
                final String path = this.data.getImagePath(i);
                final Fi resolved = this.resolve(path);
                final TextureLoader.TextureParameter textureParams = new TextureLoader.TextureParameter();
                if (parameter != null) {
                    textureParams.genMipMaps = parameter.genMipMaps;
                    textureParams.minFilter = parameter.minFilter;
                    textureParams.magFilter = parameter.magFilter;
                }
                final AssetDescriptor descriptor = new AssetDescriptor(resolved, (Class<T>)Texture.class, (AssetLoaderParameters<T>)textureParams);
                deps.add(descriptor);
            }
        }
        return deps;
    }
    
    @Override
    public void loadAsync(final AssetManager manager, final String fileName, final Fi file, final FontParameter parameter) {
    }
    
    @Override
    public Font loadSync(final AssetManager manager, final String fileName, final Fi file, final FontParameter parameter) {
        if (parameter == null || parameter.atlasName == null) {
            final int n = this.data.getImagePaths().length;
            final Seq<TextureRegion> regs = new Seq<TextureRegion>(n);
            for (int i = 0; i < n; ++i) {
                regs.add(new TextureRegion(manager.get(this.data.getImagePath(i), Texture.class)));
            }
            return new Font(this.data, regs, true);
        }
        final TextureAtlas atlas = manager.get(parameter.atlasName, TextureAtlas.class);
        final String name = file.sibling(this.data.imagePaths[0]).nameWithoutExtension();
        final TextureAtlas.AtlasRegion region = atlas.find(name);
        if (region == null) {
            throw new ArcRuntimeException("Could not find font region " + name + " in atlas " + parameter.atlasName);
        }
        return new Font(file, region);
    }
    
    public static class FontParameter extends AssetLoaderParameters<Font>
    {
        public boolean flip;
        public boolean genMipMaps;
        public Texture.TextureFilter minFilter;
        public Texture.TextureFilter magFilter;
        public Font.FontData fontData;
        public String atlasName;
        
        public FontParameter() {
            this.flip = false;
            this.genMipMaps = false;
            this.minFilter = Texture.TextureFilter.nearest;
            this.magFilter = Texture.TextureFilter.nearest;
            this.fontData = null;
            this.atlasName = null;
        }
    }
}
