// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets.loaders;

import arc.files.Fi;

public interface FileHandleResolver
{
    Fi resolve(final String p0);
}
