// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets;

public interface AssetErrorListener
{
    void error(final AssetDescriptor p0, final Throwable p1);
}
