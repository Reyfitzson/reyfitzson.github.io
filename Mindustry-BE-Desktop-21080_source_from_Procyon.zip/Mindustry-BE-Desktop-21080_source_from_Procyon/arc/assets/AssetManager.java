// 
// Decompiled by Procyon v0.5.36
// 

package arc.assets;

import arc.struct.ObjectIntMap;
import arc.util.async.Threads;
import arc.util.Time;
import arc.assets.loaders.AsynchronousAssetLoader;
import arc.files.Fi;
import arc.assets.loaders.CustomLoader;
import java.util.Iterator;
import arc.util.ArcRuntimeException;
import arc.assets.loaders.CubemapLoader;
import arc.graphics.Cubemap;
import arc.assets.loaders.ShaderProgramLoader;
import arc.graphics.gl.Shader;
import arc.assets.loaders.I18NBundleLoader;
import arc.util.I18NBundle;
import arc.assets.loaders.TextureLoader;
import arc.graphics.Texture;
import arc.assets.loaders.TextureAtlasLoader;
import arc.graphics.g2d.TextureAtlas;
import arc.assets.loaders.SoundLoader;
import arc.audio.Sound;
import arc.assets.loaders.PixmapLoader;
import arc.graphics.Pixmap;
import arc.assets.loaders.MusicLoader;
import arc.audio.Music;
import arc.assets.loaders.FontLoader;
import arc.graphics.g2d.Font;
import arc.assets.loaders.resolvers.InternalFileHandleResolver;
import arc.assets.loaders.FileHandleResolver;
import java.util.Stack;
import arc.util.async.AsyncExecutor;
import arc.assets.loaders.AssetLoader;
import arc.struct.ObjectSet;
import arc.struct.Seq;
import arc.struct.ObjectMap;
import arc.util.Disposable;

public class AssetManager implements Disposable
{
    final ObjectMap<Class, ObjectMap<String, RefCountedContainer>> assets;
    final ObjectMap<String, Class> assetTypes;
    final ObjectMap<String, Seq<String>> assetDependencies;
    final ObjectSet<String> injected;
    final ObjectMap<Class, ObjectMap<String, AssetLoader>> loaders;
    final Seq<AssetDescriptor> loadQueue;
    final AsyncExecutor executor;
    final Stack<AssetLoadingTask> tasks;
    final FileHandleResolver resolver;
    AssetErrorListener listener;
    int loaded;
    int toLoad;
    int peakTasks;
    
    public AssetManager() {
        this(new InternalFileHandleResolver());
    }
    
    public AssetManager(final FileHandleResolver resolver) {
        this(resolver, true);
    }
    
    public AssetManager(final FileHandleResolver resolver, final boolean defaultLoaders) {
        this.assets = new ObjectMap<Class, ObjectMap<String, RefCountedContainer>>();
        this.assetTypes = new ObjectMap<String, Class>();
        this.assetDependencies = new ObjectMap<String, Seq<String>>();
        this.injected = new ObjectSet<String>();
        this.loaders = new ObjectMap<Class, ObjectMap<String, AssetLoader>>();
        this.loadQueue = new Seq<AssetDescriptor>();
        this.tasks = new Stack<AssetLoadingTask>();
        this.listener = null;
        this.loaded = 0;
        this.toLoad = 0;
        this.peakTasks = 0;
        this.resolver = resolver;
        if (defaultLoaders) {
            this.setLoader(Font.class, (AssetLoader<Font, AssetLoaderParameters>)new FontLoader(resolver));
            this.setLoader(Music.class, (AssetLoader<Music, AssetLoaderParameters>)new MusicLoader(resolver));
            this.setLoader(Pixmap.class, (AssetLoader<Pixmap, AssetLoaderParameters>)new PixmapLoader(resolver));
            this.setLoader(Sound.class, (AssetLoader<Sound, AssetLoaderParameters>)new SoundLoader(resolver));
            this.setLoader(TextureAtlas.class, (AssetLoader<TextureAtlas, AssetLoaderParameters>)new TextureAtlasLoader(resolver));
            this.setLoader(Texture.class, (AssetLoader<Texture, AssetLoaderParameters>)new TextureLoader(resolver));
            this.setLoader(I18NBundle.class, (AssetLoader<I18NBundle, AssetLoaderParameters>)new I18NBundleLoader(resolver));
            this.setLoader(Shader.class, (AssetLoader<Shader, AssetLoaderParameters>)new ShaderProgramLoader(resolver));
            this.setLoader(Cubemap.class, (AssetLoader<Cubemap, AssetLoaderParameters>)new CubemapLoader(resolver));
        }
        this.executor = new AsyncExecutor(1);
    }
    
    public FileHandleResolver getFileHandleResolver() {
        return this.resolver;
    }
    
    public synchronized <T> T get(final String fileName) {
        final Class<T> type = this.assetTypes.get(fileName);
        if (type == null) {
            throw new ArcRuntimeException("Asset not loaded: " + fileName);
        }
        final ObjectMap<String, RefCountedContainer> assetsByType = this.assets.get(type);
        if (assetsByType == null) {
            throw new ArcRuntimeException("Asset not loaded: " + fileName);
        }
        final RefCountedContainer assetContainer = assetsByType.get(fileName);
        if (assetContainer == null) {
            throw new ArcRuntimeException("Asset not loaded: " + fileName);
        }
        final T asset = assetContainer.getObject(type);
        if (asset == null) {
            throw new ArcRuntimeException("Asset not loaded: " + fileName);
        }
        return asset;
    }
    
    public synchronized <T> T get(final String fileName, final Class<T> type) {
        final ObjectMap<String, RefCountedContainer> assetsByType = this.assets.get(type);
        if (assetsByType == null) {
            throw new ArcRuntimeException("Asset not loaded: " + fileName);
        }
        final RefCountedContainer assetContainer = assetsByType.get(fileName);
        if (assetContainer == null) {
            throw new ArcRuntimeException("Asset not loaded: " + fileName);
        }
        final T asset = assetContainer.getObject(type);
        if (asset == null) {
            throw new ArcRuntimeException("Asset not loaded: " + fileName);
        }
        return asset;
    }
    
    public synchronized <T> Seq<T> getAll(final Class<T> type, final Seq<T> out) {
        final ObjectMap<String, RefCountedContainer> assetsByType = this.assets.get(type);
        if (assetsByType != null) {
            for (final ObjectMap.Entry<String, RefCountedContainer> asset : assetsByType.entries()) {
                out.add(asset.value.getObject(type));
            }
        }
        return out;
    }
    
    public synchronized <T> T get(final AssetDescriptor<T> assetDescriptor) {
        return this.get(assetDescriptor.fileName, assetDescriptor.type);
    }
    
    public synchronized boolean contains(final String fileName) {
        if (this.tasks.size() > 0 && this.tasks.firstElement().assetDesc.fileName.equals(fileName)) {
            return true;
        }
        for (int i = 0; i < this.loadQueue.size; ++i) {
            if (this.loadQueue.get(i).fileName.equals(fileName)) {
                return true;
            }
        }
        return this.isLoaded(fileName);
    }
    
    public synchronized boolean contains(final String fileName, final Class type) {
        if (this.tasks.size() > 0) {
            final AssetDescriptor assetDesc = this.tasks.firstElement().assetDesc;
            if (assetDesc.type == type && assetDesc.fileName.equals(fileName)) {
                return true;
            }
        }
        for (int i = 0; i < this.loadQueue.size; ++i) {
            final AssetDescriptor assetDesc2 = this.loadQueue.get(i);
            if (assetDesc2.type == type && assetDesc2.fileName.equals(fileName)) {
                return true;
            }
        }
        return this.isLoaded(fileName, type);
    }
    
    public synchronized void unload(final String fileName) {
        if (this.tasks.size() > 0) {
            final AssetLoadingTask currAsset = this.tasks.firstElement();
            if (currAsset.assetDesc.fileName.equals(fileName)) {
                currAsset.cancel = true;
                return;
            }
        }
        int foundIndex = -1;
        for (int i = 0; i < this.loadQueue.size; ++i) {
            if (this.loadQueue.get(i).fileName.equals(fileName)) {
                foundIndex = i;
                break;
            }
        }
        if (foundIndex != -1) {
            --this.toLoad;
            this.loadQueue.remove(foundIndex);
            return;
        }
        final Class type = this.assetTypes.get(fileName);
        if (type == null) {
            throw new ArcRuntimeException("Asset not loaded: " + fileName);
        }
        final RefCountedContainer assetRef = this.assets.get(type).get(fileName);
        assetRef.decRefCount();
        if (assetRef.getRefCount() <= 0) {
            if (assetRef.getObject(Object.class) instanceof Disposable) {
                assetRef.getObject((Class<Disposable>)Object.class).dispose();
            }
            this.assetTypes.remove(fileName);
            this.assets.get(type).remove(fileName);
        }
        final Seq<String> dependencies = this.assetDependencies.get(fileName);
        if (dependencies != null) {
            for (final String dependency : dependencies) {
                if (this.isLoaded(dependency)) {
                    this.unload(dependency);
                }
            }
        }
        if (assetRef.getRefCount() <= 0) {
            this.assetDependencies.remove(fileName);
        }
    }
    
    public synchronized <T> boolean containsAsset(final T asset) {
        final ObjectMap<String, RefCountedContainer> assetsByType = this.assets.get(asset.getClass());
        if (assetsByType == null) {
            return false;
        }
        for (final String fileName : assetsByType.keys()) {
            final T otherAsset = assetsByType.get(fileName).getObject((Class<T>)Object.class);
            if (otherAsset == asset || asset.equals(otherAsset)) {
                return true;
            }
        }
        return false;
    }
    
    public synchronized <T> String getAssetFileName(final T asset) {
        for (final Class assetType : this.assets.keys()) {
            final ObjectMap<String, RefCountedContainer> assetsByType = this.assets.get(assetType);
            for (final String fileName : assetsByType.keys()) {
                final T otherAsset = assetsByType.get(fileName).getObject((Class<T>)Object.class);
                if (otherAsset == asset || asset.equals(otherAsset)) {
                    return fileName;
                }
            }
        }
        return null;
    }
    
    public synchronized boolean isLoaded(final AssetDescriptor assetDesc) {
        return this.isLoaded(assetDesc.fileName);
    }
    
    public synchronized boolean isLoaded(final String fileName) {
        return fileName != null && this.assetTypes.containsKey(fileName);
    }
    
    public synchronized boolean isLoaded(final String fileName, final Class type) {
        final ObjectMap<String, RefCountedContainer> assetsByType = this.assets.get(type);
        if (assetsByType == null) {
            return false;
        }
        final RefCountedContainer assetContainer = assetsByType.get(fileName);
        return assetContainer != null && assetContainer.getObject((Class<Object>)type) != null;
    }
    
    public <T> AssetLoader getLoader(final Class<T> type) {
        return this.getLoader(type, null);
    }
    
    public <T> AssetLoader getLoader(final Class<T> type, final String fileName) {
        final ObjectMap<String, AssetLoader> loaders = this.loaders.get(type);
        if (loaders == null || loaders.size < 1) {
            return null;
        }
        if (fileName == null) {
            return loaders.get("");
        }
        AssetLoader result = null;
        int l = -1;
        for (final ObjectMap.Entry<String, AssetLoader> entry : loaders.entries()) {
            if (entry.key.length() > l && fileName.endsWith(entry.key)) {
                result = entry.value;
                l = entry.key.length();
            }
        }
        return result;
    }
    
    public synchronized <T> AssetDescriptor load(final String fileName, final Class<T> type) {
        return this.load(fileName, type, null);
    }
    
    public synchronized AssetDescriptor loadRun(final String name, final Class<?> type, final Runnable loadasync) {
        return this.loadRun(name, type, loadasync, () -> {});
    }
    
    public synchronized AssetDescriptor loadRun(final String name, final Class<?> type, final Runnable loadasync, final Runnable loadsync) {
        if (this.getLoader(type) == null) {
            this.setLoader(type, (AssetLoader<?, AssetLoaderParameters>)new CustomLoader() {
                @Override
                public void loadAsync(final AssetManager manager, final String fileName, final Fi file, final AssetLoaderParameters parameter) {
                    loadasync.run();
                }
                
                @Override
                public Object loadSync(final AssetManager manager, final String fileName, final Fi file, final AssetLoaderParameters parameter) {
                    loadsync.run();
                    return super.loadSync(manager, fileName, file, parameter);
                }
            });
            return this.load(name, type, null);
        }
        throw new IllegalArgumentException("Class already registered or loaded: " + type);
    }
    
    public synchronized AssetDescriptor load(final Loadable load) {
        if (this.getLoader(load.getClass()) == null) {
            this.setLoader((Class<Object>)load.getClass(), (AssetLoader<Object, AssetLoaderParameters>)new AsynchronousAssetLoader(new InternalFileHandleResolver()) {
                @Override
                public void loadAsync(final AssetManager manager, final String fileName, final Fi file, final AssetLoaderParameters parameter) {
                    load.loadAsync();
                }
                
                @Override
                public Object loadSync(final AssetManager manager, final String fileName, final Fi file, final AssetLoaderParameters parameter) {
                    load.loadSync();
                    return load;
                }
                
                @Override
                public Seq<AssetDescriptor> getDependencies(final String fileName, final Fi file, final AssetLoaderParameters parameter) {
                    return load.getDependencies();
                }
            });
        }
        return this.load(load.getName(), load.getClass(), null);
    }
    
    public synchronized <T> AssetDescriptor load(final String fileName, final Class<T> type, final AssetLoaderParameters<T> parameter) {
        final AssetLoader loader = this.getLoader(type, fileName);
        if (loader == null) {
            throw new ArcRuntimeException("No loader for type: " + type.getSimpleName());
        }
        if (this.loadQueue.size == 0) {
            this.loaded = 0;
            this.toLoad = 0;
            this.peakTasks = 0;
        }
        for (int i = 0; i < this.loadQueue.size; ++i) {
            final AssetDescriptor desc = this.loadQueue.get(i);
            if (desc.fileName.equals(fileName) && !desc.type.equals(type)) {
                throw new ArcRuntimeException("Asset with name '" + fileName + "' already in preload queue, but has different type (expected: " + type.getSimpleName() + ", found: " + desc.type.getSimpleName() + ")");
            }
        }
        for (int i = 0; i < this.tasks.size(); ++i) {
            final AssetDescriptor desc = this.tasks.get(i).assetDesc;
            if (desc.fileName.equals(fileName) && !desc.type.equals(type)) {
                throw new ArcRuntimeException("Asset with name '" + fileName + "' already in task list, but has different type (expected: " + type.getSimpleName() + ", found: " + desc.type.getSimpleName() + ")");
            }
        }
        final Class otherType = this.assetTypes.get(fileName);
        if (otherType != null && !otherType.equals(type)) {
            throw new ArcRuntimeException("Asset with name '" + fileName + "' already loaded, but has different type (expected: " + type.getSimpleName() + ", found: " + otherType.getSimpleName() + ")");
        }
        ++this.toLoad;
        final AssetDescriptor assetDesc = new AssetDescriptor(fileName, (Class<T>)type, (AssetLoaderParameters<T>)parameter);
        this.loadQueue.add(assetDesc);
        return assetDesc;
    }
    
    public synchronized AssetDescriptor load(final AssetDescriptor desc) {
        return this.load(desc.fileName, desc.type, desc.params);
    }
    
    public synchronized boolean update() {
        try {
            if (this.tasks.size() == 0) {
                while (this.loadQueue.size != 0 && this.tasks.size() == 0) {
                    this.nextTask();
                }
                if (this.tasks.size() == 0) {
                    return true;
                }
            }
            return this.updateTask() && this.loadQueue.size == 0 && this.tasks.size() == 0;
        }
        catch (Throwable t) {
            this.handleTaskError(t);
            return this.loadQueue.size == 0;
        }
    }
    
    public synchronized AssetDescriptor getCurrentLoading() {
        if (this.tasks.size() > 0) {
            return this.tasks.firstElement().assetDesc;
        }
        return null;
    }
    
    public boolean update(final int millis) {
        final long endTime = Time.millis() + millis;
        boolean done;
        while (true) {
            done = this.update();
            if (done || Time.millis() > endTime) {
                break;
            }
            Threads.yield();
        }
        return done;
    }
    
    public synchronized boolean isFinished() {
        return this.loadQueue.size == 0 && this.tasks.size() == 0;
    }
    
    public void finishLoading() {
        while (!this.update()) {
            Threads.yield();
        }
    }
    
    public void finishLoadingAsset(final AssetDescriptor assetDesc) {
        this.finishLoadingAsset(assetDesc.fileName);
    }
    
    public void finishLoadingAsset(final String fileName) {
        while (!this.isLoaded(fileName)) {
            this.update();
            Threads.yield();
        }
    }
    
    synchronized void injectDependencies(final String parentAssetFilename, final Seq<AssetDescriptor> dependendAssetDescs) {
        final ObjectSet<String> injected = this.injected;
        for (final AssetDescriptor desc : dependendAssetDescs) {
            if (injected.contains(desc.fileName)) {
                continue;
            }
            injected.add(desc.fileName);
            this.injectDependency(parentAssetFilename, desc);
        }
        injected.clear();
    }
    
    private synchronized void injectDependency(final String parentAssetFilename, final AssetDescriptor dependendAssetDesc) {
        Seq<String> dependencies = this.assetDependencies.get(parentAssetFilename);
        if (dependencies == null) {
            dependencies = new Seq<String>();
            this.assetDependencies.put(parentAssetFilename, dependencies);
        }
        dependencies.add(dependendAssetDesc.fileName);
        if (this.isLoaded(dependendAssetDesc.fileName)) {
            final Class type = this.assetTypes.get(dependendAssetDesc.fileName);
            final RefCountedContainer assetRef = this.assets.get(type).get(dependendAssetDesc.fileName);
            assetRef.incRefCount();
            this.incrementRefCountedDependencies(dependendAssetDesc.fileName);
        }
        else {
            this.addTask(dependendAssetDesc);
        }
    }
    
    private void nextTask() {
        final AssetDescriptor assetDesc = this.loadQueue.remove(0);
        if (this.isLoaded(assetDesc.fileName)) {
            final Class type = this.assetTypes.get(assetDesc.fileName);
            final RefCountedContainer assetRef = this.assets.get(type).get(assetDesc.fileName);
            assetRef.incRefCount();
            this.incrementRefCountedDependencies(assetDesc.fileName);
            if (assetDesc.params != null && assetDesc.params.loadedCallback != null) {
                assetDesc.params.loadedCallback.finishedLoading(this, assetDesc.fileName, assetDesc.type);
            }
            ++this.loaded;
        }
        else {
            this.addTask(assetDesc);
        }
    }
    
    private void addTask(final AssetDescriptor assetDesc) {
        final AssetLoader loader = this.getLoader(assetDesc.type, assetDesc.fileName);
        if (loader == null) {
            throw new ArcRuntimeException("No loader for type: " + assetDesc.type.getSimpleName());
        }
        this.tasks.push(new AssetLoadingTask(this, assetDesc, loader, this.executor));
        ++this.peakTasks;
    }
    
    protected <T> void addAsset(final String fileName, final Class<T> type, final T asset) {
        this.assetTypes.put(fileName, type);
        ObjectMap<String, RefCountedContainer> typeToAssets = this.assets.get(type);
        if (typeToAssets == null) {
            typeToAssets = new ObjectMap<String, RefCountedContainer>();
            this.assets.put(type, typeToAssets);
        }
        typeToAssets.put(fileName, new RefCountedContainer(asset));
    }
    
    private boolean updateTask() {
        final AssetLoadingTask task = this.tasks.peek();
        boolean complete = true;
        try {
            complete = (task.cancel || task.update());
        }
        catch (RuntimeException ex) {
            task.cancel = true;
            this.taskFailed(task.assetDesc, ex);
        }
        if (!complete) {
            return false;
        }
        if (this.tasks.size() == 1) {
            ++this.loaded;
            this.peakTasks = 0;
        }
        this.tasks.pop();
        if (task.cancel) {
            return true;
        }
        this.addAsset(task.assetDesc.fileName, (Class<Object>)task.assetDesc.type, task.getAsset());
        if (task.assetDesc.params != null && task.assetDesc.params.loadedCallback != null) {
            task.assetDesc.params.loadedCallback.finishedLoading(this, task.assetDesc.fileName, task.assetDesc.type);
        }
        task.assetDesc.loaded.get((T)task.getAsset());
        return true;
    }
    
    protected void taskFailed(final AssetDescriptor assetDesc, final RuntimeException ex) {
        throw ex;
    }
    
    private void incrementRefCountedDependencies(final String parent) {
        final Seq<String> dependencies = this.assetDependencies.get(parent);
        if (dependencies == null) {
            return;
        }
        for (final String dependency : dependencies) {
            final Class type = this.assetTypes.get(dependency);
            final RefCountedContainer assetRef = this.assets.get(type).get(dependency);
            assetRef.incRefCount();
            this.incrementRefCountedDependencies(dependency);
        }
    }
    
    private void handleTaskError(final Throwable t) {
        if (this.tasks.isEmpty()) {
            throw new ArcRuntimeException(t);
        }
        final AssetLoadingTask task = this.tasks.pop();
        final AssetDescriptor assetDesc = task.assetDesc;
        if (task.dependenciesLoaded && task.dependencies != null) {
            for (final AssetDescriptor desc : task.dependencies) {
                this.unload(desc.fileName);
            }
        }
        this.tasks.clear();
        if (this.listener != null) {
            this.listener.error(assetDesc, t);
        }
        if (assetDesc.errored != null) {
            assetDesc.errored.get(t);
            return;
        }
        throw new ArcRuntimeException(t);
    }
    
    public synchronized <T, P extends AssetLoaderParameters<T>> void setLoader(final Class<T> type, final AssetLoader<T, P> loader) {
        this.setLoader(type, null, loader);
    }
    
    public synchronized <T, P extends AssetLoaderParameters<T>> void setLoader(final Class<T> type, final String suffix, final AssetLoader<T, P> loader) {
        if (type == null) {
            throw new IllegalArgumentException("type cannot be null.");
        }
        if (loader == null) {
            throw new IllegalArgumentException("loader cannot be null.");
        }
        ObjectMap<String, AssetLoader> loaders = this.loaders.get(type);
        if (loaders == null) {
            this.loaders.put(type, loaders = new ObjectMap<String, AssetLoader>());
        }
        loaders.put((suffix == null) ? "" : suffix, loader);
    }
    
    public synchronized int getLoadedAssets() {
        return this.assetTypes.size;
    }
    
    public synchronized int getQueuedAssets() {
        return this.loadQueue.size + this.tasks.size();
    }
    
    public synchronized float getProgress() {
        if (this.toLoad == 0) {
            return 1.0f;
        }
        float fractionalLoaded = (float)this.loaded;
        if (this.peakTasks > 0) {
            fractionalLoaded += (this.peakTasks - this.tasks.size()) / (float)this.peakTasks;
        }
        return Math.min(1.0f, fractionalLoaded / this.toLoad);
    }
    
    public synchronized void setErrorListener(final AssetErrorListener listener) {
        this.listener = listener;
    }
    
    @Override
    public synchronized void dispose() {
        this.clear();
        this.executor.dispose();
    }
    
    public synchronized void clear() {
        this.loadQueue.clear();
        while (!this.update()) {}
        final ObjectIntMap<String> dependencyCount = new ObjectIntMap<String>();
        while (this.assetTypes.size > 0) {
            dependencyCount.clear();
            final Seq<String> assets = this.assetTypes.keys().toSeq();
            for (final String asset : assets) {
                dependencyCount.put(asset, 0);
            }
            for (final String asset : assets) {
                final Seq<String> dependencies = this.assetDependencies.get(asset);
                if (dependencies == null) {
                    continue;
                }
                for (final String dependency : dependencies) {
                    int count = dependencyCount.get(dependency, 0);
                    ++count;
                    dependencyCount.put(dependency, count);
                }
            }
            for (final String asset : assets) {
                if (dependencyCount.get(asset, 0) == 0) {
                    this.unload(asset);
                }
            }
        }
        this.assets.clear();
        this.assetTypes.clear();
        this.assetDependencies.clear();
        this.loaded = 0;
        this.toLoad = 0;
        this.peakTasks = 0;
        this.loadQueue.clear();
        this.tasks.clear();
    }
    
    public synchronized int getReferenceCount(final String fileName) {
        final Class type = this.assetTypes.get(fileName);
        if (type == null) {
            throw new ArcRuntimeException("Asset not loaded: " + fileName);
        }
        return this.assets.get(type).get(fileName).getRefCount();
    }
    
    public synchronized void setReferenceCount(final String fileName, final int refCount) {
        final Class type = this.assetTypes.get(fileName);
        if (type == null) {
            throw new ArcRuntimeException("Asset not loaded: " + fileName);
        }
        this.assets.get(type).get(fileName).setRefCount(refCount);
    }
    
    public synchronized String getDiagnostics() {
        final StringBuilder sb = new StringBuilder();
        for (final String fileName : this.assetTypes.keys()) {
            sb.append(fileName);
            sb.append(", ");
            final Class type = this.assetTypes.get(fileName);
            final RefCountedContainer assetRef = this.assets.get(type).get(fileName);
            final Seq<String> dependencies = this.assetDependencies.get(fileName);
            sb.append(type.getSimpleName());
            sb.append(", refs: ");
            sb.append(assetRef.getRefCount());
            if (dependencies != null) {
                sb.append(", deps: [");
                for (final String dep : dependencies) {
                    sb.append(dep);
                    sb.append(",");
                }
                sb.append("]");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
    
    public synchronized Seq<String> getAssetNames() {
        return this.assetTypes.keys().toSeq();
    }
    
    public synchronized Seq<String> getDependencies(final String fileName) {
        return this.assetDependencies.get(fileName);
    }
    
    public synchronized Class getAssetType(final String fileName) {
        return this.assetTypes.get(fileName);
    }
}
