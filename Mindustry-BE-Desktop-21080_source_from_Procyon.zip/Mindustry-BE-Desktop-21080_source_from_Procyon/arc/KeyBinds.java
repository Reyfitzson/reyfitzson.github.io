// 
// Decompiled by Procyon v0.5.36
// 

package arc;

import arc.math.Mathf;
import arc.struct.OrderedMap;
import arc.input.KeyCode;
import arc.input.InputDevice;
import arc.struct.ObjectMap;

public class KeyBinds
{
    private Section defaultSection;
    private ObjectMap<KeyBind, ObjectMap<InputDevice.DeviceType, Axis>> defaultCache;
    private KeyBind[] definitions;
    private Section[] sections;
    
    public KeyBinds() {
        this.defaultCache = new ObjectMap<KeyBind, ObjectMap<InputDevice.DeviceType, Axis>>();
    }
    
    public void setDefaults(final KeyBind[] defs, final Section... sectionArr) {
        this.defaultSection = new Section("default");
        this.definitions = defs;
        (this.sections = new Section[sectionArr.length + 1])[0] = this.defaultSection;
        System.arraycopy(sectionArr, 0, this.sections, 1, sectionArr.length);
        for (final KeyBind def : defs) {
            this.defaultCache.put(def, new ObjectMap<InputDevice.DeviceType, Axis>());
            for (final InputDevice.DeviceType type : InputDevice.DeviceType.values()) {
                this.defaultCache.get(def).put(type, (def.defaultValue(type) instanceof Axis) ? ((Axis)def.defaultValue(type)) : new Axis((KeyCode)def.defaultValue(type)));
            }
        }
    }
    
    void save() {
        if (this.definitions == null) {
            return;
        }
        for (final Section sec : this.sections) {
            for (final InputDevice.DeviceType type : sec.binds.keys()) {
                for (final ObjectMap.Entry<KeyBind, Axis> entry : sec.binds.get(type).entries()) {
                    final String rname = "keybind-" + sec.name + "-" + type.name() + "-" + entry.key.name();
                    this.save(entry.value, rname);
                }
            }
            Core.settings.put(sec.name + "-last-device-type", Core.input.getDevices().indexOf(sec.device, true));
        }
    }
    
    void load() {
        if (this.definitions == null) {
            return;
        }
        for (final Section sec : this.sections) {
            for (final InputDevice.DeviceType type : InputDevice.DeviceType.values()) {
                for (final KeyBind def : this.definitions) {
                    final String rname = "keybind-" + sec.name + "-" + type.name() + "-" + def.name();
                    final Axis loaded = this.load(rname);
                    if (loaded != null) {
                        sec.binds.get(type, OrderedMap::new).put(def, loaded);
                    }
                }
            }
            sec.device = Core.input.getDevices().get(Mathf.clamp(Core.settings.getInt(sec.name + "-last-device-type", 0), 0, Core.input.getDevices().size - 1));
        }
    }
    
    public void resetToDefaults() {
        for (final Section sec : this.sections) {
            for (final InputDevice.DeviceType type : sec.binds.keys()) {
                for (final KeyBind def : this.definitions) {
                    final String rname = "keybind-" + sec.name + "-" + type.name() + "-" + def.name();
                    Core.settings.remove(rname + "-single");
                    Core.settings.remove(rname + "-key");
                    Core.settings.remove(rname + "-min");
                    Core.settings.remove(rname + "-max");
                }
            }
        }
        for (final Section sec : this.sections) {
            sec.binds.clear();
        }
    }
    
    public void resetToDefault(final Section section, final KeyBind bind) {
        final String rname = "keybind-" + section.name + "-" + section.device.type().name() + "-" + bind.name();
        Core.settings.remove(rname + "-single");
        Core.settings.remove(rname + "-key");
        Core.settings.remove(rname + "-min");
        Core.settings.remove(rname + "-max");
        final Axis axis;
        section.binds.each((device, bindings) -> axis = bindings.remove(bind));
    }
    
    private void save(final Axis axis, final String name) {
        Core.settings.put(name + "-single", axis.key != null);
        if (axis.key != null) {
            Core.settings.put(name + "-key", axis.key.ordinal());
        }
        else {
            Core.settings.put(name + "-min", axis.min.ordinal());
            Core.settings.put(name + "-max", axis.max.ordinal());
        }
    }
    
    private Axis load(final String name) {
        if (Core.settings.getBool(name + "-single", true)) {
            final KeyCode key = KeyCode.byOrdinal(Core.settings.getInt(name + "-key", KeyCode.unset.ordinal()));
            return (key == KeyCode.unset) ? null : new Axis(key);
        }
        final KeyCode min = KeyCode.byOrdinal(Core.settings.getInt(name + "-min", KeyCode.unset.ordinal()));
        final KeyCode max = KeyCode.byOrdinal(Core.settings.getInt(name + "-max", KeyCode.unset.ordinal()));
        return (min == KeyCode.unset || max == KeyCode.unset) ? null : new Axis(min, max);
    }
    
    public Section[] getSections() {
        return this.sections;
    }
    
    public KeyBind[] getKeybinds() {
        return this.definitions;
    }
    
    public Axis get(final KeyBind name) {
        return this.get(this.defaultSection, name);
    }
    
    public Axis get(final Section section, final KeyBind def) {
        if (this.definitions == null) {
            throw new IllegalArgumentException("No keybinds defined! Did you forget to call setDefaults(...)?");
        }
        return this.get(section, section.device.type(), def);
    }
    
    public Axis get(final Section section, final InputDevice.DeviceType type, final KeyBind def) {
        if (section.binds.containsKey(type) && section.binds.get(type).containsKey(def)) {
            return section.binds.get(type).get(def);
        }
        return this.defaultCache.get(def).get(type);
    }
    
    public interface KeyBind
    {
        String name();
        
        KeybindValue defaultValue(final InputDevice.DeviceType p0);
        
        default String category() {
            return null;
        }
    }
    
    public static class Section
    {
        public final String name;
        public ObjectMap<InputDevice.DeviceType, OrderedMap<KeyBind, Axis>> binds;
        public InputDevice device;
        
        Section(final String name) {
            this.binds = new ObjectMap<InputDevice.DeviceType, OrderedMap<KeyBind, Axis>>();
            this.device = Core.input.getKeyboard();
            this.name = name;
        }
    }
    
    public static class Axis implements KeybindValue
    {
        public KeyCode min;
        public KeyCode max;
        public KeyCode key;
        
        public Axis(final KeyCode key) {
            this.key = key;
            final KeyCode keyCode = null;
            this.max = keyCode;
            this.min = keyCode;
        }
        
        public Axis(final KeyCode min, final KeyCode max) {
            this.min = min;
            this.max = max;
            this.key = null;
        }
        
        @Override
        public String toString() {
            return "Axis{min=" + this.min + ", max=" + this.max + ", key=" + this.key + '}';
        }
    }
    
    public interface KeybindValue
    {
    }
}
