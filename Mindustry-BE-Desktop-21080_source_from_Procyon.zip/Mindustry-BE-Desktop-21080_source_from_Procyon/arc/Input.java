// 
// Decompiled by Procyon v0.5.36
// 

package arc;

import arc.func.Cons;
import arc.math.geom.Vec3;
import arc.util.OS;
import arc.input.KeyCode;
import arc.input.InputProcessor;
import arc.math.geom.Vec2;
import arc.struct.IntSet;
import arc.input.InputMultiplexer;
import arc.input.InputDevice;
import arc.struct.Seq;
import arc.input.KeyboardDevice;

public abstract class Input
{
    protected static final float deadzone = 0.3f;
    protected KeyboardDevice keyboard;
    protected Seq<InputDevice> devices;
    protected InputMultiplexer inputMultiplexer;
    protected IntSet caughtKeys;
    protected Vec2 mouseReturn;
    
    public Input() {
        this.keyboard = new KeyboardDevice();
        this.devices = Seq.with(this.keyboard);
        this.inputMultiplexer = new InputMultiplexer(new InputProcessor[] { this.keyboard });
        this.caughtKeys = new IntSet();
        this.mouseReturn = new Vec2();
    }
    
    public Vec2 mouseWorld(final float x, final float y) {
        return Core.camera.unproject(this.mouseReturn.set(x, y));
    }
    
    public Vec2 mouseScreen(final float x, final float y) {
        return Core.camera.project(this.mouseReturn.set(x, y));
    }
    
    public float mouseWorldX() {
        return Core.camera.unproject(this.mouse()).x;
    }
    
    public float mouseWorldY() {
        return Core.camera.unproject(this.mouse()).y;
    }
    
    public Vec2 mouseWorld() {
        return Core.camera.unproject(this.mouse());
    }
    
    public Vec2 mouse() {
        return this.mouseReturn.set((float)this.mouseX(), (float)this.mouseY());
    }
    
    public abstract int mouseX();
    
    public abstract int mouseX(final int p0);
    
    public abstract int deltaX();
    
    public abstract int deltaX(final int p0);
    
    public abstract int mouseY();
    
    public abstract int mouseY(final int p0);
    
    public abstract int deltaY();
    
    public abstract int deltaY(final int p0);
    
    public abstract boolean isTouched();
    
    public abstract boolean justTouched();
    
    public int getTouches() {
        int sum = 0;
        for (int i = 0; i < 10; ++i) {
            if (this.isTouched(i)) {
                ++sum;
            }
        }
        return sum;
    }
    
    public abstract boolean isTouched(final int p0);
    
    public float getPressure() {
        return this.getPressure(0);
    }
    
    public float getPressure(final int pointer) {
        return this.isTouched(pointer) ? 1.0f : 0.0f;
    }
    
    public boolean shift() {
        return this.keyDown(KeyCode.shiftLeft) || this.keyDown(KeyCode.shiftRight);
    }
    
    public boolean ctrl() {
        return OS.isMac ? this.keyDown(KeyCode.sym) : (this.keyDown(KeyCode.controlLeft) || this.keyDown(KeyCode.controlRight));
    }
    
    public boolean alt() {
        return this.keyDown(KeyCode.altLeft) || this.keyDown(KeyCode.altRight);
    }
    
    public boolean keyDown(final KeyCode key) {
        return this.keyboard.isPressed(key);
    }
    
    public boolean keyTap(final KeyCode key) {
        return this.keyboard.isTapped(key);
    }
    
    public boolean keyRelease(final KeyCode key) {
        return this.keyboard.isReleased(key);
    }
    
    public float axis(final KeyCode key) {
        return this.keyboard.getAxis(key);
    }
    
    public boolean keyDown(final KeyBinds.KeyBind key) {
        return Core.keybinds.get(key).key != null && this.keyboard.isPressed(Core.keybinds.get(key).key);
    }
    
    public boolean keyTap(final KeyBinds.KeyBind key) {
        return Core.keybinds.get(key).key != null && this.keyboard.isTapped(Core.keybinds.get(key).key);
    }
    
    public boolean keyRelease(final KeyBinds.KeyBind key) {
        return Core.keybinds.get(key).key != null && this.keyboard.isReleased(Core.keybinds.get(key).key);
    }
    
    public float axis(final KeyBinds.KeyBind key) {
        final KeyBinds.Axis axis = Core.keybinds.get(key);
        if (axis.key != null) {
            return this.keyboard.getAxis(axis.key);
        }
        return (this.keyboard.isPressed(axis.min) && this.keyboard.isPressed(axis.max)) ? 0.0f : (this.keyboard.isPressed(axis.min) ? -1.0f : (this.keyboard.isPressed(axis.max) ? 1.0f : 0.0f));
    }
    
    public float axisTap(final KeyBinds.KeyBind key) {
        final KeyBinds.Axis axis = Core.keybinds.get(key);
        if (axis.key != null) {
            return this.keyboard.getAxis(axis.key);
        }
        return this.keyboard.isTapped(axis.min) ? -1.0f : (this.keyboard.isTapped(axis.max) ? 1.0f : 0.0f);
    }
    
    public void getTextInput(final TextInput input) {
    }
    
    public void setOnscreenKeyboardVisible(final boolean visible) {
    }
    
    public void vibrate(final int milliseconds) {
    }
    
    public void vibrate(final long[] pattern, final int repeat) {
    }
    
    public void cancelVibrate() {
    }
    
    public Vec3 getAccelerometer() {
        return Vec3.Zero;
    }
    
    public Vec3 getGyroscope() {
        return Vec3.Zero;
    }
    
    public Vec3 getOrientation() {
        return Vec3.Zero;
    }
    
    public void getRotationMatrix(final float[] matrix) {
    }
    
    public abstract long getCurrentEventTime();
    
    public void setCatch(final KeyCode code, final boolean c) {
        if (c) {
            this.caughtKeys.add(code.ordinal());
        }
        else {
            this.caughtKeys.remove(code.ordinal());
        }
    }
    
    public boolean isCatch(final KeyCode code) {
        return this.caughtKeys.contains(code.ordinal());
    }
    
    public void addProcessor(final InputProcessor processor) {
        this.inputMultiplexer.addProcessor(processor);
    }
    
    public void removeProcessor(final InputProcessor processor) {
        this.inputMultiplexer.removeProcessor(processor);
    }
    
    public Seq<InputProcessor> getInputProcessors() {
        return this.inputMultiplexer.getProcessors();
    }
    
    public InputMultiplexer getInputMultiplexer() {
        return this.inputMultiplexer;
    }
    
    public Seq<InputDevice> getDevices() {
        return this.devices;
    }
    
    public KeyboardDevice getKeyboard() {
        return this.keyboard;
    }
    
    public boolean isPeripheralAvailable(final Peripheral peripheral) {
        return peripheral == Peripheral.hardwareKeyboard;
    }
    
    public int getRotation() {
        return 0;
    }
    
    public Orientation getNativeOrientation() {
        return Orientation.landscape;
    }
    
    public boolean isCursorCatched() {
        return false;
    }
    
    public void setCursorCatched(final boolean catched) {
    }
    
    public void setCursorPosition(final int x, final int y) {
    }
    
    public enum Orientation
    {
        landscape, 
        portrait;
    }
    
    public enum Peripheral
    {
        hardwareKeyboard, 
        onscreenKeyboard, 
        multitouchScreen, 
        accelerometer, 
        compass, 
        vibrator, 
        gyroscope, 
        rotationVector, 
        pressure;
    }
    
    public static class TextInput
    {
        public boolean multiline;
        public String title;
        public String text;
        public boolean numeric;
        public Cons<String> accepted;
        public Runnable canceled;
        public int maxLength;
        
        public TextInput() {
            this.multiline = false;
            this.title = "";
            this.text = "";
            this.accepted = (s -> {});
            this.canceled = (() -> {});
            this.maxLength = -1;
        }
    }
}
